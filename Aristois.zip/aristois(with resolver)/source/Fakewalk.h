#include <time.h>
#include <iostream>
#include "Vector.h"
#include "Interfaces.h"
#include "MathFunctions.h"
#include "Variables.h"
#include "MiscClasses.h"


class CFakewalk
{
public:
	int choked;
	void do_fakewalk(CUserCmd * cmd);

};

extern CFakewalk* slidebitch;