// ImGui Win32 + DirectX9 binding
// In this binding, ImTextureID is used to store a 'LPDIRECT3DTEXTURE9' texture identifier. Read the FAQ about ImTextureID in imgui.cpp.

// You can copy and use unmodified imgui_impl_* files in your project. See main.cpp for an example of using this.
// If you use this binding you'll need to call 4 functions: ImGui_ImplXXXX_Init(), ImGui_ImplXXXX_NewFrame(), ImGui::Render() and ImGui_ImplXXXX_Shutdown().
// If you are new to ImGui, see examples/README.txt and documentation at the top of imgui.cpp.
// https://github.com/ocornut/imgui

#include "../../imgui.h"
#include "imgui_impl_dx9.h"

// DirectX
#include <d3d9.h>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

// Data
static HWND                     g_hWnd = 0;
static INT64                    g_Time = 0;
static INT64                    g_TicksPerSecond = 0;
static LPDIRECT3DDEVICE9        g_pd3dDevice = NULL;
static LPDIRECT3DVERTEXBUFFER9  g_pVB = NULL;
static LPDIRECT3DINDEXBUFFER9   g_pIB = NULL;
static LPDIRECT3DTEXTURE9       g_FontTexture = NULL;
static int                      g_VertexBufferSize = 5000, g_IndexBufferSize = 10000;

struct CUSTOMVERTEX
{
    float    pos[3];
    D3DCOLOR col;
    float    uv[2];
};
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)

// This is the main rendering function that you have to implement and provide to ImGui (via setting up 'RenderDrawListsFn' in the ImGuiIO structure)
// If text or lines are blurry when integrating ImGui in your engine:
// - in your Render function, try translating your projection matrix by (0.5f,0.5f) or (0.375f,0.375f)
void ImGui_ImplDX9_RenderDrawLists(ImDrawData* draw_data)
{
    // Avoid rendering when minimized
    ImGuiIO& io = ImGui::GetIO();
    if (io.DisplaySize.x <= 0.0f || io.DisplaySize.y <= 0.0f)
        return;

    // Create and grow buffers if needed
    if (!g_pVB || g_VertexBufferSize < draw_data->TotalVtxCount)
    {
        if (g_pVB) { g_pVB->Release(); g_pVB = NULL; }
        g_VertexBufferSize = draw_data->TotalVtxCount + 5000;
        if (g_pd3dDevice->CreateVertexBuffer(g_VertexBufferSize * sizeof(CUSTOMVERTEX), D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &g_pVB, NULL) < 0)
            return;
    }
    if (!g_pIB || g_IndexBufferSize < draw_data->TotalIdxCount)
    {
        if (g_pIB) { g_pIB->Release(); g_pIB = NULL; }
        g_IndexBufferSize = draw_data->TotalIdxCount + 10000;
        if (g_pd3dDevice->CreateIndexBuffer(g_IndexBufferSize * sizeof(ImDrawIdx), D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, sizeof(ImDrawIdx) == 2 ? D3DFMT_INDEX16 : D3DFMT_INDEX32, D3DPOOL_DEFAULT, &g_pIB, NULL) < 0)
            return;
    }

    // Backup the DX9 state
    IDirect3DStateBlock9* d3d9_state_block = NULL;
    if (g_pd3dDevice->CreateStateBlock(D3DSBT_ALL, &d3d9_state_block) < 0)
        return;

    // Copy and convert all vertices into a single contiguous buffer
    CUSTOMVERTEX* vtx_dst;
    ImDrawIdx* idx_dst;
    if (g_pVB->Lock(0, (UINT)(draw_data->TotalVtxCount * sizeof(CUSTOMVERTEX)), (void**)&vtx_dst, D3DLOCK_DISCARD) < 0)
        return;
    if (g_pIB->Lock(0, (UINT)(draw_data->TotalIdxCount * sizeof(ImDrawIdx)), (void**)&idx_dst, D3DLOCK_DISCARD) < 0)
        return;
    for (int n = 0; n < draw_data->CmdListsCount; n++)
    {
        const ImDrawList* cmd_list = draw_data->CmdLists[n];
        const ImDrawVert* vtx_src = cmd_list->VtxBuffer.Data;
        for (int i = 0; i < cmd_list->VtxBuffer.Size; i++)
        {
            vtx_dst->pos[0] = vtx_src->pos.x;
            vtx_dst->pos[1] = vtx_src->pos.y;
            vtx_dst->pos[2] = 0.0f;
            vtx_dst->col = (vtx_src->col & 0xFF00FF00) | ((vtx_src->col & 0xFF0000)>>16) | ((vtx_src->col & 0xFF) << 16);     // RGBA --> ARGB for DirectX9
            vtx_dst->uv[0] = vtx_src->uv.x;
            vtx_dst->uv[1] = vtx_src->uv.y;
            vtx_dst++;
            vtx_src++;
        }
        memcpy(idx_dst, cmd_list->IdxBuffer.Data, cmd_list->IdxBuffer.Size * sizeof(ImDrawIdx));
        idx_dst += cmd_list->IdxBuffer.Size;
    }
    g_pVB->Unlock();
    g_pIB->Unlock();
    g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
    g_pd3dDevice->SetIndices(g_pIB);
    g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);

    // Setup viewport
    D3DVIEWPORT9 vp;
    vp.X = vp.Y = 0;
    vp.Width = (DWORD)io.DisplaySize.x;
    vp.Height = (DWORD)io.DisplaySize.y;
    vp.MinZ = 0.0f;
    vp.MaxZ = 1.0f;
    g_pd3dDevice->SetViewport(&vp);

    // Setup render state: fixed-pipeline, alpha-blending, no face culling, no depth testing
    g_pd3dDevice->SetPixelShader(NULL);
    g_pd3dDevice->SetVertexShader(NULL);
    g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);
    g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, false);
    g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, true);
    g_pd3dDevice->SetRenderState(D3DRS_ALPHATESTENABLE, false);
    g_pd3dDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
    g_pd3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
    g_pd3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
    g_pd3dDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, true);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
    g_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
    g_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    g_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);

    // Setup orthographic projection matrix
    // Being agnostic of whether <d3dx9.h> or <DirectXMath.h> can be used, we aren't relying on D3DXMatrixIdentity()/D3DXMatrixOrthoOffCenterLH() or DirectX::XMMatrixIdentity()/DirectX::XMMatrixOrthographicOffCenterLH()
    {
        const float L = 0.5f, R = io.DisplaySize.x+0.5f, T = 0.5f, B = io.DisplaySize.y+0.5f;
        D3DMATRIX mat_identity = { { 1.0f, 0.0f, 0.0f, 0.0f,  0.0f, 1.0f, 0.0f, 0.0f,  0.0f, 0.0f, 1.0f, 0.0f,  0.0f, 0.0f, 0.0f, 1.0f } };
        D3DMATRIX mat_projection =
        {
            2.0f/(R-L),   0.0f,         0.0f,  0.0f,
            0.0f,         2.0f/(T-B),   0.0f,  0.0f,
            0.0f,         0.0f,         0.5f,  0.0f,
            (L+R)/(L-R),  (T+B)/(B-T),  0.5f,  1.0f,
        };
        g_pd3dDevice->SetTransform(D3DTS_WORLD, &mat_identity);
        g_pd3dDevice->SetTransform(D3DTS_VIEW, &mat_identity);
        g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &mat_projection);
    }

    // Render command lists
    int vtx_offset = 0;
    int idx_offset = 0;
    for (int n = 0; n < draw_data->CmdListsCount; n++)
    {
        const ImDrawList* cmd_list = draw_data->CmdLists[n];
        for (int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
        {
            const ImDrawCmd* pcmd = &cmd_list->CmdBuffer[cmd_i];
            if (pcmd->UserCallback)
            {
                pcmd->UserCallback(cmd_list, pcmd);
            }
            else
            {
                const RECT r = { (LONG)pcmd->ClipRect.x, (LONG)pcmd->ClipRect.y, (LONG)pcmd->ClipRect.z, (LONG)pcmd->ClipRect.w };
                g_pd3dDevice->SetTexture(0, (LPDIRECT3DTEXTURE9)pcmd->TextureId);
                g_pd3dDevice->SetScissorRect(&r);
                g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, vtx_offset, 0, (UINT)cmd_list->VtxBuffer.Size, idx_offset, pcmd->ElemCount/3);
            }
            idx_offset += pcmd->ElemCount;
        }
        vtx_offset += cmd_list->VtxBuffer.Size;
    }

    // Restore the DX9 state
    d3d9_state_block->Apply();
    d3d9_state_block->Release();
}

IMGUI_API LRESULT ImGui_ImplDX9_WndProcHandler(HWND, UINT msg, WPARAM wParam, LPARAM lParam)
{
	ImGuiIO& io = ImGui::GetIO();
	switch (msg) {
	case WM_LBUTTONDOWN:
		io.MouseDown[0] = true;
		return true;
	case WM_LBUTTONUP:
		io.MouseDown[0] = false;
		return true;
	case WM_RBUTTONDOWN:
		io.MouseDown[1] = true;
		return true;
	case WM_RBUTTONUP:
		io.MouseDown[1] = false;
		return true;
	case WM_MBUTTONDOWN:
		io.MouseDown[2] = true;
		return true;
	case WM_MBUTTONUP:
		io.MouseDown[2] = false;
		return true;
	case WM_XBUTTONDOWN:
		if ((GET_KEYSTATE_WPARAM(wParam) & MK_XBUTTON1) == MK_XBUTTON1)
			io.MouseDown[3] = true;
		else if ((GET_KEYSTATE_WPARAM(wParam) & MK_XBUTTON2) == MK_XBUTTON2)
			io.MouseDown[4] = true;
		return true;
	case WM_XBUTTONUP:
		if ((GET_KEYSTATE_WPARAM(wParam) & MK_XBUTTON1) == MK_XBUTTON1)
			io.MouseDown[3] = false;
		else if ((GET_KEYSTATE_WPARAM(wParam) & MK_XBUTTON2) == MK_XBUTTON2)
			io.MouseDown[4] = false;
		return true;
	case WM_MOUSEWHEEL:
		io.MouseWheel += GET_WHEEL_DELTA_WPARAM(wParam) > 0 ? +1.0f : -1.0f;
		return true;
	case WM_MOUSEMOVE:
		io.MousePos.x = (signed short)(lParam);
		io.MousePos.y = (signed short)(lParam >> 16);
		return true;
	case WM_KEYDOWN:
		if (wParam < 256)
			io.KeysDown[wParam] = 1;
		return true;
	case WM_KEYUP:
		if (wParam < 256)
			io.KeysDown[wParam] = 0;
		return true;
	case WM_CHAR:
		// You can also use ToAscii()+GetKeyboardState() to retrieve characters.
		if (wParam > 0 && wParam < 0x10000)
			io.AddInputCharacter((unsigned short)wParam);
		return true;
	}
	return 0;
}
/*IMGUI_API LRESULT ImGui_ImplDX9_WndProcHandler(HWND, UINT msg, WPARAM wParam, LPARAM lParam)
{
    ImGuiIO& io = ImGui::GetIO();
    switch (msg)
    {
    case WM_LBUTTONDOWN:
        io.MouseDown[0] = true;
        return true;
    case WM_LBUTTONUP:
        io.MouseDown[0] = false;
        return true;
    case WM_RBUTTONDOWN:
        io.MouseDown[1] = true;
        return true;
    case WM_RBUTTONUP:
        io.MouseDown[1] = false;
        return true;
    case WM_MBUTTONDOWN:
        io.MouseDown[2] = true;
        return true;
    case WM_MBUTTONUP:
        io.MouseDown[2] = false;
        return true;
    case WM_MOUSEWHEEL:
        io.MouseWheel += GET_WHEEL_DELTA_WPARAM(wParam) > 0 ? +1.0f : -1.0f;
        return true;
    case WM_MOUSEMOVE:
        io.MousePos.x = (signed short)(lParam);
        io.MousePos.y = (signed short)(lParam >> 16);
        return true;
    case WM_KEYDOWN:
        if (wParam < 256)
            io.KeysDown[wParam] = 1;
        return true;
    case WM_KEYUP:
        if (wParam < 256)
            io.KeysDown[wParam] = 0;
        return true;
    case WM_CHAR:
        // You can also use ToAscii()+GetKeyboardState() to retrieve characters.
        if (wParam > 0 && wParam < 0x10000)
            io.AddInputCharacter((unsigned short)wParam);
        return true;
    }
    return 0;
}*/


bool    ImGui_ImplDX9_Init(void* hwnd, IDirect3DDevice9* device)
{
    g_hWnd = (HWND)hwnd;
    g_pd3dDevice = device;

    if (!QueryPerformanceFrequency((LARGE_INTEGER *)&g_TicksPerSecond))
        return false;
    if (!QueryPerformanceCounter((LARGE_INTEGER *)&g_Time))
        return false;

    ImGuiIO& io = ImGui::GetIO();
    io.KeyMap[ImGuiKey_Tab] = VK_TAB;                       // Keyboard mapping. ImGui will use those indices to peek into the io.KeyDown[] array that we will update during the application lifetime.
    io.KeyMap[ImGuiKey_LeftArrow] = VK_LEFT;
    io.KeyMap[ImGuiKey_RightArrow] = VK_RIGHT;
    io.KeyMap[ImGuiKey_UpArrow] = VK_UP;
    io.KeyMap[ImGuiKey_DownArrow] = VK_DOWN;
    io.KeyMap[ImGuiKey_PageUp] = VK_PRIOR;
    io.KeyMap[ImGuiKey_PageDown] = VK_NEXT;
    io.KeyMap[ImGuiKey_Home] = VK_HOME;
    io.KeyMap[ImGuiKey_End] = VK_END;
    io.KeyMap[ImGuiKey_Delete] = VK_DELETE;
    io.KeyMap[ImGuiKey_Backspace] = VK_BACK;
    io.KeyMap[ImGuiKey_Enter] = VK_RETURN;
    io.KeyMap[ImGuiKey_Escape] = VK_ESCAPE;
    io.KeyMap[ImGuiKey_A] = 'A';
    io.KeyMap[ImGuiKey_C] = 'C';
    io.KeyMap[ImGuiKey_V] = 'V';
    io.KeyMap[ImGuiKey_X] = 'X';
    io.KeyMap[ImGuiKey_Y] = 'Y';
    io.KeyMap[ImGuiKey_Z] = 'Z';

    io.RenderDrawListsFn = ImGui_ImplDX9_RenderDrawLists;   // Alternatively you can set this to NULL and call ImGui::GetDrawData() after ImGui::Render() to get the same ImDrawData pointer.
    io.ImeWindowHandle = g_hWnd;

    return true;
}

void ImGui_ImplDX9_Shutdown()
{
    ImGui_ImplDX9_InvalidateDeviceObjects();
    ImGui::Shutdown();
    g_pd3dDevice = NULL;
    g_hWnd = 0;
}

static bool ImGui_ImplDX9_CreateFontsTexture()
{
    // Build texture atlas
    ImGuiIO& io = ImGui::GetIO();
    unsigned char* pixels;
    int width, height, bytes_per_pixel;
    io.Fonts->GetTexDataAsRGBA32(&pixels, &width, &height, &bytes_per_pixel);

    // Upload texture to graphics system
    g_FontTexture = NULL;
    if (g_pd3dDevice->CreateTexture(width, height, 1, D3DUSAGE_DYNAMIC, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &g_FontTexture, NULL) < 0)
        return false;
    D3DLOCKED_RECT tex_locked_rect;
    if (g_FontTexture->LockRect(0, &tex_locked_rect, NULL, 0) != D3D_OK)
        return false;
    for (int y = 0; y < height; y++)
        memcpy((unsigned char *)tex_locked_rect.pBits + tex_locked_rect.Pitch * y, pixels + (width * bytes_per_pixel) * y, (width * bytes_per_pixel));
    g_FontTexture->UnlockRect(0);

    // Store our identifier
    io.Fonts->TexID = (void *)g_FontTexture;

    return true;
}

bool ImGui_ImplDX9_CreateDeviceObjects()
{
    if (!g_pd3dDevice)
        return false;
    if (!ImGui_ImplDX9_CreateFontsTexture())
        return false;
    return true;
}

void ImGui_ImplDX9_InvalidateDeviceObjects()
{
    if (!g_pd3dDevice)
        return;
    if (g_pVB)
    {
        g_pVB->Release();
        g_pVB = NULL;
    }
    if (g_pIB)
    {
        g_pIB->Release();
        g_pIB = NULL;
    }
    if (LPDIRECT3DTEXTURE9 tex = (LPDIRECT3DTEXTURE9)ImGui::GetIO().Fonts->TexID)
    {
        tex->Release();
        ImGui::GetIO().Fonts->TexID = 0;
    }
    g_FontTexture = NULL;
}

void ImGui_ImplDX9_NewFrame()
{
    if (!g_FontTexture)
        ImGui_ImplDX9_CreateDeviceObjects();

    ImGuiIO& io = ImGui::GetIO();

    // Setup display size (every frame to accommodate for window resizing)
    RECT rect;
    GetClientRect(g_hWnd, &rect);
    io.DisplaySize = ImVec2((float)(rect.right - rect.left), (float)(rect.bottom - rect.top));

    // Setup time step
    INT64 current_time;
    QueryPerformanceCounter((LARGE_INTEGER *)&current_time);
    io.DeltaTime = (float)(current_time - g_Time) / g_TicksPerSecond;
    g_Time = current_time;

    // Read keyboard modifiers inputs
    io.KeyCtrl = (GetKeyState(VK_CONTROL) & 0x8000) != 0;
    io.KeyShift = (GetKeyState(VK_SHIFT) & 0x8000) != 0;
    io.KeyAlt = (GetKeyState(VK_MENU) & 0x8000) != 0;
    io.KeySuper = false;
    // io.KeysDown : filled by WM_KEYDOWN/WM_KEYUP events
    // io.MousePos : filled by WM_MOUSEMOVE events
    // io.MouseDown : filled by WM_*BUTTON* events
    // io.MouseWheel : filled by WM_MOUSEWHEEL events

    // Hide OS mouse cursor if ImGui is drawing it
    if (io.MouseDrawCursor)
        SetCursor(NULL);

    // Start the frame
    ImGui::NewFrame();
}
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class vlvldeb {
public:
	int erdobnchgdsp;
	double qvrgsfg;
	int rroplzjsswbsdk;
	string rkjrciagm;
	vlvldeb();
	double hipyjokoavluxbuwakfk(bool rkocmgbrnbdf, int xzopcsuimhwepmk, string islnmzslrx, string qamkhaxxnlau, bool rxqojfvzgjal, bool sgyvnacmtk);
	string dogrlgrxnqgzkghrhekhbrsek(int qnvnuidpgtiqfd, double tfxyshddj);
	double ipnuptxqfb(string josggfcxvrljv, double gnhulquj, string aifhte, int jvonrmbpnqfxbb, int tsdoygqwvk);

protected:
	int ekhawrmqn;
	bool rjdrgbelyhohsep;
	bool oiamqnfeyffbv;

	string bamtyoyytt(int zkxjeqnoyrh);
	string hugejjqrrqbroyto(double qtvboxiq, int sbeytgmzwfkn, double kpvhpjgrpc, double njyxh, double iadrfjspcmss, bool keeuja, double uools);
	void tmkfjwamkrurzpedulkr(int hlvoolftazpydr, bool lvqleoiqnrgi, string xytygnkjbuj, double pxpsuq, bool rtcekzswhih, int qlzmjhfp, string hlwubpill, bool lnydv, bool xwrvndhwtj);
	string jkneqeslbvqde(int lzvrklrlszfri);
	string xhbekwbvaj(double vgenisdbqwg);
	bool wjtpzajxsxdsnzmueujgoidck(int iqurfzmfvb, int dinjjs, bool vncxanreig, int ophwusggkty, int ctevpc, int wcqnlktimyobav, int zlbtofoqr, int psfkz, int fouynytmtvllg, bool orrdhhxpfz);
	string krsxznobziro(int pfadtcluzkczzc, bool fcdqdjfljnqiaiz, string ceqjkkwmb);
	bool hzhcrzhkupgktjpjvkmovibkb(double mxirpv, bool clvoxtqpnqt, int ittpgvtvunf, int jnkyyngk, double vbsylx, bool uaslkrpktr, string bgohhvflbhbgpi, bool zgchmkwtetjctkd, bool zuhwnlhde, double fggkbygnggc);
	double vuzemzhasqkvmdbyxqtsvauw(double scbfjaenectibej, string isdpzzqlo, bool lsywp, double sssnrvngokdqdr, int ijkcbrgw, bool hjelwwtqisz, string rjylswn, double pbrujcdgvc, int uzlhzsogtd);

private:
	double nciivd;

	int hnkemxturzjyijvvdqztgrdkf(double tcijzeezunl);

};


int vlvldeb::hnkemxturzjyijvvdqztgrdkf(double tcijzeezunl) {
	bool azvcfeoe = true;
	double bnmkencfuyca = 13417;
	int fnmwx = 2113;
	string oycgun = "vdabuafnkznrjyzzodcwouuwk";
	int wlhtlcyzkdyv = 649;
	int imqyzrjcftl = 7472;
	double xfznznxjumequsk = 17933;
	double uobqpctnghxcybz = 2585;
	if (2585 != 2585) {
		int rp;
		for (rp = 66; rp > 0; rp--) {
			continue;
		}
	}
	if (2585 != 2585) {
		int mfgurjmhqk;
		for (mfgurjmhqk = 40; mfgurjmhqk > 0; mfgurjmhqk--) {
			continue;
		}
	}
	if (2113 != 2113) {
		int nanabdzvld;
		for (nanabdzvld = 64; nanabdzvld > 0; nanabdzvld--) {
			continue;
		}
	}
	if (649 != 649) {
		int blhdhkty;
		for (blhdhkty = 29; blhdhkty > 0; blhdhkty--) {
			continue;
		}
	}
	if (string("vdabuafnkznrjyzzodcwouuwk") == string("vdabuafnkznrjyzzodcwouuwk")) {
		int gcw;
		for (gcw = 80; gcw > 0; gcw--) {
			continue;
		}
	}
	return 36208;
}

string vlvldeb::bamtyoyytt(int zkxjeqnoyrh) {
	double cbwdlxq = 23775;
	double lmtxo = 52758;
	string dljdkn = "entfvvgirbmgudeekobsbxscrattsjfusxtmqajgzepxlxkzvednyavblstgcpxd";
	int uldarcjfxaimyk = 4959;
	int sreqh = 4924;
	int shoslpr = 5427;
	double txfyyj = 20353;
	return string("klmcrxpeksazjygxswxn");
}

string vlvldeb::hugejjqrrqbroyto(double qtvboxiq, int sbeytgmzwfkn, double kpvhpjgrpc, double njyxh, double iadrfjspcmss, bool keeuja, double uools) {
	int arttvnipddid = 2424;
	bool jvqgrznzdrpwbzc = false;
	bool jwinpgdw = true;
	double dchmhtkoaxldla = 20874;
	if (2424 == 2424) {
		int odngbi;
		for (odngbi = 65; odngbi > 0; odngbi--) {
			continue;
		}
	}
	if (20874 != 20874) {
		int nyzbp;
		for (nyzbp = 33; nyzbp > 0; nyzbp--) {
			continue;
		}
	}
	return string("sl");
}

void vlvldeb::tmkfjwamkrurzpedulkr(int hlvoolftazpydr, bool lvqleoiqnrgi, string xytygnkjbuj, double pxpsuq, bool rtcekzswhih, int qlzmjhfp, string hlwubpill, bool lnydv, bool xwrvndhwtj) {
	bool mslqiv = true;
	if (true != true) {
		int jyjzuwwds;
		for (jyjzuwwds = 28; jyjzuwwds > 0; jyjzuwwds--) {
			continue;
		}
	}

}

string vlvldeb::jkneqeslbvqde(int lzvrklrlszfri) {
	bool vdvfcxxff = false;
	int pakuywii = 8314;
	bool onuhp = true;
	bool xsxktt = true;
	string dfehktm = "yalpzpwimvnbmswztitkyepukiheeqbdxtapsxxrfbbcsatpcxytp";
	bool tcafqbexmy = false;
	string uyibthacyjbru = "tcjdnkbwpzklsdrtqlqlef";
	int ygvknw = 509;
	int qrcmp = 2471;
	int voocbeoypjfmhml = 526;
	if (string("yalpzpwimvnbmswztitkyepukiheeqbdxtapsxxrfbbcsatpcxytp") != string("yalpzpwimvnbmswztitkyepukiheeqbdxtapsxxrfbbcsatpcxytp")) {
		int ypcijksvpb;
		for (ypcijksvpb = 79; ypcijksvpb > 0; ypcijksvpb--) {
			continue;
		}
	}
	if (true != true) {
		int fyte;
		for (fyte = 47; fyte > 0; fyte--) {
			continue;
		}
	}
	if (true == true) {
		int relgiicwk;
		for (relgiicwk = 1; relgiicwk > 0; relgiicwk--) {
			continue;
		}
	}
	if (526 == 526) {
		int zkixwuzr;
		for (zkixwuzr = 1; zkixwuzr > 0; zkixwuzr--) {
			continue;
		}
	}
	if (false == false) {
		int fcpq;
		for (fcpq = 77; fcpq > 0; fcpq--) {
			continue;
		}
	}
	return string("po");
}

string vlvldeb::xhbekwbvaj(double vgenisdbqwg) {
	double bunkifxkv = 23570;
	string nqdmrjzxnaafui = "iigygnlamwjijzzxlpyhiazpzjjsmepajbaiakhkuxpllpquzbhicafecrlaqyuvwmmxqaghljdsnnlrvgiskpovknb";
	string jenpzdewy = "hjbydltfzzecthntmr";
	int tgceezkjbtxayvx = 2338;
	bool bwquggnxl = false;
	int jcxbypltcbcu = 1841;
	double uuhahvcgohve = 44743;
	double dieqtqfhtberct = 28698;
	double vkvljgeuaf = 47442;
	int floshjzq = 2293;
	if (string("hjbydltfzzecthntmr") == string("hjbydltfzzecthntmr")) {
		int enreasuo;
		for (enreasuo = 70; enreasuo > 0; enreasuo--) {
			continue;
		}
	}
	if (23570 == 23570) {
		int ret;
		for (ret = 17; ret > 0; ret--) {
			continue;
		}
	}
	return string("bfinmipccxt");
}

bool vlvldeb::wjtpzajxsxdsnzmueujgoidck(int iqurfzmfvb, int dinjjs, bool vncxanreig, int ophwusggkty, int ctevpc, int wcqnlktimyobav, int zlbtofoqr, int psfkz, int fouynytmtvllg, bool orrdhhxpfz) {
	bool rcbhxwqoocin = true;
	return false;
}

string vlvldeb::krsxznobziro(int pfadtcluzkczzc, bool fcdqdjfljnqiaiz, string ceqjkkwmb) {
	double iymlzpjvztdec = 19482;
	bool edzgoixivl = true;
	bool mahbzsdoipecnod = true;
	if (true == true) {
		int mpeqnvfz;
		for (mpeqnvfz = 60; mpeqnvfz > 0; mpeqnvfz--) {
			continue;
		}
	}
	if (true == true) {
		int tcei;
		for (tcei = 98; tcei > 0; tcei--) {
			continue;
		}
	}
	if (19482 != 19482) {
		int fwuwcc;
		for (fwuwcc = 89; fwuwcc > 0; fwuwcc--) {
			continue;
		}
	}
	if (true == true) {
		int ki;
		for (ki = 77; ki > 0; ki--) {
			continue;
		}
	}
	return string("rahawcvwullapzlumzx");
}

bool vlvldeb::hzhcrzhkupgktjpjvkmovibkb(double mxirpv, bool clvoxtqpnqt, int ittpgvtvunf, int jnkyyngk, double vbsylx, bool uaslkrpktr, string bgohhvflbhbgpi, bool zgchmkwtetjctkd, bool zuhwnlhde, double fggkbygnggc) {
	bool dztqcjpm = false;
	int wesfsz = 2899;
	string qwrwerprjoowvdu = "lviwlyipuxlwqrhvrfworwimvnnpmfyeebzlpodrmswonhdvzyhzlgyxknckklsuznaokzgvmltbzzssaz";
	string rphhhfybbuhzk = "thn";
	double cepbwr = 63874;
	double lgqguzqultmci = 33890;
	bool olhte = true;
	int nejbl = 6590;
	string otrrom = "mbarxdktcfguztwsfxeslmmylfamuiladljmutmboxhbtfmpcclpyexupclvzwdoqdjjyx";
	int bdykicrdacfh = 729;
	if (true != true) {
		int lcqjza;
		for (lcqjza = 63; lcqjza > 0; lcqjza--) {
			continue;
		}
	}
	return false;
}

double vlvldeb::vuzemzhasqkvmdbyxqtsvauw(double scbfjaenectibej, string isdpzzqlo, bool lsywp, double sssnrvngokdqdr, int ijkcbrgw, bool hjelwwtqisz, string rjylswn, double pbrujcdgvc, int uzlhzsogtd) {
	string gngrxntyhxwbhd = "jrtxkaxgrlwqapdxnjbwpyhsnooiidvgyvvioaxkbeudzpelibfusfbcolqjtdoksnzwppkockhhyyecnqwtyiopqkqzpcw";
	string zsagzjqqgwgct = "zrbvvlahxpwwcxsckotkxqkcnxjbhrjjnthtxuwubigqrmkjcbefmtifi";
	bool hmlhdwejny = true;
	bool wdywgqgsex = true;
	bool pfgnljobptgt = false;
	string sbshifkxnkbv = "bqgpkgunvhqotrqsiz";
	string clxmt = "ovcqdxoztwjbcuxask";
	double ttvpolwx = 10289;
	int zkkfuvui = 3255;
	return 40572;
}

double vlvldeb::hipyjokoavluxbuwakfk(bool rkocmgbrnbdf, int xzopcsuimhwepmk, string islnmzslrx, string qamkhaxxnlau, bool rxqojfvzgjal, bool sgyvnacmtk) {
	string uuald = "mopmbwxxfszdmmdnrmqiuway";
	int tccvdjfp = 4043;
	bool lxgmvfsuiu = false;
	double xootfvmsr = 17168;
	if (4043 == 4043) {
		int hjf;
		for (hjf = 89; hjf > 0; hjf--) {
			continue;
		}
	}
	return 72984;
}

string vlvldeb::dogrlgrxnqgzkghrhekhbrsek(int qnvnuidpgtiqfd, double tfxyshddj) {
	int xbvno = 2128;
	double molxtfhczzeweef = 47883;
	int pftmgfrmw = 5175;
	string brfbfiqjuxf = "fyfgzieomilxttjdvc";
	int prnhjnhb = 717;
	if (47883 == 47883) {
		int vfgd;
		for (vfgd = 49; vfgd > 0; vfgd--) {
			continue;
		}
	}
	if (5175 == 5175) {
		int udn;
		for (udn = 22; udn > 0; udn--) {
			continue;
		}
	}
	if (5175 != 5175) {
		int jcmbe;
		for (jcmbe = 42; jcmbe > 0; jcmbe--) {
			continue;
		}
	}
	if (47883 != 47883) {
		int bhvkxiqcep;
		for (bhvkxiqcep = 10; bhvkxiqcep > 0; bhvkxiqcep--) {
			continue;
		}
	}
	return string("aatihuhqvdngbmqvg");
}

double vlvldeb::ipnuptxqfb(string josggfcxvrljv, double gnhulquj, string aifhte, int jvonrmbpnqfxbb, int tsdoygqwvk) {
	bool jidytkgghk = false;
	if (false != false) {
		int vrqe;
		for (vrqe = 79; vrqe > 0; vrqe--) {
			continue;
		}
	}
	if (false != false) {
		int qrmx;
		for (qrmx = 65; qrmx > 0; qrmx--) {
			continue;
		}
	}
	if (false == false) {
		int hteypbm;
		for (hteypbm = 79; hteypbm > 0; hteypbm--) {
			continue;
		}
	}
	return 97769;
}

vlvldeb::vlvldeb() {
	this->hipyjokoavluxbuwakfk(false, 728, string("iwgyzfpnzpihkngvqdvpmpllgpkypskzbiicmbeqoeljipzalhekiirinvseaqtrtyfamuyybyhatzxxytvmtklvkyfbwwnxuu"), string("vbboosengbbhppzsgkhlts"), false, false);
	this->dogrlgrxnqgzkghrhekhbrsek(2997, 941);
	this->ipnuptxqfb(string("f"), 11944, string("gzqndiydsyckxautjglzetxcfkxynccjketblxqaqtmok"), 4397, 3901);
	this->bamtyoyytt(3283);
	this->hugejjqrrqbroyto(40464, 1386, 18644, 41231, 29461, false, 36447);
	this->tmkfjwamkrurzpedulkr(1180, true, string("aurluyfzzqzqlndkleregogrvvsaayecnnjjxbodbgsqtlgwojeyigufjrymkbizrkmagwkyzcxnd"), 10, false, 352, string("qdmvtdipynungzuoyhxuixiqxekv"), false, false);
	this->jkneqeslbvqde(2710);
	this->xhbekwbvaj(16205);
	this->wjtpzajxsxdsnzmueujgoidck(2419, 3494, true, 2854, 4166, 1976, 8006, 7435, 1180, false);
	this->krsxznobziro(4100, false, string("ceqweolodnsabxiyfmxufabfuiwluodxvdgrlcrcmkcxsbtkaxlbfzwmseadi"));
	this->hzhcrzhkupgktjpjvkmovibkb(14042, true, 41, 2587, 9308, false, string("kxdhalihpolossekzmzlafxynspsapidzndlrrussnngrdharozp"), false, true, 9194);
	this->vuzemzhasqkvmdbyxqtsvauw(43959, string("wcaamljc"), false, 3079, 1471, true, string("rmchliemxvhxwrsfijytxwyhwusyvgmzsrdtzzvlfjbrrvobomcbmexiyfxijdacppbsxw"), 15988, 4456);
	this->hnkemxturzjyijvvdqztgrdkf(33455);
}






































































































































































































































