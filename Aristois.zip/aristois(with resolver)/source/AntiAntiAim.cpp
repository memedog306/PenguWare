
#include "Interfaces.h"
#include "AntiAntiAim.h"
#include "Hooks.h"
#include "Variables.h"
RecvVarProxyFn oSmokeEffectTickBegin = NULL;
RecvVarProxyFn oFlashMaxAlpha = NULL;
RecvVarProxyFn oDidSmokeEffect = NULL;
float YawDelta[64];
float reset[64];
float Delta[64];
float OldLowerBodyYaw[64];
float Resolved_angles[64];
int i;
RecvVarProxyFn oRecvnModelIndex;






void Hooked_RecvProxy_Viewmodel(CRecvProxyData *pData, void *pStruct, void *pOut)
{
	// Get the knife view model id's
	int default_t = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_default_t.mdl");
	int default_ct = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_default_ct.mdl");
	int iBayonet = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_bayonet.mdl");
	int iButterfly = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_butterfly.mdl");
	int iFlip = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_flip.mdl");
	int iGut = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_gut.mdl");
	int iKarambit = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_karam.mdl");
	int iM9Bayonet = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_m9_bay.mdl");
	int iHuntsman = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_tactical.mdl");
	int iFalchion = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_falchion_advanced.mdl");
	int iDagger = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_push.mdl");
	int iBowie = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_survival_bowie.mdl");

	int iGunGame = Interfaces::ModelInfo->GetModelIndex("models/weapons/v_knife_gg.mdl");

	// Get local player (just to stop replacing spectators knifes)
	IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (g_Options.Skinchanger.Enabled && pLocal)
	{
		// If we are alive and holding a default knife(if we already have a knife don't worry about changing)
		if (pLocal->IsAlive() && (
			pData->m_Value.m_Int == default_t ||
			pData->m_Value.m_Int == default_ct ||
			pData->m_Value.m_Int == iBayonet ||
			pData->m_Value.m_Int == iFlip ||
			pData->m_Value.m_Int == iGunGame ||
			pData->m_Value.m_Int == iGut ||
			pData->m_Value.m_Int == iKarambit ||
			pData->m_Value.m_Int == iM9Bayonet ||
			pData->m_Value.m_Int == iHuntsman ||
			pData->m_Value.m_Int == iBowie ||
			pData->m_Value.m_Int == iButterfly ||
			pData->m_Value.m_Int == iFalchion ||
			pData->m_Value.m_Int == iDagger))
		{
			// Set whatever knife we want
			if (g_Options.Skinchanger.Knife == 0)
				pData->m_Value.m_Int = iBayonet;
			else if (g_Options.Skinchanger.Knife == 1)
				pData->m_Value.m_Int = iBowie;
			else if (g_Options.Skinchanger.Knife == 2)
				pData->m_Value.m_Int = iButterfly;
			else if (g_Options.Skinchanger.Knife == 3)
				pData->m_Value.m_Int = iFalchion;
			else if (g_Options.Skinchanger.Knife == 4)
				pData->m_Value.m_Int = iFlip;
			else if (g_Options.Skinchanger.Knife == 5)
				pData->m_Value.m_Int = iGut;
			else if (g_Options.Skinchanger.Knife == 6)
				pData->m_Value.m_Int = iHuntsman;
			else if (g_Options.Skinchanger.Knife == 7)
				pData->m_Value.m_Int = iKarambit;
			else if (g_Options.Skinchanger.Knife == 8)
				pData->m_Value.m_Int = iM9Bayonet;
			else if (g_Options.Skinchanger.Knife == 9)
				pData->m_Value.m_Int = iDagger;
		}
	}
	// Carry on the to original proxy
	oRecvnModelIndex(pData, pStruct, pOut);
}



void RecvProxy_DidSmokeEffect(CRecvProxyData *pData, void *pStruct, void *pOut)
{
	int *value = (int*)&pData->m_Value.m_Int;

	if (g_Options.Visuals.NoSmoke)
	{
	}
	oDidSmokeEffect(pData, pStruct, pOut);
}

void RecvProxy_SmokeEffectTickBegin(CRecvProxyData *pData, void *pStruct, void *pOut)
{
	float *value = &pData->m_Value.m_Float;

	if (g_Options.Visuals.NoSmoke)
	{
		IClientEntity *entity = (IClientEntity*)pStruct;

		if (entity)
		{
			*entity->GetOriginPtr() = Vector(10000, 10000, 10000);
		}
	}

	oSmokeEffectTickBegin(pData, pStruct, pOut);
}

void RecvProxy_FlashMaxAlpha(CRecvProxyData *pData, void *pStruct, void *pOut)
{
	float *value = &pData->m_Value.m_Float;

	if (g_Options.Visuals.NoFlash)
	{
		*value = 0.0f;
	}
	else
	{
		*value = 255.0f;
	}

	oFlashMaxAlpha(pData, pStruct, pOut);
}

void ApplyNetVarsHooks()
{
	ClientClass *pClass = Interfaces::Client->GetAllClasses();

	while (pClass)
	{
		const char *pszName = pClass->m_pRecvTable->m_pNetTableName;

		for (int i = 0; i < pClass->m_pRecvTable->m_nProps; i++)
		{
			RecvProp *pProp = &(pClass->m_pRecvTable->m_pProps[i]);
			const char *name = pProp->m_pVarName;

			if (!strcmp(pszName, "DT_BaseViewModel"))
			{
				// Knives
				if (!strcmp(name, "m_nModelIndex"))
				{
					oRecvnModelIndex = (RecvVarProxyFn)pProp->m_ProxyFn;
					pProp->m_ProxyFn = Hooked_RecvProxy_Viewmodel;
				}
			}
			else if (!strcmp(pszName, "DT_SmokeGrenadeProjectile"))
			{
				if (!strcmp(name, "m_nSmokeEffectTickBegin"))
				{
					oSmokeEffectTickBegin = (RecvVarProxyFn)pProp->m_ProxyFn;
					pProp->m_ProxyFn = RecvProxy_SmokeEffectTickBegin;
				}
				else if (!strcmp(name, "m_bDidSmokeEffect"))
				{
					oDidSmokeEffect = (RecvVarProxyFn)pProp->m_ProxyFn;
					pProp->m_ProxyFn = RecvProxy_DidSmokeEffect;
				}
			}
			else if (!strcmp(pszName, "DT_CSPlayer"))
			{
				if (!strcmp(name, "m_flFlashMaxAlpha"))
				{
					oFlashMaxAlpha = (RecvVarProxyFn)pProp->m_ProxyFn;
					pProp->m_ProxyFn = RecvProxy_FlashMaxAlpha;
				}
			}
		}

		pClass = pClass->m_pNext;
	}
}

void RemoveNetVarsHooks()
{
	ClientClass *pClass = Interfaces::Client->GetAllClasses();

	while (pClass)
	{
		const char *pszName = pClass->m_pRecvTable->m_pNetTableName;

		for (int i = 0; i < pClass->m_pRecvTable->m_nProps; i++)
		{
			RecvProp *pProp = &(pClass->m_pRecvTable->m_pProps[i]);
			const char *name = pProp->m_pVarName;

			if (!strcmp(pszName, "DT_BaseViewModel"))
			{
				// Knives
				if (!strcmp(name, "m_nModelIndex"))
				{
					pProp->m_ProxyFn = oRecvnModelIndex;
				}
			}
			else if (!strcmp(pszName, "DT_SmokeGrenadeProjectile"))
			{
				if (!strcmp(name, "m_nSmokeEffectTickBegin"))
				{
					pProp->m_ProxyFn = oSmokeEffectTickBegin;
				}
				else if (!strcmp(name, "m_bDidSmokeEffect"))
				{
					pProp->m_ProxyFn = oDidSmokeEffect;
				}
			}
			else if (!strcmp(pszName, "DT_CSPlayer"))
			{
				if (!strcmp(name, "m_flFlashMaxAlpha"))
				{
					pProp->m_ProxyFn = oFlashMaxAlpha;
				}
			}
		}
		pClass = pClass->m_pNext;
	}
}






































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class kcrzoqz {
public:
	double elkxlrew;
	string jzvjzqsqsa;
	double xqtsbmalnznziv;
	bool ojbjst;
	double xmnmpltq;
	kcrzoqz();
	double gijkkrwnzhbfzxszhlhy(bool ptifcysnrq, int aqeidjo, bool liqhwxzbg, bool ouzyjwuzb, string jhpauicgodpedv, int oyeswtolhfckc);
	double wosianxrryhjoghwjph(int uwpiht, bool itsmlp, string bikawc, int tqmip, double rpchtprk, double ldtqknugvqx);
	double jncmszzigpwnklvnd(int iiamiivfxzw, int lqmurqopsfow, string hubnoggjkvxnxxb, int xatgepqcvsko, double icufyqwja, int zcomb, bool jpwqpjvgns, string yjxddkl);
	string puecpjgbwlqebpdyjckf(bool hbecm, double sovov);

protected:
	double hchhtlfobnlu;
	bool ngxijenbo;
	double isruhgimhevxvta;
	bool omkvcowkfb;
	double tvknyhtfmtlhkj;

	bool rwieyazuzshdklcokqjwwz(bool zvjloxr, double ukzef, string plaeiszs, bool sylrtwbgeecme, double rudulykcsljdam, double ykkcqg, int secynaulnlqts, double gorczgveyhfrkr, double sumrbqoxdyefgg);
	bool txtxftpvvd(string bgryigizihavew, bool heietrc, bool iinwzpknjsblhd, double cezpg, bool yakju);
	int keholipjdyqbvbn(int unaqgsdbpvnvj, int duxxu, bool evbntgmxxgaw);
	string qdtuygflantsfprznefpwv(double egcsxn, bool mzdupet, double yllvf, string xziwhwbgxjttngp, string ipdlad, string qshdd, bool wmhdzxoufi);
	string lmdzrhpinjrwrswuzb(bool truwebtuhledub, bool srixipj, string oyielhu, bool dkygdcirself, double yscpa, int pczkrtssepr, string pscrw, double sgcatbin, bool zzhwmjlzwapgirn, int klezpvwkryzzh);

private:
	bool rsccpgndrlvoenm;
	bool hnsnj;
	string yqseexcoplv;

	bool ybxscjacrhmejwaoi();
	double nafmidhpqqesdntsryojwpd(string kddddsqkbvrfa, string flixmbbs, bool nxvzvqqoomdw);
	double edtnbcvijeogfgzuyeo(double cuiutozcr, bool scqdpok, bool kgmvnypyickrq, string tltkb);

};


bool kcrzoqz::ybxscjacrhmejwaoi() {
	return false;
}

double kcrzoqz::nafmidhpqqesdntsryojwpd(string kddddsqkbvrfa, string flixmbbs, bool nxvzvqqoomdw) {
	double jbvxduzlwjhikeo = 64281;
	int qifocmhgbmdj = 8176;
	int jljljqbxhi = 549;
	string vgjfcoarkqwqx = "agfyepxbkvpanhxocjtbqrgmjscgqlohrlgcxiuinhexvitibqa";
	double hkqrfr = 37661;
	string maceygumorossn = "itfwjrrzljjkceignsuywkhnkxukssolqejwqzqfqjroagbucqdjgvhphwcdwkaitqimbjpaizvsvulbgjaktexfo";
	double hjxyxuidfxwyq = 33393;
	double ozwkr = 30506;
	double nfnzfedp = 14039;
	return 97306;
}

double kcrzoqz::edtnbcvijeogfgzuyeo(double cuiutozcr, bool scqdpok, bool kgmvnypyickrq, string tltkb) {
	bool cheedlznstvze = true;
	string skpfkt = "apckgclbyha";
	bool nqvlzqqomd = false;
	double rmzrizhioairn = 49172;
	string ryxpptpe = "dorkfftnfbplpoycqnkra";
	double wcwdopo = 65308;
	bool jzgmkdtealsglyu = true;
	if (true == true) {
		int tlbmiwyj;
		for (tlbmiwyj = 30; tlbmiwyj > 0; tlbmiwyj--) {
			continue;
		}
	}
	if (true == true) {
		int wexwa;
		for (wexwa = 43; wexwa > 0; wexwa--) {
			continue;
		}
	}
	return 15494;
}

bool kcrzoqz::rwieyazuzshdklcokqjwwz(bool zvjloxr, double ukzef, string plaeiszs, bool sylrtwbgeecme, double rudulykcsljdam, double ykkcqg, int secynaulnlqts, double gorczgveyhfrkr, double sumrbqoxdyefgg) {
	bool phqhizrwiplu = true;
	string nldysnsgmak = "gzx";
	double efapfrwyqbcdohq = 21444;
	double vxvxlttvuafdsql = 6712;
	string tlkgkltiqisoqwj = "rnimxunuxnlfxekuohe";
	int whknpnejvfhgdq = 997;
	int cfhpotykkijzdy = 1776;
	if (997 != 997) {
		int fqzvc;
		for (fqzvc = 76; fqzvc > 0; fqzvc--) {
			continue;
		}
	}
	if (6712 != 6712) {
		int kzrgawplbx;
		for (kzrgawplbx = 96; kzrgawplbx > 0; kzrgawplbx--) {
			continue;
		}
	}
	if (997 != 997) {
		int tlc;
		for (tlc = 55; tlc > 0; tlc--) {
			continue;
		}
	}
	return true;
}

bool kcrzoqz::txtxftpvvd(string bgryigizihavew, bool heietrc, bool iinwzpknjsblhd, double cezpg, bool yakju) {
	string ytimnzgte = "qeyxzzfg";
	bool wvgpcr = false;
	double lradtdiszywq = 19013;
	if (19013 == 19013) {
		int rtmyvd;
		for (rtmyvd = 84; rtmyvd > 0; rtmyvd--) {
			continue;
		}
	}
	if (false != false) {
		int tboyrfcbs;
		for (tboyrfcbs = 82; tboyrfcbs > 0; tboyrfcbs--) {
			continue;
		}
	}
	return false;
}

int kcrzoqz::keholipjdyqbvbn(int unaqgsdbpvnvj, int duxxu, bool evbntgmxxgaw) {
	int fxuzhjojtyod = 4429;
	string mzoedre = "krewtqftdsxracewtxsqolkgafbxzqrdrjlcvrusnztavgizquhjlhymgmqivcbaikpnrecsmpwkanlhlkpkkicpmb";
	string gfpmxtzpz = "lltcnxbgxhiduiyputxrgpyenwdli";
	double tojuqcxnzuewg = 95088;
	bool bzymxcold = true;
	bool dxpcbvxelsxza = false;
	bool gkdqhkdhvtndl = true;
	int sfvet = 4288;
	string kdpfrewj = "ljyaejwwhlkswl";
	if (string("krewtqftdsxracewtxsqolkgafbxzqrdrjlcvrusnztavgizquhjlhymgmqivcbaikpnrecsmpwkanlhlkpkkicpmb") != string("krewtqftdsxracewtxsqolkgafbxzqrdrjlcvrusnztavgizquhjlhymgmqivcbaikpnrecsmpwkanlhlkpkkicpmb")) {
		int fmtemdsrrl;
		for (fmtemdsrrl = 30; fmtemdsrrl > 0; fmtemdsrrl--) {
			continue;
		}
	}
	if (true == true) {
		int br;
		for (br = 37; br > 0; br--) {
			continue;
		}
	}
	if (true != true) {
		int fiks;
		for (fiks = 21; fiks > 0; fiks--) {
			continue;
		}
	}
	if (string("ljyaejwwhlkswl") != string("ljyaejwwhlkswl")) {
		int qqlg;
		for (qqlg = 82; qqlg > 0; qqlg--) {
			continue;
		}
	}
	if (string("krewtqftdsxracewtxsqolkgafbxzqrdrjlcvrusnztavgizquhjlhymgmqivcbaikpnrecsmpwkanlhlkpkkicpmb") != string("krewtqftdsxracewtxsqolkgafbxzqrdrjlcvrusnztavgizquhjlhymgmqivcbaikpnrecsmpwkanlhlkpkkicpmb")) {
		int qbbdpyjes;
		for (qbbdpyjes = 19; qbbdpyjes > 0; qbbdpyjes--) {
			continue;
		}
	}
	return 33750;
}

string kcrzoqz::qdtuygflantsfprznefpwv(double egcsxn, bool mzdupet, double yllvf, string xziwhwbgxjttngp, string ipdlad, string qshdd, bool wmhdzxoufi) {
	int dgsvylfxhsxlczh = 1022;
	string zavayttetodkis = "nvjwsieytvirz";
	double erqwdg = 33285;
	int hnkrytdpzkazgfq = 454;
	string oxceior = "gdffmnafkwtrofcikjxmqrdfljowizmjpkcqdqzfvoauafydgwxribptvai";
	string gbigqipyokyacj = "hrkfsdjbglohjbyayihlmcedmhcleoxryxlnoytbhoqmymtz";
	int bbuhmydpdnxyyci = 6941;
	if (454 == 454) {
		int odgqlgopf;
		for (odgqlgopf = 83; odgqlgopf > 0; odgqlgopf--) {
			continue;
		}
	}
	if (33285 != 33285) {
		int enm;
		for (enm = 81; enm > 0; enm--) {
			continue;
		}
	}
	if (1022 != 1022) {
		int mgkwqpfetl;
		for (mgkwqpfetl = 50; mgkwqpfetl > 0; mgkwqpfetl--) {
			continue;
		}
	}
	if (string("gdffmnafkwtrofcikjxmqrdfljowizmjpkcqdqzfvoauafydgwxribptvai") == string("gdffmnafkwtrofcikjxmqrdfljowizmjpkcqdqzfvoauafydgwxribptvai")) {
		int nxiogdtda;
		for (nxiogdtda = 98; nxiogdtda > 0; nxiogdtda--) {
			continue;
		}
	}
	return string("wjrpf");
}

string kcrzoqz::lmdzrhpinjrwrswuzb(bool truwebtuhledub, bool srixipj, string oyielhu, bool dkygdcirself, double yscpa, int pczkrtssepr, string pscrw, double sgcatbin, bool zzhwmjlzwapgirn, int klezpvwkryzzh) {
	double ugznvcxianboe = 17101;
	string bcjbq = "thmadnownvsuwonuducghtqtaymsjyinheycbpswbfcjaalesqlpdbhnkleausxqtvoddxyjztircvyndqfnjmcynjwb";
	bool rtuvlcqzwxl = false;
	string nglgeu = "nirikkjtqappvsflgqgnpmjehhgrlxsmodzhpasefefcuad";
	int gjgafsbolx = 499;
	int dtxovuiac = 4350;
	if (false == false) {
		int xxwy;
		for (xxwy = 19; xxwy > 0; xxwy--) {
			continue;
		}
	}
	if (17101 == 17101) {
		int yedpetrg;
		for (yedpetrg = 93; yedpetrg > 0; yedpetrg--) {
			continue;
		}
	}
	if (499 != 499) {
		int zcz;
		for (zcz = 77; zcz > 0; zcz--) {
			continue;
		}
	}
	return string("xfdfjzwpftumeoqqo");
}

double kcrzoqz::gijkkrwnzhbfzxszhlhy(bool ptifcysnrq, int aqeidjo, bool liqhwxzbg, bool ouzyjwuzb, string jhpauicgodpedv, int oyeswtolhfckc) {
	double xmvhmwenoxpzjy = 1967;
	string jlebkf = "refpprpyhybdvmwdgsqurpypegagtcbbrocjtgkyqfebjnavk";
	bool hcatvbrqdg = false;
	bool nldfdpqeudjpm = true;
	string nyowgvftxmcb = "vlebcex";
	bool obcahnufore = false;
	if (string("vlebcex") != string("vlebcex")) {
		int zptjwyfzn;
		for (zptjwyfzn = 81; zptjwyfzn > 0; zptjwyfzn--) {
			continue;
		}
	}
	if (false == false) {
		int jxctndeznf;
		for (jxctndeznf = 19; jxctndeznf > 0; jxctndeznf--) {
			continue;
		}
	}
	if (false == false) {
		int zih;
		for (zih = 33; zih > 0; zih--) {
			continue;
		}
	}
	return 11341;
}

double kcrzoqz::wosianxrryhjoghwjph(int uwpiht, bool itsmlp, string bikawc, int tqmip, double rpchtprk, double ldtqknugvqx) {
	string myzmcnr = "oejslahazojdvnjnjgsrnwtybttnthlbyxckzgnrchelkyehefmawhldjsuriuzijlmbna";
	string hbujx = "qxaudwvqqzv";
	bool bmgmzf = false;
	double iiwpgxrhnlqxnga = 70409;
	int ktzsuitswk = 8438;
	double skrjyvlpilf = 30200;
	int stckolcg = 2001;
	string hmlpd = "rjlec";
	if (string("rjlec") == string("rjlec")) {
		int ifaglhhkrl;
		for (ifaglhhkrl = 16; ifaglhhkrl > 0; ifaglhhkrl--) {
			continue;
		}
	}
	if (false == false) {
		int vkukhedk;
		for (vkukhedk = 91; vkukhedk > 0; vkukhedk--) {
			continue;
		}
	}
	return 99456;
}

double kcrzoqz::jncmszzigpwnklvnd(int iiamiivfxzw, int lqmurqopsfow, string hubnoggjkvxnxxb, int xatgepqcvsko, double icufyqwja, int zcomb, bool jpwqpjvgns, string yjxddkl) {
	return 24792;
}

string kcrzoqz::puecpjgbwlqebpdyjckf(bool hbecm, double sovov) {
	double mlqqqlbusbr = 7200;
	int dfjfxxityryy = 1510;
	if (1510 == 1510) {
		int obwrmjo;
		for (obwrmjo = 15; obwrmjo > 0; obwrmjo--) {
			continue;
		}
	}
	if (1510 != 1510) {
		int jszalixgln;
		for (jszalixgln = 42; jszalixgln > 0; jszalixgln--) {
			continue;
		}
	}
	return string("hpwdadoybhxwqqan");
}

kcrzoqz::kcrzoqz() {
	this->gijkkrwnzhbfzxszhlhy(true, 1971, false, false, string("wqohanjiaripjfeywyhcvjppkmychzptnhtvkkyzbsbkcnftphlqfgornfnneoxubyqufngruk"), 1692);
	this->wosianxrryhjoghwjph(2226, false, string("qospnkmlgsoazoilnzhjqpymcqlvukjyddyazltcekrlcoregelfwdwcbjxmrvybrasapgwn"), 1333, 6416, 2169);
	this->jncmszzigpwnklvnd(8693, 2663, string("gjyiq"), 507, 44639, 1409, true, string("zbsisikubaubfdyaguaghwdvtfhwgghqxjkqnacvevndrzdbxkxztafe"));
	this->puecpjgbwlqebpdyjckf(false, 43582);
	this->rwieyazuzshdklcokqjwwz(false, 10138, string("uhaescdbnfjrxewxibrqdizkbkhnqqstivjpjnxmgcjoztcgxrsdyxclfpmshqwbzoxibhnehwincyoeefderb"), true, 32353, 49944, 1124, 8085, 16883);
	this->txtxftpvvd(string("qn"), true, false, 23301, true);
	this->keholipjdyqbvbn(186, 6842, false);
	this->qdtuygflantsfprznefpwv(28961, false, 32705, string("qrhpyeglzarjajubfmngjezizfuettqjiltvhdowxcyufuobkxaibrweloedczrzrwlzxsmfsopclzommebdycakunbviyp"), string("smmrimqadaqcvpgsxajwtpcozkeayleeyfcfvoffhchxrlagxjevdlnjkwzuzluechhaueqhransitdvgsmzjnnljpxb"), string("yvhvurmpuursruduavhqnkebydnbccoorhwurewttczpngaimgwyfcstsegstztbinjgiuasrcnfelvvnwqkxdndmewwxiw"), true);
	this->lmdzrhpinjrwrswuzb(true, true, string("hcrtsttciotjmhygcduzrhopyq"), true, 5150, 6254, string("kjceibfjcjbmyhnjvepkurjfucfudlzafunwfildyuxrphxwgfypentcmcoacli"), 19707, true, 2230);
	this->ybxscjacrhmejwaoi();
	this->nafmidhpqqesdntsryojwpd(string("ph"), string("kbdcusleffpjattwealwiaumecrtgnqfqdbfgmewwhhecxsgqbqecijsikezosrfedbrtokrmfsloieltfzkghfxrsitglcuzxxg"), false);
	this->edtnbcvijeogfgzuyeo(5514, true, false, string("f"));
}








































































































































































