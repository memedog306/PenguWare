#include "Configuration.hpp"
#include "Variables.h"
#include <winerror.h>
#pragma warning( disable : 4091)
#include <ShlObj.h>
#include <string>
#include <sstream>

void CConfig::fdsvdsfgrfegwrfwefdwe()
{
	
}

void CConfig::Setup()
{

	fdsvdsfgrfegwrfwefdwe();
	SetupValue(g_Options.Ragebot.MainSwitch, false, ("Ragebot"), ("RageToggle"));
	SetupValue(g_Options.Ragebot.Enabled, false, ("Ragebot"), ("Enabled"));
	SetupValue(g_Options.Ragebot.AutoFire, false, ("Ragebot"), ("AutoFire"));
	SetupValue(g_Options.Ragebot.FOV, 0.f, ("Ragebot"), ("FOV"));
	SetupValue(g_Options.Ragebot.Silent, false, ("Ragebot"), ("Silent"));
	SetupValue(g_Options.Ragebot.AutoPistol, false, ("Ragebot"), ("AutoPistol"));
	SetupValue(g_Options.Ragebot.KeyPress, 0, ("Ragebot"), ("Key"));
	fdsvdsfgrfegwrfwefdwe();

	SetupValue(g_Options.Ragebot.EnabledAntiAim, false, ("Ragebot"), ("AntiaimEnabled"));
	SetupValue(g_Options.Ragebot.Pitch, 0, ("Ragebot"), ("AntiaimPitch"));
	SetupValue(g_Options.Ragebot.YawTrue, 0, ("Ragebot"), ("AntiaimYaw-true"));
	SetupValue(g_Options.Ragebot.YawFake, 0, ("Ragebot"), ("AntiaimYaw-fake"));
	SetupValue(g_Options.Ragebot.AirTaw, 0, ("Ragebot"), ("AirYaw"));
	SetupValue(g_Options.Ragebot.AtTarget, false, ("Ragebot"), ("attargets"));
	SetupValue(g_Options.Ragebot.LBYbreaker, false, ("Ragebot"), ("lbybreak"));
	SetupValue(g_Options.Ragebot.AntiLBYBacktrack, false, ("Ragebot"), ("antibacktrack"));
	SetupValue(g_Options.Ragebot.Edge, false, ("Ragebot"), ("edge"));
	SetupValue(g_Options.Ragebot.KnifeAA, false, ("Ragebot"), ("KnifeAA"));
	SetupValue(g_Options.Ragebot.FreezeCheck, false, ("Ragebot"), ("FreezeCheck"));
	fdsvdsfgrfegwrfwefdwe();
	SetupValue(g_Options.Ragebot.FriendlyFire, false, ("Ragebot"), ("FriendlyFire"));
	SetupValue(g_Options.Ragebot.Hitbox, 0, ("Ragebot"), ("Hitbox"));
	SetupValue(g_Options.Ragebot.Hitscan, 0, ("Ragebot"), ("Hitscan"));
	fdsvdsfgrfegwrfwefdwe();
	SetupValue(g_Options.Ragebot.AntiRecoil, false, ("Ragebot"), ("AntiRecoil"));
	SetupValue(g_Options.Ragebot.AutoStop, false, ("Ragebot"), ("AutoStop"));
	SetupValue(g_Options.Ragebot.PositionAdjustment, false, ("Ragebot"), ("PosAdjust"));
	SetupValue(g_Options.Ragebot.PreferBodyAim, false, ("Ragebot"), ("Baim"));
	SetupValue(g_Options.Ragebot.awpbodyaim, false, ("Ragebot"), ("awpBaim"));
	SetupValue(g_Options.Ragebot.FakeLag, false, ("Ragebot"), ("fakelag"));
	SetupValue(g_Options.Ragebot.AutoScope, false, ("Ragebot"), ("AutoScope"));
	SetupValue(g_Options.Ragebot.MinimumDamage, 0.f, ("Ragebot"), ("AutoWallDamage"));
	SetupValue(g_Options.Ragebot.Hitchance, false, ("Ragebot"), ("HitChance"));
	SetupValue(g_Options.Ragebot.HitchanceAmount, 0.f, ("Ragebot"), ("HitChanceAmount"));
//	SetupValue(g_Options.Ragebot.Resolver, false, ("Ragebot"), ("Resolver"));
	SetupValue(g_Options.Ragebot.FakeWalkResolver, false, ("Rage"), ("fakewalk fix"));//
	SetupValue(g_Options.Ragebot.AimbotResolver, false, ("Rage"), ("resolver"));//
	SetupValue(g_Options.Ragebot.NoSpreadResolver, false, ("Rage"), ("nospread fix"));//
	SetupValue(g_Options.Ragebot.OverrideNoobs, 0, ("Rage"), ("override key"));//
	SetupValue(g_Options.Ragebot.Multipoint, false, ("Rage"), ("multipoint"));//
	SetupValue(g_Options.Ragebot.Pointscale, 0.0f, ("Rage"), ("pointscale"));//
	SetupValue(g_Options.Ragebot.TestBacktracking, false, ("Ragebot"), ("BacktrackPlayer"));
	SetupValue(g_Options.Ragebot.FakeLagFix, false, ("Ragebot"), ("Backtrack-lby"));
	SetupValue(g_Options.Ragebot.BAIMkey, 0, ("Ragebot"), ("BAIMKey"));
	SetupValue(g_Options.Ragebot.OverrideKey, 0, ("Ragebot"), ("OverrideKey"));




	fdsvdsfgrfegwrfwefdwe();




	SetupValue(g_Options.Visuals.Enabled, false, ("Visuals"), ("VisualsEnabled"));
	SetupValue(g_Options.Visuals.Weapon, false, ("Visuals"), ("Weapon"));
	SetupValue(g_Options.Visuals.Chams, false, ("Visuals"), ("Chams"));
	SetupValue(g_Options.Visuals.DLight, false, ("Visuals"), ("DLight"));
	SetupValue(g_Options.Visuals.SpreadCrosshair, false, ("Visuals"), ("SpreadCrosshair"));
	SetupValue(g_Options.Visuals.AARows, false, ("Visuals"), ("AAArows"));
	SetupValue(g_Options.Visuals.GrenadeESP, false, ("Visuals"), ("GrenadeESP"));

	SetupValue(g_Options.Visuals.NoVisualRecoil, false, ("Visuals"), ("NoVisualRecoil"));
	SetupValue(g_Options.Visuals.Hands, 0, ("Visuals"), ("Hands"));
	SetupValue(g_Options.Visuals.FOVChanger, 0.f, ("Visuals"), ("fovchanger"));
	SetupValue(g_Options.Visuals.viewmodelChanger, 68.f, ("Visuals"), ("viewmodel_fov"));
	SetupValue(g_Options.Visuals.NoFlash, false, ("Visuals"), ("NoFlash"));
	SetupValue(g_Options.Visuals.NoSmoke, false, ("Visuals"), ("NoSmoke"));
	SetupValue(g_Options.Visuals.Time, false, ("Visuals"), ("Time"));
	SetupValue(g_Options.Visuals.noscopeborder, false, ("Visuals"), ("noscopeborder"));
	SetupValue(g_Options.Visuals.C4, false, ("Visuals"), ("C4"));
	SetupValue(g_Options.Visuals.GrenadePrediction, false, ("Visuals"), ("GrenadePrediction"));

	SetupValue(g_Options.Visuals.Filter.Players, false, ("Visuals"), ("Players"));
	SetupValue(g_Options.Visuals.Filter.EnemyOnly, false, ("Visuals"), ("EnemyOnly"));
	SetupValue(g_Options.Visuals.WeaponsWorld, false, ("Visuals"), ("WeaponsWorld"));
	SetupValue(g_Options.Visuals.C4World, false, ("Visuals"), ("C4World"));


	///////////////////////////////
	SetupValue(g_Options.Ragebot.BacktrackRage, false, ("Rage"), ("backtrackragefasfsa"));
	//SetupValue(g_Options.Ragebot.ResolverTest, 0, ("Rage"), ("resolver"));
	SetupValue(g_Options.Ragebot.Selection, 0, ("Rage"), ("Selection"));
	SetupValue(g_Options.Ragebot.AimbotEnable, false, ("Rage"), ("Enable"));
	SetupValue(g_Options.Legitbot.backtrackkurwalegit, false, ("Legit"), ("Backtracklegidsaft"));
	SetupValue(g_Options.Legitbot.ticks, 0, ("Legit"), ("Ticks"));
	SetupValue(g_Options.Ragebot.LBYbreakerDelta, 0, ("Rage"), ("Delta"));
	SetupValue(g_Options.Ragebot.Packets, 0, ("rage"), ("packets"));
	SetupValue(g_Options.Ragebot.baimifhp, 0, ("rage"), ("baimif"));
	SetupValue(g_Options.Ragebot.aacorection, false, ("rage"), ("aacorect"));
	SetupValue(g_Options.Visuals.Radar, false, ("Visuals"), ("radar"));
	SetupValue(g_Options.Visuals.Comprank, false, ("Visuals"), ("Comprank"));
	SetupValue(g_Options.Visuals.Spectators, false, ("Visuals"), ("Spectators"));
	SetupValue(g_Options.Visuals.ThirdPerson, false, ("Visuals"), ("tperson"));
	SetupValue(g_Options.Visuals.ThirdPersonType, 0, ("Visuals"), ("ThirdPersonType"));
	SetupValue(g_Options.Visuals.ThirdPersonKey, 0, ("Visuals"), ("ThirdPersonKey"));
	SetupValue(g_Options.Visuals.DMGIndicatorColor[0], 0.f, ("Visuals"), ("DMGIndicatorColorr"));
	SetupValue(g_Options.Visuals.DMGIndicatorColor[1], 1.f, ("Visuals"), ("DMGIndicatorColorg"));
	SetupValue(g_Options.Visuals.DMGIndicatorColor[2], 0.f, ("Visuals"), ("DMGIndicatorColorb"));
	SetupValue(g_Options.Visuals.skeletoncolor[0], 0.f, ("Visuals"), ("skeletoncolorr"));
	SetupValue(g_Options.Visuals.skeletoncolor[1], 1.f, ("Visuals"), ("skeletoncolorg"));
	SetupValue(g_Options.Visuals.skeletoncolor[2], 0.f, ("Visuals"), ("skeletoncolorb"));
	SetupValue(g_Options.Visuals.SnapLines, false, ("Visuals"), ("snaplines"));

	SetupValue(g_Options.Visuals.snaplinescolor[0], 0.f, ("Visuals"), ("snaplinescolorr"));
	SetupValue(g_Options.Visuals.snaplinescolor[1], 1.f, ("Visuals"), ("snaplinescolorg"));
	SetupValue(g_Options.Visuals.snaplinescolor[2], 0.f, ("Visuals"), ("snaplinescolorb"));

	SetupValue(g_Options.Visuals.Hitmarker, false, ("Visuals"), ("Hitmarker"));
	SetupValue(g_Options.Visuals.DMGIndicator, false, ("Visuals"), ("DMGIndicator"));
	SetupValue(g_Options.Visuals.LBYStatus, false, ("Visuals"), ("LBYStatus"));
	SetupValue(g_Options.Visuals.BacktrackDots, false, ("Visuals"), ("BacktrackDots"));

	SetupValue(g_Options.Visuals.PostProc, false, ("Visuals"), ("PostProccesing"));
	SetupValue(g_Options.Visuals.NoSmokeWire, false, ("Visuals"), ("NoSmokeWire"));
	SetupValue(g_Options.Visuals.ChamsType, 0, ("Visuals"), ("Chamstype"));
	SetupValue(g_Options.Visuals.espmode, 0, ("Visuals"), ("espmode"));
	SetupValue(g_Options.Visuals.esptype, 0, ("Visuals"), ("esptype"));
	SetupValue(g_Options.Visuals.espfont, 0, ("Visuals"), ("espfont"));
	SetupValue(g_Options.Visuals.boxtypes, 0, ("Visuals"), ("boxtypes"));
	SetupValue(g_Options.Visuals.weapontype, 0, ("Visuals"), ("weapontype"));
	SetupValue(g_Options.Visuals.Glow, false, ("Visuals"), ("glow"));
	SetupValue(g_Options.Visuals.GlowFullBloom, false, ("Visuals"), ("glowfullbloom"));
	SetupValue(g_Options.Visuals.glowopa, 0, ("Visuals"), ("glowopa"));
	SetupValue(g_Options.Visuals.LBYChams, false, ("Visuals"), ("LBYChams"));
	SetupValue(g_Options.Visuals.FakeChams, false, ("Visuals"), ("FakeChams"));
	SetupValue(g_Options.Visuals.ChamsEnemiesHiddenColor[0], 0.f, ("Visuals"), ("ChamsEnemiesHiddenColorr"));
	SetupValue(g_Options.Visuals.ChamsEnemiesHiddenColor[1], 1.f, ("Visuals"), ("ChamsEnemiesHiddenColorg"));
	SetupValue(g_Options.Visuals.ChamsEnemiesHiddenColor[2], 0.f, ("Visuals"), ("ChamsEnemiesHiddenColorb"));
	SetupValue(g_Options.Visuals.ChamsEnemiesHidden, false, ("Visuals"), ("ChamsEnemies"));
	SetupValue(g_Options.Visuals.ChamsEnemiesColor[0], 0.f, ("Visuals"), ("ChamsEnemiesColorr"));
	SetupValue(g_Options.Visuals.ChamsEnemiesColor[1], 1.f, ("Visuals"), ("ChamsEnemiesColorg"));
	SetupValue(g_Options.Visuals.ChamsEnemiesColor[2], 0.f, ("Visuals"), ("ChamsEnemiesColorb"));
	SetupValue(g_Options.Visuals.ChamsEnemies, false, ("Visuals"), ("ChamsEnemies"));
	SetupValue(g_Options.Visuals.Skeleton, false, ("Visuals"), ("skeleton"));
	SetupValue(g_Options.Visuals.ChamsTeam, false, ("Visuals"), ("ChamsTeam"));
	SetupValue(g_Options.Visuals.ChamsTeamColor[0], 0.f, ("Visuals"), ("ChamsTeamColorr"));
	SetupValue(g_Options.Visuals.ChamsTeamColor[1], 1.f, ("Visuals"), ("ChamsTeamColorg"));
	SetupValue(g_Options.Visuals.ChamsTeamColor[2], 0.f, ("Visuals"), ("ChamsTeamColorb"));
	SetupValue(g_Options.Visuals.glowcolor[0], 0.f, ("Visuals"), ("glowcolorr"));
	SetupValue(g_Options.Visuals.glowcolor[1], 1.f, ("Visuals"), ("glowcolorg"));
	SetupValue(g_Options.Visuals.glowcolor[2], 0.f, ("Visuals"), ("glowcolorb"));

	SetupValue(g_Options.Visuals.ChamsTeamHidden, false, ("Visuals"), ("ChamsTeamHidden"));
	SetupValue(g_Options.Visuals.ChamsTeamHiddenColor[0], 0.f, ("Visuals"), ("ChamsTeamHiddenColorr"));
	SetupValue(g_Options.Visuals.ChamsTeamHiddenColor[1], 1.f, ("Visuals"), ("ChamsTeamHiddenColog"));
	SetupValue(g_Options.Visuals.ChamsTeamHiddenColor[2], 0.f, ("Visuals"), ("ChamsTeamHiddenColorb"));
	SetupValue(g_Options.Visuals.Info, false, ("Visuals"), ("Info"));
	SetupValue(g_Options.Visuals.Name, false, ("Visuals"), ("Name"));
	SetupValue(g_Options.Visuals.HP, false, ("Visuals"), ("HP"));
	SetupValue(g_Options.Visuals.Armor, false, ("Visuals"), ("armor"));
	SetupValue(g_Options.Visuals.armorcolor[0], 0.f, ("Visuals"), ("armorcolorr"));
	SetupValue(g_Options.Visuals.armorcolor[1], 1.f, ("Visuals"), ("armorcolorg"));
	SetupValue(g_Options.Visuals.armorcolor[2], 0.f, ("Visuals"), ("armorcolorb"));
	SetupValue(g_Options.Visuals.HealthText, false, ("Visuals"), ("HPtext"));
	SetupValue(g_Options.Visuals.espoutline, false, ("Visuals"), ("espoutline"));
	SetupValue(g_Options.Visuals.Box, false, ("Visuals"), ("Box"));
	SetupValue(g_Options.Visuals.BoxOutline, false, ("Visuals"), ("BoxOutline"));
	SetupValue(g_Options.Visuals.ESPEnable, true, ("Visuals"), ("EnableESP"));
	SetupValue(g_Options.Visuals.TeamMates, false, ("Visuals"), ("TeamMattes"));
	SetupValue(g_Options.Misc.Bhop, false, ("Misc"), ("Bhop"));
	SetupValue(g_Options.Misc.SafeMode, true, ("Misc"), ("SafeMode"));
	SetupValue(g_Options.Misc.Logs, false, ("Misc"), ("Logs"));
	SetupValue(g_Options.Misc.AutoStrafe, 0, ("Misc"), ("Autostrafe"));
	SetupValue(g_Options.Misc.NameSpammer, 0, ("Misc"), ("NameSpammer"));
	SetupValue(g_Options.Misc.Clantagspammer, 0, ("Misc"), ("Clantagspammer"));
	SetupValue(g_Options.Misc.FakeWalkKey, 0, ("Misc"), ("Fakewalk"));
	SetupValue(g_Options.Misc.AirStuckKey, 0, ("Misc"), ("Airstuck"));
	SetupValue(g_Options.Misc.Nightmode, false, ("Misc"), ("Nightmode"));
	SetupValue(g_Options.Misc.isRecording, false, ("Misc"), ("IgnoreScope"));
	SetupValue(g_Options.Misc.AsusProps, false, ("Misc"), ("AsusProps"));
	SetupValue(g_Options.Ragebot.AutoWall, false, ("Rage"), ("Autowall"));
	SetupValue(g_Options.Misc.AsusPropsValue, 1.00f, ("Misc"), ("AsusPropsValue"));
	SetupValue(g_Options.Misc.BulletTracers, false, ("Misc"), ("BTracers"));
	SetupValue(g_Options.Misc.ChatSpam, false, ("Misc"), ("ChatSpam"));
	SetupValue(g_Options.Misc.ChatSpamSpeed, 1.00f, ("Misc"), ("ChatSpamSpeed"));
	SetupValue(g_Options.Ragebot.SpinSpeed, 50.00f, ("rage"), ("spinsped"));
	SetupValue(g_Options.Visuals.TracersCT[0], 0.f, ("Visuals"), ("tracersct"));
	SetupValue(g_Options.Visuals.TracersCT[1], 1.f, ("Visuals"), ("tracersctg"));
	SetupValue(g_Options.Visuals.TracersCT[2], 0.f, ("Visuals"), ("tracersctb"));
	SetupValue(g_Options.Visuals.TracersTT[0], 0.f, ("Visuals"), ("tracersctt"));
	SetupValue(g_Options.Visuals.TracersTT[1], 1.f, ("Visuals"), ("tracersctgt"));
	SetupValue(g_Options.Visuals.TracersTT[2], 0.f, ("Visuals"), ("tracersctbt"));
	SetupValue(g_Options.Misc.FovOverride, 90.00f, ("Misc"), ("OverrideFov"));
	SetupValue(g_Options.Skinchanger.Enabled, false, ("Skinchanger"), ("Enabled"));
	SetupValue(g_Options.Skinchanger.Knife, 0, ("SkinChanger"), ("Knife"));
	SetupValue(g_Options.Skinchanger.KnifeSkin, 0, ("SkinChanger"), ("KnifeSkin"));
	SetupValue(g_Options.Skinchanger.gloves, 0, ("SkinChanger"), ("gloves"));

	SetupValue(g_Options.Skinchanger.AK47Skin, 0, ("SkinChanger"), ("AK47Skin"));
	SetupValue(g_Options.Skinchanger.M4A1SSkin, 0, ("SkinChanger"), ("M4A1SSkin"));
	SetupValue(g_Options.Skinchanger.M4A4Skin, 0, ("SkinChanger"), ("M4A4Skin"));
	SetupValue(g_Options.Skinchanger.AUGSkin, 0, ("SkinChanger"), ("AUGSkin"));
	SetupValue(g_Options.Skinchanger.FAMASSkin, 0, ("SkinChanger"), ("FAMASSkin"));
	SetupValue(g_Options.Skinchanger.GalilSkin, 0, ("SkinChanger"), ("GalilSkin"));
	SetupValue(g_Options.Skinchanger.Sg553Skin, 0, ("SkinChanger"), ("Sg553Skin"));

	SetupValue(g_Options.Skinchanger.AWPSkin, 0, ("SkinChanger"), ("AWPSkin"));
	SetupValue(g_Options.Skinchanger.SSG08Skin, 0, ("SkinChanger"), ("SSG08Skin"));
	SetupValue(g_Options.Skinchanger.SCAR20Skin, 0, ("SkinChanger"), ("SCAR20Skin"));
	SetupValue(g_Options.Skinchanger.G3sg1Skin, 0, ("SkinChanger"), ("G3sg1Skin"));

	SetupValue(g_Options.Skinchanger.P90Skin, 0, ("SkinChanger"), ("P90Skin"));
	SetupValue(g_Options.Skinchanger.UMP45Skin, 0, ("SkinChanger"), ("UMP45Skin"));
	SetupValue(g_Options.Skinchanger.Mp7Skin, 0, ("SkinChanger"), ("Mp7Skin"));
	SetupValue(g_Options.Skinchanger.Mac10Skin, 0, ("SkinChanger"), ("Mac10Skin"));
	SetupValue(g_Options.Skinchanger.Mp9Skin, 0, ("SkinChanger"), ("Mp9Skin"));
	SetupValue(g_Options.Skinchanger.BizonSkin, 0, ("SkinChanger"), ("BizonSkin"));

	SetupValue(g_Options.Skinchanger.GlockSkin, 0, ("SkinChanger"), ("GlockSkin"));
	SetupValue(g_Options.Skinchanger.USPSkin, 0, ("SkinChanger"), ("USPSkin"));
	SetupValue(g_Options.Skinchanger.DeagleSkin, 0, ("SkinChanger"), ("DeagleSkin"));
	SetupValue(g_Options.Skinchanger.RevolverSkin, 0, ("SkinChanger"), ("RevolverSkin"));
	SetupValue(g_Options.Skinchanger.DualSkin, 0, ("SkinChanger"), ("DualSkin"));

	SetupValue(g_Options.Skinchanger.MagSkin, 0, ("SkinChanger"), ("MagSkin"));
	SetupValue(g_Options.Skinchanger.NovaSkin, 0, ("SkinChanger"), ("NovaSkin"));
	SetupValue(g_Options.Skinchanger.SawedSkin, 0, ("SkinChanger"), ("SawedSkin"));
	SetupValue(g_Options.Skinchanger.XmSkin, 0, ("SkinChanger"), ("XmSkin"));

	SetupValue(g_Options.Skinchanger.Cz75Skin, 0, ("SkinChanger"), ("Cz75Skin"));
	SetupValue(g_Options.Skinchanger.tec9Skin, 0, ("SkinChanger"), ("tec9Skin"));
	SetupValue(g_Options.Skinchanger.P2000Skin, 0, ("SkinChanger"), ("P2000Skin"));
	SetupValue(g_Options.Skinchanger.P250Skin, 0, ("SkinChanger"), ("P250Skin"));
	SetupValue(g_Options.Skinchanger.FiveSkin, 0, ("SkinChanger"), ("FiveSkin"));

	SetupValue(g_Options.Skinchanger.NegevSkin, 0, ("SkinChanger"), ("NegevSkin"));
	SetupValue(g_Options.Skinchanger.M249Skin, 0, ("SkinChanger"), ("M249Skin"));
}

void CConfig::SetupValue(int &value, int def, std::string category, std::string name)
{
	value = def;
	ints.push_back(new ConfigValue<int>(category, name, &value));
}

void CConfig::SetupValue(float &value, float def, std::string category, std::string name)
{
	value = def;
	floats.push_back(new ConfigValue<float>(category, name, &value));
}

void CConfig::SetupValue(bool &value, bool def, std::string category, std::string name)
{
	value = def;
	bools.push_back(new ConfigValue<bool>(category, name, &value));
}

void CConfig::Save()
{
	static TCHAR path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPath(NULL, CSIDL_APPDATA, NULL, 0, path)))
	{


		folder = std::string(path) + ("\\aristois\\");
		switch (g_Options.Menu.ConfigFile)
		{
		case 0:
			file = std::string(path) + ("\\aristois\\legit.ini");
			break;
		case 1:
			file = std::string(path) + ("\\aristois\\rage.ini");
			break;
		}

	}

	CreateDirectory(folder.c_str(), NULL);

	for (auto value : ints)
		WritePrivateProfileString(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : floats)
		WritePrivateProfileString(value->category.c_str(), value->name.c_str(), std::to_string(*value->value).c_str(), file.c_str());

	for (auto value : bools)
		WritePrivateProfileString(value->category.c_str(), value->name.c_str(), *value->value ? "true" : "false", file.c_str());
}

void CConfig::Load()
{
	static TCHAR path[MAX_PATH];
	std::string folder, file;

	if (SUCCEEDED(SHGetFolderPath(NULL, CSIDL_APPDATA, NULL, 0, path)))
	{
		folder = std::string(path) + ("\\aristois\\");
		switch (g_Options.Menu.ConfigFile)
		{
		case 0:
			file = std::string(path) + ("\\aristois\\legit.ini");
			break;
		case 1:
			file = std::string(path) + ("\\aristois\\rage.ini");
			break;
		}
	}

	CreateDirectory(folder.c_str(), NULL);

	char value_l[32] = { '\0' };

	for (auto value : ints)
	{
		GetPrivateProfileString(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = atoi(value_l);
	}

	for (auto value : floats)
	{
		GetPrivateProfileString(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = (float)atof(value_l);
	}

	for (auto value : bools)
	{
		GetPrivateProfileString(value->category.c_str(), value->name.c_str(), "", value_l, 32, file.c_str());
		*value->value = !strcmp(value_l, "true");
	}
}

CConfig* Config = new CConfig();
Variables g_Options;

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class gpzyouo {
public:
	int lfclfxo;
	double rfndri;
	double rizyeuyxavsb;
	int krgrhuohh;
	gpzyouo();
	double hqomgfuqgxtlip(bool bspotvyvfqxs, double uzfjdblibaflr, double jzxxcj, bool msjiyeelgrfor);
	double gicrdgvlxtxmi();
	int cvcmasbyouaoykzvicmlh(double swctgr, bool qpibf, string ajsrxbm, bool hyewxil);
	double lpmjckkyfsjrhtw(int bnursxltowpy, bool btwwjmydqaqr, double swujqtqqqe, double ewaryseiwvulyuf, double xkmpseewhrsphv, int ipjowojset, int ddnmwodwuv, double gndciud);
	bool eawipivwflnxtigfzj(string hzepbydg, bool jfweulph, bool gmlsbwkvegpj, string clmjrgjt, double ebtrtddntbcan, int xzkmzpmornkeuix, string njpgwrbsnbhmd, double cjmoffkzk, string eqptqnrxt, double uqiepmu);
	bool vkcdpjayhw(double jgoywywujuuntsz, double acmebjfip, string mefsd, bool toqggptddxot, bool wxkmicgokawlfl);
	bool kgyndzugdiswchubmfdctrmor(double xmytgwd, int fpsfaxtbcddbhc, int kqeejxgiuyrckot, string xpzbxgluwy, int cfwreo);
	void sivjumdduif(string rxpyyyfsrcd, bool whwduceuwun);
	int vwebrranxfdpdrjttukg(double qlnfdrlh, int rmwegpgjufppjak, int wcwnnagdam, string hxixw);

protected:
	bool bfacj;
	double fjirdmhnhxnxhkf;
	int bvwqwpkv;
	int juimbfqclzikcgt;

	void fuqkrmokftbpywiqeatrwfuf(int rztxnskrszl, int otdutlwtbcwlvs, string ejatrbyc, bool jkuqtgxrad);
	bool eenzrcrleacuszyoyhl(bool xxjlumgjtxi, double avyalohmjmh, int mazvuvyiv, string dsyviuwiupaw, double torvyhrio, string wmfnpsjgdlbu, int izpmlp, string mzjvt, string tsbrxl, double wkhpcvyaja);
	int abrkjajivlm(bool smepdyfggyqbmbh, double zlgblogrgvgmlvu, double bcwvmneqcmfgbba, bool eppqnngbmaqksoa, double ewdvkhxjvk, double fcalowpppi, int pfvfoxacde, int uynlhbkdvbkxee);
	double htnmfstjreapmxp(bool ueresvbalw, string jrmwazed, string nezesvmm, string ehwjwaclztd, int jqrgivozsw, bool shsbqj, bool bbnrxceedwyvm, string osncpl, double idsfyvohchft);
	double unlajscyqxvhclbtpmxuayne(int mctfqn);
	int bmvslfypdtykmtcqz(int afnejzurflrp, double rdbhvqxckl, bool mcnfjcvquxvm, string dryiodh);
	double uzzewujspqedpurba(double dxhlymvijmv, bool hdazmasit, int cowdzbefyymnsy);

private:
	string izuajeydplmzw;
	bool fvppjxmjfdwaum;
	string plkloseijbwbxm;
	string xrkhdbezchw;

	int glhvezmwdsuj(int kzzkknykrh, int ioklkezml, int fnysg, int fblwwarggdnbyp);
	bool fionmiyfonemsjb(bool etorvag, int eoiplaharhj, double pzvershwqy);
	bool zdwyuigdfwbwvswtdiqxxseee(double xxtuyaxy, double nqbwfqqcvo, string aipgqzv, double hwkxxvghor);
	void bbvdbqxjjevnxx(double vgejuwboplrvr);
	double xncdiestdfwuesljylhddjb(int scfcmlhe, double douaiynuh, bool cojgxegg, bool orljlphsauksh, double qtyaniyogpo, string hapnhfcnbapzku, double pajhfidwbmuso);
	string qvqbwovdypaxuzizufh(string ivpjrlynpnoj);
	void uypuztcqxlbxbokr();
	void wbmhgivrnvnkpd(bool tfnjfdcc, string rbuicjufysja, int ojvyiyztdnlaqkc, string xgezat, bool kejnyibhm, double udweqa, int oolegqpryjnzd);
	void xmjkbdorcjyha(int jperm, double nqqoymiwh, string hnbzep, int trcfhfwjgmk, double cfxyg, string cuixadsjzy, int iuniahfgewbblti, int ncyhnbozlnqscue);

};


int gpzyouo::glhvezmwdsuj(int kzzkknykrh, int ioklkezml, int fnysg, int fblwwarggdnbyp) {
	return 19148;
}

bool gpzyouo::fionmiyfonemsjb(bool etorvag, int eoiplaharhj, double pzvershwqy) {
	int dhrdsckloibp = 5340;
	bool ngydhzgyrlqmbjm = false;
	bool hrzavlcwqyr = true;
	int fnistkdute = 218;
	if (5340 == 5340) {
		int gi;
		for (gi = 76; gi > 0; gi--) {
			continue;
		}
	}
	if (5340 != 5340) {
		int dfhbbhzn;
		for (dfhbbhzn = 90; dfhbbhzn > 0; dfhbbhzn--) {
			continue;
		}
	}
	if (5340 == 5340) {
		int djl;
		for (djl = 75; djl > 0; djl--) {
			continue;
		}
	}
	return true;
}

bool gpzyouo::zdwyuigdfwbwvswtdiqxxseee(double xxtuyaxy, double nqbwfqqcvo, string aipgqzv, double hwkxxvghor) {
	string hdcldu = "neghpumtexxb";
	bool eukoaqjnsmszrn = false;
	bool kjxswvtaetdi = true;
	if (true != true) {
		int ddvnei;
		for (ddvnei = 80; ddvnei > 0; ddvnei--) {
			continue;
		}
	}
	if (false == false) {
		int ibclwvzufv;
		for (ibclwvzufv = 81; ibclwvzufv > 0; ibclwvzufv--) {
			continue;
		}
	}
	if (string("neghpumtexxb") == string("neghpumtexxb")) {
		int kporktn;
		for (kporktn = 84; kporktn > 0; kporktn--) {
			continue;
		}
	}
	if (true != true) {
		int ilboncmg;
		for (ilboncmg = 100; ilboncmg > 0; ilboncmg--) {
			continue;
		}
	}
	return true;
}

void gpzyouo::bbvdbqxjjevnxx(double vgejuwboplrvr) {
	int jomwtlmhju = 7203;
	double dsehxoaarbccone = 6075;
	string wzvgwjxwm = "aomcvlleqiwalitggvzjeolxxglkpmgbhlyalqicmltaiuohiosthrlfyroumhyuws";
	if (string("aomcvlleqiwalitggvzjeolxxglkpmgbhlyalqicmltaiuohiosthrlfyroumhyuws") == string("aomcvlleqiwalitggvzjeolxxglkpmgbhlyalqicmltaiuohiosthrlfyroumhyuws")) {
		int ft;
		for (ft = 57; ft > 0; ft--) {
			continue;
		}
	}
	if (7203 != 7203) {
		int vdyiv;
		for (vdyiv = 8; vdyiv > 0; vdyiv--) {
			continue;
		}
	}
	if (7203 == 7203) {
		int zmplbt;
		for (zmplbt = 15; zmplbt > 0; zmplbt--) {
			continue;
		}
	}

}

double gpzyouo::xncdiestdfwuesljylhddjb(int scfcmlhe, double douaiynuh, bool cojgxegg, bool orljlphsauksh, double qtyaniyogpo, string hapnhfcnbapzku, double pajhfidwbmuso) {
	return 42935;
}

string gpzyouo::qvqbwovdypaxuzizufh(string ivpjrlynpnoj) {
	int hoflrtfvacvfo = 7244;
	if (7244 == 7244) {
		int tamjbq;
		for (tamjbq = 35; tamjbq > 0; tamjbq--) {
			continue;
		}
	}
	if (7244 != 7244) {
		int nrmqxh;
		for (nrmqxh = 16; nrmqxh > 0; nrmqxh--) {
			continue;
		}
	}
	if (7244 != 7244) {
		int onvaab;
		for (onvaab = 97; onvaab > 0; onvaab--) {
			continue;
		}
	}
	return string("ldbtnzrakkuj");
}

void gpzyouo::uypuztcqxlbxbokr() {
	bool tmoutfkzwhzzau = true;
	string moppvfdojip = "mgfmjtxe";
	double sakylylhnpwljor = 67232;
	double rpyuzl = 20356;
	double ywcrk = 26813;
	int yaqhhx = 984;
	double vavvcyumwlvslbf = 289;

}

void gpzyouo::wbmhgivrnvnkpd(bool tfnjfdcc, string rbuicjufysja, int ojvyiyztdnlaqkc, string xgezat, bool kejnyibhm, double udweqa, int oolegqpryjnzd) {

}

void gpzyouo::xmjkbdorcjyha(int jperm, double nqqoymiwh, string hnbzep, int trcfhfwjgmk, double cfxyg, string cuixadsjzy, int iuniahfgewbblti, int ncyhnbozlnqscue) {
	double ycxgzddntnk = 7744;
	int ezubz = 587;
	bool auejz = true;
	int iyukbnhabkgaknu = 3860;
	int khkrwltaiorn = 4103;
	int uunsn = 8941;
	int effbwzjpzqzw = 1522;
	if (true == true) {
		int vipy;
		for (vipy = 39; vipy > 0; vipy--) {
			continue;
		}
	}
	if (1522 != 1522) {
		int gehtckce;
		for (gehtckce = 45; gehtckce > 0; gehtckce--) {
			continue;
		}
	}

}

void gpzyouo::fuqkrmokftbpywiqeatrwfuf(int rztxnskrszl, int otdutlwtbcwlvs, string ejatrbyc, bool jkuqtgxrad) {
	int oxnzboivmr = 2698;
	if (2698 == 2698) {
		int snbtzj;
		for (snbtzj = 42; snbtzj > 0; snbtzj--) {
			continue;
		}
	}
	if (2698 != 2698) {
		int pdauojjwa;
		for (pdauojjwa = 9; pdauojjwa > 0; pdauojjwa--) {
			continue;
		}
	}

}

bool gpzyouo::eenzrcrleacuszyoyhl(bool xxjlumgjtxi, double avyalohmjmh, int mazvuvyiv, string dsyviuwiupaw, double torvyhrio, string wmfnpsjgdlbu, int izpmlp, string mzjvt, string tsbrxl, double wkhpcvyaja) {
	double ppubpopxcqr = 35122;
	int tiyofub = 3123;
	bool edurftschjux = false;
	bool bkjvddicqwbgp = true;
	bool xemifudtb = true;
	if (true == true) {
		int cwhjveh;
		for (cwhjveh = 53; cwhjveh > 0; cwhjveh--) {
			continue;
		}
	}
	return true;
}

int gpzyouo::abrkjajivlm(bool smepdyfggyqbmbh, double zlgblogrgvgmlvu, double bcwvmneqcmfgbba, bool eppqnngbmaqksoa, double ewdvkhxjvk, double fcalowpppi, int pfvfoxacde, int uynlhbkdvbkxee) {
	string gfdyoglxkrdu = "vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw";
	if (string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw") != string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw")) {
		int mrkypl;
		for (mrkypl = 3; mrkypl > 0; mrkypl--) {
			continue;
		}
	}
	if (string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw") == string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw")) {
		int qjfdd;
		for (qjfdd = 17; qjfdd > 0; qjfdd--) {
			continue;
		}
	}
	if (string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw") == string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw")) {
		int rpkcabmyoy;
		for (rpkcabmyoy = 24; rpkcabmyoy > 0; rpkcabmyoy--) {
			continue;
		}
	}
	if (string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw") != string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw")) {
		int rvwngcgy;
		for (rvwngcgy = 82; rvwngcgy > 0; rvwngcgy--) {
			continue;
		}
	}
	if (string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw") == string("vpgygpjtyeoteckomfhwdtrrzfirpfnelzndnsmxitfdxsgdmgmumwznteqtweaw")) {
		int ytgyttanfc;
		for (ytgyttanfc = 39; ytgyttanfc > 0; ytgyttanfc--) {
			continue;
		}
	}
	return 54016;
}

double gpzyouo::htnmfstjreapmxp(bool ueresvbalw, string jrmwazed, string nezesvmm, string ehwjwaclztd, int jqrgivozsw, bool shsbqj, bool bbnrxceedwyvm, string osncpl, double idsfyvohchft) {
	double pluypgmemalxnn = 36311;
	int hpdqhc = 612;
	if (36311 != 36311) {
		int qh;
		for (qh = 22; qh > 0; qh--) {
			continue;
		}
	}
	if (612 != 612) {
		int wxwyzxv;
		for (wxwyzxv = 17; wxwyzxv > 0; wxwyzxv--) {
			continue;
		}
	}
	if (612 != 612) {
		int llxchyxfkx;
		for (llxchyxfkx = 99; llxchyxfkx > 0; llxchyxfkx--) {
			continue;
		}
	}
	if (36311 != 36311) {
		int qbzznlg;
		for (qbzznlg = 89; qbzznlg > 0; qbzznlg--) {
			continue;
		}
	}
	if (612 != 612) {
		int cvi;
		for (cvi = 13; cvi > 0; cvi--) {
			continue;
		}
	}
	return 539;
}

double gpzyouo::unlajscyqxvhclbtpmxuayne(int mctfqn) {
	return 61486;
}

int gpzyouo::bmvslfypdtykmtcqz(int afnejzurflrp, double rdbhvqxckl, bool mcnfjcvquxvm, string dryiodh) {
	bool zljpeyvmzr = false;
	double ypsbboiawlmlyhf = 12916;
	if (false != false) {
		int hh;
		for (hh = 4; hh > 0; hh--) {
			continue;
		}
	}
	return 38774;
}

double gpzyouo::uzzewujspqedpurba(double dxhlymvijmv, bool hdazmasit, int cowdzbefyymnsy) {
	int eriucrizgpudl = 579;
	int leyva = 1843;
	double ygjbxvzuowzy = 78317;
	int itnnysjjygve = 4548;
	if (579 != 579) {
		int nmx;
		for (nmx = 39; nmx > 0; nmx--) {
			continue;
		}
	}
	if (4548 != 4548) {
		int meflqlvb;
		for (meflqlvb = 3; meflqlvb > 0; meflqlvb--) {
			continue;
		}
	}
	if (4548 == 4548) {
		int tfbpll;
		for (tfbpll = 65; tfbpll > 0; tfbpll--) {
			continue;
		}
	}
	return 41669;
}

double gpzyouo::hqomgfuqgxtlip(bool bspotvyvfqxs, double uzfjdblibaflr, double jzxxcj, bool msjiyeelgrfor) {
	int facjraonxtbtup = 0;
	string nbtagavlzh = "xdk";
	bool okbwzhunavzo = false;
	int giruc = 5410;
	double pubpyhsi = 47134;
	int enbdnjmoufx = 6331;
	if (5410 != 5410) {
		int uvgrfdlu;
		for (uvgrfdlu = 44; uvgrfdlu > 0; uvgrfdlu--) {
			continue;
		}
	}
	if (6331 == 6331) {
		int eba;
		for (eba = 81; eba > 0; eba--) {
			continue;
		}
	}
	if (47134 != 47134) {
		int vitssf;
		for (vitssf = 42; vitssf > 0; vitssf--) {
			continue;
		}
	}
	if (0 != 0) {
		int gwhtpejaww;
		for (gwhtpejaww = 13; gwhtpejaww > 0; gwhtpejaww--) {
			continue;
		}
	}
	if (5410 == 5410) {
		int whscwrp;
		for (whscwrp = 73; whscwrp > 0; whscwrp--) {
			continue;
		}
	}
	return 36056;
}

double gpzyouo::gicrdgvlxtxmi() {
	bool vjlitbayc = true;
	string vnihuxlsbumt = "dhdnytgygbixnq";
	double ygogigejaqhj = 53635;
	double dvbqjafp = 36036;
	int zxgyfeuxqpck = 175;
	bool lqofqtbqlgj = true;
	double jdylalokghot = 14681;
	int tnwhquways = 1571;
	if (14681 == 14681) {
		int kk;
		for (kk = 49; kk > 0; kk--) {
			continue;
		}
	}
	if (true != true) {
		int ilfsnjszr;
		for (ilfsnjszr = 19; ilfsnjszr > 0; ilfsnjszr--) {
			continue;
		}
	}
	if (175 == 175) {
		int idy;
		for (idy = 13; idy > 0; idy--) {
			continue;
		}
	}
	return 76044;
}

int gpzyouo::cvcmasbyouaoykzvicmlh(double swctgr, bool qpibf, string ajsrxbm, bool hyewxil) {
	string ieudy = "bqcqjqmwyfu";
	int wpbsr = 2324;
	string eqlco = "fbnirbewhxcabhdoveffrxbupiftgquztvroqjhwvvenvncrimnjwrm";
	int wwjlaqjdtmk = 1430;
	double hpqcaoagcnvanj = 10771;
	string nqwahuh = "wbvwzfvlidnhajomgmepebwqnxaswwsqhkijpoblbmgdkizb";
	if (2324 == 2324) {
		int scr;
		for (scr = 10; scr > 0; scr--) {
			continue;
		}
	}
	if (string("bqcqjqmwyfu") == string("bqcqjqmwyfu")) {
		int rlvyhp;
		for (rlvyhp = 83; rlvyhp > 0; rlvyhp--) {
			continue;
		}
	}
	return 35624;
}

double gpzyouo::lpmjckkyfsjrhtw(int bnursxltowpy, bool btwwjmydqaqr, double swujqtqqqe, double ewaryseiwvulyuf, double xkmpseewhrsphv, int ipjowojset, int ddnmwodwuv, double gndciud) {
	bool vrbhdmdfv = true;
	bool uynfidsxhcw = true;
	double xhsarbcqrnax = 7061;
	bool hwzhfzbo = true;
	bool csiytovbq = true;
	double vgqffmeeuuyms = 34210;
	string hwxmlsnlh = "pnlrklrltskdctel";
	double jmmdwfrtvmgn = 69331;
	double wiesihefdvzha = 11892;
	bool tddlnhfuf = false;
	if (false != false) {
		int jwvhxzrz;
		for (jwvhxzrz = 4; jwvhxzrz > 0; jwvhxzrz--) {
			continue;
		}
	}
	if (false != false) {
		int zdqwc;
		for (zdqwc = 54; zdqwc > 0; zdqwc--) {
			continue;
		}
	}
	if (true == true) {
		int mg;
		for (mg = 77; mg > 0; mg--) {
			continue;
		}
	}
	return 80741;
}

bool gpzyouo::eawipivwflnxtigfzj(string hzepbydg, bool jfweulph, bool gmlsbwkvegpj, string clmjrgjt, double ebtrtddntbcan, int xzkmzpmornkeuix, string njpgwrbsnbhmd, double cjmoffkzk, string eqptqnrxt, double uqiepmu) {
	int lcnta = 2413;
	int ypepopddmvnkhk = 3561;
	double cvedukmsthz = 7826;
	string pbfhnnpysiihlrw = "bspvfztxvzdkcgddshtasaojlqugonsb";
	double eimpkaydvyok = 25567;
	bool hfyllidgzfeiw = true;
	bool tkcpkwaydhgr = false;
	bool malijo = false;
	string drolgoeo = "qfpzczecdzsatukatbahhfweccm";
	if (7826 == 7826) {
		int bmv;
		for (bmv = 9; bmv > 0; bmv--) {
			continue;
		}
	}
	return true;
}

bool gpzyouo::vkcdpjayhw(double jgoywywujuuntsz, double acmebjfip, string mefsd, bool toqggptddxot, bool wxkmicgokawlfl) {
	return true;
}

bool gpzyouo::kgyndzugdiswchubmfdctrmor(double xmytgwd, int fpsfaxtbcddbhc, int kqeejxgiuyrckot, string xpzbxgluwy, int cfwreo) {
	double ceokyfgdbbp = 16284;
	if (16284 != 16284) {
		int jna;
		for (jna = 32; jna > 0; jna--) {
			continue;
		}
	}
	if (16284 != 16284) {
		int aiixrpzwvz;
		for (aiixrpzwvz = 0; aiixrpzwvz > 0; aiixrpzwvz--) {
			continue;
		}
	}
	return true;
}

void gpzyouo::sivjumdduif(string rxpyyyfsrcd, bool whwduceuwun) {
	bool ngbdkmz = true;
	if (true == true) {
		int nn;
		for (nn = 17; nn > 0; nn--) {
			continue;
		}
	}

}

int gpzyouo::vwebrranxfdpdrjttukg(double qlnfdrlh, int rmwegpgjufppjak, int wcwnnagdam, string hxixw) {
	double nbxjykbzpsiq = 4532;
	string ltdkywxgdttfs = "bgualamncujjxjtxiuxxpahnwphucadugzwhtxnzlmorymxd";
	string ugxosl = "qaa";
	int rqekkgtrge = 1229;
	double orgzn = 24602;
	bool nqssyoevehsbbn = false;
	if (false != false) {
		int hgax;
		for (hgax = 53; hgax > 0; hgax--) {
			continue;
		}
	}
	if (4532 == 4532) {
		int fso;
		for (fso = 0; fso > 0; fso--) {
			continue;
		}
	}
	if (string("qaa") == string("qaa")) {
		int hv;
		for (hv = 48; hv > 0; hv--) {
			continue;
		}
	}
	return 99959;
}

gpzyouo::gpzyouo() {
	this->hqomgfuqgxtlip(false, 22738, 10439, true);
	this->gicrdgvlxtxmi();
	this->cvcmasbyouaoykzvicmlh(18202, true, string("dpmekwpxauldjpxyfwfqiibshm"), false);
	this->lpmjckkyfsjrhtw(3887, false, 73224, 13365, 9637, 845, 2231, 41884);
	this->eawipivwflnxtigfzj(string("tsmliyudgfnszhutbnzmkvsgyubetjwbirmrxgebnmisuxnzalflfttvjhswdeltvt"), false, false, string("e"), 5192, 4139, string("jfairyeonjeqmcnqwyujtfeajvnkwccqsgzwwpzrmbnhvnlwkkqlujespokvxjhqwfygcbfw"), 39445, string("jufkuranerfuguedmgpqsamfuceofxxmvurunjkxqsyjtmuyrzcqbqlhfhotmq"), 66916);
	this->vkcdpjayhw(72967, 52855, string("aqvhzlnmmjfbznkripswygmtkvvstsezjfgswoiebcfjrtrwsxvzulntjnwrrfuggzqowlkstepalblukuqohddjfr"), false, false);
	this->kgyndzugdiswchubmfdctrmor(4926, 264, 561, string("fyvlraimudjgqqm"), 6821);
	this->sivjumdduif(string("gttdpzurdakbsqouxnilhxgmwocdqusiknkfiqmsvcdqqlvwmgmfganm"), false);
	this->vwebrranxfdpdrjttukg(21184, 1764, 2706, string("ybjnepohqrzydmeybzwhamhxyrtmycjbenkxpxnobu"));
	this->fuqkrmokftbpywiqeatrwfuf(6039, 564, string("twlifrwxtaakrjpgpcfjxoawhiudfphszgpmykvxfduabgyeauvoqgolbvaardyhnvdkycfkoibopinssyidzgjrdwizp"), true);
	this->eenzrcrleacuszyoyhl(false, 23561, 8068, string("gixwjfnqjtgrhvzcmdhd"), 35806, string("rnvpkhyeeptahrspihhntvb"), 1086, string("eagarbelfxuewjytitojtanvkpcssznqbjrrpdkr"), string("bmqbentouhqvnkghddfjdkcszpdwujskwjacbqulcubybuhcivhdqmmqqry"), 42784);
	this->abrkjajivlm(true, 10777, 46016, true, 20788, 10409, 787, 5327);
	this->htnmfstjreapmxp(true, string("ssxmysoorjgzplnjqsxzsyhclaiiziolxhrpxhpcdfuiurmxnqhzmrfl"), string("bcbaxvwgjmryzkpmxyqejdwysyrfjzbtioaiwmpgwmesuqmhvrggejpauxhsxzsyljvjjaqilqxnexfrjwhs"), string("bixhaucjdocnhqodsyvuccyojuypzpmiitcbbazlzgdbwasmtcemd"), 1069, true, true, string("fzielnyaylbedplwwjeridqrptarbkoaplpqmkfncffdbudtvouyianpbezsuowwkfgwgmzfweyos"), 3790);
	this->unlajscyqxvhclbtpmxuayne(1091);
	this->bmvslfypdtykmtcqz(1436, 83807, true, string("qybaumzbjbcfyhtqtcwebqdgamaapoyvgkbjrqptyjqlrawrairdadky"));
	this->uzzewujspqedpurba(15318, true, 2073);
	this->glhvezmwdsuj(2144, 1035, 3179, 8458);
	this->fionmiyfonemsjb(false, 81, 10695);
	this->zdwyuigdfwbwvswtdiqxxseee(6112, 24043, string("lxvktomvymzmjttsbmdfvtzmkuibpxczzbbfxfphdoopiwjosydxwkrdykhelcxxlcvpjzrqwlmhjuhxzk"), 23494);
	this->bbvdbqxjjevnxx(25871);
	this->xncdiestdfwuesljylhddjb(2570, 10450, true, true, 17706, string("zhqzutyaczxrljgdywkfngvphbfuhbphliprweteikaqnlfwean"), 53025);
	this->qvqbwovdypaxuzizufh(string("m"));
	this->uypuztcqxlbxbokr();
	this->wbmhgivrnvnkpd(true, string("yw"), 1859, string("gdhgcwyqwzogowgiibvbmkrkfgezbgkbfmzdupdfmurpwqdsqesasgrclotlxrqcqztkjogpqcxuwvoaodrbe"), true, 37240, 2836);
	this->xmjkbdorcjyha(1677, 25975, string("gzloawpndlycgurngitsvujrjmlgaonjtbebuziulziraqtsohszgacstwcasnygksujcsocqjrelob"), 3874, 6555, string("rvdyqzguacavjknfznrpeakxsvjedeppemxwnhcrqkwdcmbclgtxseafqlzjo"), 193, 4043);
}







































































































































































































































