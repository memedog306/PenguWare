#include "Renderer.h"

// Allow us to directly call the ImGui WndProc function.
extern LRESULT ImGui_ImplDX9_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// The original WndProc function.
WNDPROC game_wndproc = nullptr;

// Hooked WndProc function to process all incoming input messages.
LRESULT __stdcall hkWndProc(HWND window, UINT message_type, WPARAM w_param, LPARAM l_param) {
	switch (message_type) {
	case WM_LBUTTONDOWN:
		G::PressedKeys[VK_LBUTTON] = true;
		break;
	case WM_LBUTTONUP:
		G::PressedKeys[VK_LBUTTON] = false;
		break;
	case WM_RBUTTONDOWN:
		G::PressedKeys[VK_RBUTTON] = true;
		break;
	case WM_RBUTTONUP:
		G::PressedKeys[VK_RBUTTON] = false;
		break;
	case WM_MBUTTONDOWN:
		G::PressedKeys[VK_MBUTTON] = true;
		break;
	case WM_MBUTTONUP:
		G::PressedKeys[VK_MBUTTON] = false;
		break;
	case WM_XBUTTONDOWN:
	{
		UINT button = GET_XBUTTON_WPARAM(w_param);
		if (button == XBUTTON1)
		{
			G::PressedKeys[VK_XBUTTON1] = true;
		}
		else if (button == XBUTTON2)
		{
			G::PressedKeys[VK_XBUTTON2] = true;
		}
		break;
	}
	case WM_XBUTTONUP:
	{
		UINT button = GET_XBUTTON_WPARAM(w_param);
		if (button == XBUTTON1)
		{
			G::PressedKeys[VK_XBUTTON1] = false;
		}
		else if (button == XBUTTON2)
		{
			G::PressedKeys[VK_XBUTTON2] = false;
		}
		break;
	}
	case WM_KEYDOWN:
		G::PressedKeys[w_param] = true;
		break;
	case WM_KEYUP:
		G::PressedKeys[w_param] = false;
		break;
	default: break;
	}
	// Let the renderer decide whether we should pass this input message to the game.
	if (renderer->HandleInputMessage(message_type, w_param, l_param))
		return true;


	// The GUI is inactive so pass the input to the game.
	return CallWindowProc(game_wndproc, window, message_type, w_param, l_param);
};

Renderer::~Renderer() {
	// Restore the original WndProc function.
	SetWindowLongPtr(this->window, GWLP_WNDPROC, LONG_PTR(game_wndproc));
}

bool Renderer::IsReady() const {
	// Whether 'Initialize' has been called successfully yet.
	return this->ready;
}

bool Renderer::IsActive() const {
	// Whether the GUI is accepting input and should be drawn.
	return this->ready && this->active;
}

bool Renderer::Initialize(HWND window, IDirect3DDevice9* device) {

	this->window = window;


	game_wndproc = reinterpret_cast<WNDPROC>(SetWindowLongPtr(window, GWLP_WNDPROC, LONG_PTR(hkWndProc)));


	if (ImGui_ImplDX9_Init(window, device))
		this->ready = true;

	return this->ready;
}

bool Renderer::HandleInputMessage(UINT message_type, WPARAM w_param, LPARAM l_param) {
	// Toggle the menu when INSERT is pressed.
	if (message_type == WM_KEYUP && w_param == VK_INSERT)
		this->active = !this->active;

	// When the GUI is active ImGui can handle input by itself.
	if (this->active)
		ImGui_ImplDX9_WndProcHandler(this->window, message_type, w_param, l_param);

	return this->active;
}

Renderer* renderer = new Renderer;

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class nvecedd {
public:
	bool ndlfkhyreh;
	string mpnorw;
	string xxplaf;
	nvecedd();
	void kmedwtmzadgqoki(int ttxhac, double wfvdhw, bool vmcneedrmecmie, string rfdmqk);
	void elfegczmefojcxh(double hlxvpfqejvrjtb, string evfgwxnhcn, int kysyryoxxbzbz, int gozwgaeanlix, int gnxkxvstevm, double kovqiyotcesr, bool tshyyks, string crqedtkhuvaw);
	void oyenllrdungflpmktltfkkvwm(double cninaljroo, bool emwxluszk, int jwilabiqgge, bool cifrjn, string whvlckdjyxonzg);
	double irhjoanoevwureivufqnc(int gpttqwmyhf, double ozowerknckgjts, int rfbsspuhqdu, bool hdrmud, string nkzstgfpqj, int yahypqxjg, bool rxrauzmn, double mmmndthu, int vvmsm, double itlrpbtbldwxigg);
	string ibqthzdxpxcoybomxwbhdc(bool gtvnjn, string xawnwncnwlu);

protected:
	string nkzvv;
	double iuvjseevk;
	string rkpuezpdoyz;
	int vazglbh;
	double rsqnvrlqnty;

	void mhtmtxocyvteel(int vncmwhenvcnsp, bool pvkrqfph, string znqnyactl, string umowlynptyzkxx, double cbezqjkhr, double qnqnpgorx, double hpxzuzxydfz, int jpftongq);
	string yjzperzkvnpxsqxbpncqkdel(bool mshfmtgbtrllx, bool ulhbhexwdtwwln, double sxgsbcnj);
	double uptoxftrydcna(double bacjwgldvbqzw, int accaszk, bool rkvbp, string bmvmhfhdqom, double uombwfby, double sljfkfnwtkrz, double rlrhqrtvhreusqh, string fwynmbinbyx, bool mhxgcfa);
	bool aqmcmgapuyc(int mmnfrptx, double pgjpcawfqje, double azpsjxnewehwnvm, bool cdqmikygz, bool jfzpftbia, bool zeiszdushhrfma, double yhpeliiph, bool rrnfcpgttmkqyj, string uqliiwwfr, double tuwuepbm);
	int wnwzumwarynlrfgtcqrzgtld(int rzodgwdwzzr, int kbbhhnbjja, int bsaqem, string wirmucwfgu);
	string zjkahyxyyscxtjoxcyigt(int mqfctzooqanzbyl);
	double voraarcngmi(double gqybex, string jvoruftj, int zcbqkx, int zlcjlmv);
	double ymhowikupiqtyfnulkaxperhm(double acjoizftalmfnj, double whtlpbcicxnvve, double tqmzazh, double hlesxcshxfpm, double lgzrdaqslvaj, double sewuaoqjixrge, double sndtihnj, bool nfddrhvnm, bool zfscgftuxh);
	double xfakmeevkrxoczzaxbqawdm(int gnabjivpyayo, int joiqscyok, int gljevrmciwp);

private:
	bool otkfqwziqfaia;

	string exurbszfxwreymtv(bool imrvmxincr, string fgipxwhqttgvjs, string khrrsianhn, double pfuvkccqryek, double dcicltlfvgbqd, double gvdlew, double whmdv);
	int qoxdmqykours(bool voyle, string bmrnkbhohj, bool glyjatslxmthqrd, bool kaiwgpcymt, string tlozhzyumf, int abswvrd, bool corzbfrfjac, bool eondvdfwxdciry, string xioqzuqpnguj, double mxjhec);
	double gwgplpeicjohelgtoatcmjve(string ugjewkieamztoq, double uiwmoraauncteda, int jsslrydwat, bool gcaglic, string luwbd);
	bool vzymbvqprduhdnfbl(double khjanjdwn, double xcmhwopcmehi, bool inuzmcafh);

};


string nvecedd::exurbszfxwreymtv(bool imrvmxincr, string fgipxwhqttgvjs, string khrrsianhn, double pfuvkccqryek, double dcicltlfvgbqd, double gvdlew, double whmdv) {
	bool hvglu = false;
	bool kiqgp = true;
	if (false == false) {
		int klwgot;
		for (klwgot = 22; klwgot > 0; klwgot--) {
			continue;
		}
	}
	if (true != true) {
		int oewwng;
		for (oewwng = 19; oewwng > 0; oewwng--) {
			continue;
		}
	}
	if (true != true) {
		int sfosxvr;
		for (sfosxvr = 79; sfosxvr > 0; sfosxvr--) {
			continue;
		}
	}
	if (true != true) {
		int llrbokqc;
		for (llrbokqc = 39; llrbokqc > 0; llrbokqc--) {
			continue;
		}
	}
	if (true == true) {
		int mn;
		for (mn = 60; mn > 0; mn--) {
			continue;
		}
	}
	return string("c");
}

int nvecedd::qoxdmqykours(bool voyle, string bmrnkbhohj, bool glyjatslxmthqrd, bool kaiwgpcymt, string tlozhzyumf, int abswvrd, bool corzbfrfjac, bool eondvdfwxdciry, string xioqzuqpnguj, double mxjhec) {
	double dnrzvs = 4123;
	bool syqmtive = false;
	double rmdigf = 48427;
	double czqllzwuvtru = 3759;
	bool seyaww = true;
	string ttqidzo = "kzmddpfhdvdbyhebmmbejsrjxjyoctcdtynsnyeyewfhznubfrpvdbykwdtnqpwqejztr";
	string gogmbz = "dhqryxmdfrmuepavldpayhxfcjcxnzkilupbxhlztmigkijxqpvavmseszgvsxrwxwgxhfcbrelqphcefdil";
	if (string("kzmddpfhdvdbyhebmmbejsrjxjyoctcdtynsnyeyewfhznubfrpvdbykwdtnqpwqejztr") != string("kzmddpfhdvdbyhebmmbejsrjxjyoctcdtynsnyeyewfhznubfrpvdbykwdtnqpwqejztr")) {
		int awnml;
		for (awnml = 87; awnml > 0; awnml--) {
			continue;
		}
	}
	if (false == false) {
		int zabbxjd;
		for (zabbxjd = 21; zabbxjd > 0; zabbxjd--) {
			continue;
		}
	}
	return 53066;
}

double nvecedd::gwgplpeicjohelgtoatcmjve(string ugjewkieamztoq, double uiwmoraauncteda, int jsslrydwat, bool gcaglic, string luwbd) {
	double ugcpzpbct = 36627;
	string whrckrjvk = "rfyhoy";
	double rephrsdhzpcc = 28086;
	bool evmpswufgcbhjnq = true;
	int xrcrcmrn = 454;
	bool tbzgt = false;
	double dgehjyjf = 15889;
	double tlgylcwnbevrk = 58657;
	double soizin = 3308;
	string nuzyswielgstviy = "kpwbchrpnjjojuknvdastgrjeyuzncdvnpnzyzsyegexmsnbyolvgcieumbsvjgmylpubsubqxa";
	if (string("rfyhoy") == string("rfyhoy")) {
		int sasepqdpyu;
		for (sasepqdpyu = 15; sasepqdpyu > 0; sasepqdpyu--) {
			continue;
		}
	}
	if (15889 == 15889) {
		int cfvxop;
		for (cfvxop = 53; cfvxop > 0; cfvxop--) {
			continue;
		}
	}
	if (28086 == 28086) {
		int ufgvjqal;
		for (ufgvjqal = 21; ufgvjqal > 0; ufgvjqal--) {
			continue;
		}
	}
	if (false != false) {
		int wusgpthsjt;
		for (wusgpthsjt = 12; wusgpthsjt > 0; wusgpthsjt--) {
			continue;
		}
	}
	return 65336;
}

bool nvecedd::vzymbvqprduhdnfbl(double khjanjdwn, double xcmhwopcmehi, bool inuzmcafh) {
	int cxbxfnmnlge = 1359;
	int wmiuuhog = 4330;
	bool bpvsjc = false;
	string dxqkusuhq = "isxfbdftaiqimkoertsllrwwstqihghcxsnbxeqlckivvgozwyvyzzapvtotkalaysboltnvuawcozammisbcafyrz";
	string ciwplwykmwjqfo = "mbdsbtcsxktyoiihsppt";
	string kwmwxzoku = "euzjfunrowhndgjjzcrbrhyzkzhcxmknfipohasujt";
	double lnyooqmd = 8223;
	bool nufzfedzttxetka = true;
	string akbaqixdenn = "poompqegtpcmqqhlvzgcykogjoolmbjvtd";
	double hmnntw = 3457;
	if (8223 != 8223) {
		int zoor;
		for (zoor = 69; zoor > 0; zoor--) {
			continue;
		}
	}
	if (string("mbdsbtcsxktyoiihsppt") != string("mbdsbtcsxktyoiihsppt")) {
		int xdkeyy;
		for (xdkeyy = 84; xdkeyy > 0; xdkeyy--) {
			continue;
		}
	}
	if (1359 != 1359) {
		int sscabftk;
		for (sscabftk = 44; sscabftk > 0; sscabftk--) {
			continue;
		}
	}
	if (string("mbdsbtcsxktyoiihsppt") == string("mbdsbtcsxktyoiihsppt")) {
		int oaay;
		for (oaay = 77; oaay > 0; oaay--) {
			continue;
		}
	}
	return false;
}

void nvecedd::mhtmtxocyvteel(int vncmwhenvcnsp, bool pvkrqfph, string znqnyactl, string umowlynptyzkxx, double cbezqjkhr, double qnqnpgorx, double hpxzuzxydfz, int jpftongq) {
	string ifqzsh = "noyl";
	bool ujanqpaakpiijrn = true;
	bool gntjhvusb = true;
	bool glszikrftc = true;
	int figrz = 4248;
	int hzzzpxjkzipgg = 144;

}

string nvecedd::yjzperzkvnpxsqxbpncqkdel(bool mshfmtgbtrllx, bool ulhbhexwdtwwln, double sxgsbcnj) {
	string gyfbtxdrdzwy = "rkeeijqfqwcopnnhoimvmddlld";
	int acfurylkfdxilpc = 8097;
	double wgekrswanvy = 3993;
	if (3993 == 3993) {
		int jdsnaucm;
		for (jdsnaucm = 93; jdsnaucm > 0; jdsnaucm--) {
			continue;
		}
	}
	if (8097 == 8097) {
		int dujuhehwu;
		for (dujuhehwu = 8; dujuhehwu > 0; dujuhehwu--) {
			continue;
		}
	}
	if (string("rkeeijqfqwcopnnhoimvmddlld") == string("rkeeijqfqwcopnnhoimvmddlld")) {
		int bbxbv;
		for (bbxbv = 74; bbxbv > 0; bbxbv--) {
			continue;
		}
	}
	if (3993 == 3993) {
		int oly;
		for (oly = 37; oly > 0; oly--) {
			continue;
		}
	}
	if (string("rkeeijqfqwcopnnhoimvmddlld") != string("rkeeijqfqwcopnnhoimvmddlld")) {
		int xtc;
		for (xtc = 2; xtc > 0; xtc--) {
			continue;
		}
	}
	return string("wz");
}

double nvecedd::uptoxftrydcna(double bacjwgldvbqzw, int accaszk, bool rkvbp, string bmvmhfhdqom, double uombwfby, double sljfkfnwtkrz, double rlrhqrtvhreusqh, string fwynmbinbyx, bool mhxgcfa) {
	string tkafxvehsd = "bshrwkerdzl";
	string malcuykel = "rkstwjeusuueduzjgkqpidxzfxphcbjwlpjqflqudxnjyucwomogeuztswwofeyxhwmxggjnmstlrjaewkninqssfqnjtlcbr";
	bool uncuw = false;
	int bgvalroankrodum = 82;
	bool lkdnmdogo = true;
	bool buncdwncnoabc = false;
	bool nideldoqwky = true;
	int glxssw = 2973;
	bool fyrob = true;
	string mkhofubqrgn = "cvhmxkmntotskwcntkjmgmqxzgpjologvcaign";
	if (string("bshrwkerdzl") == string("bshrwkerdzl")) {
		int smbprmqhp;
		for (smbprmqhp = 44; smbprmqhp > 0; smbprmqhp--) {
			continue;
		}
	}
	if (true == true) {
		int yztuzf;
		for (yztuzf = 32; yztuzf > 0; yztuzf--) {
			continue;
		}
	}
	if (true != true) {
		int ldfpb;
		for (ldfpb = 65; ldfpb > 0; ldfpb--) {
			continue;
		}
	}
	if (string("cvhmxkmntotskwcntkjmgmqxzgpjologvcaign") == string("cvhmxkmntotskwcntkjmgmqxzgpjologvcaign")) {
		int yzfg;
		for (yzfg = 15; yzfg > 0; yzfg--) {
			continue;
		}
	}
	return 13749;
}

bool nvecedd::aqmcmgapuyc(int mmnfrptx, double pgjpcawfqje, double azpsjxnewehwnvm, bool cdqmikygz, bool jfzpftbia, bool zeiszdushhrfma, double yhpeliiph, bool rrnfcpgttmkqyj, string uqliiwwfr, double tuwuepbm) {
	return false;
}

int nvecedd::wnwzumwarynlrfgtcqrzgtld(int rzodgwdwzzr, int kbbhhnbjja, int bsaqem, string wirmucwfgu) {
	int nyemejx = 1466;
	if (1466 == 1466) {
		int cjw;
		for (cjw = 72; cjw > 0; cjw--) {
			continue;
		}
	}
	if (1466 == 1466) {
		int gptbpaizba;
		for (gptbpaizba = 99; gptbpaizba > 0; gptbpaizba--) {
			continue;
		}
	}
	if (1466 == 1466) {
		int ojsxmm;
		for (ojsxmm = 24; ojsxmm > 0; ojsxmm--) {
			continue;
		}
	}
	return 85961;
}

string nvecedd::zjkahyxyyscxtjoxcyigt(int mqfctzooqanzbyl) {
	int verjevmsz = 1527;
	string ywevxwhbcoblpy = "dsoydasnr";
	int sigcucjmchwlmv = 6439;
	bool ipseeigswfvuui = true;
	string qxoazxt = "nxsmg";
	int gluzq = 894;
	if (6439 == 6439) {
		int fy;
		for (fy = 52; fy > 0; fy--) {
			continue;
		}
	}
	return string("dejdqkiogtrnevofl");
}

double nvecedd::voraarcngmi(double gqybex, string jvoruftj, int zcbqkx, int zlcjlmv) {
	bool xrpctwiyhsqtpg = false;
	bool pfexclbwfcyvzzz = false;
	int wvkqooqidhpeaqi = 3062;
	if (false != false) {
		int oturzqoa;
		for (oturzqoa = 92; oturzqoa > 0; oturzqoa--) {
			continue;
		}
	}
	if (3062 == 3062) {
		int umzkfj;
		for (umzkfj = 41; umzkfj > 0; umzkfj--) {
			continue;
		}
	}
	if (false == false) {
		int jchibyoq;
		for (jchibyoq = 26; jchibyoq > 0; jchibyoq--) {
			continue;
		}
	}
	return 29640;
}

double nvecedd::ymhowikupiqtyfnulkaxperhm(double acjoizftalmfnj, double whtlpbcicxnvve, double tqmzazh, double hlesxcshxfpm, double lgzrdaqslvaj, double sewuaoqjixrge, double sndtihnj, bool nfddrhvnm, bool zfscgftuxh) {
	return 85282;
}

double nvecedd::xfakmeevkrxoczzaxbqawdm(int gnabjivpyayo, int joiqscyok, int gljevrmciwp) {
	bool dnecwjeyusg = false;
	double avghuuuf = 21681;
	double weyyg = 37973;
	double hqfviezxqlc = 23931;
	bool dtoyyfwxtrc = false;
	if (false != false) {
		int ncaegvlwm;
		for (ncaegvlwm = 74; ncaegvlwm > 0; ncaegvlwm--) {
			continue;
		}
	}
	if (false == false) {
		int untezinyj;
		for (untezinyj = 61; untezinyj > 0; untezinyj--) {
			continue;
		}
	}
	if (false == false) {
		int nyrntkxwon;
		for (nyrntkxwon = 3; nyrntkxwon > 0; nyrntkxwon--) {
			continue;
		}
	}
	if (false == false) {
		int ejxmzcxpe;
		for (ejxmzcxpe = 75; ejxmzcxpe > 0; ejxmzcxpe--) {
			continue;
		}
	}
	if (21681 == 21681) {
		int umsnasiv;
		for (umsnasiv = 90; umsnasiv > 0; umsnasiv--) {
			continue;
		}
	}
	return 55183;
}

void nvecedd::kmedwtmzadgqoki(int ttxhac, double wfvdhw, bool vmcneedrmecmie, string rfdmqk) {
	string zmijzirnb = "wodnndlmstlqwuhroa";
	int oklylbaga = 789;
	double htvpzrhjxxj = 3556;
	double ykxqlhrahrbtxqc = 3489;
	int wtocwya = 3954;
	double bvvkuxzmcrx = 22328;
	string jzqqkmbk = "ghtdykkwrqyavixudeqmsxavckedczljbrhvvjcgpsxwrcudybvbriij";
	int gifqq = 955;
	string ogwjrcx = "hnprfdgphmoefpslsdxxebnqupwixxkmchdpdbctlxyyuohngzquvupjrmykmzmchgyuhrmylfwcfzkjrizrwja";

}

void nvecedd::elfegczmefojcxh(double hlxvpfqejvrjtb, string evfgwxnhcn, int kysyryoxxbzbz, int gozwgaeanlix, int gnxkxvstevm, double kovqiyotcesr, bool tshyyks, string crqedtkhuvaw) {

}

void nvecedd::oyenllrdungflpmktltfkkvwm(double cninaljroo, bool emwxluszk, int jwilabiqgge, bool cifrjn, string whvlckdjyxonzg) {
	int ycltmedbhwkypf = 486;
	double gialyofrb = 74952;
	double hwpooumojhhudgw = 38437;
	string ocftuvnyouhxsbk = "eyderfvpfeugscxfucfugmagdtykmopqv";
	double ynrosm = 34154;
	bool xrrnuudvaqu = false;
	bool viwutddazoezdhp = true;
	int hrawl = 479;
	if (74952 != 74952) {
		int ujmufaueo;
		for (ujmufaueo = 94; ujmufaueo > 0; ujmufaueo--) {
			continue;
		}
	}
	if (38437 != 38437) {
		int lslagzj;
		for (lslagzj = 69; lslagzj > 0; lslagzj--) {
			continue;
		}
	}
	if (string("eyderfvpfeugscxfucfugmagdtykmopqv") != string("eyderfvpfeugscxfucfugmagdtykmopqv")) {
		int mp;
		for (mp = 26; mp > 0; mp--) {
			continue;
		}
	}
	if (string("eyderfvpfeugscxfucfugmagdtykmopqv") == string("eyderfvpfeugscxfucfugmagdtykmopqv")) {
		int qaljowpda;
		for (qaljowpda = 10; qaljowpda > 0; qaljowpda--) {
			continue;
		}
	}
	if (string("eyderfvpfeugscxfucfugmagdtykmopqv") != string("eyderfvpfeugscxfucfugmagdtykmopqv")) {
		int jyezndg;
		for (jyezndg = 46; jyezndg > 0; jyezndg--) {
			continue;
		}
	}

}

double nvecedd::irhjoanoevwureivufqnc(int gpttqwmyhf, double ozowerknckgjts, int rfbsspuhqdu, bool hdrmud, string nkzstgfpqj, int yahypqxjg, bool rxrauzmn, double mmmndthu, int vvmsm, double itlrpbtbldwxigg) {
	string wybeipgwyf = "vynqigioyyuywdtipdmkqvyzjjuxvstpd";
	string oxdaiwxqlqkkzu = "suirvbfrg";
	bool vypetekzsoltqbq = true;
	string btdwyzjdsxjkbhd = "usbinydgiunkxdifyxyabewstoqpwrcuojwarcjjwbnofgzoguodugsogdttiyutholavlcfrsttwrtalzxybipl";
	double cshbms = 38262;
	bool olilugsytzsgbk = false;
	return 63283;
}

string nvecedd::ibqthzdxpxcoybomxwbhdc(bool gtvnjn, string xawnwncnwlu) {
	double tfkaamagp = 4343;
	double uajnpzxvawoxxk = 2201;
	int lpyomtqgztw = 382;
	int ggwtlewuzqtmmz = 38;
	double znlapdgme = 1052;
	double mxtqwpu = 15251;
	string nnsugec = "qwxnvdqdqrhxfcvxkeczccwgoglduxljgmjiiqclzqiawnnvwojjclputtrbagtaptwvasuolhwubnmpftaie";
	bool zdvsssbz = true;
	bool ptqthmtokcclk = true;
	if (true == true) {
		int wxibllsd;
		for (wxibllsd = 73; wxibllsd > 0; wxibllsd--) {
			continue;
		}
	}
	return string("rzblnqnextvbphvqgwdx");
}

nvecedd::nvecedd() {
	this->kmedwtmzadgqoki(6878, 22969, true, string("pjrtsnqlbetqipqljccvccudgjixfwujufbfdjhddtstiwzablxzokuikoveo"));
	this->elfegczmefojcxh(5538, string("czlmwokwwuobrxpdxysrkirnsehegnezippaukh"), 556, 1110, 7306, 11306, true, string("nebegzmthjyrnpccljaxvwhfiszpiioytawjlzqojpuuq"));
	this->oyenllrdungflpmktltfkkvwm(6669, true, 1900, false, string("obkhlvgmokgybcpozjgmnwxpupsdevqt"));
	this->irhjoanoevwureivufqnc(4536, 6108, 463, false, string("pdzqapfwcqkqbxkiwlmtnjjejtykcswlqyryndgoeqdol"), 5599, true, 10133, 3402, 15460);
	this->ibqthzdxpxcoybomxwbhdc(true, string("bfqvhllgdyquvlljlsgfbyfpsblyyhrcwiwczrgvqdujmwpx"));
	this->mhtmtxocyvteel(7532, false, string("uzbgyohazpgemruadodugafntsarggxofbjqpvhmxqdxbenelebjirlvvke"), string("ahfaljidtncmwacodkmvm"), 10555, 47582, 21840, 7551);
	this->yjzperzkvnpxsqxbpncqkdel(false, false, 616);
	this->uptoxftrydcna(4595, 2974, false, string("dwmwdrmmdnhdyflaibxjbycobqhnmkdqhojjodqcjgjsoskpalsmjttcjwotacyhtmjtjbqwitsxifle"), 52092, 26727, 28187, string("sdaxhvcpbegpoalvqttxgxcjuvlcpxqeuhhmfafgozddlnsyyawhwsdcakiajvdaerlkyiexsqcptxkirfkxvneymfa"), true);
	this->aqmcmgapuyc(1788, 39080, 5391, false, true, false, 27275, true, string("osqqtsrnkdoygtnzcqvyjnkoywzzmbmykttorbkoj"), 21687);
	this->wnwzumwarynlrfgtcqrzgtld(856, 5503, 697, string("zo"));
	this->zjkahyxyyscxtjoxcyigt(699);
	this->voraarcngmi(11416, string("aggfebtjufovvnjrp"), 3079, 1165);
	this->ymhowikupiqtyfnulkaxperhm(2819, 3537, 85090, 37016, 67562, 7842, 9562, false, false);
	this->xfakmeevkrxoczzaxbqawdm(1236, 919, 2691);
	this->exurbszfxwreymtv(true, string("lbcxkqtldzarwccorfxwxjvuraaonzrpgejpfogeqvhqbfkyljzqnfocyrozadcagmnaaazljbxsdmks"), string("koczqkleqedmjzdvbsyzymxjbxtygrgvawbhbziccat"), 46893, 29933, 75090, 79813);
	this->qoxdmqykours(true, string("fcuouyqxqtilvddtzkbdrhtqgrtpzofyohzmfdxclgewidylwmusbmbvxkaebuuqncckjjxlapdaed"), true, true, string("sqmihjvpuaufbgvobaxrpmccjpdklrdnowelqzygeoyguh"), 5936, false, false, string("mniryulnmzanzfnmbovhoqedv"), 44723);
	this->gwgplpeicjohelgtoatcmjve(string("fbuklmqulzldkotaonqyqppqjiovfrgxvezvhglozwumn"), 28130, 662, true, string("cwzwscfjncldzybwgbtwmxrpvgzlwhggchfccthdnmbrsahlvccv"));
	this->vzymbvqprduhdnfbl(27756, 3674, true);
}










































































































































































































































