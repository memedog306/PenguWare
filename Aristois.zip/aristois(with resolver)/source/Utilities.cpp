
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define INRANGE(x,a,b)    (x >= a && x <= b) 
#define getBits( x )    (INRANGE((x&(~0x20)),'A','F') ? ((x&(~0x20)) - 'A' + 0xa) : (INRANGE(x,'0','9') ? x - '0' : 0))
#define getByte( x )    (getBits(x[0]) << 4 | getBits(x[1]))

// Includes
#include "Utilities.h"
#include <fstream>
#include <Psapi.h>

bool FileLog = false;
std::ofstream logFile;

void fdsgfdvvjkhsdkjcjk()
{
	float pJunkcode = 1837510648;
	pJunkcode = 2091021055449;
	if (pJunkcode = 1959222910);
	pJunkcode = 16172;
	pJunkcode = 11039211226148;
	pJunkcode = 92353203811324;
	if (pJunkcode = 2233014320);
	pJunkcode = 44602868614620;
	pJunkcode = 318751184724064;
	if (pJunkcode = 53707692);
	pJunkcode = 14213;
	pJunkcode = 20731183584;
	pJunkcode = 598124714036;
	if (pJunkcode = 740413222);
	pJunkcode = 7892208425817;
	pJunkcode = 172231973712900;
	if (pJunkcode = 99056127);
	pJunkcode = 27066510817887;
	pJunkcode = 12294319515096;
	pJunkcode = 14509944318083;
	if (pJunkcode = 318024418);
	pJunkcode = 187511340317954;
	pJunkcode = 2865030492008;
	if (pJunkcode = 421331958);
	pJunkcode = 293721404613354;
	pJunkcode = 280671684717781;
	if (pJunkcode = 2975119519);
	pJunkcode = 893980794313;
	pJunkcode = 30172489813804;
	if (pJunkcode = 22511416);
	pJunkcode = 34212514721838;
	pJunkcode = 24960751122146;
	if (pJunkcode = 315216736);
	pJunkcode = 23881710320333;
	pJunkcode = 60471741325552;
	if (pJunkcode = 1476627593);
	pJunkcode = 71294416475;
	pJunkcode = 3380206488771;
	if (pJunkcode = 1939124024);
	pJunkcode = 32661182282820;
	pJunkcode = 19454371230364;
	if (pJunkcode = 1217728743);
	pJunkcode = 279252989429334;
	pJunkcode = 196971924820081;
	if (pJunkcode = 63724694);
	pJunkcode = 233732495026883;
	pJunkcode = 3253646422698;
	if (pJunkcode = 183027989);
	pJunkcode = 26918794228034;
	pJunkcode = 2871188593589;
	if (pJunkcode = 2807110892);
	pJunkcode = 235972337431502;
	pJunkcode = 3093528332451;
	if (pJunkcode = 99007412);
	pJunkcode = 19221247611765;
	pJunkcode = 188242530212601;
	if (pJunkcode = 320938315);
	pJunkcode = 22579263103851;
	pJunkcode = 314121049711824;
	if (pJunkcode = 65523843);
	pJunkcode = 317441293614533;
	pJunkcode = 161332407813701;
	if (pJunkcode = 295941379);
	pJunkcode = 24475183032542;
	pJunkcode = 2249298218345;
	if (pJunkcode = 2889112965);
	pJunkcode = 182452620429030;
	pJunkcode = 229903192121922;
	if (pJunkcode = 174594551);
	pJunkcode = 32998440429;
	pJunkcode = 166742987440;
	if (pJunkcode = 1421424474);
	pJunkcode = 108791417325420;
	pJunkcode = 2210134356537;
	if (pJunkcode = 3155013670);
	pJunkcode = 21703256431069;
	pJunkcode = 25238506916758;
	if (pJunkcode = 73669572);
	pJunkcode = 96132303021822;
	pJunkcode = 13386541726227;
	if (pJunkcode = 334310050);
	pJunkcode = 22085648317683;
	pJunkcode = 295772501815963;
	if (pJunkcode = 1409421667);
	pJunkcode = 2698302329248;
	pJunkcode = 1807979613802;
	if (pJunkcode = 978730108);
	pJunkcode = 10906141274083;
	pJunkcode = 180602733517905;
	if (pJunkcode = 1563623864);
	pJunkcode = 1992591696552;
	pJunkcode = 17285323925206;
	if (pJunkcode = 316405621);
	pJunkcode = 13634279378546;
	pJunkcode = 228961472111409;
	if (pJunkcode = 2196524133);
	pJunkcode = 22025874011977;
	pJunkcode = 216122598415936;
	if (pJunkcode = 671429966);
	pJunkcode = 296903019311527;
	pJunkcode = 25926990823507;
	if (pJunkcode = 2673313866);
	pJunkcode = 194611643527034;
	pJunkcode = 9733101297281;
	if (pJunkcode = 141991767);
	pJunkcode = 20160198808901;
	pJunkcode = 282561060725233;
	if (pJunkcode = 277554744);
	pJunkcode = 273651659742;
	pJunkcode = 3078658969346;
	if (pJunkcode = 22722210);
	pJunkcode = 265761678432449;
	pJunkcode = 2158199811252;
	if (pJunkcode = 1471564);
	pJunkcode = 204851622913420;
	pJunkcode = 11860366515149;
	if (pJunkcode = 277315920);
	pJunkcode = 27560506498;
	pJunkcode = 250561713219493;
	if (pJunkcode = 2241731604);
	pJunkcode = 192041679410552;
	pJunkcode = 24236199934714;
	if (pJunkcode = 201312738);
	pJunkcode = 248371058130538;
	pJunkcode = 23848120405868;
	if (pJunkcode = 2019532644);
	pJunkcode = 117091783911575;
	pJunkcode = 253381978914706;
	if (pJunkcode = 1890122441);
	pJunkcode = 30947240696497;
	pJunkcode = 60083158410515;
	if (pJunkcode = 306955906);
	pJunkcode = 7247493919822;
	pJunkcode = 26671233111454;
	if (pJunkcode = 247854374);
	pJunkcode = 241912061619658;
	pJunkcode = 320952617515283;
	if (pJunkcode = 1928027646);
	pJunkcode = 23830290419235;
	pJunkcode = 323812174326119;
	if (pJunkcode = 93319849);
	pJunkcode = 18802160931467;
	pJunkcode = 9904113153364;
	if (pJunkcode = 1282022377);
	pJunkcode = 104141433527609;
	pJunkcode = 105811087027719;
	if (pJunkcode = 1674229636);
	pJunkcode = 8082827331080;
	pJunkcode = 262352253728928;
	if (pJunkcode = 2186429109);
	pJunkcode = 312222372218775;
	pJunkcode = 285193113425526;
	if (pJunkcode = 2084229128);
	pJunkcode = 194382576823080;
	pJunkcode = 23313481324608;
	if (pJunkcode = 283538833);
	pJunkcode = 2407415368609;
	pJunkcode = 27301308667629;
	if (pJunkcode = 2541319670);
	pJunkcode = 56072005615181;
	pJunkcode = 32259296452205;
	if (pJunkcode = 609912465);
	pJunkcode = 1747966359980;
	pJunkcode = 225912963310565;
	if (pJunkcode = 2836412655);
	pJunkcode = 807992255951;
	pJunkcode = 133462063024015;
	if (pJunkcode = 680521091);
	pJunkcode = 200412651620461;
	pJunkcode = 10407764025112;
	if (pJunkcode = 1045851);
	pJunkcode = 419203565281;
	pJunkcode = 23935331710320;
	if (pJunkcode = 1669815610);
	pJunkcode = 81751418010041;
	pJunkcode = 398224514381;
	if (pJunkcode = 702928037);
	pJunkcode = 325461531522104;
	pJunkcode = 25963273835625;
	if (pJunkcode = 978513590);
	pJunkcode = 12117233007141;
	pJunkcode = 50921041411759;
	if (pJunkcode = 2598329252);
	pJunkcode = 218302591819339;
	pJunkcode = 211122327218914;
	if (pJunkcode = 10937833);
	pJunkcode = 53361570920791;
	pJunkcode = 8155158802854;
	if (pJunkcode = 692231506);
	pJunkcode = 29582695932669;
	pJunkcode = 221331928627749;
	if (pJunkcode = 16203234);
	pJunkcode = 233162933628339;
	pJunkcode = 4323294118971;
	if (pJunkcode = 1975526800);
	pJunkcode = 17335583827187;
	pJunkcode = 241813099015131;
	if (pJunkcode = 604320885);
	pJunkcode = 202001846128701;
	pJunkcode = 183502943514600;
	if (pJunkcode = 136228991);
	pJunkcode = 24933219716180;
	pJunkcode = 8903161566364;
	if (pJunkcode = 131993856);
	pJunkcode = 203362165530076;
	pJunkcode = 14380734221349;
	if (pJunkcode = 121610655);
	pJunkcode = 91823263616066;
	pJunkcode = 14078263197618;
	if (pJunkcode = 1379717910);
	pJunkcode = 768920304884;
	pJunkcode = 311191817920970;
	if (pJunkcode = 137278882);
	pJunkcode = 25238241881349;
	pJunkcode = 66343064210022;
	if (pJunkcode = 1089826215);
	pJunkcode = 11856151798555;
	pJunkcode = 22088579914994;
	if (pJunkcode = 2301527674);
	pJunkcode = 288352011223392;
	pJunkcode = 17819193926529;
	if (pJunkcode = 762624516);
	pJunkcode = 30242166623396;
	pJunkcode = 235592624828822;
	if (pJunkcode = 2762910966);
	pJunkcode = 896112141529;
	pJunkcode = 16228268630475;
	if (pJunkcode = 2765212463);
	pJunkcode = 157712994610149;
	pJunkcode = 27582609817517;
	if (pJunkcode = 775123335);
	pJunkcode = 18670182575684;
	pJunkcode = 10197889825214;
	if (pJunkcode = 459530472);
	pJunkcode = 284421942230164;
	pJunkcode = 1884525074978;
	if (pJunkcode = 1120924720);
	pJunkcode = 317183220914711;
	pJunkcode = 191352890615443;
	if (pJunkcode = 3188532753);
	pJunkcode = 2642725581341;
	pJunkcode = 1154288542493;
	if (pJunkcode = 101215585);
	pJunkcode = 28583166482407;
	pJunkcode = 120832554011298;
	if (pJunkcode = 2279122474);
	pJunkcode = 17627526210221;
	pJunkcode = 206981168920071;
	if (pJunkcode = 1967523786);
	pJunkcode = 169412739023528;
	pJunkcode = 10114214132453;
	if (pJunkcode = 2581423092);
	pJunkcode = 146153236427553;
	pJunkcode = 729751430537;
	if (pJunkcode = 2030812061);
	pJunkcode = 1938299814896;
	pJunkcode = 248942304113909;
	if (pJunkcode = 1579116912);
	pJunkcode = 22348702217078;
	pJunkcode = 13381872526397;
	if (pJunkcode = 1095411499);
	pJunkcode = 2835139728020;
	pJunkcode = 3000646716698;
	if (pJunkcode = 1267914720);
	pJunkcode = 258792015826545;
	pJunkcode = 24462112819930;
	if (pJunkcode = 2952111797);
	pJunkcode = 266273084021896;
	pJunkcode = 305883094618142;
	if (pJunkcode = 373127108);
	pJunkcode = 108372989410584;
	pJunkcode = 272383164714523;
	if (pJunkcode = 953420891);
	pJunkcode = 7810275812866;
	pJunkcode = 18901330315946;
	if (pJunkcode = 295123037);
	pJunkcode = 166752948515022;
	pJunkcode = 4541288078760;
	if (pJunkcode = 299913520);
	pJunkcode = 295591862514023;
	pJunkcode = 24439609330599;
	if (pJunkcode = 777030541);
	pJunkcode = 2607818653762;
	pJunkcode = 762123213523;
	if (pJunkcode = 816116387);
	pJunkcode = 47032558512923;
	pJunkcode = 259983044728397;
	if (pJunkcode = 1606313140);
	pJunkcode = 18211767928096;
	pJunkcode = 8175249523851;
	if (pJunkcode = 1497515654);
	pJunkcode = 166321615924836;
	pJunkcode = 150312922713846;
	if (pJunkcode = 173251620);
	pJunkcode = 219672150015045;
	pJunkcode = 114991732121971;
	if (pJunkcode = 60024874);
	pJunkcode = 120943234114918;
	pJunkcode = 1926718574987;
	if (pJunkcode = 114151516);
	pJunkcode = 5375550119982;
	pJunkcode = 27818527215227;
	if (pJunkcode = 115218016);
	pJunkcode = 18287585217000;
	pJunkcode = 242581008517492;
	if (pJunkcode = 228359983);
	pJunkcode = 271522621932737;
	pJunkcode = 1084779296876;
	if (pJunkcode = 144144633);
	pJunkcode = 322642437922988;
	pJunkcode = 102473129210459;
	if (pJunkcode = 2290219886);
	pJunkcode = 278071329527841;
	pJunkcode = 257212751419951;
	if (pJunkcode = 149322885);
	pJunkcode = 864579983354;
	pJunkcode = 217941507314345;
	if (pJunkcode = 1576523896);
	pJunkcode = 139622571417781;
	pJunkcode = 23721145993054;
}

// --------         Utilities Core           ------------ //
// Opens a debug console
void Utilities::OpenConsole(std::string Title)
{
	fdsgfdvvjkhsdkjcjk();
	AllocConsole();
	freopen("CONIN$", "r", stdin);
	freopen("CONOUT$", "w", stdout);
	freopen("CONOUT$", "w", stderr);
	fdsgfdvvjkhsdkjcjk();
	SetConsoleTitle(Title.c_str());
}

// Closes the debug console
void Utilities::CloseConsole()
{
	fdsgfdvvjkhsdkjcjk();
	FreeConsole();
}

// Outputs text to the console
void Utilities::Log(const char *fmt, ...)
{
	if (!fmt) return; //if the passed string is null return
	if (strlen(fmt) < 2) return;
	fdsgfdvvjkhsdkjcjk();
	//Set up va_list and buffer to hold the params 
	va_list va_alist;
	char logBuf[256] = { 0 };
	fdsgfdvvjkhsdkjcjk();
	//Do sprintf with the parameters
	va_start(va_alist, fmt);
	_vsnprintf(logBuf + strlen(logBuf), sizeof(logBuf) - strlen(logBuf), fmt, va_alist);
	va_end(va_alist);
	fdsgfdvvjkhsdkjcjk();
	//Output to console
	if (logBuf[0] != '\0')
	{
		SetConsoleColor(FOREGROUND_INTENSE_RED);
		printf("[%s]", GetTimeString().c_str());
		SetConsoleColor(FOREGROUND_WHITE);
		printf(": %s\n", logBuf);
	}

	if (FileLog)
	{
		fdsgfdvvjkhsdkjcjk();
		logFile << logBuf << std::endl;
	}
}

// Gets the current time as a string
std::string Utilities::GetTimeString()
{
	fdsgfdvvjkhsdkjcjk();
	//Time related variables
	time_t current_time;
	struct tm *time_info;
	static char timeString[10];

	//Get current time
	time(&current_time);
	time_info = localtime(&current_time);

	//Get current time as string
	strftime(timeString, sizeof(timeString), "%I:%M%p", time_info);
	return timeString;
}

// Sets the console color for upcoming text
void Utilities::SetConsoleColor(WORD color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
	fdsgfdvvjkhsdkjcjk();
}

// Enables writing all log calls to a file
void Utilities::EnableLogFile(std::string filename)
{
	fdsgfdvvjkhsdkjcjk();
	logFile.open(filename.c_str());
	if (logFile.is_open())
		FileLog = true;
}


// --------         Utilities Memory           ------------ //

DWORD Utilities::Memory::WaitOnModuleHandle(std::string moduleName)
{
	DWORD ModuleHandle = NULL;
	while (!ModuleHandle)
	{
		ModuleHandle = (DWORD)GetModuleHandle(moduleName.c_str());
		if (!ModuleHandle)
			Sleep(25);
	}
	return ModuleHandle;
}

bool bCompare(const BYTE* Data, const BYTE* Mask, const char* szMask)
{
	for (; *szMask; ++szMask, ++Mask, ++Data)
	{
		if (*szMask == 'x' && *Mask != *Data)
		{
			return false;
		}
	}
	return (*szMask) == 0;
}

DWORD Utilities::Memory::FindPattern(std::string moduleName, BYTE* Mask, char* szMask)
{
	DWORD Address = WaitOnModuleHandle(moduleName.c_str());
	MODULEINFO ModInfo; GetModuleInformation(GetCurrentProcess(), (HMODULE)Address, &ModInfo, sizeof(MODULEINFO));
	DWORD Length = ModInfo.SizeOfImage;
	for (DWORD c = 0; c < Length; c += 1)
	{
		if (bCompare((BYTE*)(Address + c), Mask, szMask))
		{
			return (DWORD)(Address + c);
		}
	}
	return 0;
}

std::uint8_t* Utilities::Memory::pattern_scan(void* module, const char* signature)
{
	static auto pattern_to_byte = [](const char* pattern) {
		auto bytes = std::vector<int>{};
		auto start = const_cast<char*>(pattern);
		auto end = const_cast<char*>(pattern) + strlen(pattern);

		for (auto current = start; current < end; ++current) {
			if (*current == '?') {
				++current;
				if (*current == '?')
					++current;
				bytes.push_back(-1);
			}
			else {
				bytes.push_back(strtoul(current, &current, 16));
			}
		}
		return bytes;
	};

	auto dosHeader = (PIMAGE_DOS_HEADER)module;
	auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)module + dosHeader->e_lfanew);

	auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
	auto patternBytes = pattern_to_byte(signature);
	auto scanBytes = reinterpret_cast<std::uint8_t*>(module);

	auto s = patternBytes.size();
	auto d = patternBytes.data();

	for (auto i = 0ul; i < sizeOfImage - s; ++i) {
		bool found = true;
		for (auto j = 0ul; j < s; ++j) {
			if (scanBytes[i + j] != d[j] && d[j] != -1) {
				found = false;
				break;
			}
		}
		if (found) {
			return &scanBytes[i];
		}
	}
	return nullptr;
}


DWORD Utilities::Memory::FindPatternV2(std::string moduleName, std::string pattern)
{
	const char* pat = pattern.c_str();
	DWORD firstMatch = 0;
	DWORD rangeStart = (DWORD)GetModuleHandleA(moduleName.c_str());
	MODULEINFO miModInfo; GetModuleInformation(GetCurrentProcess(), (HMODULE)rangeStart, &miModInfo, sizeof(MODULEINFO));
	DWORD rangeEnd = rangeStart + miModInfo.SizeOfImage;
	for (DWORD pCur = rangeStart; pCur < rangeEnd; pCur++)
	{
		if (!*pat)
			return firstMatch;

		if (*(PBYTE)pat == '\?' || *(BYTE*)pCur == getByte(pat))
		{
			if (!firstMatch)
				firstMatch = pCur;

			if (!pat[2])
				return firstMatch;

			if (*(PWORD)pat == '\?\?' || *(PBYTE)pat != '\?')
				pat += 3;

			else
				pat += 2;
		}
		else
		{
			pat = pattern.c_str();
			firstMatch = 0;
		}
	}
	return NULL;
}

DWORD Utilities::Memory::FindTextPattern(std::string moduleName, char* string)
{
	DWORD Address = WaitOnModuleHandle(moduleName.c_str());
	MODULEINFO ModInfo; GetModuleInformation(GetCurrentProcess(), (HMODULE)Address, &ModInfo, sizeof(MODULEINFO));
	DWORD Length = ModInfo.SizeOfImage;

	int len = strlen(string);
	char* szMask = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		szMask[i] = 'x';
	}
	szMask[len] = '\0';

	for (DWORD c = 0; c < Length; c += 1)
	{
		if (bCompare((BYTE*)(Address + c), (BYTE*)string, szMask))
		{
			return (DWORD)(Address + c);
		}
	}
	return 0;
}

// --------         Utilities Memory VMT Manager       ------------ //

bool	Utilities::Memory::VMTManager::Initialise(DWORD* InstancePointer)
{
	// Store the instance pointers and such, and work out how big the table is
	Instance = InstancePointer;
	OriginalTable = (DWORD*)*InstancePointer;
	int VMTSize = MethodCount(InstancePointer);
	size_t TableBytes = VMTSize * 4;

	// Allocate some memory and copy the table
	CustomTable = (DWORD*)malloc(TableBytes + 8);
	if (!CustomTable) return false;
	memcpy((void*)CustomTable, (void*)OriginalTable, VMTSize * 4);

	// Change the pointer
	*InstancePointer = (DWORD)CustomTable;

	initComplete = true;
	return true;
}

int		Utilities::Memory::VMTManager::MethodCount(DWORD* InstancePointer)
{
	DWORD *VMT = (DWORD*)*InstancePointer;
	int Index = 0;
	int Amount = 0;
	while (!IsBadCodePtr((FARPROC)VMT[Index]))
	{
		if (!IsBadCodePtr((FARPROC)VMT[Index]))
		{
			Amount++;
			Index++;
		}
	}

	return Amount;
}

DWORD	Utilities::Memory::VMTManager::HookMethod(DWORD NewFunction, int Index)
{
	if (initComplete)
	{
		CustomTable[Index] = NewFunction;
		return OriginalTable[Index];
	}
	else
		return NULL;
}

void	Utilities::Memory::VMTManager::UnhookMethod(int Index)
{
	if (initComplete)
		CustomTable[Index] = OriginalTable[Index];
	return;
}

void	Utilities::Memory::VMTManager::RestoreOriginal()
{
	if (initComplete)
	{
		*Instance = (DWORD)OriginalTable;
	}
	return;
}

void	Utilities::Memory::VMTManager::RestoreCustom()
{
	if (initComplete)
	{
		*Instance = (DWORD)CustomTable;
	}
	return;
}

DWORD	Utilities::Memory::VMTManager::GetOriginalFunction(int Index)
{
	return OriginalTable[Index];
}








































































































































































































































































































































































































































































































