#include "lagcomp.h"
#include "skinchanger.h"
#include "DamageIndicators.h"
#include "Hooks.h"
#include "Hacks.h"
#include "Chams.h"
#include "hitmarker.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "MiscHacks.h"
#include "CRC32.h"
#include "Resolver.h"
#include <intrin.h>
#include "XorStr.h"
#include "SceneEndChams.h"
#include "IDirect3DDevice9.h"
#include "Variables.h"
#include "BulletListener.h"
#include "ESP.h"
#include "grenadeprediction.h"
#include "Fakewalk.h"
#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )
#define TICKS_TO_TIME(t) (Interfaces::Globals->interval_per_tick * (t) )
Vector LastAngleAA;
Vector LastAngleAAReal;

Vector real_angles;
Vector fake_angles;
extern float lineFakeAngle;
extern Vector FakePosition;
extern float lineRealAngle;
extern float lineLBY;
Vector LBYThirdpersonAngle;
//bool Resolver::didhitHS;
bool Resolver::didhitHS;
CUserCmd* Globals::UserCmd;
IClientEntity* Globals::Target;
int Globals::Shots;
bool Globals::change;
int Globals::TargetID;
std::map<int, QAngle>Globals::storedshit;
int Globals::missedshots;
CEsp* esp;



namespace Global
{
	CUserCmd* UserCmd;
	IClientEntity* Target;
	int Shots;
	bool change;
	int choked_ticks;
	int TargetID;
	bool Up2date;
	std::map<int, QAngle>storedshit;
	float oldSimulTime[65];
	int fired;
	int hit;
}

int Global::missedshots;

std::vector<trace_info> trace_logs;
LagCompensation *lagComp = nullptr;

// Funtion Typedefs
typedef void(__thiscall* DrawModelEx_)(void*, void*, void*, const ModelRenderInfo_t&, matrix3x4*);
typedef void(__thiscall* PaintTraverse_)(PVOID, unsigned int, bool, bool);
typedef bool(__thiscall* InPrediction_)(PVOID);
typedef void(__stdcall *FrameStageNotifyFn)(ClientFrameStage_t);
typedef bool(__thiscall *FireEventClientSideFn)(PVOID, IGameEvent*);
typedef void(__thiscall* RenderViewFn)(void*, CViewSetup&, CViewSetup&, int, int);
typedef void(__thiscall *SceneEnd_t)(void *pEcx);
using OverrideViewFn = void(__fastcall*)(void*, void*, CViewSetup*);
typedef float(__stdcall *oGetViewModelFOV)();
typedef int(__thiscall* SendDatagramFn)(NetChannel*, void*);

#define MakePtr(cast, ptr, addValue) (cast)( (DWORD)(ptr) + (DWORD)(addValue))
// Function Pointers to the originals
SceneEnd_t pSceneEnd;
PaintTraverse_ oPaintTraverse;
FrameStageNotifyFn oFrameStageNotify;
OverrideViewFn oOverrideView;
FireEventClientSideFn oFireEventClientSide;
RenderViewFn oRenderView;
SendDatagramFn original_send_datagram;

// Hook function prototypes
void __fastcall PaintTraverse_Hooked(PVOID pPanels, int edx, unsigned int vguiPanel, bool forceRepaint, bool allowForce);
bool __fastcall Hooked_FireEventClientSide(PVOID ECX, PVOID EDX, IGameEvent *Event);
bool __stdcall CreateMoveClient_Hooked(/*void* self, int edx,*/ float frametime, CUserCmd* pCmd);
void  __stdcall Hooked_FrameStageNotify(ClientFrameStage_t curStage);
void __fastcall Hooked_OverrideView(void* ecx, void* edx, CViewSetup* pSetup);
float __stdcall GGetViewModelFOV();
void __fastcall Hooked_RenderView(void* ecx, void* edx, CViewSetup &setup, CViewSetup &hudViewSetup, int nClearFlags, int whatToDraw);
void __fastcall	hkSceneEnd(void *pEcx, void *pEdx);
int __fastcall hkSendDatagram(NetChannel* thisptr, void* edx, void* datagram);

// VMT Managers
namespace Hooks
{
	// VMT Managers
	Utilities::Memory::VMTManager VMTPanel; // Hooking drawing functions
	Utilities::Memory::VMTManager VMTClient; // Maybe CreateMove
	Utilities::Memory::VMTManager VMTClientMode; // CreateMove for functionality
	Utilities::Memory::VMTManager VMTModelRender; // DrawModelEx for chams
	Utilities::Memory::VMTManager VMTPrediction; // InPrediction for no vis recoil
	Utilities::Memory::VMTManager VMTPlaySound; // Autoaccept 
	Utilities::Memory::VMTManager VMTRenderView;
	Utilities::Memory::VMTManager VMTEventManager;
	Utilities::Memory::VMTManager VMTModelCache;
	Utilities::Memory::VMTManager VMTClientState;
};
// Undo our hooks
void Hooks::UndoHooks()
{
	VMTPanel.RestoreOriginal();
	VMTPrediction.RestoreOriginal();
	VMTModelRender.RestoreOriginal();
	VMTClientMode.RestoreOriginal();
}


// Initialise all our hooks
void Hooks::Initialise()
{

	// Panel hooks for drawing to the screen via surface functions
	VMTPanel.Initialise((DWORD*)Interfaces::Panels);
	oPaintTraverse = (PaintTraverse_)VMTPanel.HookMethod((DWORD)&PaintTraverse_Hooked, Offsets::VMT::Panel_PaintTraverse);

	VMTClientMode.Initialise((DWORD*)Interfaces::ClientMode);
	VMTClientMode.HookMethod((DWORD)CreateMoveClient_Hooked, 24);

	VMTRenderView.Initialise((DWORD*)Interfaces::RenderView);
	pSceneEnd = (SceneEnd_t)VMTRenderView.HookMethod((DWORD)&hkSceneEnd, 9);

	oOverrideView = (OverrideViewFn)VMTClientMode.HookMethod((DWORD)&Hooked_OverrideView, 18);
	VMTClientMode.HookMethod((DWORD)&GGetViewModelFOV, 35);

	VMTEventManager.Initialise((DWORD*)Interfaces::EventManager);
	oFireEventClientSide = (FireEventClientSideFn)VMTEventManager.HookMethod((DWORD)&Hooked_FireEventClientSide, 9);

	VMTClient.Initialise((DWORD*)Interfaces::Client);
	oFrameStageNotify = (FrameStageNotifyFn)VMTClient.HookMethod((DWORD)&Hooked_FrameStageNotify, 36);

	m_present = Utilities::Memory::pattern_scan(GetModuleHandleW(L"gameoverlayrenderer.dll"), "57 50 FF 75 0C 56 FF 15 ? ? ? ? 8B F8 85") + 0x8;//big ( large ) obs bypass
	m_reset = Utilities::Memory::pattern_scan(GetModuleHandleW(L"gameoverlayrenderer.dll"), "57 C7 45 FC ? ? ? ? FF 15 ? ? ? ? 8B F8 85") + 0xA;  //big ( large ) obs bypass


	oPresent = **reinterpret_cast<Present_T**>(m_present);
	oReset = **reinterpret_cast<Reset_t**>(m_reset);

	**reinterpret_cast<void***>(m_present) = reinterpret_cast<void*>(&hkPresent);
	**reinterpret_cast<void***>(m_reset) = reinterpret_cast<void*>(&hkReset);

	while (!Interfaces::Engine->IsInGame() || !Interfaces::Engine->IsConnected())
		Sleep(1000);

	while (!(Interfaces::g_ClientState)->m_NetChannel)
		Sleep(100);


	VMTClientState.Initialise((DWORD*)Interfaces::g_ClientState->m_NetChannel);
	original_send_datagram = (SendDatagramFn)VMTClientState.HookMethod((DWORD)&hkSendDatagram, 48);

}



struct CIncomingSequence
{
	CIncomingSequence::CIncomingSequence(int instate, int outstate, int seqnr, float time)
	{
		inreliablestate = instate;
		outreliablestate = outstate;
		sequencenr = seqnr;
		curtime = time;
	}
	int inreliablestate;
	int outreliablestate;
	int sequencenr;
	float curtime;
};

std::deque<CIncomingSequence> m_sequences;
int lastincomingsequencenumber;

CFakeLatency* g_FakeLatency = new CFakeLatency;
void CFakeLatency::AddLatency(NetChannel *netchan, float latency)
{
	for (auto& seq : m_sequences)
	{
		if (Interfaces::Globals->realtime - seq.curtime >= latency)
		{
			netchan->m_nInReliableState = seq.inreliablestate;
			netchan->m_nInSequenceNr = seq.sequencenr;
			break;
		}
	}
}


void CFakeLatency::UpdateIncomingSequences()
{

	NetChannel *netchan = *reinterpret_cast< NetChannel** >(reinterpret_cast< std::uintptr_t >(Interfaces::g_ClientState) + 0x9C);
	if (netchan)
	{
		if (netchan->m_nInSequenceNr > lastincomingsequencenumber)
		{
			//sequences.push_front(netchan->m_nInSequenceNr);
			lastincomingsequencenumber = netchan->m_nInSequenceNr;

			m_sequences.push_front(CIncomingSequence(netchan->m_nInReliableState, netchan->m_nOutReliableState, netchan->m_nInSequenceNr, Interfaces::Globals->realtime));
		}

		if (m_sequences.size() > 2048)
			m_sequences.pop_back();
	}

}

int CFakeLatency::SendDatagram(NetChannel* netchan, void* datagram)
{
	if (!Interfaces::Engine->IsInGame() || !Interfaces::Engine->IsConnected() || datagram)
		return original_send_datagram(netchan, datagram);

	if (!g_Options.Ragebot.FakePing)
		return original_send_datagram(netchan, datagram);

	auto instate = netchan->m_nInReliableState;
	auto in_sequencenr = netchan->m_nInSequenceNr;

	AddLatency(netchan, g_Options.Ragebot.fakepingvalue);

	int ret = original_send_datagram(netchan, datagram);

	netchan->m_nInReliableState = instate;
	netchan->m_nInSequenceNr = in_sequencenr;

	return ret;
}

int __fastcall hkSendDatagram(NetChannel* netchan, void* edx, void* datagram)
{
	if (!Interfaces::Engine->IsInGame() || !Interfaces::Engine->IsConnected() || datagram)
		return original_send_datagram(netchan, datagram);

	if (!g_Options.Ragebot.FakePing)
		return original_send_datagram(netchan, datagram);

	g_FakeLatency->m_netchan = netchan;

	auto instate = netchan->m_nInReliableState;
	auto in_sequencenr = netchan->m_nInSequenceNr;

	auto lag_s = g_Options.Ragebot.fakepingvalue / 1000.f;
	auto lag_delta = lag_s - Interfaces::Engine->GetNetChannelInfo()->GetLatency(FLOW_OUTGOING);

	g_FakeLatency->AddLatency(netchan, lag_delta);

	int ret = original_send_datagram(netchan, datagram);

	netchan->m_nInReliableState = instate;
	netchan->m_nInSequenceNr = in_sequencenr;

	return ret;
}

static int ground_tick;
void ground_ticks()
{
	auto pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (!pLocal)
		return;

	if (pLocal->GetFlags() & FL_ONGROUND)
		ground_tick++;
	else
		ground_tick = 0;
}

void AristoisSetClanTagFunc(const char* tag, const char* name)
{
	static auto AyySetClanTag = reinterpret_cast<void(__fastcall*)(const char*, const char*)>(((DWORD)Utilities::Memory::FindPattern("engine.dll", (PBYTE)"\x53\x56\x57\x8B\xDA\x8B\xF9\xFF\x15\x00\x00\x00\x00\x6A\x24\x8B\xC8\x8B\x30", "xxxxxxxxx????xxxxxx")));
	AyySetClanTag(tag, name);
}

void NoClantag()
{
	AristoisSetClanTagFunc("", "");
}

void ClanTag()
{
	static int counter = 0;
	switch (g_Options.Misc.Clantagspammer)
	{
	case 0:
		// No 
		break;
	case 1:
	{

		static int motion = 0;
		int ServerTime = (float)Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase() * 3;
		if (counter % 48 == 0)
			motion++;
		int value = ServerTime % 2;
		switch (value) {
		case 0:AristoisSetClanTagFunc(XorStr("aristois.me"), "aristois.me"); break;
		case 1:AristoisSetClanTagFunc(XorStr("aristois.me"), "aristois.me"); break;

		}
		counter++;
	}
	break;
	case 2:
	{
		static int motion = 0;
		int ServerTime = (float)Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase() * 2.5;
		if (counter % 48 == 0)
			motion++;
		int value = ServerTime % 29;
		switch (value) {
		case 0:AristoisSetClanTagFunc("              g", "gamesense"); break;
		case 1:AristoisSetClanTagFunc("             ga", "gamesense"); break;
		case 2:AristoisSetClanTagFunc("            gam", "gamesense"); break;
		case 3:AristoisSetClanTagFunc("           game", "gamesense"); break;
		case 4:AristoisSetClanTagFunc("          games", "gamesense"); break;
		case 5:AristoisSetClanTagFunc("         gamese", "gamesense"); break;
		case 6:AristoisSetClanTagFunc("        gamesen", "gamesense"); break;
		case 7:AristoisSetClanTagFunc("       gamesens", "gamesense"); break;
		case 8:AristoisSetClanTagFunc("      gamesense", "gamesense"); break;
		case 9:AristoisSetClanTagFunc("     gamesense ", "gamesense"); break;
		case 10:AristoisSetClanTagFunc("     gamesense ", "gamesense"); break;
		case 11:AristoisSetClanTagFunc("    gamesense  ", "gamesense"); break;
		case 12:AristoisSetClanTagFunc("    gamesense  ", "gamesense"); break;
		case 13:AristoisSetClanTagFunc("   gamesense   ", "gamesense"); break;
		case 14:AristoisSetClanTagFunc("   gamesense   ", "gamesense"); break;
		case 15:AristoisSetClanTagFunc("  gamesense    ", "gamesense"); break;
		case 16:AristoisSetClanTagFunc("  gamesense    ", "gamesense"); break;
		case 17:AristoisSetClanTagFunc(" gamesense     ", "gamesense"); break;
		case 18:AristoisSetClanTagFunc(" gamesense     ", "gamesense"); break;
		case 19:AristoisSetClanTagFunc("gamesense      ", "gamesense"); break;
		case 20:AristoisSetClanTagFunc("gamesense      ", "gamesense"); break;
		case 21:AristoisSetClanTagFunc("amesense       ", "gamesense"); break;
		case 22:AristoisSetClanTagFunc("mesense        ", "gamesense"); break;
		case 23:AristoisSetClanTagFunc("sense          ", "gamesense"); break;
		case 24:AristoisSetClanTagFunc("ense           ", "gamesense"); break;
		case 25:AristoisSetClanTagFunc("nse            ", "gamesense"); break;
		case 26:AristoisSetClanTagFunc("se             ", "gamesense"); break;
		case 27:AristoisSetClanTagFunc("e              ", "gamesense"); break;
		case 28:AristoisSetClanTagFunc("               ", "gamesense"); break;
		}
		counter++;
	}
	break;
	case 3:
	{
		static int motion = 0;
		int ServerTime = (float)Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase() * 3;

		if (counter % 48 == 0)
			motion++;
		int value = ServerTime % 4;
		switch (value) {
		case 0:AristoisSetClanTagFunc(XorStr(u8"\u2708__\u258C_\u258C"), "aristois.me"); break;
		case 1:AristoisSetClanTagFunc(XorStr(u8"_\u2708_\u258C_\u258C"), "aristois.me"); break;
		case 2:AristoisSetClanTagFunc(XorStr(u8"__\u2708\u258C_\u258C"), "aristois.me"); break;
		case 3:AristoisSetClanTagFunc(XorStr(u8"___\u2620\u2708\u258C"), "aristois.me"); break;
		case 4:AristoisSetClanTagFunc(XorStr(u8"___\u2620_\u2620"), "aristois.me"); break;
		}
		counter++;
	}
	break;
	case 4:
		AristoisSetClanTagFunc("[VALV\xE1\xB4\xB1]", "Valve");
		break;
	}
}

static bool roundStartTest;
static float myLBYTimer;
static int roundStartTimer;

static float saveLastHeadshotFloat[65];
static float saveLastBaimFloat[65];
static float saveLastBaim30Float[65];

static float saveLastBaim10Float[65];

int hitmarkertime = 0;

static float testtimeToTick;
static float testServerTick;
static float testTickCount64 = 1;
template <typename T, std::size_t N> T* end_(T(&arr)[N]) { return arr + N; }
template <typename T, std::size_t N> T* begin_(T(&arr)[N]) { return arr; }


int kek = 0;

int LagCompBreak()
{
	IClientEntity *pLocalPlayer = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	Vector velocity = pLocalPlayer->GetVelocity();
	velocity.z = 0;
	float speed = velocity.Length();
	if (speed > 0.f) {
		auto distance_per_tick = speed *
			Interfaces::Globals->interval_per_tick;
		int choked_ticks = std::ceilf(65.f / distance_per_tick);
		return std::min<int>(choked_ticks, g_Options.Ragebot.Packets);
	}
	return 1;
}



Vector OldOrigin;
bool __stdcall CreateMoveClient_Hooked(float frametime, CUserCmd* pCmd)
{
	if (!pCmd->command_number)
		return true;

	IClientEntity* local = hackManager.pLocal();
	if (g_Options.Ragebot.BacktrackRage || g_Options.Legitbot.backtrackkurwalegit)
	{
		backtracking->legitBacktrack(pCmd, local);
	}
	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	IClientEntity* pEntity;
	PVOID pebp;
	__asm mov pebp, ebp;
	bool* pbSendPacket = (bool*)(*(DWORD*)pebp - 0x1C);
	bool& bSendPacket = *pbSendPacket;
	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && pLocal && pLocal->IsAlive())
	{
		Hacks::MoveHacks(pCmd, bSendPacket);
		ResolverSetup::GetInst().CM(pEntity);
	}

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{
		if (g_Options.Ragebot.YawTrue > 0)
		{
			ground_ticks();
		}

		slidebitch->do_fakewalk(pCmd);


		PVOID pebp;
		__asm mov pebp, ebp;
		bool* pbSendPacket = (bool*)(*(DWORD*)pebp - 0x1C);
		bool& bSendPacket = *pbSendPacket;

		grenade_prediction::instance().Tick(pCmd->buttons);

		if (g_Options.Misc.Clantagspammer > 0)
			ClanTag();
		//	CUserCmd* cmdlist = *(CUserCmd**)((DWORD)Interfaces::pInput + 0xEC);
		//	CUserCmd* pCmd = &cmdlist[sequence_number % 150];


		// Backup for safety
		Vector origView = pCmd->viewangles;
		Vector viewforward, viewright, viewup, aimforward, aimright, aimup;
		Vector qAimAngles;
		qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
		AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);

		// Do da hacks
		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		if (pLocal->IsAlive())
		{
			/*fake lag memes*/
			if (g_Options.Ragebot.FakeLag)
			{
				static int ticks = 0;
				static int ticks1 = 0;
				static int iTick = 0;
				static int iTick1 = 0;
				static int iTick2 = 0;
				int ticksMax = 16;
				int value = g_Options.Ragebot.Packets;
				if (g_Options.Ragebot.FakeLag && value > 0)
				{
					{
						value = LagCompBreak();
						if (iTick2 < value) {
							bSendPacket = false;
							iTick2++;
						}
						else {
							bSendPacket = true;
							iTick2 = 0;
						}
					}
				}
			}
		}

#pragma region Timer4LBY
		static float myOldLby;
		static float myoldTime;
		testtimeToTick = TIME_TO_TICKS(0.1);
		testServerTick = TIME_TO_TICKS(1);
		static int timerino;
		static float oneTickMinues;

		if (testServerTick == 128) {
			oneTickMinues = testServerTick / 128;
		}
		else {
			oneTickMinues = testServerTick / 64;
		}
		//IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());


#pragma endregion
		Hacks::MoveHacks(pCmd, bSendPacket);

		int bestTargetIndex = -1;
		float bestFov = FLT_MAX;
		player_info_t info;


#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )
#define TICKS_TO_TIME(t) (Interfaces::Globals->interval_per_tick * (t) )

		IClientEntity* LocalPlayer = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
		float flServerTime = (float)(LocalPlayer->GetTickBase()  * Interfaces::Globals->interval_per_tick);
		static float next_time = 0;
		if (!bSendPacket && LocalPlayer->IsAlive() && LocalPlayer->GetVelocity().Length2D() == 0) {

			float TickStuff = TICKS_TO_TIME(LocalPlayer->GetTickBase());
			Global::Up2date = false;
			//flServerTime = next_time;

			if (next_time - TICKS_TO_TIME(LocalPlayer->GetTickBase()) > 1.1)
			{
				next_time = 0;
			}

			if (TickStuff > next_time + 1.1f)
			{
				next_time = TickStuff + TICKS_TO_TIME(1);
				Global::Up2date = true;
			}
		}
		//Movement Fix
		//GameUtils::CL_FixMove(pCmd, origView);
		qAimAngles.Init(0.0f, GetAutostrafeView().y, 0.0f); // if pCmd->viewangles.x > 89, set pCmd->viewangles.x instead of 0.0f on first
		AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);
		qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
		AngleVectors(qAimAngles, &aimforward, &aimright, &aimup);
		Vector vForwardNorm;		Normalize(viewforward, vForwardNorm);
		Vector vRightNorm;			Normalize(viewright, vRightNorm);
		Vector vUpNorm;				Normalize(viewup, vUpNorm);

		// Original shit for movement correction
		float forward = pCmd->forwardmove;
		float right = pCmd->sidemove;
		float up = pCmd->upmove;
		if (forward > 450) forward = 450;
		if (right > 450) right = 450;
		if (up > 450) up = 450;
		if (forward < -450) forward = -450;
		if (right < -450) right = -450;
		if (up < -450) up = -450;
		pCmd->forwardmove = DotProduct(forward * vForwardNorm, aimforward) + DotProduct(right * vRightNorm, aimforward) + DotProduct(up * vUpNorm, aimforward);
		pCmd->sidemove = DotProduct(forward * vForwardNorm, aimright) + DotProduct(right * vRightNorm, aimright) + DotProduct(up * vUpNorm, aimright);
		pCmd->upmove = DotProduct(forward * vForwardNorm, aimup) + DotProduct(right * vRightNorm, aimup) + DotProduct(up * vUpNorm, aimup);

		// Angle normalisation
		if (g_Options.Misc.SafeMode)
		{
			GameUtils::NormaliseViewAngle(pCmd->viewangles);

			if (pCmd->viewangles.z != 0.0f)
			{
				pCmd->viewangles.z = 0.00;
			}

			if (pCmd->viewangles.x < -89 || pCmd->viewangles.x > 89 || pCmd->viewangles.y < -180 || pCmd->viewangles.y > 180)
			{
				Utilities::Log("Having to re-normalise!");
				GameUtils::NormaliseViewAngle(pCmd->viewangles);
				Beep(750, 800); // Why does it do this
				if (pCmd->viewangles.x < -89 || pCmd->viewangles.x > 89 || pCmd->viewangles.y < -180 || pCmd->viewangles.y > 180)
				{
					pCmd->viewangles = origView;
					pCmd->sidemove = right;
					pCmd->forwardmove = forward;
				}
			}
		}

		if (pCmd->viewangles.x > 90)
		{
			pCmd->forwardmove = -pCmd->forwardmove;
		}

		if (pCmd->viewangles.x < -90)
		{
			pCmd->forwardmove = -pCmd->forwardmove;
		}

		// LBY
		LBYThirdpersonAngle = Vector(pLocal->GetEyeAnglesXY()->x, pLocal->GetLowerBodyYaw(), pLocal->GetEyeAnglesXY()->z);


		//fake angle chams shit

		if (bSendPacket == true)
		{
			LastAngleAA = pCmd->viewangles;
		}
		else if (bSendPacket == false)
		{
			LastAngleAAReal = pCmd->viewangles;
		}


		lineLBY = pLocal->GetLowerBodyYaw();
		if (bSendPacket == true)
		{
			OldOrigin = pLocal->GetAbsOrigin();
			lineFakeAngle = pCmd->viewangles.y;
			FakePosition = pLocal->GetAbsOrigin();
		}
		else if (bSendPacket == false)
		{
			lineRealAngle = pCmd->viewangles.y;
		}
	}
	return false;
}

std::string GetTimeString()
{
	time_t current_time;
	struct tm *time_info;
	static char timeString[10];
	time(&current_time);
	time_info = localtime(&current_time);
	strftime(timeString, sizeof(timeString), "%X", time_info);
	return timeString;
}

void Hooks::DrawBeamd(Vector src, Vector end, Color color)
{
	BeamInfo_t beamInfo;
	beamInfo.m_nType = TE_BEAMPOINTS;
	beamInfo.m_pszModelName = "sprites/physbeam.vmt";
	beamInfo.m_nModelIndex = -1;
	beamInfo.m_flHaloScale = 0.0f;
	beamInfo.m_flLife = 3.0f;
	beamInfo.m_flWidth = 7.0f;
	beamInfo.m_flEndWidth = 7.0f;
	beamInfo.m_flFadeLength = 0.0f;
	beamInfo.m_flAmplitude = 2.0f;
	beamInfo.m_flBrightness = color.a();
	beamInfo.m_flSpeed = 0.2f;
	beamInfo.m_nStartFrame = 0.f;
	beamInfo.m_flFrameRate = 0.f;
	beamInfo.m_flRed = color.r();
	beamInfo.m_flGreen = color.g();
	beamInfo.m_flBlue = color.b();
	beamInfo.m_nSegments = 2;
	beamInfo.m_bRenderable = true;
	beamInfo.m_nFlags = FBEAM_ONLYNOISEONCE | FBEAM_NOTILE | FBEAM_HALOBEAM;
	beamInfo.m_vecStart = src;
	beamInfo.m_vecEnd = end;

	Beam_t* myBeam = Interfaces::g_pViewRenderBeams->CreateBeamPoints(beamInfo);

	if (myBeam)
		Interfaces::g_pViewRenderBeams->DrawBeam(myBeam);
}



// Paint Traverse Hooked function
void __fastcall PaintTraverse_Hooked(PVOID pPanels, int edx, unsigned int vguiPanel, bool forceRepaint, bool allowForce)
{
	if (g_Options.Visuals.ESPEnable && g_Options.Visuals.noscopeborder && strcmp("HudZoom", Interfaces::Panels->GetName(vguiPanel)) == 0)
		return;
	oPaintTraverse(pPanels, vguiPanel, forceRepaint, allowForce);

	static unsigned int FocusOverlayPanel = 0;
	static bool FoundPanel = false;

	if (!FoundPanel)
	{
		PCHAR szPanelName = (PCHAR)Interfaces::Panels->GetName(vguiPanel);
		if (strstr(szPanelName, "MatSystemTopPanel"))
		{
			FocusOverlayPanel = vguiPanel;
			FoundPanel = true;
		}
	}
	else if (FocusOverlayPanel == vguiPanel)
	{
		if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
		{
			esp->paint();
			Hacks::DrawHacks();
			damage_indicators.paint();

			int pos_y = 30;
			char buffer_shots[128];
			float shots = Global::Shots;
			sprintf_s(buffer_shots, "Shots: %1.0f", shots);
			Render::text1(4, pos_y, buffer_shots, Render::Fonts::Menu, Color(255, 255, 255));
			pos_y += 10;

			char buffer_chokedticks[128];
			float missed = Global::missedshots;
			sprintf_s(buffer_chokedticks, "Missed Shots: %1.0f", missed);
			Render::text1(4, pos_y, buffer_chokedticks, Render::Fonts::Menu, Color(255, 255, 255));
			pos_y += 10;

		}

		if (g_Options.Visuals.LBYStatus)
		{
			CUserCmd* cmdlist = *(CUserCmd**)((DWORD)Interfaces::pInput + 0xEC);
			CUserCmd* pCmd = cmdlist;
			IClientEntity* localplayer = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
			//RECT TextSize = Render::GetTextSize(Render::Fonts::LBY, "LBY");
			RECT scrn = Render::GetViewport();
			if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
				if (pCmd->viewangles.y - *localplayer->GetLowerBodyYawTarget() >= -35 && pCmd->viewangles.y - *localplayer->GetLowerBodyYawTarget() <= 35)
					Render::Text(10, scrn.bottom - 70.5, Color(255, 0, 0, 255), Render::Fonts::LBY, XorStr("LBY"));
			//Render::Text(10, scrn.bottom - 22, Color(255, 0, 0, 255), Render::Fonts::LBY, "LBY");
				else
					Render::Text(10, scrn.bottom - 70.5, Color(124, 195, 13, 255), Render::Fonts::LBY, XorStr("LBY"));
			//Render::Text(10, scrn.bottom - 22, Color(0, 255, 0, 255), Render::Fonts::LBY, "LBY");
		}

		if (g_Options.Visuals.LBYStatus)
		{
			if (g_Options.Ragebot.FakeLag)
			{
				CUserCmd* cmdlist = *(CUserCmd**)((DWORD)Interfaces::pInput + 0xEC);
				CUserCmd* pCmd = cmdlist;

				//sry big codenz here
			}
		}

		if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && g_Options.Visuals.Hitmarker)
			hitmarker::singleton()->on_paint();


	}
}

int Kills2 = 0;
int Kills = 0;
bool RoundInfo = false;
size_t Delay = 0;
player_info_t GetInfo(int Index)
{
	player_info_t Info;
	Interfaces::Engine->GetPlayerInfo(Index, &Info);
	return Info;
}

template <typename t> t xd(t value, t min, t max)
{
	if (value > max) {
		return max;
	}
	if (value < min) {
		return min;
	}
	return value;
}

bool IsWarmup = false;
bool __fastcall Hooked_FireEventClientSide(PVOID ECX, PVOID EDX, IGameEvent *Event)
{
	CBulletListener::singleton()->OnStudioRender();

	if (!strcmp(Event->GetName(), "round_prestart") || (!strcmp(Event->GetName(), "round_end")))
	{
		if (!strcmp(Event->GetName(), "round_end"))
		{
			IsWarmup = false;
		}
		else
		{
			IsWarmup = true;
		}
	}

	if (!strcmp(Event->GetName(), "round_freeze_end"))
	{
		IsWarmup = false;
	}

	if (!strcmp(Event->GetName(), "round_end"))
	{
		IsWarmup = true;
	}


	if (!strcmp(Event->GetName(), "player_hurt"))
	{

		if (Interfaces::Engine->GetPlayerForUserID(Event->GetInt("attacker")) == Interfaces::Engine->GetLocalPlayer())
		{
			int userid = Interfaces::Engine->GetPlayerForUserID(Event->GetInt("userid"));

			auto m_local = Interfaces::Engine->GetLocalPlayer();
			IClientEntity* m_entity = Interfaces::EntList->GetClientEntity(userid);
			if (g_Options.Visuals.DMGIndicator)
			{
				DamageIndicator_t DmgIndicator;
				DmgIndicator.iDamage = Event->GetInt("dmg_health");
				DmgIndicator.Player = m_entity;
				DmgIndicator.flEraseTime = hackManager.pLocal()->GetTickBase() * Interfaces::Globals->interval_per_tick + 3.f;
				DmgIndicator.bInitialized = false;
				damage_indicators.data.push_back(DmgIndicator);
			}
		}
	}

	int k = 0;
	if (g_Options.Misc.Logs)
	{
		if (!strcmp(Event->GetName(), "item_purchase"))
		{
			int nUserID = Event->GetInt("attacker");
			int nDead = Event->GetInt("userid");
			if (nUserID || nDead)
			{
				player_info_t killed_info = GetInfo(Interfaces::Engine->GetPlayerForUserID(nDead));
				player_info_t killer_info = GetInfo(Interfaces::Engine->GetPlayerForUserID(nUserID));
				//std::string before = ("[aristois.me] ");
				std::string one = killed_info.name;
				std::string two = (" bought ");
				std::string three = Event->GetString("weapon");
				std::string six = "\n";
				if (g_Options.Misc.Logs)
				{
					Interfaces::ChatElement->ChatPrintf(0, 0, (" \x04" + one + two + three + six + "\n").c_str());
				}
			}
		}
		if (g_Options.Misc.Logs)
		{
			if (!strcmp(Event->GetName(), "player_hurt"))
			{

				int attackerid = Event->GetInt("attacker");
				int entityid = Interfaces::Engine->GetPlayerForUserID(attackerid);
				if (entityid == Interfaces::Engine->GetLocalPlayer())
				{
					int nUserID = Event->GetInt("attacker");
					int nDead = Event->GetInt("userid");
					if (nUserID || nDead)
					{
						player_info_t killed_info = GetInfo(Interfaces::Engine->GetPlayerForUserID(nDead));
						player_info_t killer_info = GetInfo(Interfaces::Engine->GetPlayerForUserID(nUserID));
						//std::string before = ("[aristois.me] ");
						std::string two = ("Hit ");
						std::string three = killed_info.name;
						std::string foura = " for ";
						std::string fivea = Event->GetString("dmg_health");
						std::string damage = " damage";
						std::string fourb = " (";
						std::string fiveb = Event->GetString("health");
						std::string six = " health remaining)";
						std::string newline = "\n";
						if (g_Options.Misc.Logs)
						{
							//Interfaces::ChatElement->ChatPrintf(0, 0, (two + three + foura + fivea + damage + fourb + fiveb + six + newline).c_str());
							Interfaces::ChatElement->ChatPrintf(0, 0, (" \x04" + two + three + foura + fivea + damage + fourb + fiveb + six + newline + "\n").c_str());
						}

					}
				}
			}

		}

	}


	if (strcmp(Event->GetName(), "round_start") == 0)
		k = 0;

	int dmg = Event->GetInt("dmg_health");
	int deadfag = Event->GetInt("userid");
	int attackingfag = Event->GetInt("attacker");
	int hit = Event->GetInt("hitgroup");

	auto testindx = Interfaces::Engine->GetPlayerForUserID(deadfag);
	auto testidx2 = Interfaces::Engine->GetPlayerForUserID(attackingfag);
	IClientEntity* userid1 = Interfaces::EntList->GetClientEntity(testindx);
	IClientEntity* hitnig = Interfaces::EntList->GetClientEntity(testidx2);

	IClientEntity* localplayer = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	IClientEntity* hittedplayer = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetPlayerForUserID(deadfag));

	player_info_t bitch_info;
	player_info_t coolguy49_info;

	/*if (!strcmp(Event->GetName(), "weapon_fire"))
	{
	auto userID = Event->GetInt("userid");
	auto attacker = Interfaces::Engine->GetPlayerForUserID(userID);

	if (attacker) {
	if (attacker == Interfaces::Engine->GetLocalPlayer()) {

	if (Global::Target)
	{
	Global::fired++;
	}
	}
	}
	}

	if (!strcmp(Event->GetName(), "player_hurt"))
	{
	int deadfag = Event->GetInt("userid");
	int attackingfag = Event->GetInt("attacker");
	IClientEntity* pLocal = hackManager.pLocal();
	if (Interfaces::Engine->GetPlayerForUserID(deadfag) != Interfaces::Engine->GetLocalPlayer() && Interfaces::Engine->GetPlayerForUserID(attackingfag) == Interfaces::Engine->GetLocalPlayer())
	{
	IClientEntity* hittedplayer = (IClientEntity*)(Interfaces::Engine->GetPlayerForUserID(deadfag));
	int hit = Event->GetInt("hitgroup");
	if (hit == 1 && hittedplayer && deadfag && attackingfag)
	{
	Resolver::didhitHS = true;
	Global::missedshots = 0;
	}
	else
	{
	Resolver::didhitHS = false;
	Global::missedshots++;
	}
	}
	} */

	if (g_Options.Ragebot.Resolver)
	{
		IClientEntity* pLocal = hackManager.pLocal();

		if (!strcmp(Event->GetName(), "weapon_fire"))
		{
			auto userID = Event->GetInt("userid");
			auto attacker = Interfaces::Engine->GetPlayerForUserID(userID);

			if (attacker)
			{
				if (attacker == Interfaces::Engine->GetLocalPlayer())
				{

					if (Global::Target)
					{
						Global::fired++;
					}
				}
			}
		}

		if (!strcmp(Event->GetName(), "player_hurt"))
		{
			int deadfag = Event->GetInt("userid");
			int attackingfag = Event->GetInt("attacker");

			if (Interfaces::Engine->GetPlayerForUserID(deadfag) != Interfaces::Engine->GetLocalPlayer() && Interfaces::Engine->GetPlayerForUserID(attackingfag) == Interfaces::Engine->GetLocalPlayer()) {
				Global::hit++;
			}
		}

		if (Global::fired > 10)
		{
			Global::fired = 0;
			Global::hit = 0;
		}

		Global::missedshots = Global::fired - Global::hit;
	}

	return oFireEventClientSide(ECX, Event);
}


void AnimationFix(int stage)
{
	//gay paste
	auto local_player = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!local_player)
		return;

	if (local_player->GetHealth() <= 0)
		return;

	static int userId[64];
	static AnimationLayer
		backupLayersUpdate[64][15],
		backupLayersInterp[64][15];

	for (int i = 1; i < Interfaces::Globals->maxClients; i++)
	{
		IClientEntity* player = Interfaces::EntList->GetClientEntity(i);

		if (!player ||
			player == local_player ||
			player->GetTeamNum() == local_player->GetTeamNum() ||
			!player ||
			player->GetIsDormant())
			continue;

		player_info_t player_info;
		Interfaces::Engine->GetPlayerInfo(i, &player_info);

		switch (stage)
		{
		case ClientFrameStage_t::FRAME_NET_UPDATE_START: // Copy new, server layers to use when drawing.
			userId[i] = player_info.userid;
			memcpy(&backupLayersUpdate[i], player->GetAnimOverlays(), (sizeof AnimationLayer) * player->GetNumAnimOverlays());
			break;
		case ClientFrameStage_t::FRAME_RENDER_START: // Render started, don't use inaccurately extrapolated layers but save them to not mess shit up either.
			if (userId[i] != player_info.userid) continue;
			memcpy(&backupLayersInterp[i], player->GetAnimOverlays(), (sizeof AnimationLayer) * player->GetNumAnimOverlays());
			memcpy(player->GetAnimOverlays(), &backupLayersUpdate[i], (sizeof AnimationLayer) * player->GetNumAnimOverlays());
			break;
		case ClientFrameStage_t::FRAME_RENDER_END: // Restore layers to keep being accurate when backtracking.
			if (userId[i] != player_info.userid) continue;
			memcpy(player->GetAnimOverlays(), &backupLayersInterp[i], (sizeof AnimationLayer) * player->GetNumAnimOverlays());
			break;
		default:
			return;
		}
	}
}

#define TEXTURE_GROUP_OTHER							"Other textures"
void  __stdcall Hooked_FrameStageNotify(ClientFrameStage_t curStage)
{
	lagComp->log(curStage);
	DWORD eyeangles = NetVar.GetNetVar(0xBFEA4E7B);
	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	Vector*pPunchAngle = nullptr, *pViewPunchAngle = nullptr, vPunchAngle, vViewPunchAngle;

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && curStage == FRAME_RENDER_START)
	{

		if (g_Options.Visuals.NoVisualRecoil)
		{
			pPunchAngle = pLocal->GetPunchAngles();
			pViewPunchAngle = pLocal->GetPunchAngles2();

			if (pPunchAngle && pViewPunchAngle)
			{
				vPunchAngle = *pPunchAngle;
				pPunchAngle->Init();
				vViewPunchAngle = *pViewPunchAngle;
				pViewPunchAngle->Init();
			}
		}

		static auto smoke_count = *reinterpret_cast<uint32_t**>(GameUtils::FindPattern1("client.dll", "A3 ? ? ? ? 57 8B CB") + 1);
		if (g_Options.Visuals.NoSmokeWire)
		{
			*(int*)(smoke_count) = 0;
		}

		std::vector<const char*> vistasmoke_mats =
		{
			"particle/vistasmokev1/vistasmokev1_fire",
			"particle/vistasmokev1/vistasmokev1_smokegrenade",
			"particle/vistasmokev1/vistasmokev1_emods",
			"particle/vistasmokev1/vistasmokev1_emods_impactdust",
		};

		if (g_Options.Visuals.NoSmokeWire)
		{
			for (auto mat_s : vistasmoke_mats)
			{
				IMaterial* mat = Interfaces::MaterialSystem->FindMaterial(mat_s, TEXTURE_GROUP_OTHER);
				mat->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, true);
			}
		}


		if (pLocal->IsAlive() && g_Options.Visuals.ThirdPerson)
		{
			auto animstate = pLocal->GetAnimState();
			Vector thirdpersonMode;
			thirdpersonMode = LastAngleAAReal;



			static bool rekt = false;
			if (!rekt)
			{
				ConVar* sv_cheats = Interfaces::CVar->FindVar("sv_cheats");
				SpoofedConvar* sv_cheats_spoofed = new SpoofedConvar(sv_cheats);
				sv_cheats_spoofed->SetInt(1);
				rekt = true;
			}


			static bool kek = false;

			if (!kek)
			{
				Interfaces::Engine->ClientCmd_Unrestricted("thirdperson");
				kek = true;
			}

			static bool toggleThirdperson;
			static float memeTime;
			int ThirdPersonKey = g_Options.Visuals.ThirdPersonKey;
			if (ThirdPersonKey >= 0 && GetAsyncKeyState(ThirdPersonKey) && abs(memeTime - Interfaces::Globals->curtime) > 0.5)
			{
				toggleThirdperson = !toggleThirdperson;
				memeTime = Interfaces::Globals->curtime;
			}
			if (toggleThirdperson)
			{
				//thirdperson
				Interfaces::pInput->m_fCameraInThirdPerson = true;
				if (*(bool*)((DWORD)Interfaces::pInput + 0xA5))

					if (animstate->m_bInHitGroundAnimation && ground_tick > 1)
					{
						//pitch 0 meme
						*(Vector*)((DWORD)pLocal + 0x31C8) = Vector(0.0f, LastAngleAAReal.y, 0.f);
					}
					else
					{
						*(Vector*)((DWORD)pLocal + 0x31C8) = Vector(LastAngleAAReal.x, LastAngleAAReal.y, 0.f);
					}

			}
			else
			{
				// firstperson
				static Vector vecAngles;
				Interfaces::Engine->GetViewAngles(vecAngles);
				Interfaces::pInput->m_fCameraInThirdPerson = false;
				Interfaces::pInput->m_vecCameraOffset = Vector(vecAngles.x, vecAngles.y, 0);
			}


		}
		else if (pLocal->IsAlive() == 0)
		{
			kek = false;
			Interfaces::Engine->ClientCmd_Unrestricted("firstperson");

		}

		if (!g_Options.Visuals.ThirdPerson) {

			// No Thirdperson
			static Vector vecAngles;
			Interfaces::Engine->GetViewAngles(vecAngles);
			Interfaces::pInput->m_fCameraInThirdPerson = false;
			Interfaces::pInput->m_vecCameraOffset = Vector(vecAngles.x, vecAngles.y, 0);
		}
		else if (pLocal->GetHealth() <= 0)
		{
			Interfaces::Engine->ClientCmd_Unrestricted("firstperson");
			kek = false;
		}
	}

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && curStage == FRAME_NET_UPDATE_POSTDATAUPDATE_START) {
		{
			IClientEntity* pEntity;
			ResolverSetup::GetInst().FSN(pEntity, curStage);
			//backtracking->Update(GetTickCount64());

		}
	}


	if (curStage == FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{

		g_FakeLatency->UpdateIncomingSequences();

		if (g_Options.Skinchanger.Enabled)
		{
			//GloveChanger(); // working on it
			SkinChanger();
		}

		if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
		{
			for (int i = 1; i < 65; i++)
			{
				auto pEntity = Interfaces::EntList->GetClientEntity(i);
				auto local_player = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

				if (!pEntity)
					continue;

				if (!local_player)
					continue;

				bool is_local_player = pEntity == local_player;
				bool is_teammate = local_player->GetTeamNum() == pEntity->GetTeamNum() && !is_local_player;

				if (is_local_player)
					continue;

				if (is_teammate)
					continue;

				if (pEntity->GetHealth() <= 0)
					continue;

				/*	if (g_Options.Ragebot.Resolver)
				{
				resolver->resolve(pEntity);
				}*/
			}

		}

		// 1. Time on Server LBY Update Predicten
		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
		for (int i = 0; i <= Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
			if (!pEntity || pEntity->IsDormant() || !pEntity->IsAlive())
				continue;
			if (pEntity->GetTeamNum() == pLocal->GetTeamNum() || !pLocal->IsAlive())
				continue;
			//Utilities::Log("APPLY SKIN APPLY SKIN");
			//ResolverSetup::GetInst().FSN(pEntity, curStage);
			IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
			INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
			if (g_Options.Ragebot.BacktrackRage || g_Options.Legitbot.backtrackkurwalegit)
				backtracking->Update(Interfaces::Globals->tickcount);

			VarMapping_t *map = pLocal->GetVarMap(pEntity);
			/*interpolation*/

			if (map)
			{
				if (g_Options.Ragebot.BacktrackRage)//make this backtracking
					map->m_nInterpolatedEntries = 0;
				else
					if (map->m_nInterpolatedEntries == 0)
						map->m_nInterpolatedEntries = 6;
			}
		}
		static int startTickBase;
		static int timerxd;
		static float oldlbyyy[65];
		static float oldtimer[65];
		static bool isLBYPredictited[65];


		for (int i = 0; i <= Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
			if (!pEntity || pEntity->IsDormant() || !pEntity->IsAlive())
				continue;
			if (pEntity->GetTeamNum() == pLocal->GetTeamNum() || !pLocal->IsAlive())
				continue;
			Vector* eyeAngles = pEntity->GetEyeAnglesPointer();
			player_info_t pTemp;
			if (!Interfaces::Engine->GetPlayerInfo(i, &pTemp))
				continue;

			missedLogHits[pEntity->GetIndex()] = abs(shotsfired[pEntity->GetIndex()] - hittedLogHits[pEntity->GetIndex()]);

			printf("MissedLogHits: %i Index: %i\n", missedLogHits[pEntity->GetIndex()], pEntity->GetIndex());
			printf("Shotsfired: %i\n", shotsfired);
			printf("Hitted: %i Index: %i\n", hittedLogHits[pEntity->GetIndex()], pEntity->GetIndex());


			//.... Delta
			float deltadif = abs(pEntity->GetEyeAngles().y - pEntity->GetLowerBodyYaw());


			static float oldlowerbodyyaw;
			static float lbyproxytime;
			static int bullets;
		}
	}


	if (g_Options.Ragebot.AimbotEnable)// pvs fix
	{
		for (int i = 1; i <= Interfaces::Engine->GetMaxClients(); i++)
		{
			if (i == Interfaces::Engine->GetLocalPlayer()) continue;
			IClientEntity* pCurEntity = Interfaces::EntList->GetClientEntity(i);
			if (!pCurEntity) continue;
			*(int*)((uintptr_t)pCurEntity + 0xA30) = Interfaces::Globals->framecount;
			*(int*)((uintptr_t)pCurEntity + 0xA28) = 0; //clear occlusion flags
		}
	}

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && curStage == FRAME_NET_UPDATE_POSTDATAUPDATE_START)
	{
		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		for (int i = 0; i <= Interfaces::EntList->GetHighestEntityIndex(); i++)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

			if (pEntity)
			{

				ULONG hOwnerEntity = *(PULONG)((DWORD)pEntity + 0x148);

				IClientEntity* pOwner = Interfaces::EntList->GetClientEntityFromHandle((HANDLE)hOwnerEntity);

				if (pOwner)
				{
					if (pOwner == pLocal)
					{
						std::string sWeapon = Interfaces::ModelInfo->GetModelName(pEntity->GetModel());

						if (sWeapon.find("models/weapons", 0) != std::string::npos)
							continue;

						if (sWeapon.find("c4_planted", 0) != std::string::npos)
							continue;

						if (sWeapon.find("thrown", 0) != std::string::npos)
							continue;

						if (sWeapon.find("smokegrenade", 0) != std::string::npos)
							continue;

						if (sWeapon.find("flashbang", 0) != std::string::npos)
							continue;

						if (sWeapon.find("fraggrenade", 0) != std::string::npos)
							continue;

						if (sWeapon.find("molotov", 0) != std::string::npos)
							continue;

						if (sWeapon.find("decoy", 0) != std::string::npos)
							continue;
						if (sWeapon.find("incendiarygrenade", 0) != std::string::npos)
							continue;
						if (sWeapon.find("ied", 0) != std::string::npos)
							continue;
						if (sWeapon.find("w_eq_", 0) != std::string::npos)
							continue;

						CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)pEntity;

						ClientClass *pClass = Interfaces::Client->GetAllClasses();

					}
				}

			}
		}
	}

	AnimationFix(curStage);

	oFrameStageNotify(curStage);
}


void __fastcall Hooked_OverrideView(void* ecx, void* edx, CViewSetup* pSetup)
{

	IClientEntity* pLocal = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{

		if (g_Options.Misc.IgnoreScope)
		{
			auto ratio = Interfaces::CVar->FindVar("zoom_sensitivity_ratio_mouse");

			if (g_Options.Misc.IgnoreScope)
			{
				ratio->SetValue("0");
			}
			else
			{
				ratio->SetValue("1");
			}

			if (g_Options.Visuals.ESPEnable && pLocal->IsAlive())
			{

				if (pSetup->fov = 90)
					pSetup->fov = g_Options.Misc.FovOverride;
			}
		}
		else
		{

			if (g_Options.Visuals.ESPEnable && pLocal->IsAlive() && !pLocal->IsScoped())
			{

				if (pSetup->fov = 90)
					pSetup->fov = g_Options.Misc.FovOverride;
			}
		}
		grenade_prediction::instance().View(pSetup);
		oOverrideView(ecx, edx, pSetup);
	}

}

void GetViewModelFOV(float& fov)
{
	IClientEntity* localplayer = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{

		if (!localplayer)
			return;

		//if (g_Options.Visuals.ESPEnable)
		//fov += Menu::Window.VisualsTab.OtherViewmodelFOV.GetValue();
	}
}

float __stdcall GGetViewModelFOV()
{

	float fov = Hooks::VMTClientMode.GetMethod<oGetViewModelFOV>(35)();

	GetViewModelFOV(fov);

	return fov;
}

void __fastcall  hkSceneEnd(void *pEcx, void *pEdx)
{

	if (g_Options.Visuals.Glow)
	{
		esp->glow.paint();
	}

	if (g_Options.Visuals.FakeChams)
	{
		IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		Vector Orig; //
		auto original_angle = pLocal->GetEyeAngles();
		Orig = pLocal->GetAbsOrigin(); //
		pLocal->SetAngle2(Vector(0, lineFakeAngle, 0));
		pLocal->GetAbsOrigin() = OldOrigin; //
		chams->override_material(false, false, false, false, false, Color(255, 255, 255, 255));
		pLocal->DrawModel(0x1, pLocal->GetModelInstance());
		Interfaces::ModelRender->ForcedMaterialOverride(nullptr);
		pLocal->SetAngle2(original_angle);
		pLocal->GetAbsOrigin() = Orig; //
	}

	if (g_Options.Visuals.LBYChams)
	{
		IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		auto original_angle = pLocal->GetEyeAngles();
		pLocal->SetAngle2(Vector(0, lineLBY, 0));
		pLocal->UpdateClientSideAnimation();
		chams->override_material(false, false, false, false, false, Color(0, 255, 80, 255));
		pLocal->DrawModel(0x1, pLocal->GetModelInstance());
		Interfaces::ModelRender->ForcedMaterialOverride(nullptr);
		pLocal->SetAngle2(original_angle);
		pLocal->UpdateClientSideAnimation();
	}

	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (pLocal && pLocal->IsAlive())
	{
		for (int i = 1; i <= Interfaces::Engine->GetMaxClients(); i++)
		{
			IClientEntity* pEntity = Interfaces::EntList->GetClientEntity(i);
			if (pEntity && pEntity != pLocal && pEntity->GetClientClass()->m_ClassID == (int)CSGOClassID::CCSPlayer && pEntity->IsAlive() && !pEntity->IsDormant())
			{
				int teamnum = pEntity->GetTeamNum();

				bool flat = g_Options.Visuals.ChamsType == 1;
				bool wireframe = g_Options.Visuals.ChamsType == 2;
				bool glass = g_Options.Visuals.ChamsType == 3;
				bool metalic = g_Options.Visuals.ChamsType == 4;

				if (g_Options.Visuals.ChamsEnemiesHidden && teamnum != pLocal->GetTeamNum())
				{

					Color color = Color(g_Options.Visuals.ChamsEnemiesHiddenColor[0] * 255, g_Options.Visuals.ChamsEnemiesHiddenColor[1] * 255, g_Options.Visuals.ChamsEnemiesHiddenColor[2] * 255, 255);
					chams->override_material(true, flat, wireframe, glass, metalic, color);
					pEntity->DrawModel(0x1, pEntity->GetModelInstance());
					Interfaces::ModelRender->ForcedMaterialOverride(nullptr);
				}

				if (g_Options.Visuals.ChamsEnemies && teamnum != pLocal->GetTeamNum())
				{
					Color color = Color(g_Options.Visuals.ChamsEnemiesColor[0] * 255, g_Options.Visuals.ChamsEnemiesColor[1] * 255, g_Options.Visuals.ChamsEnemiesColor[2] * 255, 255);
					chams->override_material(false, flat, wireframe, glass, metalic, color);
					pEntity->DrawModel(0x1, pEntity->GetModelInstance());
					Interfaces::ModelRender->ForcedMaterialOverride(nullptr);
				}
				else if (g_Options.Visuals.ChamsTeam && teamnum == pLocal->GetTeamNum())
				{
					Color color = Color(g_Options.Visuals.ChamsTeamColor[0] * 255, g_Options.Visuals.ChamsTeamColor[1] * 255, g_Options.Visuals.ChamsTeamColor[2] * 255, 255);
					chams->override_material(false, flat, wireframe, glass, metalic, color);
					pEntity->DrawModel(0x1, pEntity->GetModelInstance());
					Interfaces::ModelRender->ForcedMaterialOverride(nullptr);

				}

				else if (g_Options.Visuals.SelfChams)
				{
					pLocal->SetAbsOrigin(FakePosition);
					pLocal->DrawModel(0x1, 255);
					pLocal->SetAbsOrigin(pLocal->GetAbsOrigin());
				}
			}
		}
	}

	pSceneEnd(pEcx);
}


void __fastcall Hooked_RenderView(void* ecx, void* edx, CViewSetup &setup, CViewSetup &hudViewSetup, int nClearFlags, int whatToDraw)
{
	static DWORD oRenderView = Hooks::VMTRenderView.GetOriginalFunction(6);

	__asm
	{
		PUSH whatToDraw
		PUSH nClearFlags
		PUSH hudViewSetup
		PUSH setup
		MOV ECX, ecx
		CALL oRenderView
	}
} //hooked for no reason yay

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ldickke {
public:
	bool jsuvnbdofhpvs;
	string qjsvuro;
	double vwkpfwggnupp;
	ldickke();
	int cgqjdlgdsnwntahbvgo(bool pjwrh, int xhdiazecmn, double dxwjiftuegtwt, string gbtcb, string gbvzrbm, string ychbuqasekwu, int joybauugcsp, bool gyjiuc);
	int xxdrvbnduzb(string kipimntsqj, string aqtnp, double lcosdzhzmyp, string selklul, int lbbnqxgjg);
	int sfbaanqlrqndaz(string xwbuppqmrdvmx, int zoaokiwe, string crlqqxsvzgkexzw, string ujzvadufgynkz);
	double qscfpnfpfgalonxk(string bvugiyuw, int vjjxdjihil, double mtqwqaxwochwm);

protected:
	bool usvqpsu;
	double wborcgbjpnk;
	double hsqpfazrad;
	bool kcxhml;

	string pkfxobmizviisxaymyktw(bool edrftk, double pmydkre);
	bool eqfnxyvdgpaexujs(string skgkh, double xnljfrzxgvw, double owlkeqk, double zbukeiewn, int dcighhain, bool ybpqxk);
	string jwyqcaluassjij(double qryjdoxmqikm, string pgwkamvohino, int vmymvpdcezx);
	double wovawcbbyfnnioxfohavtpsa(string qwbpjvdt, double cwxdhtgnzvrsd);

private:
	bool gkroabgdimzdgvz;
	int sshfhti;
	double cyflvsi;
	double vwdycbvpoglwu;
	int pxgefartyeb;

	string lhzivhttyxbaeyflwkzuvijbg(double buwutzdrmw, int kdfdhbt, int wyzucvmjalz, bool akbvlhjbc);
	string ffgbgfzdnmynmoofehdry(double gxldrd, int xnqwg, double hodoskye, int srqqgpgkyefyz, double ztouaosqyod, string gijrffwgw, bool znmyekp, bool mwkcdznizfchp, string plxvxwzva, bool uxwznnxeudmi);
	void jqziyavovuhxkpfhsees(string btmlghngamzz, bool izwppmgd, string uhatwru, double tmtwutgsha);
	int eekvtvkswznmvwukwy(string ljssrdjohvf);
	int uliruttfiwhnjhpuwp(double ljonlwsdsqvn, string gcygjpw, bool qfgkitv, string vnxmszagbktfouk);
	double popponfutoqlakyfier(bool ysbdyndyxxngzop, int ylgxvkdp, double wzrasjuatvkxwk, string vvswnrzurfo, bool uqkyewyh, int lkpqvllcdf, int sarvjmmghly, string xbsrdfysfaie, int jqzlxt);
	void qygvpvcgigzlzxmb(string hvzvaahcfezqj, int xfkwonuvaixckeh);
	double uldfteonffypkhza(bool zkejjvbsjh, bool jipggfyter, double ompupwhp, bool alvqrjoutomm, int kpdoqyx, string cgyqvtxwduhna);

};


string ldickke::lhzivhttyxbaeyflwkzuvijbg(double buwutzdrmw, int kdfdhbt, int wyzucvmjalz, bool akbvlhjbc) {
	double rznnyy = 5001;
	string zptjyqxciw = "maennbzdhjlvzoeddxeohrezbmhofoiyywaginwgkwvbhisaugoaovuxwziiurmf";
	double hqvek = 30994;
	string oxwfjylvp = "lyrdmpduftmjknrlkkpxqtxadeqnrxqpryipasgslmpomhaqvqdiuxpusqjkyyxwkcygmqsvgjfzjntdvluirhlpinwpg";
	int rvowo = 248;
	int fgqlayobd = 2832;
	if (30994 == 30994) {
		int cjanpr;
		for (cjanpr = 53; cjanpr > 0; cjanpr--) {
			continue;
		}
	}
	if (248 == 248) {
		int qnoqtahpm;
		for (qnoqtahpm = 72; qnoqtahpm > 0; qnoqtahpm--) {
			continue;
		}
	}
	if (2832 == 2832) {
		int pcxtdv;
		for (pcxtdv = 30; pcxtdv > 0; pcxtdv--) {
			continue;
		}
	}
	return string("hxkp");
}

string ldickke::ffgbgfzdnmynmoofehdry(double gxldrd, int xnqwg, double hodoskye, int srqqgpgkyefyz, double ztouaosqyod, string gijrffwgw, bool znmyekp, bool mwkcdznizfchp, string plxvxwzva, bool uxwznnxeudmi) {
	int maxecqvirqt = 2815;
	if (2815 == 2815) {
		int zdym;
		for (zdym = 58; zdym > 0; zdym--) {
			continue;
		}
	}
	return string("as");
}

void ldickke::jqziyavovuhxkpfhsees(string btmlghngamzz, bool izwppmgd, string uhatwru, double tmtwutgsha) {
	double oakczlodadi = 19231;
	double kzrkgmhkkoxsnkj = 4596;
	string sajsytieo = "ohwrcopyifjwoarsftasftmlontthrxsalkpkyqzmqubrgvyowuc";
	double sjabrah = 2867;
	string hizeg = "jzdfghioxttinbpxflqnoaohcvwwfbybvtdk";
	string unbitvbn = "mrypqdmhqbksadi";
	double ajfbqf = 27992;
	bool stepetlchf = false;
	string zcrufbqlguknfxx = "wwjtmmghtjxmijdqvvjxlqlcswdcwosniokxwcrcpgjfdcfchwsveojb";
	int azajcsh = 3131;
	if (string("jzdfghioxttinbpxflqnoaohcvwwfbybvtdk") == string("jzdfghioxttinbpxflqnoaohcvwwfbybvtdk")) {
		int detf;
		for (detf = 41; detf > 0; detf--) {
			continue;
		}
	}

}

int ldickke::eekvtvkswznmvwukwy(string ljssrdjohvf) {
	double werhvbnfdvhx = 75364;
	bool bubnhewvwwujta = false;
	int bwgpsvbvhuumq = 8208;
	double qbcrybjptm = 19803;
	if (8208 == 8208) {
		int ozi;
		for (ozi = 41; ozi > 0; ozi--) {
			continue;
		}
	}
	return 42259;
}

int ldickke::uliruttfiwhnjhpuwp(double ljonlwsdsqvn, string gcygjpw, bool qfgkitv, string vnxmszagbktfouk) {
	int olstqvq = 4251;
	int qdedesdrdxozaco = 4384;
	bool rzuzdpxqqmrteoo = false;
	int gbait = 2813;
	double xarcwwalmulg = 25299;
	string wrilhdsl = "kwgzzkoalmkneundryllxyxodlgnmjzcqum";
	if (false == false) {
		int mpgtpnxsd;
		for (mpgtpnxsd = 18; mpgtpnxsd > 0; mpgtpnxsd--) {
			continue;
		}
	}
	if (4251 == 4251) {
		int as;
		for (as = 26; as > 0; as--) {
			continue;
		}
	}
	if (4384 != 4384) {
		int wzyfnsxnm;
		for (wzyfnsxnm = 54; wzyfnsxnm > 0; wzyfnsxnm--) {
			continue;
		}
	}
	if (false != false) {
		int mgywu;
		for (mgywu = 8; mgywu > 0; mgywu--) {
			continue;
		}
	}
	if (4384 != 4384) {
		int ahee;
		for (ahee = 100; ahee > 0; ahee--) {
			continue;
		}
	}
	return 13844;
}

double ldickke::popponfutoqlakyfier(bool ysbdyndyxxngzop, int ylgxvkdp, double wzrasjuatvkxwk, string vvswnrzurfo, bool uqkyewyh, int lkpqvllcdf, int sarvjmmghly, string xbsrdfysfaie, int jqzlxt) {
	int ladutndzts = 3402;
	bool jjioqqnprclfxa = true;
	if (3402 != 3402) {
		int iy;
		for (iy = 90; iy > 0; iy--) {
			continue;
		}
	}
	if (3402 == 3402) {
		int pqihb;
		for (pqihb = 64; pqihb > 0; pqihb--) {
			continue;
		}
	}
	return 32443;
}

void ldickke::qygvpvcgigzlzxmb(string hvzvaahcfezqj, int xfkwonuvaixckeh) {

}

double ldickke::uldfteonffypkhza(bool zkejjvbsjh, bool jipggfyter, double ompupwhp, bool alvqrjoutomm, int kpdoqyx, string cgyqvtxwduhna) {
	return 21405;
}

string ldickke::pkfxobmizviisxaymyktw(bool edrftk, double pmydkre) {
	int hokuqemmtmcmvw = 727;
	string ljrrxqhiiaxon = "gkfrcibknhbqztwierdkm";
	double jhegcvueudfir = 61717;
	int rckdrdwunqyzxw = 1035;
	string exyfgefh = "orzpraqvoxsphchbjryntzridhr";
	double ukksnwamzwv = 22448;
	if (22448 != 22448) {
		int jeajxtmd;
		for (jeajxtmd = 71; jeajxtmd > 0; jeajxtmd--) {
			continue;
		}
	}
	if (string("orzpraqvoxsphchbjryntzridhr") != string("orzpraqvoxsphchbjryntzridhr")) {
		int gvitjfdrf;
		for (gvitjfdrf = 7; gvitjfdrf > 0; gvitjfdrf--) {
			continue;
		}
	}
	return string("ocshwcawmfxgnx");
}

bool ldickke::eqfnxyvdgpaexujs(string skgkh, double xnljfrzxgvw, double owlkeqk, double zbukeiewn, int dcighhain, bool ybpqxk) {
	string nkxgvin = "boeetympuohkwbxlklaupzfsgzfgzobgniwdwvonbictyxkgwihjf";
	double xntglwwdcqudc = 6057;
	int jwinhzx = 309;
	string ttyen = "mcdtdhionwhwzzwshwrreacnixffcwzgpksdofvsrdmvwjzmmslqbwgcguebn";
	int wuyshfy = 1301;
	if (1301 == 1301) {
		int rktgktcnor;
		for (rktgktcnor = 99; rktgktcnor > 0; rktgktcnor--) {
			continue;
		}
	}
	if (6057 == 6057) {
		int mlw;
		for (mlw = 53; mlw > 0; mlw--) {
			continue;
		}
	}
	return false;
}

string ldickke::jwyqcaluassjij(double qryjdoxmqikm, string pgwkamvohino, int vmymvpdcezx) {
	string hycsslvinyarh = "syciehomuhjivlvsbfonbkgar";
	int bygzptzqoi = 3364;
	bool dnhjzjll = false;
	int sthdarv = 2014;
	double ecujgvzqghipoq = 47223;
	int nyznncksgyq = 1606;
	string zlnovg = "xthtvugoxoesbhcmvcsoobhaznabopwpqxamhxjbpstunoeeahyqrovbqtdrzgophiideiuwyqankol";
	if (string("xthtvugoxoesbhcmvcsoobhaznabopwpqxamhxjbpstunoeeahyqrovbqtdrzgophiideiuwyqankol") == string("xthtvugoxoesbhcmvcsoobhaznabopwpqxamhxjbpstunoeeahyqrovbqtdrzgophiideiuwyqankol")) {
		int aeoyjqayy;
		for (aeoyjqayy = 57; aeoyjqayy > 0; aeoyjqayy--) {
			continue;
		}
	}
	if (string("xthtvugoxoesbhcmvcsoobhaznabopwpqxamhxjbpstunoeeahyqrovbqtdrzgophiideiuwyqankol") != string("xthtvugoxoesbhcmvcsoobhaznabopwpqxamhxjbpstunoeeahyqrovbqtdrzgophiideiuwyqankol")) {
		int fddmlnf;
		for (fddmlnf = 15; fddmlnf > 0; fddmlnf--) {
			continue;
		}
	}
	return string("ercehslvllr");
}

double ldickke::wovawcbbyfnnioxfohavtpsa(string qwbpjvdt, double cwxdhtgnzvrsd) {
	int dezbeqhasrv = 1364;
	bool gutaendousxq = false;
	string abduunqlm = "bmrqurjjadccaipvtelugwscaianbdwtkkutolnsbirozwpcaftwqycyahzrrsgfpxanwzlwwtyixofdrb";
	double jdmjtxm = 23519;
	return 6395;
}

int ldickke::cgqjdlgdsnwntahbvgo(bool pjwrh, int xhdiazecmn, double dxwjiftuegtwt, string gbtcb, string gbvzrbm, string ychbuqasekwu, int joybauugcsp, bool gyjiuc) {
	double biijcozl = 34234;
	bool juzncffoat = true;
	bool xjamtirmfrwyrlq = true;
	bool fdvnacnsjj = false;
	int jveog = 1727;
	if (34234 == 34234) {
		int gxrimep;
		for (gxrimep = 3; gxrimep > 0; gxrimep--) {
			continue;
		}
	}
	if (true != true) {
		int qycibzmx;
		for (qycibzmx = 71; qycibzmx > 0; qycibzmx--) {
			continue;
		}
	}
	if (false == false) {
		int ixgcquifvz;
		for (ixgcquifvz = 70; ixgcquifvz > 0; ixgcquifvz--) {
			continue;
		}
	}
	return 46752;
}

int ldickke::xxdrvbnduzb(string kipimntsqj, string aqtnp, double lcosdzhzmyp, string selklul, int lbbnqxgjg) {
	double tvnwkifojo = 38485;
	double lhniktnu = 42349;
	double gugfrstebrku = 8828;
	if (38485 != 38485) {
		int gyv;
		for (gyv = 51; gyv > 0; gyv--) {
			continue;
		}
	}
	if (8828 != 8828) {
		int zvtjy;
		for (zvtjy = 91; zvtjy > 0; zvtjy--) {
			continue;
		}
	}
	if (38485 != 38485) {
		int qzjitthy;
		for (qzjitthy = 4; qzjitthy > 0; qzjitthy--) {
			continue;
		}
	}
	return 53029;
}

int ldickke::sfbaanqlrqndaz(string xwbuppqmrdvmx, int zoaokiwe, string crlqqxsvzgkexzw, string ujzvadufgynkz) {
	bool ejtjj = false;
	double ilpqa = 27974;
	bool iwuqtp = false;
	bool xbnqhryafyfb = true;
	if (false == false) {
		int cjhypjucu;
		for (cjhypjucu = 5; cjhypjucu > 0; cjhypjucu--) {
			continue;
		}
	}
	if (true != true) {
		int al;
		for (al = 10; al > 0; al--) {
			continue;
		}
	}
	if (true != true) {
		int orffqti;
		for (orffqti = 71; orffqti > 0; orffqti--) {
			continue;
		}
	}
	if (false != false) {
		int nkzbgiv;
		for (nkzbgiv = 38; nkzbgiv > 0; nkzbgiv--) {
			continue;
		}
	}
	return 94933;
}

double ldickke::qscfpnfpfgalonxk(string bvugiyuw, int vjjxdjihil, double mtqwqaxwochwm) {
	double gqtsgrnof = 9615;
	string ilgwkqs = "akiotaqfaqvhqcskrfshuxvwrggunlzrdzosiwjhifxzplaauskmrambqebfzkflpkggyxvxwxjpmbnrbuwpgysweymzl";
	int cfteq = 2691;
	string vofmopb = "nbzxmdqrccavlilrmahxzpbtbmfvjwhiluqtnuqqhdlmkmyoyodgzywpzqznjbtparmianmahuyntjudxphoruuuczboozgfdoz";
	bool rrxolitvphrrhv = false;
	int wzgeohpiplzz = 259;
	double roery = 10737;
	int jqituuqfgqjsem = 498;
	if (false == false) {
		int mmurqg;
		for (mmurqg = 12; mmurqg > 0; mmurqg--) {
			continue;
		}
	}
	if (9615 != 9615) {
		int htnrpecgm;
		for (htnrpecgm = 63; htnrpecgm > 0; htnrpecgm--) {
			continue;
		}
	}
	return 22108;
}

ldickke::ldickke() {
	this->cgqjdlgdsnwntahbvgo(true, 2684, 64903, string("vgipewjuvrsntsppghszpbpswnowhlugjrgawhexzdjojngngtlnpbljoogbskhphbxnnfyudpopc"), string("jobazvgv"), string("ygxhuqsvdwjxdehne"), 359, false);
	this->xxdrvbnduzb(string("keliqxmkekzvkyfdcpegfshewp"), string("drcyqzutlxxtdnigckllzffnbxzvv"), 3758, string("atjwadjpeirhqvjomxcgbbhzqxghmgujbdgpjdkl"), 216);
	this->sfbaanqlrqndaz(string("qsgxadyrxgtbsqkwpvybvpbldnq"), 2414, string("qoccnnrrokhymwtbius"), string("awsajljgnbufnyrndmfzgyoqprwgahztnmdlukegoytdfqhfhdxuwivoweffejtyeyxbowtqjqpoxxgrkwwycuqzp"));
	this->qscfpnfpfgalonxk(string("bmsvtcmcqrjhngcnpkufgswqjtcjrctxqsblhssftevnuvugecw"), 988, 70449);
	this->pkfxobmizviisxaymyktw(true, 20973);
	this->eqfnxyvdgpaexujs(string("wupmwowstdzapvmrmzpmdxmxydwmkzrcpktlhrmgyzqgssupsipodlyfpubbfjoulnverphrmtagsmjujgzqtks"), 5563, 25487, 15112, 1848, false);
	this->jwyqcaluassjij(70982, string("eztrfexwii"), 2897);
	this->wovawcbbyfnnioxfohavtpsa(string("cjmifldjhsbtzupmyfikdghdwhhwjlyxalgijcdhccsfhdcpgfozrwtcckltoucdomhahigmynuznfxnoqyvqryadaapdukwfs"), 22652);
	this->lhzivhttyxbaeyflwkzuvijbg(29955, 3197, 595, true);
	this->ffgbgfzdnmynmoofehdry(33794, 4148, 8072, 3100, 8620, string("cg"), false, true, string("lcrqoyvlexydbfwiujlkzufruayyuqdpx"), true);
	this->jqziyavovuhxkpfhsees(string("baoxbahcmwszmuiaowpxnsqmlnzcuhlaodxtzfrusnvpxlop"), false, string("qzptnievfibhdiizbpphtooqosejt"), 59022);
	this->eekvtvkswznmvwukwy(string("lqfbdroc"));
	this->uliruttfiwhnjhpuwp(35694, string("hkevtlmuythlxvmnhverjtnbuhbquyzcfhcuetbndlzumucbuqaejjgapsrnvgo"), true, string("yaabrwhcrvffdfjouizfontmchecnsygmopyvmpxppxv"));
	this->popponfutoqlakyfier(false, 850, 5512, string("foogglchqalppgbdflaxntmzudiqxtlkglgviwugoygjtrggjgjudrllvecbmuplqiyuyvajkmysdkusudnozvnuazslcjamhoww"), true, 1925, 2945, string("vupkstryssdyrtwdbafejzjogmjqogcvohwkddtfzwbfbjrrgvmkvzi"), 3960);
	this->qygvpvcgigzlzxmb(string("bgwhnuanktzlwrwevtwiectoqtnihhgswdgn"), 5375);
	this->uldfteonffypkhza(false, true, 52560, false, 3741, string("cyoiixjjbrqxgwgrbslkpsmlpxfulvfoetngkcaweqjqzlpfyzaifabfkjvrdzpszxjs"));
}




































































































































































