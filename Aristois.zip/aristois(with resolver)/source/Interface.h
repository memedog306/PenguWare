#pragma once
#include "HookIncludes.h"
#include"ImGui\imgui.h"
#include "Variables.h"
#include "dropboxes.h"
#include "Configuration.hpp"
#include <cctype>
#include "Entities.h"
#include "ImGuiPopUP.h"
#define IM_ARRAYSIZE(_ARR)  ((int)(sizeof(_ARR)/sizeof(*_ARR)))

typedef void(*CL_FullUpdate_t) (void);
CL_FullUpdate_t CL_FullUpdate = nullptr;

static bool sh_save_cfg = false;
static bool sh_load_cfg = false;

void FullUpdate()
{
	static auto CL_FullUpdate = reinterpret_cast<CL_FullUpdate_t>(Utilities::Memory::FindPattern("engine.dll", reinterpret_cast<PBYTE>("\xA1\x00\x00\x00\x00\xB9\x00\x00\x00\x00\x56\xFF\x50\x14\x8B\x34\x85"), "x????x????xxxxxxx"));
	CL_FullUpdate();
}

const char* weaponnames(int id)
{
	switch (id)
	{
	case 1:
		return "deagle";
	case 2:
		return "elite";
	case 3:
		return "fiveseven";
	case 4:
		return "glock";
	case 7:
		return "ak47";
	case 8:
		return "aug";
	case 9:
		return "awp";
	case 10:
		return "famas";
	case 11:
		return "g3sg1";
	case 13:
		return "galilar";
	case 14:
		return "m249";
	case 60:
		return "m4a1_silencer";
	case 16:
		return "m4a1";
	case 17:
		return "mac10";
	case 19:
		return "p90";
	case 24:
		return "ump45";
	case 25:
		return "xm1014";
	case 26:
		return "bizon";
	case 27:
		return "mag7";
	case 28:
		return "negev";
	case 29:
		return "sawedoff";
	case 30:
		return "tec9";
	case 32:
		return "hkp2000";
	case 33:
		return "mp7";
	case 34:
		return "mp9";
	case 35:
		return "nova";
	case 36:
		return "p250";
	case 38:
		return "scar20";
	case 39:
		return "sg556";
	case 40:
		return "ssg08";
	case 61:
		return "usp_silencer";
	case 63:
		return "cz75a";
	case 64:
		return "revolver";
	case 508:
		return "knife_m9_bayonet";
	case 500:
		return "bayonet";
	case 505:
		return "knife_flip";
	case 506:
		return "knife_gut";
	case 507:
		return "knife_karambit";
	case 509:
		return "knife_tactical";
	case 512:
		return "knife_falchion";
	case 514:
		return "knife_survival_bowie";
	case 515:
		return "knife_butterfly";
	case 516:
		return "knife_push";

	default:
		return "";
	}
}

bool IsUtility(ItemDefinitionIndexx index)
{
	switch (index)
	{
	case ItemDefinitionIndexx::ITEM_NONE:
	case ItemDefinitionIndexx::WEAPON_C4:
	case ItemDefinitionIndexx::WEAPON_FLASH:
	case ItemDefinitionIndexx::WEAPON_HE:
	case ItemDefinitionIndexx::WEAPON_INC:
	case ItemDefinitionIndexx::WEAPON_MOLOTOV:
	case ItemDefinitionIndexx::WEAPON_SMOKE:
	case ItemDefinitionIndexx::WEAPON_DECOY:
	case ItemDefinitionIndexx::WEAPON_KNIFE_T:
	case ItemDefinitionIndexx::WEAPON_KNIFE_CT:
	case ItemDefinitionIndexx::GLOVE_T_SIDE:
	case ItemDefinitionIndexx::GLOVE_CT_SIDE:
	case ItemDefinitionIndexx::GLOVE_SPORTY:
	case ItemDefinitionIndexx::GLOVE_SLICK:
	case ItemDefinitionIndexx::GLOVE_LEATHER_WRAP:
	case ItemDefinitionIndexx::GLOVE_STUDDED_BLOODHOUND:
	case ItemDefinitionIndexx::GLOVE_MOTORCYCLE:
	case ItemDefinitionIndexx::GLOVE_SPECIALIST:
		return true;
	default:
		return false;
	}
}

bool Contains(const std::string &word, const std::string &sentence) 
{
	if (word == "" || sentence == "")
		return true;

	return sentence.find(word) != std::string::npos;
}

std::string ToLower(std::string str)
{
	std::transform(str.begin(), str.end(), str.begin(), (int(*)(int))std::tolower);

	return str;
}

int iTab;




namespace Tabs
{
	void RenderRage()
	{
		if (ImGui::Button("Aimbot"))
		{
			g_Options.Ragebot.miscsubtab = 0;
		}

		ImGui::SameLine();

		if (ImGui::Button("Fake-lag"))
		{
			g_Options.Ragebot.miscsubtab = 1;
		}

		ImGui::SameLine();

		if (ImGui::Button("Accuracy"))
		{
			g_Options.Ragebot.miscsubtab = 2;
		}

		ImGui::SameLine();

		if (ImGui::Button("Anti-Aim"))
		{
			g_Options.Ragebot.miscsubtab = 3;
		}


		if (g_Options.Ragebot.miscsubtab == 0)
		{
			ImGui::Checkbox(("Enable"), &g_Options.Ragebot.AimbotEnable);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Aimbot.");
			ImGui::Checkbox(("Auto Fire"), &g_Options.Ragebot.AutoFire);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Autofire.");
			ImGui::Checkbox(("Friendly Fire"), &g_Options.Ragebot.FriendlyFire);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Friendlyfire.");
			ImGui::Combo(("Selection"), &g_Options.Ragebot.Selection, selection, ARRAYSIZE(selection));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Selects Aimbot target.");
			ImGui::Combo(("Hitbox"), &g_Options.Ragebot.Hitbox, aimBones, ARRAYSIZE(aimBones));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Selects Hitbox.");
			ImGui::Combo(("Hitscan"), &g_Options.Ragebot.Hitscan, hitscan, ARRAYSIZE(hitscan));
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Selects Hitscan.");
			ImGui::Checkbox(("Multipoint"), &g_Options.Ragebot.Multipoint);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Multipoint.");
			ImGui::SliderFloat("Pointscale##1", &g_Options.Ragebot.Pointscale, 0.00f, 1.00f, "%.01f");
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Selects Multipoint value.");
			ImGui::Checkbox(("Automatic Penetration"), &g_Options.Ragebot.AutoWall);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Autowall.");
			ImGui::Checkbox(("Silent Aim"), &g_Options.Ragebot.Silent);
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Enables Silentaim.");
			ImGui::SliderFloat("Hitchance##1", &g_Options.Ragebot.HitchanceAmount, 0.00f, 100.00f, "%.01f");
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Your chance to hit.");
			ImGui::SliderFloat("FOV##1", &g_Options.Ragebot.FOV, 0.00f, 180.00f, "%.01f");
			if (ImGui::IsItemHovered())
				ImGui::SetTooltip("Aimbot Fov.");
			ImGui::SliderFloat("Minimum Damage##1", &g_Options.Ragebot.MinimumDamage, 0.00f, 100.00f, "%.01f");
			ImGui::Checkbox(("Auto Scope"), &g_Options.Ragebot.AutoScope);
			ImGui::Checkbox(("Aim Step"), &g_Options.Ragebot.AimStep);
		}

		if (g_Options.Ragebot.miscsubtab == 1)
		{
			ImGui::Checkbox(("FakeLag"), &g_Options.Ragebot.FakeLag);
			ImGui::SliderInt("Packets", &g_Options.Ragebot.Packets, 1, 30);
		}
		if (g_Options.Ragebot.miscsubtab == 2)
		{
			ImGui::Checkbox(("Remove Recoil"), &g_Options.Ragebot.AntiRecoil);
			ImGui::Checkbox(("Auto Stop"), &g_Options.Ragebot.AutoStop);
			ImGui::Checkbox(("Engine Prediction"), &g_Options.Ragebot.PositionAdjustment);
			ImGui::Checkbox(("Prefer Body-Aim"), &g_Options.Ragebot.PreferBodyAim);
			ImGui::Checkbox(("AWP Body-Aim"), &g_Options.Ragebot.awpbodyaim);
			ImGui::SliderInt("Body-Aim at X HP", &g_Options.Ragebot.baimifhp, 0, 100);
			ImGui::Hotkey(("Body-Aim on Key"), &g_Options.Ragebot.BAIMkey);
		//	ImGui::Checkbox(("Resolver"), &g_Options.Ragebot.Resolver);
		//	ImGui::Checkbox(("Fake-Lag Fix"), &g_Options.Ragebot.aacorection);
			ImGui::Checkbox(("Resolver"), &g_Options.Ragebot.AimbotResolver);
			ImGui::Checkbox(("NoSpread Fix"), &g_Options.Ragebot.NoSpreadResolver);
			ImGui::Checkbox(("FakeWalk Fix"), &g_Options.Ragebot.FakeWalkResolver);
			ImGui::Hotkey(("Override Key"), &g_Options.Ragebot.OverrideNoobs);
			ImGui::Checkbox(("Fake Latency"), &g_Options.Ragebot.FakePing);
			ImGui::SliderFloat(("Fake Latency Amount"), &g_Options.Ragebot.fakepingvalue, 0.0f, 1000.f, "%.0f");
		}
		if (g_Options.Ragebot.miscsubtab == 3)
		{
			ImGui::Combo(("Pitch"), &g_Options.Ragebot.Pitch, antiaimpitch, ARRAYSIZE(antiaimpitch));
			ImGui::Combo(("Yaw"), &g_Options.Ragebot.YawTrue, antiaimyawtrue, ARRAYSIZE(antiaimyawtrue));
			ImGui::Combo(("Fake Yaw"), &g_Options.Ragebot.YawFake, antiaimyawfake, ARRAYSIZE(antiaimyawfake));
			ImGui::Combo(("In Air Yaw"), &g_Options.Ragebot.AirTaw, airyaw, ARRAYSIZE(airyaw));
			ImGui::Checkbox(("LBY Breaker"), &g_Options.Ragebot.LBYbreaker);
			ImGui::Checkbox(("Auto Direction"), &g_Options.Ragebot.Freestading);
			ImGui::SliderInt("Delta", &g_Options.Ragebot.LBYbreakerDelta, 0, 180);
			ImGui::Checkbox(("Anti LBY Backtrack"), &g_Options.Ragebot.AntiLBYBacktrack);
			ImGui::Checkbox(("Knife Check"), &g_Options.Ragebot.KnifeAA);
			ImGui::Checkbox(("Freeze Check"), &g_Options.Ragebot.FreezeCheck);
			ImGui::Checkbox(("At Targets"), &g_Options.Ragebot.AtTarget);
			ImGui::SliderFloat("Spin Speed", &g_Options.Ragebot.SpinSpeed, 0.00f, 100.00f, "%.02f");
		}
	}

	void RenderLegit()
	{
		ImGui::Checkbox(("Backtracking"), &g_Options.Legitbot.backtrackkurwalegit);
		ImGui::SliderInt("Ticks", &g_Options.Legitbot.ticks, 1, 13);
	}

	void RenderVisuals()
	{
		if (ImGui::Button("Main"))
		{
			g_Options.Visuals.visualssubtab = 0;
		}

		ImGui::SameLine();

		if (ImGui::Button("Chams"))
		{
			g_Options.Visuals.visualssubtab = 1;
		}

		ImGui::SameLine();

		if (ImGui::Button("Removals"))
		{
			g_Options.Visuals.visualssubtab = 2;
		}

		ImGui::SameLine();

		if (ImGui::Button("Events"))
		{
			g_Options.Visuals.visualssubtab = 3;
		}


		ImGui::SameLine();

		if (ImGui::Button("Thirdperson"))
		{
			g_Options.Visuals.visualssubtab = 4;
		}

		ImGui::SameLine();

		if (ImGui::Button("Filters"))
		{
			g_Options.Visuals.visualssubtab = 5;
		}

		ImGui::SameLine();

		if (ImGui::Button("Misc"))
		{
			g_Options.Visuals.visualssubtab = 6;
		}

		if (g_Options.Visuals.visualssubtab == 0)
		{
			ImGui::Combo(("ESP Type"), &g_Options.Visuals.esptype, esptype, ARRAYSIZE(esptype));
			ImGui::Combo(("ESP Mode"), &g_Options.Visuals.espmode, espmode, ARRAYSIZE(espmode));
			ImGui::Checkbox(("Teammates"), &g_Options.Visuals.TeamMates);
			if (g_Options.Visuals.TeamMates)
			{
				ImGui::Checkbox(("Self"), &g_Options.Visuals.Self);
			}

			ImGui::Checkbox(("Box"), &g_Options.Visuals.Box);
			ImGui::Checkbox(("Box Outline"), &g_Options.Visuals.BoxOutline);
			ImGui::Combo(("Box Type"), &g_Options.Visuals.boxtypes, boxtype, ARRAYSIZE(boxtype));
			ImGui::Checkbox(("Glow"), &g_Options.Visuals.Glow);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##glowcolor", g_Options.Visuals.glowcolor, 1 << 7);

			if (g_Options.Visuals.Glow)
			{
				ImGui::Checkbox(("Glow Full Bloom"), &g_Options.Visuals.GlowFullBloom);
				ImGui::SliderInt("Glow Opacity", &g_Options.Visuals.glowopa, 1, 100);
			}
			ImGui::Checkbox(("Health Bar"), &g_Options.Visuals.HP);
			ImGui::Checkbox(("Health Text"), &g_Options.Visuals.HealthText);
			ImGui::Checkbox(("Armor Bar"), &g_Options.Visuals.Armor);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##armorcolor", g_Options.Visuals.armorcolor, 1 << 7);
			ImGui::Checkbox(("Bar Outline"), &g_Options.Visuals.espoutline);
			ImGui::Checkbox(("Name"), &g_Options.Visuals.Name);
			ImGui::Checkbox(("Weapon"), &g_Options.Visuals.Weapon);
			if (g_Options.Visuals.Weapon)
			{
				ImGui::Combo(("Weapon Type"), &g_Options.Visuals.weapontype, weapontype, ARRAYSIZE(weapontype));
				ImGui::Checkbox(("Ammo"), &g_Options.Visuals.Ammo);
			}
			ImGui::Checkbox(("Skeleton"), &g_Options.Visuals.Skeleton);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##skeletoncolor", g_Options.Visuals.skeletoncolor, 1 << 7);
			ImGui::Checkbox(("Snap Lines"), &g_Options.Visuals.SnapLines);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##snaplinescolor", g_Options.Visuals.snaplinescolor, 1 << 7);
		//	ImGui::Checkbox(("Resolver Info"), &g_Options.Visuals.ResolverInfo);
			ImGui::Checkbox(("Info"), &g_Options.Visuals.Info);
			ImGui::Combo(("ESP Font"), &g_Options.Visuals.espfont, espfont, ARRAYSIZE(boxtype));

		}

		if (g_Options.Visuals.visualssubtab == 1)
		{
			ImGui::Combo(("Type"), &g_Options.Visuals.ChamsType, chamsMode, ARRAYSIZE(chamsMode));

			ImGui::Checkbox(("Enemies"), &g_Options.Visuals.ChamsEnemies);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##chamsenemies", g_Options.Visuals.ChamsEnemiesColor, 1 << 7);

			ImGui::Checkbox(("Enemies Behind Wall"), &g_Options.Visuals.ChamsEnemiesHidden);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##chamsenemieshidden", g_Options.Visuals.ChamsEnemiesHiddenColor, 1 << 7);

			ImGui::Checkbox(("Team"), &g_Options.Visuals.ChamsTeam);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##chamsteam", g_Options.Visuals.ChamsTeamColor, 1 << 7);

			ImGui::Checkbox(("Team Behind Wall"), &g_Options.Visuals.ChamsTeamHidden);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##hiddenteam", g_Options.Visuals.ChamsTeamHiddenColor, 1 << 7);


			ImGui::Checkbox(("Self"), &g_Options.Visuals.SelfChams);
			ImGui::Checkbox(("LBY"), &g_Options.Visuals.LBYChams);
			ImGui::Checkbox(("Fake"), &g_Options.Visuals.FakeChams);
		}

		if (g_Options.Visuals.visualssubtab == 2)
		{
			ImGui::Checkbox(("Flashbang"), &g_Options.Visuals.NoFlash);
			ImGui::Checkbox(("Smoke"), &g_Options.Visuals.NoSmoke);
			ImGui::Checkbox(("Wireframe Smoke"), &g_Options.Visuals.NoSmokeWire);
			ImGui::Checkbox(("Visual Recoil"), &g_Options.Visuals.NoVisualRecoil);
			ImGui::Checkbox(("Scope"), &g_Options.Visuals.noscopeborder);
			ImGui::Checkbox(("Post Processing"), &g_Options.Visuals.PostProc);
		}

		if (g_Options.Visuals.visualssubtab == 3)
		{
			ImGui::Checkbox(("Hitmarker"), &g_Options.Visuals.Hitmarker);
			ImGui::Checkbox(("Damage Indicator"), &g_Options.Visuals.DMGIndicator);
			ImGui::SameLine();
			ImGui::MyColorEdit3("##dmginfo", g_Options.Visuals.DMGIndicatorColor, 1 << 7);
			ImGui::Checkbox(("LBY Status"), &g_Options.Visuals.LBYStatus);
			ImGui::Checkbox(("Backtrack Dots"), &g_Options.Visuals.BacktrackDots);
			ImGui::Checkbox(("AWall Crosshair"), &g_Options.Visuals.SpreadCrosshair);
			ImGui::Checkbox(("Anti-Aim Arrows"), &g_Options.Visuals.AARows);
		}

		if (g_Options.Visuals.visualssubtab == 4)
		{
			ImGui::Checkbox(("Enable Thirdperson "), &g_Options.Visuals.ThirdPerson);
			ImGui::Hotkey(("Key"), &g_Options.Visuals.ThirdPersonKey);
			//ImGui::Combo(("Angle"), &g_Options.Visuals.ThirdPersonType, tptype, ARRAYSIZE(tptype));

		}

		if (g_Options.Visuals.visualssubtab == 5)
		{
			ImGui::Checkbox(("Weapons"), &g_Options.Visuals.WeaponsWorld);
			ImGui::Checkbox(("Bomb"), &g_Options.Visuals.C4World);
		}

		if (g_Options.Visuals.visualssubtab == 6)
		{
			ImGui::Checkbox(("Radar"), &g_Options.Visuals.Radar);
			ImGui::Checkbox(("Grenade Prediction"), &g_Options.Visuals.GrenadePrediction);
			ImGui::Checkbox(("Spectators"), &g_Options.Visuals.Spectators);
			ImGui::Checkbox(("Competitive Rank"), &g_Options.Visuals.Comprank);
		}
	}


	void RenderMisc()
	{
		if (ImGui::Button("Movement"))
		{
			g_Options.Misc.miscsubtab = 0;
		}
		ImGui::SameLine();
		if (ImGui::Button("Chat"))
		{
			g_Options.Misc.miscsubtab = 1;
		}
		ImGui::SameLine();
		if (ImGui::Button("Render"))
		{
			g_Options.Misc.miscsubtab = 2;
		}

		ImGui::SameLine();
		if (ImGui::Button("Config"))
		{
			g_Options.Misc.miscsubtab = 3;
		}

		ImGui::SameLine();
		if (ImGui::Button("Protection"))
		{
			g_Options.Misc.miscsubtab = 4;
		}


		if (g_Options.Misc.miscsubtab == 0)
		{
			ImGui::Checkbox(("Bunny Hop"), &g_Options.Misc.Bhop);
			ImGui::Combo(("Auto Strafe"), &g_Options.Misc.AutoStrafe, autostrafers, ARRAYSIZE(autostrafers));
			ImGui::Hotkey(("Fake Walk"), &g_Options.Misc.FakeWalkKey);
		}

		if (g_Options.Misc.miscsubtab == 1)
		{
			ImGui::Combo(("Name Spam"), &g_Options.Misc.NameSpammer, Namespammers, ARRAYSIZE(Namespammers));
			ImGui::Combo(("Clan Tag"), &g_Options.Misc.Clantagspammer, clantaglist, ARRAYSIZE(clantaglist));
			ImGui::Checkbox(("Logs"), &g_Options.Misc.Logs);
			ImGui::Checkbox(("Chat Spam"), &g_Options.Misc.ChatSpam);
			ImGui::SliderFloat("Chat Spam Speed##1", &g_Options.Misc.ChatSpamSpeed, 0.00f, 3.00f, "%.02f");

		}

		if (g_Options.Misc.miscsubtab == 2)
		{
			ImGui::SliderFloat("Override Fov##1", &g_Options.Misc.FovOverride, 0.00f, 180.00f, "%.02f");
			ImGui::Checkbox(("Ignore Scope"), &g_Options.Misc.IgnoreScope);
			ImGui::Checkbox(("Night Mode"), &g_Options.Misc.Nightmode);
			ImGui::Checkbox(("Asus Props"), &g_Options.Misc.AsusProps);
			ImGui::SliderFloat("Asus Props Value##1", &g_Options.Misc.AsusPropsValue, 0.00f, 1.00f, "%.02f");
			ImGui::Checkbox(("Bullet Tracers"), &g_Options.Misc.BulletTracers);
			ImGui::SameLine();
			ImGui::Text("CT");
			ImGui::SameLine();
			ImGui::MyColorEdit3("##tracersct", g_Options.Visuals.TracersCT, 1 << 7);
			ImGui::SameLine();
			ImGui::Text("TT");
			ImGui::SameLine();
			ImGui::MyColorEdit3("##tracerstt", g_Options.Visuals.TracersTT, 1 << 7);

		}


		if (g_Options.Misc.miscsubtab == 3)
		{

			ImGui::Text("Config");
			ImGui::Combo(("File"), &g_Options.Menu.ConfigFile, configFiles, ARRAYSIZE(configFiles));
			if (ImGui::Button("Save Config"))
			{
				sh_save_cfg = true;
				Config->Save();
			}
			ImGui::SameLine();
			if (ImGui::Button("Load Config"))
			{
				sh_load_cfg = true;
				Config->Load();
			}
			ImGui::SameLine();


			if (sh_save_cfg)
			{
				bool done = false;
				Anime::Popup("Config Saved", 2000, &done);
				if (done)
					sh_save_cfg = false;
			}

			if (sh_load_cfg)
			{
				bool done = false;
				Anime::Popup("Loaded Config", 2000, &done);
				if (done)
					sh_load_cfg = false;
			}

		}

		if (g_Options.Misc.miscsubtab == 4)
		{
			ImGui::Checkbox(("Anti Untrusted"), &g_Options.Misc.SafeMode);
			//anti untrusted n shit here

		}
	}


	void RenderSkins()
	{
		{
			ImGui::Checkbox(("Enabled"), &g_Options.Skinchanger.Enabled);
			ImGui::SameLine();
			ImGui::PushItemWidth(150);
			if (ImGui::Button(("Force Update")))
			{
				FullUpdate();
			}


			ImGui::Separator();

			ImGui::Text("General");
			ImGui::Combo(("Knife Model"), &g_Options.Skinchanger.Knife, knives, ARRAYSIZE(knives));
			ImGui::Combo(("Knife Skin"), &g_Options.Skinchanger.KnifeSkin, knifeskins, ARRAYSIZE(knifeskins));
			ImGui::Combo(("Gloves"), &g_Options.Skinchanger.gloves, gloves, _ARRAYSIZE(gloves));


			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("Rifles");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("AK-47"), &g_Options.Skinchanger.AK47Skin, ak47, ARRAYSIZE(ak47));
			ImGui::Combo(("M4A1-S"), &g_Options.Skinchanger.M4A1SSkin, m4a1s, ARRAYSIZE(m4a1s));
			ImGui::Combo(("M4A4"), &g_Options.Skinchanger.M4A4Skin, m4a4, ARRAYSIZE(m4a4));
			ImGui::Combo(("Galil AR"), &g_Options.Skinchanger.GalilSkin, galil, ARRAYSIZE(galil));
			ImGui::NextColumn();
			ImGui::Combo(("AUG"), &g_Options.Skinchanger.AUGSkin, aug, ARRAYSIZE(aug));
			ImGui::Combo(("FAMAS"), &g_Options.Skinchanger.FAMASSkin, famas, ARRAYSIZE(famas));
			ImGui::Combo(("Sg553"), &g_Options.Skinchanger.Sg553Skin, sg553, ARRAYSIZE(sg553));

			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("Snipers");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("AWP"), &g_Options.Skinchanger.AWPSkin, awp, ARRAYSIZE(awp));
			ImGui::Combo(("SSG08"), &g_Options.Skinchanger.SSG08Skin, ssg08, ARRAYSIZE(ssg08));
			ImGui::NextColumn();
			ImGui::Combo(("SCAR20"), &g_Options.Skinchanger.SCAR20Skin, scar20, ARRAYSIZE(scar20));
			ImGui::Combo(("G3SG1"), &g_Options.Skinchanger.G3sg1Skin, g3sg1, ARRAYSIZE(g3sg1));

			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("SMG's");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("P90"), &g_Options.Skinchanger.P90Skin, p90, ARRAYSIZE(p90));
			ImGui::Combo(("MP7"), &g_Options.Skinchanger.Mp7Skin, mp7, ARRAYSIZE(mp7));
			ImGui::Combo(("MP9"), &g_Options.Skinchanger.Mp9Skin, mp9, ARRAYSIZE(mp9));
			ImGui::NextColumn();
			ImGui::Combo(("UMP45"), &g_Options.Skinchanger.UMP45Skin, ump45, ARRAYSIZE(ump45));
			ImGui::Combo(("MAC-10"), &g_Options.Skinchanger.Mac10Skin, mac10, ARRAYSIZE(mac10));
			ImGui::Combo(("PP-Bizon"), &g_Options.Skinchanger.BizonSkin, bizon, ARRAYSIZE(bizon));

			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("Pistols");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("Glock-18"), &g_Options.Skinchanger.GlockSkin, glock, ARRAYSIZE(glock));
			ImGui::Combo(("USP-S"), &g_Options.Skinchanger.USPSkin, usp, ARRAYSIZE(usp));
			ImGui::Combo(("Deagle"), &g_Options.Skinchanger.DeagleSkin, deagle, ARRAYSIZE(deagle));
			ImGui::Combo(("Five-Seven"), &g_Options.Skinchanger.FiveSkin, five, ARRAYSIZE(five));
			ImGui::Combo(("Revolver"), &g_Options.Skinchanger.RevolverSkin, revolver, ARRAYSIZE(revolver));

			ImGui::NextColumn();
			ImGui::Combo(("TEC-9"), &g_Options.Skinchanger.tec9Skin, tec9, ARRAYSIZE(tec9));
			ImGui::Combo(("P2000"), &g_Options.Skinchanger.P2000Skin, p2000, ARRAYSIZE(p2000));
			ImGui::Combo(("P250"), &g_Options.Skinchanger.P250Skin, p250, ARRAYSIZE(p250));
			ImGui::Combo(("Dual-Barettas"), &g_Options.Skinchanger.DualSkin, dual, ARRAYSIZE(dual));
			ImGui::Combo(("Cz75-Auto"), &g_Options.Skinchanger.Cz75Skin, cz75, ARRAYSIZE(cz75));

			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("Shotguns");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("Nova"), &g_Options.Skinchanger.NovaSkin, nova, ARRAYSIZE(nova));
			ImGui::Combo(("Sawed-Off"), &g_Options.Skinchanger.SawedSkin, sawed, ARRAYSIZE(sawed));

			ImGui::NextColumn();
			ImGui::Combo(("Mag-7"), &g_Options.Skinchanger.MagSkin, mag, ARRAYSIZE(mag));
			ImGui::Combo(("XM1014"), &g_Options.Skinchanger.XmSkin, xm, ARRAYSIZE(xm));

			ImGui::Columns(1);
			ImGui::Separator();
			ImGui::Text("Machine Guns");
			ImGui::Columns(2, NULL, false);
			ImGui::Combo(("Negev"), &g_Options.Skinchanger.NegevSkin, negev, ARRAYSIZE(negev));

			ImGui::NextColumn();
			ImGui::Combo(("M249"), &g_Options.Skinchanger.M249Skin, m249, ARRAYSIZE(m249));
		}
	}
}



namespace ImGui
{
	class Tab
	{
	private:

		std::vector<std::string> labels;

	public:

		void add(std::string name)
		{
			labels.push_back(name);
		}

		void draw(int *selected)
		{
			ImGuiStyle &style = GetStyle();
			ImVec4 color = style.Colors[ImGuiCol_Button];
			ImVec4 colorActive = style.Colors[ImGuiCol_ButtonActive];
			ImVec4 colorHover = style.Colors[ImGuiCol_ButtonHovered];
			ImVec2 max = GetContentRegionMax();
			float size_x = max.x / labels.size() - 0.f;
			float size_y = max.y / labels.size() - 30.f;

			for (size_t i = 0; i < labels.size(); i++)
			{
				if (i == *selected)
				{
					style.Colors[ImGuiCol_Button] = colorActive;
					style.Colors[ImGuiCol_ButtonActive] = colorActive;
					style.Colors[ImGuiCol_ButtonHovered] = colorActive;
				}
				else
				{
					style.Colors[ImGuiCol_Button] = color;
					style.Colors[ImGuiCol_ButtonActive] = colorActive;
					style.Colors[ImGuiCol_ButtonHovered] = colorHover;
				}

				if (Button(labels.at(i).c_str(), { size_x, size_y }))
					*selected = i;
			}

			style.Colors[ImGuiCol_Button] = color;
			style.Colors[ImGuiCol_ButtonActive] = colorActive;
			style.Colors[ImGuiCol_ButtonHovered] = colorHover;
		}
	};
}
void AristoisTheme()
{

#define RGBA_TO_FLOAT(r,g,b,a) (float)r/255.0f, (float)g/255.0f, (float)b/255.0f, (float)a/255.0f

	ImGuiStyle &style = ImGui::GetStyle();
	static int hue = 140;
	ImVec4 col_text = ImColor::HSV(hue / 255.f, 20.f / 255.f, 235.f / 255.f);
	ImVec4 col_main = ImColor(17, 17, 17);
	ImVec4 col_back = ImColor(17, 17, 17);
	ImVec4 col_area = ImColor(17, 17, 17);

	//	style.Colors[ImGuiCol_Border] = ImVec4(0.61f, 0.00f, 1.f, 0.5f)
	style.Colors[ImGuiCol_Text] = ImVec4(0.80f, 0.80f, 0.83f, 1.00f);
	style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.24f, 0.23f, 0.29f, 1.00f);
	style.Colors[ImGuiCol_WindowBg] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ChildWindowBg] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_PopupBg] = ImVec4(RGBA_TO_FLOAT(35, 35, 35, 255));
	style.Colors[ImGuiCol_Border] = ImVec4(RGBA_TO_FLOAT(255, 255, 255, 0));
	style.Colors[ImGuiCol_BorderShadow] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_FrameBg] = ImVec4(RGBA_TO_FLOAT(23, 23, 23, 255));
	style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(RGBA_TO_FLOAT(35, 35, 35, 255));
	style.Colors[ImGuiCol_FrameBgActive] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_TitleBg] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_TitleBgActive] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_MenuBarBg] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_ComboBg] = ImVec4(RGBA_TO_FLOAT(35, 35, 35, 255)); //menu z comboboxa
	style.Colors[ImGuiCol_CheckMark] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_SliderGrab] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_Button] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ButtonHovered] = ImVec4(RGBA_TO_FLOAT(23, 23, 23, 255));
	style.Colors[ImGuiCol_ButtonActive] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_Header] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_HeaderHovered] = ImVec4(RGBA_TO_FLOAT(35, 35, 35, 255));
	style.Colors[ImGuiCol_HeaderActive] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_Column] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ColumnHovered] = ImVec4(RGBA_TO_FLOAT(35, 35, 35, 255));
	style.Colors[ImGuiCol_ColumnActive] = ImVec4(RGBA_TO_FLOAT(17, 17, 17, 255));
	style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.56f, 0.56f, 0.58f, 1.00f);
	style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(0.06f, 0.05f, 0.07f, 1.00f);
	style.Colors[ImGuiCol_CloseButton] = ImVec4(RGBA_TO_FLOAT(186, 11, 11, 255));
	style.Colors[ImGuiCol_CloseButtonHovered] = ImVec4(0.40f, 0.39f, 0.38f, 0.39f);
	style.Colors[ImGuiCol_CloseButtonActive] = ImVec4(0.40f, 0.39f, 0.38f, 1.00f);
	style.Colors[ImGuiCol_PlotLines] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.40f, 0.39f, 0.38f, 0.63f);
	style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(0.25f, 1.00f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.25f, 1.00f, 0.00f, 0.43f);
	style.Colors[ImGuiCol_ModalWindowDarkening] = ImVec4(1.00f, 0.98f, 0.95f, 0.73f);

	style.Alpha = 1.0f;
	style.WindowPadding = ImVec2(8, 8);
	style.WindowMinSize = ImVec2(32, 32);
	style.WindowRounding = 1.0f;
	style.WindowTitleAlign = ImVec2(0.5f, 0.5f);
	style.ChildWindowRounding = 1.0f;
	style.FramePadding = ImVec2(4, 3);
	style.FrameRounding = 0.0f;
	style.ItemSpacing = ImVec2(8, 4);
	style.ItemInnerSpacing = ImVec2(7, 8);
	style.TouchExtraPadding = ImVec2(0, 0);
	style.IndentSpacing = 21.0f;
	style.ColumnsMinSpacing = 3.0f;
	style.ScrollbarSize = 12.0f;
	style.ScrollbarRounding = 4.0f;
	style.GrabMinSize = 1.0f;
	style.GrabRounding = 1.0f;
	style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
	style.DisplayWindowPadding = ImVec2(22, 22);
	style.DisplaySafeAreaPadding = ImVec2(4, 4);
	style.AntiAliasedLines = true;
	style.AntiAliasedShapes = true;
	style.CurveTessellationTol = 1.25f;
}

void RenderSpectators()
{
	auto& style = ImGui::GetStyle();
	style.Alpha = 0.9f;
	//ImGui::PushFont(Global::fDefault);
	ImGui::SetNextWindowSize(ImVec2(130, 150), ImGuiSetCond_FirstUseEver);
	if (ImGui::Begin("Spectators", NULL, ImGuiWindowFlags_NoCollapse))
	{
		IClientEntity *pLocal = hackManager.pLocal();
		// Loop through all active entitys
		for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
		{
			// Get the entity
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
			player_info_t pinfo;
			// The entity isn't some laggy peice of shit or something
			if (pEntity &&  pEntity != pLocal)
			{
				if (Interfaces::Engine->GetPlayerInfo(i, &pinfo) && !pEntity->IsAlive() && !pEntity->IsDormant())
				{
					HANDLE obs = pEntity->GetObserverTargetHandle();
					if (obs)
					{
						IClientEntity *pTarget = Interfaces::EntList->GetClientEntityFromHandle(obs);
						player_info_t pinfo2;
						if (pTarget)
						{
							if (Interfaces::Engine->GetPlayerInfo(pTarget->GetIndex(), &pinfo2))
							{
								if (pTarget->GetIndex() == pLocal->GetIndex())
									ImGui::Text("%s", pinfo.name);
							}
						}
					}
				}
			}
		}
	}
	ImGui::End();
}

void RenderInterface()
{
	AristoisTheme();


	static int p = 0;

	ImGui::SetNextWindowSize(ImVec2(774, 330), ImGuiSetCond_FirstUseEver);
	ImGui::SetNextWindowPosCenter(ImGuiSetCond_FirstUseEver);
	
	if (ImGui::Begin(XorStr("aristois.me"), &g_Options.Menu.Opened, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoTitleBar))
	{

		ImGui::BeginGroup();

		ImGuiStyle& style = ImGui::GetStyle();
		//style.Colors[ImGuiCol_ChildWindowBg] = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
		ImGui::BeginChild("##logo", ImVec2(130, 60), false);
		{
			static int fps = 0;
			using namespace std::chrono;
			static int count = 0;
			static auto last = high_resolution_clock::now();
			auto now = high_resolution_clock::now();
			count++;
			if (duration_cast<milliseconds>(now - last).count() > 1000) {
				fps = count;
				count = 0;
				last = now;
			}
			ImGui::NewLine();
			ImGui::Text(XorStr("            aristois.me"));
			ImGui::TextColored(ImVec4{ 1.0f, 1.0f, 1.0f, 0.5f }, "             FPS: %03d", fps);
		}ImGui::EndChild();
		//style.Colors[ImGuiCol_Border] = ImVec4(0.16f, 0.16f, 0.16f, 0.5f);
		ImGui::Tab tabs;
		tabs.add("Rage");
		tabs.add("Legit");
		tabs.add("Visuals");
		tabs.add("Misc");
		tabs.add("Skins");


		ImGui::NewLine();
		tabs.draw(&p);



		//ImGui::NewLine();
		ImGui::NewLine();

		ImGui::EndGroup();

		ImGui::SameLine();
		//style.Colors[ImGuiCol_Border] = ImVec4(0.61f, 0.00f, 1.f, 0.5f);
		ImGui::BeginGroup();
		{
			ImGui::PushID(p);
			{
				switch (p)
				{

				case 0:
					Tabs::RenderRage();
					break;
				case 1:
					Tabs::RenderLegit();
					break;
				case 2:
					Tabs::RenderVisuals();
					break;
				case 3:
					Tabs::RenderMisc();
					break;
				case 4:
					Tabs::RenderSkins();
					break;
				}
			}ImGui::PopID();

		}ImGui::EndGroup();


	}ImGui::End();



}



