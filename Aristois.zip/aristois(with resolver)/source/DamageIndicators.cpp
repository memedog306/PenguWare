#include "DamageIndicators.h"
#include "Interfaces.h"
#include "Hacks.h"
#include "RenderManager.h"
#include "Variables.h"

DamageIndicators damage_indicators;


void DamageIndicators::paint()
{
	auto m_local = Interfaces::Engine->GetLocalPlayer();
	float current_time = hackManager.pLocal()->GetTickBase() * Interfaces::Globals->interval_per_tick;

	for (int i = 0; i < data.size(); i++) {
		if (data[i].flEraseTime < current_time) 
		{
			data.erase(data.begin() + i);
			continue;			
		}

		if (!data[i].bInitialized) 
		{
			data[i].Position = data[i].Player->GetHeadPos();
			data[i].bInitialized = true;
		}
		if (current_time - data[i].flLastUpdate > 0.0001f) 
		{
			data[i].Position.z -= (0.1f * (current_time - data[i].flEraseTime));
			data[i].flLastUpdate = current_time;
		}
		Vector screen_pos;
		if (Render::WorldToScreen(data[i].Position, screen_pos))
		{
			Render::text1(screen_pos.x, screen_pos.y, std::to_string(data[i].iDamage).c_str(), Render::Fonts::ESP, Color(g_Options.Visuals.DMGIndicatorColor[0] * 255, g_Options.Visuals.DMGIndicatorColor[1] * 255, g_Options.Visuals.DMGIndicatorColor[2] * 255, 255));
		}
	}
}
