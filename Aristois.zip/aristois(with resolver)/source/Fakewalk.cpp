#include <time.h>
#include <iostream>
#include "Fakewalk.h"
#include "Vector.h"
#include "Interfaces.h"
#include "Variables.h"
#include "MiscClasses.h"

float local_update;
bool fake_walk;

Vector CalcAngleFakewalk(Vector src, Vector dst)
{
	Vector ret;
	VectorAngles(dst - src, ret);
	return ret;
}

void rotate_movement(float yaw, CUserCmd* cmd)
{
	Vector viewangles;
	Interfaces::Engine->GetViewAngles(viewangles);

	float rotation = DEG2RAD(viewangles.y - yaw);

	float cos_rot = cos(rotation);
	float sin_rot = sin(rotation);

	float new_forwardmove = (cos_rot * cmd->forwardmove) - (sin_rot * cmd->sidemove);
	float new_sidemove = (sin_rot * cmd->forwardmove) + (cos_rot * cmd->sidemove);

	cmd->forwardmove = new_forwardmove;
	cmd->sidemove = new_sidemove;
}

float fakewalk_curtime(CUserCmd* ucmd)
{
	auto local_player = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (!local_player)
		return 0;

	int g_tick = 0;
	CUserCmd* g_pLastCmd = nullptr;
	if (!g_pLastCmd || g_pLastCmd->hasbeenpredicted) 
	{
		g_tick = (float)local_player->GetTickBase();
	}
	else {
		++g_tick;
	}
	g_pLastCmd = ucmd;
	float curtime = g_tick * Interfaces::Globals->interval_per_tick;
	return curtime;
}

void CFakewalk::do_fakewalk(CUserCmd* cmd)
{
	int key1 = g_Options.Misc.FakeWalkKey;
	if (GetAsyncKeyState(key1)) //make sure fakelag is set to max when u trigger fakewalk!
	{
		auto local_player = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		if (!local_player || local_player->GetHealth() <= 0)
			return;

		auto net_channel = Interfaces::Engine->GetNetChannel();
		if (!net_channel)
			return;

		auto animstate = local_player->GetAnimState();
		if (!animstate)
			return;

		const int choked_ticks = net_channel->m_nChokedPackets;

		fake_walk = true;

		if (fabs(local_update - Interfaces::Globals->curtime) <= 0.1)
		{
			cmd->forwardmove = 450;
			rotate_movement(CalcAngleFakewalk(Vector(0, 0, 0), local_player->GetVelocity()).y + 180.f, cmd);
		}

		choked = choked > 7 ? 0 : choked + 1;
		cmd->forwardmove = choked < 2 || choked > 5 ? 0 : cmd->forwardmove;
		cmd->sidemove = choked < 2 || choked > 5 ? 0 : cmd->sidemove;
	}
	else
		fake_walk = false;
}

CFakewalk* slidebitch = new CFakewalk();