
#pragma once
void ApplyNetVarsHooks();
void RemoveNetVarsHooks();
