

void fewfsdhkjcgwjkefjkwe()
{
	float pJunkcode = 177152158;
	pJunkcode = 16827993014057;
	if (pJunkcode = 1282416787);
	pJunkcode = 17658;
	pJunkcode = 180343160523257;
	pJunkcode = 3371643311302;
	if (pJunkcode = 2872918202);
	pJunkcode = 2671395755263;
	pJunkcode = 31252324439875;
	if (pJunkcode = 1979932536);
	pJunkcode = 13532;
	pJunkcode = 150812288414331;
	pJunkcode = 190191345620438;
	if (pJunkcode = 3039017201);
	pJunkcode = 227451107811204;
	pJunkcode = 2794686455443;
	if (pJunkcode = 214529811);
	pJunkcode = 14535153826752;
	pJunkcode = 682137863153;
	pJunkcode = 227252752113686;
	if (pJunkcode = 2094119476);
	pJunkcode = 300912398312117;
	pJunkcode = 13600104288031;
	if (pJunkcode = 2604630649);
	pJunkcode = 99072827820168;
	pJunkcode = 9712698824879;
	if (pJunkcode = 67376268);
	pJunkcode = 8841115627593;
	pJunkcode = 262042207629764;
	if (pJunkcode = 2762232702);
	pJunkcode = 17452262288857;
	pJunkcode = 287042179524;
	if (pJunkcode = 115842997);
	pJunkcode = 1912910119501;
	pJunkcode = 3082952710310;
	if (pJunkcode = 1895124553);
	pJunkcode = 309793094917759;
	pJunkcode = 12926375632246;
	if (pJunkcode = 647028088);
	pJunkcode = 600057754109;
	pJunkcode = 153461441910102;
	if (pJunkcode = 1636519667);
	pJunkcode = 193101002730457;
	pJunkcode = 249461933811048;
	if (pJunkcode = 904025534);
	pJunkcode = 7661231432967;
	pJunkcode = 33581189226917;
	if (pJunkcode = 2755924660);
	pJunkcode = 457848618818;
	pJunkcode = 31399882416313;
	if (pJunkcode = 577265);
	pJunkcode = 19142761328920;
	pJunkcode = 101982937632740;
	if (pJunkcode = 652810630);
	pJunkcode = 171721458329017;
	pJunkcode = 53811298712762;
	if (pJunkcode = 522221241);
	pJunkcode = 4814565025516;
	pJunkcode = 21923322810628;
	if (pJunkcode = 512615554);
	pJunkcode = 17913111355401;
	pJunkcode = 28852815327389;
	if (pJunkcode = 2573930943);
	pJunkcode = 17181287108560;
	pJunkcode = 44312858824342;
	if (pJunkcode = 2970117312);
	pJunkcode = 16838306887585;
	pJunkcode = 18232498122483;
	if (pJunkcode = 1764011308);
	pJunkcode = 207412457221058;
	pJunkcode = 58591941425835;
	if (pJunkcode = 288123323);
	pJunkcode = 2814430021549;
	pJunkcode = 6893511030796;
	if (pJunkcode = 1476321593);
	pJunkcode = 107811249922622;
	pJunkcode = 296062387123189;
	if (pJunkcode = 120067402);
	pJunkcode = 251311329511193;
	pJunkcode = 184411824028570;
	if (pJunkcode = 238725664);
	pJunkcode = 1082218058258;
	pJunkcode = 56681543519171;
	if (pJunkcode = 476915558);
	pJunkcode = 26222114237748;
	pJunkcode = 5018204725165;
	if (pJunkcode = 1237225465);
	pJunkcode = 116313041128843;
	pJunkcode = 241001168015336;
	if (pJunkcode = 34652857);
	pJunkcode = 171321258728553;
	pJunkcode = 31755585932695;
	if (pJunkcode = 270922973);
	pJunkcode = 23572171014997;
	pJunkcode = 114392921816115;
	if (pJunkcode = 285893052);
	pJunkcode = 41233125935;
	pJunkcode = 2307268867977;
	if (pJunkcode = 1815819205);
	pJunkcode = 324431973426941;
	pJunkcode = 297105880151;
	if (pJunkcode = 1416814376);
	pJunkcode = 17121014124826;
	pJunkcode = 234041834217075;
	if (pJunkcode = 2331023403);
	pJunkcode = 31313111012833;
	pJunkcode = 183801779622692;
	if (pJunkcode = 248563638);
	pJunkcode = 20384730030;
	pJunkcode = 157281440911719;
	if (pJunkcode = 24545966);
	pJunkcode = 214161298925854;
	pJunkcode = 27823497423083;
	if (pJunkcode = 142658622);
	pJunkcode = 21536172277154;
	pJunkcode = 12918529810005;
	if (pJunkcode = 136510321);
	pJunkcode = 19544991715312;
	pJunkcode = 268182114525469;
	if (pJunkcode = 929011113);
	pJunkcode = 349317300402;
	pJunkcode = 1832232722191;
	if (pJunkcode = 1678923172);
	pJunkcode = 26079685510965;
	pJunkcode = 49422487511819;
	if (pJunkcode = 322786530);
	pJunkcode = 21988927924666;
	pJunkcode = 249433204720325;
	if (pJunkcode = 846426904);
	pJunkcode = 225473158012425;
	pJunkcode = 94353111224326;
	if (pJunkcode = 232118016);
	pJunkcode = 14033234066633;
	pJunkcode = 205961281211273;
	if (pJunkcode = 574728679);
	pJunkcode = 29448277089641;
	pJunkcode = 182265985663;
	if (pJunkcode = 2402217773);
	pJunkcode = 15011241934635;
	pJunkcode = 23712174774652;
	if (pJunkcode = 1911326760);
	pJunkcode = 28435226333379;
	pJunkcode = 95652418632455;
	if (pJunkcode = 246831154);
	pJunkcode = 153091282532525;
	pJunkcode = 60442530918622;
	if (pJunkcode = 2787314614);
	pJunkcode = 1556254925700;
	pJunkcode = 316521564024463;
	if (pJunkcode = 36817991);
	pJunkcode = 135733125514619;
	pJunkcode = 113452895431216;
	if (pJunkcode = 64717769);
	pJunkcode = 21761484729368;
	pJunkcode = 101292703010825;
	if (pJunkcode = 68117766);
	pJunkcode = 441624612788;
	pJunkcode = 283922214617205;
	if (pJunkcode = 1415232379);
	pJunkcode = 2253111456637;
	pJunkcode = 1431670653076;
	if (pJunkcode = 1103929864);
	pJunkcode = 3166829451324;
	pJunkcode = 278502018517724;
	if (pJunkcode = 1153829315);
	pJunkcode = 20868296839727;
	pJunkcode = 319351818132019;
	if (pJunkcode = 2328917669);
	pJunkcode = 12243614715192;
	pJunkcode = 319031488413302;
	if (pJunkcode = 1947323804);
	pJunkcode = 8378111207468;
	pJunkcode = 59702764820742;
	if (pJunkcode = 1317626503);
	pJunkcode = 187731469314973;
	pJunkcode = 200502781626261;
	if (pJunkcode = 478613982);
	pJunkcode = 12357144634080;
	pJunkcode = 26072635018093;
	if (pJunkcode = 3178331111);
	pJunkcode = 5166187412880;
	pJunkcode = 314993249026506;
	if (pJunkcode = 2601817762);
	pJunkcode = 210491456226889;
	pJunkcode = 18718165026171;
	if (pJunkcode = 277228062);
	pJunkcode = 236991258722701;
	pJunkcode = 542675991157;
	if (pJunkcode = 2452711393);
	pJunkcode = 16619450615731;
	pJunkcode = 18728321222720;
	if (pJunkcode = 50037076);
	pJunkcode = 161203009813747;
	pJunkcode = 144502303724184;
	if (pJunkcode = 880531860);
	pJunkcode = 28401324887276;
	pJunkcode = 42472845032461;
	if (pJunkcode = 3087520659);
	pJunkcode = 307391290329630;
	pJunkcode = 65793100031123;
	if (pJunkcode = 942517141);
	pJunkcode = 22303929324432;
	pJunkcode = 18164721115;
	if (pJunkcode = 679924356);
	pJunkcode = 135302989912139;
	pJunkcode = 59171754019784;
	if (pJunkcode = 12166908);
	pJunkcode = 19595730531293;
	pJunkcode = 17670465322179;
	if (pJunkcode = 1029311919);
	pJunkcode = 25216233618327;
	pJunkcode = 184592304821576;
	if (pJunkcode = 2204815554);
	pJunkcode = 19081246319151;
	pJunkcode = 9433130825038;
	if (pJunkcode = 2831419406);
	pJunkcode = 32379282211615;
	pJunkcode = 3412316567299;
	if (pJunkcode = 294693520);
	pJunkcode = 17582942226980;
	pJunkcode = 2091519829509;
	if (pJunkcode = 1050630970);
	pJunkcode = 262403004713344;
	pJunkcode = 83702448922314;
	if (pJunkcode = 1949212464);
	pJunkcode = 304162012030840;
	pJunkcode = 6176371025562;
	if (pJunkcode = 2075515723);
	pJunkcode = 103721287524951;
	pJunkcode = 956714526800;
	if (pJunkcode = 143075514);
	pJunkcode = 13571786929897;
	pJunkcode = 13798291829180;
	if (pJunkcode = 2829030140);
	pJunkcode = 211791105115681;
	pJunkcode = 142742793930915;
	if (pJunkcode = 172222438);
	pJunkcode = 15261297601364;
	pJunkcode = 271522282017534;
	if (pJunkcode = 2646825539);
	pJunkcode = 17308226888603;
	pJunkcode = 321336246599;
	if (pJunkcode = 37818208);
	pJunkcode = 32562137719285;
	pJunkcode = 12551410016463;
	if (pJunkcode = 2048616028);
	pJunkcode = 31195211322786;
	pJunkcode = 137131065425499;
	if (pJunkcode = 235321550);
	pJunkcode = 318952857612873;
	pJunkcode = 30707696415650;
	if (pJunkcode = 1509217054);
	pJunkcode = 257082459126547;
	pJunkcode = 184471953628160;
	if (pJunkcode = 251622890);
	pJunkcode = 22741836716366;
	pJunkcode = 261092977175;
	if (pJunkcode = 230016739);
	pJunkcode = 12933193026859;
	pJunkcode = 221206530264;
	if (pJunkcode = 678414606);
	pJunkcode = 85511068725664;
	pJunkcode = 1307184082382;
	if (pJunkcode = 1463512740);
	pJunkcode = 9115783920903;
	pJunkcode = 192692699825652;
	if (pJunkcode = 206677890);
	pJunkcode = 152911865718813;
	pJunkcode = 5234159733210;
	if (pJunkcode = 1454216345);
	pJunkcode = 223712308618244;
	pJunkcode = 27279824417188;
	if (pJunkcode = 264722383);
	pJunkcode = 5556326779250;
	pJunkcode = 8366312866283;
	if (pJunkcode = 1316923805);
	pJunkcode = 7634241528543;
	pJunkcode = 2494325720858;
	if (pJunkcode = 100374735);
	pJunkcode = 138324526747;
	pJunkcode = 2446084317010;
	if (pJunkcode = 2531420422);
	pJunkcode = 182052009514806;
	pJunkcode = 22094319044327;
	if (pJunkcode = 385412697);
	pJunkcode = 18727169877893;
	pJunkcode = 23062316063680;
	if (pJunkcode = 2436617424);
	pJunkcode = 296252387515556;
	pJunkcode = 309332664822107;
	if (pJunkcode = 924819224);
	pJunkcode = 224112241411038;
	pJunkcode = 1090079201558;
	if (pJunkcode = 2832223282);
	pJunkcode = 256912368530855;
	pJunkcode = 45891962923047;
	if (pJunkcode = 1685616564);
	pJunkcode = 12136140569539;
	pJunkcode = 32151555316982;
	if (pJunkcode = 2196215046);
	pJunkcode = 189351981511708;
	pJunkcode = 50551430818270;
	if (pJunkcode = 27108358);
	pJunkcode = 10194284589472;
	pJunkcode = 278572932715919;
	if (pJunkcode = 101017973);
	pJunkcode = 55722874524384;
	pJunkcode = 10675294619726;
	if (pJunkcode = 51686503);
	pJunkcode = 16414571611346;
	pJunkcode = 31075671916372;
	if (pJunkcode = 529326855);
	pJunkcode = 18741217098752;
	pJunkcode = 185481985211531;
	if (pJunkcode = 3248916945);
	pJunkcode = 286412295330584;
	pJunkcode = 12685664526932;
	if (pJunkcode = 1555411814);
	pJunkcode = 179202709028138;
	pJunkcode = 158503079219588;
}

#pragma once

#include "GUI.h"

#include "Interfaces.h"

void CWindow::SetPosition(int x, int y)
{
	m_x = x; m_y = y;
	fewfsdhkjcgwjkefjkwe();
}

void CWindow::SetSize(int w, int h)
{
	m_iWidth = w;
	m_iHeight = h;
	fewfsdhkjcgwjkefjkwe();
}

void CWindow::SetTitle(std::string title)
{
	Title = title;
	fewfsdhkjcgwjkefjkwe();
}

void CWindow::RegisterTab(CTab* Tab)
{
	if (Tabs.size() == 0)
	{
		SelectedTab = Tab;
	}
	Tab->parent = this;
	Tabs.push_back(Tab);
}

RECT CWindow::GetClientArea()
{
	RECT client;
	client.left = m_x + 8;
	client.top = m_y + 1 + 7;
	client.right = m_iWidth - 4 - 12;
	client.bottom = m_iHeight - 2 - 8 - 26 + 500;
	return client;
}

#define UI_WIN_TOPHEIGHT	26
#define UI_WIN_TITLEHEIGHT	32
#define UI_TAB_WIDTH		130

RECT CWindow::GetTabArea()
{
	RECT client;
	client.left = m_x;
	client.top = m_y + UI_WIN_TOPHEIGHT + UI_WIN_TITLEHEIGHT;
	client.right = UI_TAB_WIDTH;
	client.bottom = m_iHeight - UI_WIN_TOPHEIGHT - UI_WIN_TITLEHEIGHT;
	return client;
}

void CWindow::Open()
{
	m_bIsOpen = true;
}

void CWindow::Close()
{
	m_bIsOpen = false;
	fewfsdhkjcgwjkefjkwe();
}

void CWindow::Toggle()
{
	m_bIsOpen = !m_bIsOpen;
	if (m_bIsOpen)
	{
		Interfaces::Engine->ClientCmd_Unrestricted("cl_mouseenable 0");
		Interfaces::InputSystem->EnableInput(false);
		fewfsdhkjcgwjkefjkwe();
	}

	else
	{
		Interfaces::Engine->ClientCmd_Unrestricted("cl_mouseenable 1");
		Interfaces::InputSystem->EnableInput(true);
		fewfsdhkjcgwjkefjkwe();
	}
}

CControl* CWindow::GetFocus()
{
	return FocusedControl;
}

// TABS ---------------------------------------------------------------------------------------------------

void CTab::fwecsdgrwewyrutyutg()
{
	float pJunkcode = 179869539;
	pJunkcode = 24993833718199;
	if (pJunkcode = 1106312976);
	pJunkcode = 4070;
	pJunkcode = 122401283610981;
	pJunkcode = 3993189528391;
	if (pJunkcode = 290315472);
	pJunkcode = 243823154026140;
	pJunkcode = 177202965816840;
	if (pJunkcode = 2084524923);
	pJunkcode = 13163;
	pJunkcode = 15456220225557;
	pJunkcode = 2923514807372;
	if (pJunkcode = 1526826597);
	pJunkcode = 27511811432350;
	pJunkcode = 19653007325053;
	if (pJunkcode = 170326513);
	pJunkcode = 109242944711268;
	pJunkcode = 308072590316929;
	pJunkcode = 13834679119224;
	if (pJunkcode = 8284474);
	pJunkcode = 179701622911433;
	pJunkcode = 15728609924374;
	if (pJunkcode = 203193609);
	pJunkcode = 157962437720126;
	pJunkcode = 5574325223909;
	if (pJunkcode = 150589279);
	pJunkcode = 210653146721434;
	pJunkcode = 20570198521097;
	if (pJunkcode = 3015316332);
	pJunkcode = 19149777730413;
	pJunkcode = 8510161919195;
	if (pJunkcode = 137743236);
	pJunkcode = 158911373425145;
	pJunkcode = 158183012425332;
	if (pJunkcode = 1593423855);
	pJunkcode = 244171008724694;
	pJunkcode = 192231183211894;
	if (pJunkcode = 145378412);
	pJunkcode = 68973262923695;
	pJunkcode = 23685126159668;
	if (pJunkcode = 2405327289);
	pJunkcode = 6261056612962;
	pJunkcode = 5662481627412;
	if (pJunkcode = 280591885);
	pJunkcode = 24371496320580;
	pJunkcode = 265122393713828;
	if (pJunkcode = 305699375);
	pJunkcode = 4673197719628;
	pJunkcode = 4473122430226;
	if (pJunkcode = 295341756);
	pJunkcode = 188642739125763;
	pJunkcode = 200161391315;
	if (pJunkcode = 1083320501);
	pJunkcode = 2158317324842;
	pJunkcode = 84711820927133;
	if (pJunkcode = 2826722094);
	pJunkcode = 19089197226996;
	pJunkcode = 1003507910957;
	if (pJunkcode = 91282576);
	pJunkcode = 1372255011367;
	pJunkcode = 91892086112194;
	if (pJunkcode = 623527880);
	pJunkcode = 149871880126687;
	pJunkcode = 20612514213551;
	if (pJunkcode = 116876118);
	pJunkcode = 269872349218667;
	pJunkcode = 25722799519981;
	if (pJunkcode = 2048621022);
	pJunkcode = 59503156913231;
	pJunkcode = 8194440830647;
	if (pJunkcode = 1632514123);
	pJunkcode = 23483856631472;
	pJunkcode = 244971902114988;
	if (pJunkcode = 1063028071);
	pJunkcode = 157561912330635;
	pJunkcode = 211611598323953;
	if (pJunkcode = 377328084);
	pJunkcode = 24270289756639;
	pJunkcode = 338680510412;
	if (pJunkcode = 3230722390);
	pJunkcode = 31125593918782;
	pJunkcode = 332655514122;
	if (pJunkcode = 730222935);
	pJunkcode = 11365250045551;
	pJunkcode = 100601176223098;
	if (pJunkcode = 3191110178);
	pJunkcode = 58181706914127;
	pJunkcode = 199015662927;
	if (pJunkcode = 18523296);
	pJunkcode = 177931329124380;
	pJunkcode = 160762765528482;
	if (pJunkcode = 1452418174);
	pJunkcode = 2857232022728;
	pJunkcode = 245821823326510;
	if (pJunkcode = 242458956);
	pJunkcode = 610900130940;
	pJunkcode = 125103122013842;
	if (pJunkcode = 1524015840);
	pJunkcode = 322851056824339;
	pJunkcode = 26371964412019;
	if (pJunkcode = 105711513);
	pJunkcode = 8843135381562;
	pJunkcode = 304401626531543;
	if (pJunkcode = 49671373);
	pJunkcode = 274858659271;
	pJunkcode = 292512992827467;
	if (pJunkcode = 3253618692);
	pJunkcode = 23739225923487;
	pJunkcode = 303502453722910;
	if (pJunkcode = 2558422186);
	pJunkcode = 8126676215262;
	pJunkcode = 1114529767300;
	if (pJunkcode = 2158813216);
	pJunkcode = 28404104904051;
	pJunkcode = 20919187402548;
	if (pJunkcode = 3020531548);
	pJunkcode = 212162943497;
	pJunkcode = 24796214432249;
	if (pJunkcode = 190641365);
	pJunkcode = 11895229322464;
	pJunkcode = 139571770713285;
	if (pJunkcode = 183427367);
	pJunkcode = 70762201211545;
	pJunkcode = 21632231703209;
	if (pJunkcode = 1644517909);
	pJunkcode = 6085269094526;
	pJunkcode = 12128219115583;
	if (pJunkcode = 72375442);
	pJunkcode = 431113623615;
	pJunkcode = 33222465527249;
	if (pJunkcode = 249885527);
	pJunkcode = 242228325030;
	pJunkcode = 29419172656319;
	if (pJunkcode = 318716096);
	pJunkcode = 14951635910188;
	pJunkcode = 9488268437020;
	if (pJunkcode = 1428731887);
	pJunkcode = 322612923413554;
	pJunkcode = 13323125796497;
	if (pJunkcode = 564117432);
	pJunkcode = 16712647812649;
	pJunkcode = 7109192227849;
	if (pJunkcode = 1467015219);
	pJunkcode = 18489306422394;
	pJunkcode = 291591029216195;
	if (pJunkcode = 1129528573);
	pJunkcode = 262082459313311;
	pJunkcode = 93111668918836;
	if (pJunkcode = 229946935);
	pJunkcode = 303962588914056;
	pJunkcode = 18402108702275;
	if (pJunkcode = 1819131845);
	pJunkcode = 22591119835047;
	pJunkcode = 30308308796106;
	if (pJunkcode = 674015504);
	pJunkcode = 149271213829188;
	pJunkcode = 157772994717163;
	if (pJunkcode = 2981026021);
	pJunkcode = 146622518828154;
	pJunkcode = 7576871931593;
	if (pJunkcode = 641426932);
	pJunkcode = 19186174626840;
	pJunkcode = 5898411422731;
	if (pJunkcode = 2640014034);
	pJunkcode = 315102711710609;
	pJunkcode = 1894437011373;
	if (pJunkcode = 856725240);
	pJunkcode = 306961678719628;
	pJunkcode = 9282243989070;
	if (pJunkcode = 184423457);
	pJunkcode = 2830558311540;
	pJunkcode = 81613225031059;
	if (pJunkcode = 1543412943);
	pJunkcode = 142561642812297;
	pJunkcode = 45261267114978;
	if (pJunkcode = 51628679);
	pJunkcode = 214632779011486;
	pJunkcode = 1984128245832;
	if (pJunkcode = 1625531536);
	pJunkcode = 14348157065818;
	pJunkcode = 143222066117364;
	if (pJunkcode = 230844152);
	pJunkcode = 272102896116487;
	pJunkcode = 323543161228602;
	if (pJunkcode = 2414418128);
	pJunkcode = 2815777051477;
	pJunkcode = 27636467517265;
	if (pJunkcode = 3059510411);
	pJunkcode = 1383190027719;
	pJunkcode = 25805284030037;
	if (pJunkcode = 1464422530);
	pJunkcode = 9668168074981;
	pJunkcode = 201842629727557;
	if (pJunkcode = 1411517939);
	pJunkcode = 1144239630057;
	pJunkcode = 205492998028422;
	if (pJunkcode = 2813431134);
	pJunkcode = 48342086530546;
	pJunkcode = 76842711227903;
	if (pJunkcode = 3158925958);
	pJunkcode = 4917102218932;
	pJunkcode = 231181663419067;
	if (pJunkcode = 1007820150);
	pJunkcode = 2459944506694;
	pJunkcode = 7972940917994;
	if (pJunkcode = 1532917370);
	pJunkcode = 233970074435;
	pJunkcode = 288473107527551;
	if (pJunkcode = 117338865);
	pJunkcode = 16230121069721;
	pJunkcode = 2560792065267;
	if (pJunkcode = 548912002);
	pJunkcode = 4578425215405;
	pJunkcode = 95801543131905;
	if (pJunkcode = 3040414580);
	pJunkcode = 3124649805653;
	pJunkcode = 130323141425385;
	if (pJunkcode = 2308621556);
	pJunkcode = 1441918105229;
	pJunkcode = 324581915915854;
	if (pJunkcode = 135407554);
	pJunkcode = 1451238118178;
	pJunkcode = 159092456331639;
	if (pJunkcode = 85604548);
	pJunkcode = 303602159819770;
	pJunkcode = 18255653422065;
	if (pJunkcode = 2667129795);
	pJunkcode = 31408211871674;
	pJunkcode = 981427113739;
	if (pJunkcode = 2248217865);
	pJunkcode = 17937205734862;
	pJunkcode = 23998245788793;
	if (pJunkcode = 2812518921);
	pJunkcode = 22379290909141;
	pJunkcode = 288052903318290;
	if (pJunkcode = 202677863);
	pJunkcode = 1212895167010;
	pJunkcode = 1310105591426;
	if (pJunkcode = 419925259);
	pJunkcode = 238133231232461;
	pJunkcode = 2091560205432;
	if (pJunkcode = 2011627458);
	pJunkcode = 23140797613648;
	pJunkcode = 134912545214665;
	if (pJunkcode = 60222941);
	pJunkcode = 14589133136490;
	pJunkcode = 84824543396;
	if (pJunkcode = 880727233);
	pJunkcode = 77453198222767;
	pJunkcode = 26626286667468;
	if (pJunkcode = 2258026997);
	pJunkcode = 4117268119765;
	pJunkcode = 207381524515673;
	if (pJunkcode = 113256983);
	pJunkcode = 44371621914249;
	pJunkcode = 28368132111831;
	if (pJunkcode = 1757718919);
	pJunkcode = 3662236516456;
	pJunkcode = 17069263345965;
	if (pJunkcode = 294233434);
	pJunkcode = 64673111619495;
	pJunkcode = 1565097924967;
	if (pJunkcode = 3183829289);
	pJunkcode = 30441235714300;
	pJunkcode = 277673107519732;
	if (pJunkcode = 1294912415);
	pJunkcode = 31467841427218;
	pJunkcode = 151652536929785;
	if (pJunkcode = 2356428879);
	pJunkcode = 134142961410392;
	pJunkcode = 160693018923069;
	if (pJunkcode = 277869339);
	pJunkcode = 272462379020307;
	pJunkcode = 55431448817067;
	if (pJunkcode = 350027438);
	pJunkcode = 2676031372824;
	pJunkcode = 220762318118483;
	if (pJunkcode = 305642451);
	pJunkcode = 69582242512691;
	pJunkcode = 33631444619785;
	if (pJunkcode = 626428635);
	pJunkcode = 31822993224770;
	pJunkcode = 193921243632612;
	if (pJunkcode = 383920540);
	pJunkcode = 20427332520666;
	pJunkcode = 181041831526976;
	if (pJunkcode = 2890317773);
	pJunkcode = 122823165827522;
	pJunkcode = 114273155628;
	if (pJunkcode = 257142346);
	pJunkcode = 2717470291459;
	pJunkcode = 70821180816989;
	if (pJunkcode = 222815030);
	pJunkcode = 110211808328414;
	pJunkcode = 453282518330;
	if (pJunkcode = 1179913652);
	pJunkcode = 31585502321158;
	pJunkcode = 270061014410734;
	if (pJunkcode = 2427930413);
	pJunkcode = 31442853326625;
	pJunkcode = 1262412542473;
	if (pJunkcode = 142155613);
	pJunkcode = 214681852029436;
	pJunkcode = 250812936926623;
	if (pJunkcode = 397818694);
	pJunkcode = 31147184615268;
	pJunkcode = 156121505115095;
	if (pJunkcode = 2908231852);
	pJunkcode = 4920786927485;
	pJunkcode = 23328249272749;
	if (pJunkcode = 2566830967);
	pJunkcode = 12409237671023;
	pJunkcode = 232801570015153;
	if (pJunkcode = 6186788);
	pJunkcode = 14423241086580;
	pJunkcode = 79932681713974;
	if (pJunkcode = 255365748);
	pJunkcode = 5425174419931;
	pJunkcode = 75662186712307;
}

void CTab::SetTitle(std::string name)
{
	Title = name;
	fwecsdgrwewyrutyutg();

}

void CTab::RegisterControl(CControl* control)
{
	control->parent = parent;
	Controls.push_back(control);
	fwecsdgrwewyrutyutg();
}










































































































































































































































































































































































































































































































