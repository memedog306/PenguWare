
#pragma once

#include "Interfaces.h"

#include "Vector2D.h"

void Quad();


namespace Render
{
	void Initialise();

	// Normal Drawing functions
	void Clear(int x, int y, int w, int h, Color color);
	void Outline(int x, int y, int w, int h, Color color);
	void Line(int x, int y, int x2, int y2, Color color);
	void PolyLine(int *x, int *y, int count, Color color);
	void Polygon(int count, Vertex_t* Vertexs, Color color);
	void PolygonOutline(int count, Vertex_t* Vertexs, Color color, Color colorLine);
	void PolyLine(int count, Vertex_t* Vertexs, Color colorLine);
	void DrawRect(int x, int y, int w, int h, Color col);
	void DrawCircle(float x, float y, float r, float segments, Color color);

	void DrawTexturedPoly(int n, Vertex_t * vertice, Color col);

	void TexturedPolygon(int n, std::vector<Vertex_t> vertice, Color color);

	void DrawFilledCircle(Vector2D center, Color color, float radius, float points);

	void DrawRectRainbow(int x, int y, int width, int height, float flSpeed, float &flRainbow);
	void GradientSideways(int x, int y, int w, int h, Color color1, Color color2, int variation);

	// Gradient Functions
	void GradientV(int x, int y, int w, int h, Color c1, Color c2);
	void GradientH(int x, int y, int w, int h, Color c1, Color c2);

	// Text functions
	namespace Fonts
	{
		extern DWORD Default;
		extern DWORD Menu;
		extern DWORD MenuBold;
		extern DWORD Tabs;
		extern DWORD Icon;
		extern DWORD WaterMark;
		extern DWORD ESP;
		extern DWORD Clock;
		extern DWORD AAarows;
		extern DWORD Slider;
		extern DWORD MenuText;
		extern DWORD Font_Weapons;
		extern DWORD LBY;
		extern DWORD ESPNew;
	};

	void Text(int x, int y, Color color, DWORD font, const char* text);
	void Text(int x, int y, Color color, DWORD font, const wchar_t * text);
	void Textf(int x, int y, Color color, DWORD font, const char* fmt, ...);
	RECT GetTextSize(DWORD font, const char* text);

	// Other rendering functions
	bool WorldToScreen(Vector &in, Vector &out);
	void ColorSpectrum(int x, int y, int w, int h);
	Color ColorSpectrumPen(int x, int y, int w, int h, Vector stx);
	RECT get_text_size(const char * _Input, int font);
	void OutlinedRect(int x, int y, int w, int h, Color color_out, Color color_in);
	void text1(int x, int y, const char * _Input, int font, Color color);
	RECT GetViewport();
};

