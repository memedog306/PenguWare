#include "Hacks.h"
#include "ESP.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include <iostream>
#include "MiscHacks.h"
#include "Variables.h"
#include "glow.h"
#include "Resolver.h"
#include "grenadeprediction.h"
#include "MathFunctions.h"
#include "lagcomp.h"



#define minimum(a,b)            (((a) < (b)) ? (a) : (b))
#define ccsplayer 35


//CEsp esp;
//CVisuals visuals;

extern int resolve_type[65];
float flPlayerAlpha[65];

template<class T, class U>
T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}


extern float lineFakeAngle;
extern float lineRealAngle;
extern float lineLBY;

void CEsp::paint() 
{
	IClientEntity* m_local = hackManager.pLocal();
	NightMode();

	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame())
	{
		for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
			player_info_t pinfo;
			if (pEntity && pEntity != hackManager.pLocal() && !pEntity->IsDormant())
			{
				if (g_Options.Visuals.BacktrackDots)
				{

					if (Interfaces::Engine->GetPlayerInfo(i, &pinfo) && pEntity->IsAlive())
					{
						if (g_Options.Legitbot.backtrackkurwalegit)
						{
							if (m_local == nullptr)
								return;

							if (m_local)
							{
								for (int t = 0; t < 12; ++t)
								{
									Vector screenbacktrack[64][12];

									if (headPositions[i][t].simtime && headPositions[i][t].simtime + 1 > hackManager.pLocal()->GetSimulationTime())
									{
										if (Render::WorldToScreen(headPositions[i][t].hitboxPos, screenbacktrack[i][t]))
										{

											Interfaces::Surface->DrawSetColor(Color(255, 255, 255, 200));
											Interfaces::Surface->DrawOutlinedRect(screenbacktrack[i][t].x, screenbacktrack[i][t].y, screenbacktrack[i][t].x + 2, screenbacktrack[i][t].y + 2);

										}
									}
								}
							}
							else
							{
								memset(&headPositions[0][0], 0, sizeof(headPositions));
							}
						}
						if (g_Options.Ragebot.TestBacktracking)
						{
							if (m_local)
							{
								for (int t = 0; t < 12; ++t)
								{
									Vector screenbacktrack[64];

									if (backtracking->records[i].tick_count + 12 > Interfaces::Globals->tickcount)
									{
										if (Render::WorldToScreen(backtracking->records[i].headPosition, screenbacktrack[i]))
										{

											Interfaces::Surface->DrawSetColor(Color(255, 255, 255, 200));
											Interfaces::Surface->DrawOutlinedRect(screenbacktrack[i].x, screenbacktrack[i].y, screenbacktrack[i].x + 2, screenbacktrack[i].y + 2);

										}
									}
								}
							}
							else
							{
								memset(&backtracking->records[0], 0, sizeof(backtracking->records));
							}
						}
					}
				}
			}
		}
	}

	if (g_Options.Visuals.GrenadePrediction)
	{
		grenade_prediction::instance().Paint();
	}

	if (g_Options.Visuals.AARows)
	{

		int screen_width, screen_height;
		Interfaces::Engine->GetScreenSize(screen_width, screen_height);

		static const auto fake_color = Color(255, 0, 0, 255);


		auto client_viewangles = Vector();
		Interfaces::Engine->GetViewAngles(client_viewangles);

		constexpr auto radius = 80.f;

		const auto screen_center = Vector2D(screen_width / 2.f, screen_height / 2.f);
		const auto fake_rot = DEG2RAD(client_viewangles.y - lineFakeAngle - 90);

		auto draw_arrow = [&](float rot, Color color) -> void
		{
			std::vector<Vertex_t> vertices;
			vertices.push_back(Vertex_t(Vector2D(screen_center.x + cosf(rot) * radius, screen_center.y + sinf(rot) * radius)));
			vertices.push_back(Vertex_t(Vector2D(screen_center.x + cosf(rot + DEG2RAD(12)) * (radius - 25.f), screen_center.y + sinf(rot + DEG2RAD(12)) * (radius - 25.f)))); //25
			vertices.push_back(Vertex_t(Vector2D(screen_center.x + cosf(rot - DEG2RAD(12)) * (radius - 25.f), screen_center.y + sinf(rot - DEG2RAD(12)) * (radius - 25.f)))); //25
			Render::TexturedPolygon(3, vertices, color);
		};

		draw_arrow(fake_rot, fake_color);


		static const auto real_color = Color(0, 255, 0, 255);

		const auto real_rot = DEG2RAD(client_viewangles.y - lineRealAngle - 90);

		draw_arrow(real_rot, real_color);


		static const auto lby_color = Color(0, 0, 255);

		const auto lby_rot = DEG2RAD(client_viewangles.y - lineLBY - 90);

		draw_arrow(lby_rot, lby_color);
	}

	if (m_local) 
	{
		for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
		{
			auto m_entity = static_cast<IClientEntity*>(Interfaces::EntList->GetClientEntity(i));
			if (!m_entity) continue;


			ClientClass* cClass = (ClientClass*)m_entity->GetClientClass();

			if (g_Options.Visuals.C4World)
			{
				if (cClass->m_ClassID == (int)CSGOClassID::CPlantedC4)
					DrawBombPlanted(m_entity, cClass);

				if (cClass->m_ClassID == (int)CSGOClassID::CPlantedC4)
					DrawBombPlanted2(m_entity, cClass);

				if (cClass->m_ClassID == (int)CSGOClassID::CC4)
					DrawBomb(m_entity, cClass);
			}


			if (g_Options.Visuals.Radar)
			{
				DWORD m_bSpotted = NetVar.GetNetVar(0x839EB159);
				*(char*)((DWORD)(m_entity)+m_bSpotted) = 1;
			}

			if (m_entity->GetClientClass()->m_ClassID == ccsplayer)
			{
				if (m_entity->IsDormant() && flPlayerAlpha[i] > 0) flPlayerAlpha[i] -= 5;
				else if (!(m_entity->IsDormant()) && flPlayerAlpha[i] < 255) flPlayerAlpha[i] += 5;
				float alpha = flPlayerAlpha[i];
				clamp(alpha, 0, 255);

				if (m_entity->IsAlive())
				{
					Color plc = Color(get_player_colors(m_entity).r(), get_player_colors(m_entity).g(), get_player_colors(m_entity).b(), alpha);

					Box box; if (!get_box(m_entity, box, g_Options.Visuals.espmode))
					{
						//player.direction_arrow(m_entity->GetOrigin());
						continue;
					}

					if (g_Options.Visuals.Self)
					{
						if (!g_Options.Visuals.TeamMates && m_entity->GetTeamNum() == m_local->GetTeamNum()) continue;
					}
					else
					{
						if (!g_Options.Visuals.TeamMates && m_entity->GetTeamNum() == m_local->GetTeamNum() || m_entity == m_local) continue;
					}

					if (g_Options.Visuals.esptype == 1 && !game::functions.visible(m_local, m_entity, 0)) continue;
					player.paint_player(m_entity, box, plc);
				}
			}
		}
	}
}
void CEsp::CVisualsPlayer::draw_box(IClientEntity* m_entity, Box box, Color color)
{
	float alpha = flPlayerAlpha[m_entity->GetIndex()];


	if (g_Options.Visuals.Box)
	{
		if (!g_Options.Visuals.boxtypes)
		{
			Render::Outline(box.x, box.y, box.w, box.h, color);
			if (g_Options.Visuals.BoxOutline)
			{
				Render::Outline(box.x - 1, box.y - 1, box.w + 2, box.h + 2, Color(21, 21, 21, alpha));
				Render::Outline(box.x + 1, box.y + 1, box.w - 2, box.h - 2, Color(21, 21, 21, alpha));
			}
		}
		else if (g_Options.Visuals.Box)
		{
			float width_corner = box.w / 4;
			float height_corner = width_corner;

			if (g_Options.Visuals.Box)
			{

				Render::DrawRect(box.x - 1, box.y - 1, width_corner + 2, 3, Color(21, 21, 21, alpha));
				Render::DrawRect(box.x - 1, box.y - 1, 3, height_corner + 2, Color(21, 21, 21, alpha));

				Render::DrawRect((box.x + box.w) - width_corner - 1, box.y - 1, width_corner + 2, 3, Color(21, 21, 21, alpha));
				Render::DrawRect(box.x + box.w - 1, box.y - 1, 3, height_corner + 2, Color(21, 21, 21, alpha));

				Render::DrawRect(box.x - 1, box.y + box.h - 4, width_corner + 2, 3, Color(21, 21, 21, alpha));
				Render::DrawRect(box.x - 1, (box.y + box.h) - height_corner - 4, 3, height_corner + 2, Color(21, 21, 21, alpha));

				Render::DrawRect((box.x + box.w) - width_corner - 1, box.y + box.h - 4, width_corner + 2, 3, Color(21, 21, 21, alpha));
				Render::DrawRect(box.x + box.w - 1, (box.y + box.h) - height_corner - 4, 3, height_corner + 3, Color(21, 21, 21, alpha));
			}

			Render::DrawRect(box.x, box.y, width_corner, 1, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x, box.y, 1, height_corner, Color(21, 21, 21, alpha));
			Render::DrawRect((box.x + box.w) - width_corner, box.y, width_corner, 1, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x + box.w, box.y, 1, height_corner, Color(21, 21, 21, alpha));

			Render::DrawRect(box.x, box.y + box.h - 3, width_corner, 1, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x, (box.y + box.h) - height_corner - 3, 1, height_corner, Color(21, 21, 21, alpha));

			Render::DrawRect((box.x + box.w) - width_corner, box.y + box.h - 3, width_corner, 1, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x + box.w, (box.y + box.h) - height_corner - 3, 1, height_corner + 1, Color(21, 21, 21, alpha));
		}
	}
}

void CEsp::CVisualsPlayer::draw_health(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.HP)
	{
		float alpha = flPlayerAlpha[m_entity->GetIndex()];
		int player_health = m_entity->GetHealth() > 100 ? 100 : m_entity->GetHealth();

		if (player_health) {
			int color[3] = { 0, 0, 0 };
			if (player_health >= 85) {
				color[0] = 83; color[1] = 200; color[2] = 84;
			}
			else if (player_health >= 70) {
				color[0] = 107; color[1] = 142; color[2] = 35;
			}
			else if (player_health >= 55) {
				color[0] = 173; color[1] = 255; color[2] = 47;
			}
			else if (player_health >= 40) {
				color[0] = 255; color[1] = 215; color[2] = 0;
			}
			else if (player_health >= 25) {
				color[0] = 255; color[1] = 127; color[2] = 80;
			}
			else if (player_health >= 10) {
				color[0] = 205; color[1] = 92; color[2] = 92;
			}
			else if (player_health >= 0) {
				color[0] = 178; color[1] = 34; color[2] = 34;
			}

			if (g_Options.Visuals.espoutline)
				Render::Outline(box.x - 7, box.y - 1, 4, box.h + 2, Color(21, 21, 21, alpha));

			int health_height = player_health * box.h / 100;
			int add_space = box.h - health_height;

			Color hec = Color(color[0], color[1], color[2], alpha);
			Render::DrawRect(box.x - 6, box.y, 2, box.h, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x - 6, box.y + add_space, 2, health_height, hec);

			if (g_Options.Visuals.HealthText && player_health < 100) 
			{
				RECT text_size = Render::get_text_size(std::to_string(player_health).c_str(), Render::Fonts::ESP);
				Render::text1(box.x - 5 - (text_size.right / 2), box.y + add_space - (text_size.bottom / 2), std::to_string(player_health).c_str(), Render::Fonts::ESP, Color(255, 255, 255, alpha));
			}
		}
	}
}

void CEsp::CVisualsPlayer::draw_armor(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.Armor)
	{
		int player_armor = m_entity->ArmorValue() > 100 ? 100 : m_entity->ArmorValue();
		float alpha = flPlayerAlpha[m_entity->GetIndex()];

		if (player_armor) 
		{
			Color arc = Color(g_Options.Visuals.armorcolor[0] * 255, g_Options.Visuals.armorcolor[1] * 255, g_Options.Visuals.armorcolor[2] * 255, alpha);
			if (g_Options.Visuals.espoutline)
				Render::Outline(box.x - 1, box.y + box.h + 2, box.w + 2, 4, Color(21, 21, 21, alpha));

			int armor_width = player_armor * box.w / 100;

			Render::DrawRect(box.x, box.y + box.h + 3, box.w, 2, Color(21, 21, 21, alpha));
			Render::DrawRect(box.x, box.y + box.h + 3, armor_width, 2, arc);
		}
	}
}

void CEsp::CVisualsPlayer::draw_name(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.Name)
	{
		float alpha = flPlayerAlpha[m_entity->GetIndex()];

		player_info_t player_info;
		if (Interfaces::Engine->GetPlayerInfo(m_entity->GetIndex(), &player_info))
		{
			RECT name_size = Render::get_text_size(player_info.name, Render::Fonts::ESP);

			if (g_Options.Visuals.espfont == 0)
			{
				Render::text1(box.x + (box.w / 2) - (name_size.right / 2), box.y - 14, player_info.name, Render::Fonts::ESP, Color(225, 225, 225, alpha));
			}
			else if (g_Options.Visuals.espfont == 1)
			{
				Render::text1(box.x + (box.w / 2) - (name_size.right / 2), box.y - 14, player_info.name, Render::Fonts::ESPNew, Color(225, 225, 225, alpha));
			}
		}
	}
}

void CEsp::DrawBombPlanted(IClientEntity* pEntity, ClientClass* cClass)
{
	IClientEntity *BombCarrier;

	// Null it out incase bomb has been dropped or planted
	BombCarrier = nullptr;

	Vector vOrig; Vector vScreen;
	vOrig = pEntity->GetOrigin();
	CCSBomb* Bomb = (CCSBomb*)pEntity;

	if (Render::WorldToScreen(vOrig, vScreen))
	{
		float flBlow = Bomb->GetC4BlowTime();
		float TimeRemaining = flBlow - (Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase());
		char buffer[64];
		if (TimeRemaining > 0)
		{
			sprintf_s(buffer, "Bomb", TimeRemaining);
			Render::Text(vScreen.x, vScreen.y, Color(255, 255, 255, 255), Render::Fonts::ESP, buffer);
		}
		else {
			sprintf_s(buffer, "Bomb", TimeRemaining);
			Render::Text(vScreen.x, vScreen.y, Color(255, 25, 25, 255), Render::Fonts::ESP, buffer);
		}
	}
}

bool done = false;
void CEsp::NightMode()
{
	if (g_Options.Misc.Nightmode)
	{
		if (!done)
		{
			static auto sv_skyname = Interfaces::CVar->FindVar("sv_skyname");
			static auto r_DrawSpecificStaticProp = Interfaces::CVar->FindVar("r_DrawSpecificStaticProp");
			r_DrawSpecificStaticProp->SetValue(1);
			sv_skyname->SetValue("sky_csgo_night02");

			for (MaterialHandle_t i = Interfaces::MaterialSystem->FirstMaterial(); i != Interfaces::MaterialSystem->InvalidMaterial(); i = Interfaces::MaterialSystem->NextMaterial(i))
			{
				IMaterial *pMaterial = Interfaces::MaterialSystem->GetMaterial(i);

				if (!pMaterial)
					continue;

				const char* group = pMaterial->GetTextureGroupName();
				const char* name = pMaterial->GetName();

				if (strstr(group, "World textures"))
				{

					pMaterial->ColorModulate(0.10, 0.10, 0.10);
				}
				if (strstr(group, "StaticProp"))
				{

					pMaterial->ColorModulate(0.30, 0.30, 0.30);
				}
				if (strstr(name, "models/props/de_dust/palace_bigdome"))
				{

					pMaterial->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, true);
				}
				if (strstr(name, "models/props/de_dust/palace_pillars"))
				{
					pMaterial->ColorModulate(0.30, 0.30, 0.30);
				}

				if (strstr(group, "Particle textures"))
				{

					pMaterial->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, true);
				}

				done = true;
			}

		}
	}
	else
	{
		if (done)
		{
			for (MaterialHandle_t i = Interfaces::MaterialSystem->FirstMaterial(); i != Interfaces::MaterialSystem->InvalidMaterial(); i = Interfaces::MaterialSystem->NextMaterial(i))
			{
				IMaterial *pMaterial = Interfaces::MaterialSystem->GetMaterial(i);

				if (!pMaterial)
					continue;

				const char* group = pMaterial->GetTextureGroupName();
				const char* name = pMaterial->GetName();

				if (strstr(group, "World textures"))
				{

					pMaterial->ColorModulate(1, 1, 1);
				}
				if (strstr(group, "StaticProp"))
				{

					pMaterial->ColorModulate(1, 1, 1);
				}
				if (strstr(name, "models/props/de_dust/palace_bigdome"))
				{

					pMaterial->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, false);
				}
				if (strstr(name, "models/props/de_dust/palace_pillars"))
				{

					pMaterial->ColorModulate(1, 1, 1);
				}
				if (strstr(group, "Particle textures"))
				{

					pMaterial->SetMaterialVarFlag(MATERIAL_VAR_NO_DRAW, false);
				}

			}
			done = false;
		}
	}

	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && pLocal)
	{

		if (g_Options.Misc.AsusProps)
		{

			{
				if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame()) {
					float AsusWallsAlpha;
					AsusWallsAlpha = g_Options.Misc.AsusPropsValue;

					for (MaterialHandle_t i = Interfaces::MaterialSystem->FirstMaterial(); i != Interfaces::MaterialSystem->InvalidMaterial(); i = Interfaces::MaterialSystem->NextMaterial(i))
					{

						IMaterial *pMaterial = Interfaces::MaterialSystem->GetMaterial(i);

						if (!pMaterial)
							continue;

						const char* group = pMaterial->GetTextureGroupName();
						if (strstr(group, "StaticProp"))
						{

							pMaterial->AlphaModulate(AsusWallsAlpha);

						}

					}
				}

			}
		}
		else
		{

			if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame()) {
				for (MaterialHandle_t i = Interfaces::MaterialSystem->FirstMaterial(); i != Interfaces::MaterialSystem->InvalidMaterial(); i = Interfaces::MaterialSystem->NextMaterial(i))
				{
					IMaterial *pMaterial = Interfaces::MaterialSystem->GetMaterial(i);

					if (!pMaterial)
						continue;

					const char* group = pMaterial->GetTextureGroupName();
					if (strstr(group, "StaticProp"))
					{
						pMaterial->AlphaModulate(1);

					}

				}
			}
		}
	}
}



void CEsp::DrawBombPlanted2(IClientEntity* pEntity, ClientClass* cClass)
{
	IClientEntity *BombCarrier;
	// Null it out incase bomb has been dropped or planted
	BombCarrier = nullptr;

	Vector vOrig; Vector vScreen;
	vOrig = pEntity->GetOrigin();
	CCSBomb* Bomb = (CCSBomb*)pEntity;

	float flBlow = Bomb->GetC4BlowTime();
	float TimeRemaining = flBlow - (Interfaces::Globals->interval_per_tick * hackManager.pLocal()->GetTickBase());
	char buffer[64];
	sprintf_s(buffer, " %.1fs", TimeRemaining);
	Render::Text(10, 10, Color(124, 195, 13, 255), Render::Fonts::LBY, buffer);

}

void CEsp::DrawBomb(IClientEntity* pEntity, ClientClass* cClass)
{
	IClientEntity *BombCarrier;
	BombCarrier = nullptr;
	CBaseCombatWeapon *BombWeapon = (CBaseCombatWeapon *)pEntity;
	Vector vOrig; Vector vScreen;
	vOrig = pEntity->GetOrigin();
	bool adopted = true;
	HANDLE parent = BombWeapon->GetOwnerHandle();
	if (parent || (vOrig.x == 0 && vOrig.y == 0 && vOrig.z == 0))
	{
		IClientEntity* pParentEnt = (Interfaces::EntList->GetClientEntityFromHandle(parent));
		if (pParentEnt && pParentEnt->IsAlive())
		{

			BombCarrier = pParentEnt;
			adopted = false;
		}
	}

	if (adopted)
	{
		if (Render::WorldToScreen(vOrig, vScreen))
		{
			Render::Text(vScreen.x, vScreen.y, Color(112, 230, 20, 255), Render::Fonts::ESP, "Bomb");
		}
	}
}

std::string CleanItemName(std::string name)
{
	std::string Name = name;
	// Tidy up the weapon Name
	if (Name[0] == 'C')
		Name.erase(Name.begin());

	// Remove the word Weapon
	auto startOfWeap = Name.find("Weapon");
	if (startOfWeap != std::string::npos)
		Name.erase(Name.begin() + startOfWeap, Name.begin() + startOfWeap + 6);

	return Name;
}

void CEsp::CVisualsPlayer::draw_weapon_test(IClientEntity* pEntity, Box box)
{
	float alpha = flPlayerAlpha[pEntity->GetIndex()];
	IClientEntity* pWeapon = Interfaces::EntList->GetClientEntityFromHandle((HANDLE)pEntity->GetActiveWeaponHandle());
	if (g_Options.Visuals.Weapon && pWeapon)
	{;
		ClientClass* cClass = (ClientClass*)pWeapon->GetClientClass();
		if (cClass)
		{
			std::string meme;
			if (GameUtils::IsRevolver(pWeapon))
			{
				meme = "Revolver";
			}
			else if (GameUtils::IsDeagle(pWeapon))
			{
				meme = "Deagle";
			}
			else
			{
				meme = CleanItemName(cClass->m_pNetworkName);

			}
			CBaseCombatWeapon* WeaponInfo = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pEntity->GetActiveWeaponHandle());
			std::string Weapon = meme.c_str();
			std::string AmmoAmmount = std::to_string(WeaponInfo->GetAmmoInClip());
			std::string WeaponWithAmmo = Weapon;
			RECT iconSize = Render::GetTextSize(Render::Fonts::Font_Weapons, pWeapon->GetGunIcon());
			RECT WeaponMeme = Render::GetTextSize(Render::Fonts::ESP, WeaponWithAmmo.c_str());
			int i = 0;
			RECT nameSize = Render::GetTextSize(Render::Fonts::ESP, meme.c_str());


			if (g_Options.Visuals.Ammo)
			{
				char buffer[128];
				char* format = "";
				format = XorStr("%1.0f");
				float ammo = WeaponInfo->GetAmmoInClip();
				sprintf_s(buffer, format, ammo);
				Render::text1((box.x + box.w) + 3, box.y, buffer, Render::Fonts::ESP, Color(255, 255, 255, alpha));
			}

			if (g_Options.Visuals.weapontype == 0) //icon
			{

				if (g_Options.Visuals.Armor)
				{
	
					Render::Text(box.x + (box.w / 2) - (iconSize.right / 2), box.y + 5 + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::Font_Weapons, pWeapon->GetGunIcon());
				}
				else
				{
					Render::Text(box.x + (box.w / 2) - (iconSize.right / 2), box.y + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::Font_Weapons, pWeapon->GetGunIcon());
				}
			}

			else if (g_Options.Visuals.weapontype == 1) //text
			{

				if (g_Options.Visuals.Armor)
				{
					if (g_Options.Visuals.espfont == 0)
					{
						Render::Textf(box.x + (box.w / 2) - (nameSize.right / 2), box.y + 5 + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::ESP, WeaponWithAmmo.c_str());
					}
					else if (g_Options.Visuals.espfont == 1)
					{
						Render::Textf(box.x + (box.w / 2) - (nameSize.right / 2), box.y + 5 + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::ESPNew, WeaponWithAmmo.c_str());
					}

				}
				else
				{
					if (g_Options.Visuals.espfont == 0)
					{
						Render::Textf(box.x + (box.w / 2) - (nameSize.right / 2), box.y + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::ESP, WeaponWithAmmo.c_str());
					}
					else if (g_Options.Visuals.espfont == 1)
					{
						Render::Textf(box.x + (box.w / 2) - (nameSize.right / 2), box.y + box.h + 2, Color(255, 255, 255, alpha), Render::Fonts::ESPNew, WeaponWithAmmo.c_str());
					}
				}

			}

		}
	}
}


void CEsp::CVisualsPlayer::draw_skeletons(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.Skeleton)
	{
		float alpha = flPlayerAlpha[m_entity->GetIndex()];
		studiohdr_t* studio_hdr = Interfaces::ModelInfo->GetStudiomodel(m_entity->GetModel());

		if (!studio_hdr)
			return;

		Vector vParent, vChild, sParent, sChild;

		for (int j = 0; j < studio_hdr->numbones; j++) {
			mstudiobone_t* pBone = studio_hdr->GetBone(j);

			if (pBone && (pBone->flags & BONE_USED_BY_HITBOX) && (pBone->parent != -1)) {
				vChild = m_entity->GetBonePos(j);
				vParent = m_entity->GetBonePos(pBone->parent);

				if (game::functions.world_to_screen(vParent, sParent) && game::functions.world_to_screen(vChild, sChild))
				{
					Render::Line(sParent[0], sParent[1], sChild[0], sChild[1], Color(g_Options.Visuals.skeletoncolor[0] * 255, g_Options.Visuals.skeletoncolor[1] * 255, g_Options.Visuals.skeletoncolor[2] * 255, alpha));
				}
			}
		}
	}
}

void CEsp::CVisualsPlayer::draw_snaplines(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.SnapLines)
	{
		float alpha = flPlayerAlpha[m_entity->GetIndex()];
		if (box.x >= 0 && box.y >= 0) {
			int width = 0;
			int height = 0;

			Vector to = Vector(box.x + (box.w / 2), box.y + box.h, 0);
			Interfaces::Engine->GetScreenSize(width, height);
			Vector From((width / 2), (height / 2), 0);
			Render::Line(From.x, From.y, to.x, to.y, Color(g_Options.Visuals.snaplinescolor[0] * 255, g_Options.Visuals.snaplinescolor[1] * 255, g_Options.Visuals.snaplinescolor[2] * 255, alpha));
		}
	}
}

void CEsp::CVisualsPlayer::draw_scoped(IClientEntity* m_entity, Box box) 
{
	if (g_Options.Visuals.ResolverInfo)
	{
		float alpha = flPlayerAlpha[m_entity->GetIndex()];
		/*		if (g_Options.Ragebot.Resolver)
				{
					if (resolve_type[m_entity->GetIndex()] == 1)
						Render::text1((box.x + box.w) + 3, box.y, "R::Moving", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 2)
						Render::text1((box.x + box.w) + 3, box.y, "R::Shuffle", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 3)
						Render::text1((box.x + box.w) + 3, box.y, "R::Prediction", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 4)
						Render::text1((box.x + box.w) + 3, box.y, "R::Brute", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 5)
						Render::text1((box.x + box.w) + 3, box.y, "R::Last Moving LBY", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 5)
						Render::text1((box.x + box.w) + 3, box.y, "R::Backtracking (test)", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else if (resolve_type[m_entity->GetIndex()] == 5)
						Render::text1((box.x + box.w) + 3, box.y, "R::Legit", Render::Fonts::ESP, Color(255, 255, 255, alpha));
					else
						Render::text1((box.x + box.w) + 3, box.y, "", Render::Fonts::ESP, Color(255, 255, 255, alpha));

				}
			}*/
	}
}



void CEsp::CGlow::shutdown() 
{
	for (auto i = 0; i < Interfaces::m_pGlowObjManager->size; i++)
	{
		auto& glow_object = Interfaces::m_pGlowObjManager->m_GlowObjectDefinitions[i];
		auto entity = reinterpret_cast<IClientEntity*>(glow_object.m_pEntity);

		if (glow_object.IsUnused())
			continue;

		if (!entity || entity->IsDormant())
			continue;
		glow_object.m_flGlowAlpha = 0.0f;
	}
}


void CEsp::CGlow::paint()
{
	auto m_local = hackManager.pLocal();
	for (auto i = 0; i < Interfaces::m_pGlowObjManager->size; i++) 
	{
		auto glow_object = &Interfaces::m_pGlowObjManager->m_GlowObjectDefinitions[i];

		IClientEntity *m_entity = glow_object->m_pEntity;

		if (!glow_object->m_pEntity || glow_object->IsUnused())
			continue;

		if (m_entity->GetClientClass()->m_ClassID == 35) 
		{
			if (m_entity->GetTeamNum() == m_local->GetTeamNum() && !g_Options.Visuals.TeamMates || g_Options.Visuals.TeamMates) continue;

			bool m_visible = game::functions.visible(m_local, m_entity, 0);
			float m_flRed = (g_Options.Visuals.glowcolor[0] * 255), m_flGreen = (g_Options.Visuals.glowcolor[1] * 255), m_flBlue = (g_Options.Visuals.glowcolor[2] * 255);
			bool m_teammate = m_entity->GetTeamNum() == m_local->GetTeamNum();
			glow_object->m_vGlowColor = Vector(m_flRed / 255, m_flGreen / 255, m_flBlue / 255);
			glow_object->m_flGlowAlpha = (g_Options.Visuals.glowopa * 2.55) / 255;
			glow_object->m_bRenderWhenOccluded = true;
			glow_object->m_bRenderWhenUnoccluded = false;

			if (g_Options.Visuals.GlowFullBloom)
			{
				glow_object->m_bFullBloomRender = true;
			}
			else
			{
				glow_object->m_bFullBloomRender = false;
			}
		}
	}
}