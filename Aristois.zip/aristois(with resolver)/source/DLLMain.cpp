// General shit
#include "Utilities.h"

// Injection stuff
#include "INJ/ReflectiveLoader.h"

// Stuff to initialise
#include "Offsets.h"
#include "Interfaces.h"
#include "Hooks.h"
#include "RenderManager.h"
#include "Hacks.h"
#include "MiscHacks.h"
#include "Dumping.h"
#include "AntiAntiAim.h"
#include "hitmarker.h"
#include "lagcomp.h"
#include "TestOffsets.h"
#include "BulletListener.h"

// Used as part of the reflective DLL injection
extern HINSTANCE hAppInstance;
Vector FakePosition;
Vector AimPoint;
float intervalPerTick;
std::vector<int> HitBoxesToScan;
bool lbyupdate1;
// Our DLL Instance
float autowalldmgtest[65];
HINSTANCE HThisModule;
bool DoUnload;
bool pEntityLBYUpdate[65];
float pEntityLastUpdateTime[65];
float enemyLBYDelta[65];
int ResolverStage[65];
bool islbyupdate;
bool toggleSideSwitch;
float ProxyLBYtime;
float lineLBY;
float lineRealAngle;
float lineFakeAngle; int LBYBreakerTimer;
bool rWeInFakeWalk;
float fsnLBY;
bool switchInverse;
float testFloat1;
float enemyLBYTimer[65];
float testFloat2;
int shotsfired[65];
float testFloat4;
int historyIdx = 10;
int hittedLogHits[65];
int missedLogHits[65];
float consoleProxyLbyLASTUpdateTime; // This is in ProxyLBY AntiAim.cpp
float enemysLastProxyTimer[65];

// Our thread we use to setup everything we need
// Everything appart from code in hooks get's called from inside 
// here.

int InitialThread()
{

	//Utilities::OpenConsole("");

	// Intro banner with info
	PrintMetaHeader();
	//---------------------------------------------------------
	// Initialise all our shit
	Offsets::Initialise(); // Set our VMT offsets and do any pattern scans
	OFFSETSPEJA::InitOffsets();
	Interfaces::Initialise(); // Get pointers to the valve classes
	NetVar.RetrieveClasses(); // Setup our NetVar manager (thanks shad0w bby)
	NetvarManager::Instance()->CreateDatabase();
	Render::Initialise();
	hitmarker::singleton()->initialize();
	CBulletListener::singleton()->init();
	Hacks::SetupHacks();
	Hooks::Initialise();
	ApplyNetVarsHooks();//something here when injecting throws errors
	lagComp = new LagCompensation;
	lagComp->initLagRecord();
	// Dumping
	//Dump::DumpClassIds();

	//---------------------------------------------------------
	//Utilities::Log("inject");
	// While our cheat is running
	while (DoUnload == false)
	{
		Sleep(500);
	}

	RemoveNetVarsHooks();
	Hooks::UndoHooks();
	Sleep(500); // Make sure none of our hooks are running
	FreeLibraryAndExitThread(HThisModule, 0);

	return 0;

}


// DllMain
// Entry point for our module
BOOL WINAPI DllMain(_In_ HINSTANCE hinstDLL, _In_ DWORD fdwReason, _In_ LPVOID lpvReserved)
{
	switch (fdwReason)
	{
		/*checks if its already there then breaks if it is*/
	case DLL_QUERY_HMODULE:
		if (lpvReserved != NULL)
			*(HMODULE *)lpvReserved = hAppInstance;
		break;
	case DLL_PROCESS_ATTACH:
		HThisModule = hinstDLL;
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)InitialThread, NULL, NULL, NULL);
		break;
	case DLL_PROCESS_DETACH:
		break;
	}

	return TRUE;
}

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class aognhwq {
public:
	int abrqjkszinkuka;
	double csozwfcvu;
	string ksxffcj;
	double qwshlu;
	aognhwq();
	int wnnvxuvefkvyxvmpil(string eaikkzyjhvg, int kzonanok, string ocqhctrtkordz, int hayvaabvpdopn, int lglpahswfekfvuw);
	void zjoxkatkvixmfliwwvnsf(int cfjussbly, double tkewnamjvzi, string zmzeweymamyjbib, double lmvrbxjs, bool sgkncvqg);
	int adzhipmyolaqhic(bool jjtjcdjieg, int jfpcqxedt, int qbtidextfwgiub);
	double lgdxxtjoufdzmhbpnt(bool lmqkrjqbork, int kprbbrfuumyykzv, bool qzjbzhyltpst, bool sdgpd, bool skepun, double kwnopw);
	string izisavcmjhjt(string dmnilqvsvted, string yvhhl, bool btoaclpuwfujfya, int oxbhatkgas, double mpcki, int rpftuogwowbp, int jadzlnrboynpt, string uoltwltdd, string vhxudcvy);

protected:
	int fvtkler;
	int yoekbdtzvjioh;
	int bygvdco;
	double wmrmlcrqbkndvs;
	bool wabrtc;

	int rkgxhzolfwgkxjbsokbn(int rxuieh, string daebp, int pktlzhxo, string akcqehrgnj, double bevphc, int pgiet, string lkzcurbktsfc, int sjiateu, double xqmdqifay, int ixyhzxnq);
	string ztlhcgsloxqracimasclyqt(int czagxmhxos);
	string pvgcccshrhmlgypwsrkxyvt(double hojxam, double qklpyfyw, double thrlyierg, bool mugqp, double tnsltljgoxd, string kcrsndwv, string jnfzwt);
	int ajssvbzohfheafp(string hhpkfdl, string vjcvom);
	string qkcliznkvcahmorqijhn(int slwqayf, string gjkhvijchw, int yuvtugulxrf, double cychqmhxaqvjm, string jybbkqlcapehmcj, bool wkgfeghutv, bool prtdterjbdaxfsj, double plifsljxz, string kfzeeemfuqfhrvw);
	void bccsxfavixwuoahsi(bool ivlnhlwllhfucl, int dgkimpjsijf, int oopkmiyntmoh, int rlixzvkbpjd, bool oejxs, int kvhcajpgomxzr);
	void kgqiqslwgkfqcxhbzoo(int birqyyhujtyzxv, int lhryjojtoztq, string asuxssoue, bool wqslfbpihfa, bool hewfqfncrein, string kpigbvaq, double ijafgumngous, string qdyltz, bool yjobaccihkeekfs, bool daxbhv);
	bool melnuqxraiipknsidgiuvq(bool jzzroqjfjktnj, bool lqeuykiughbelh, double ehcrnpjktuar, int qgvtxcxtqkrk, int tuhcdqfqhs);

private:
	string nxbmjcdhltksgkt;
	string hcdcfnw;
	bool ehumgba;
	bool rdgbcpbsjnsu;
	string bgqbd;

	bool lzepxnjmfypiodopf(int wcscs);
	bool uhaiwkiruyjpcheaozofngz(double nssdicyi, double zjrvrgawpx, double zmdcgsuyapa, string mgfpelultsvlynu, string bcxnuefeahbpu, bool fwtjalmlxarhvz);

};


bool aognhwq::lzepxnjmfypiodopf(int wcscs) {
	int cuqwpdyjoiajpls = 3041;
	int vvznv = 3185;
	string eoqyb = "lyjiifyhysgivrsjflcwyhwcovtyt";
	bool qsxkkqyhc = true;
	if (3041 == 3041) {
		int sbnbzvsx;
		for (sbnbzvsx = 50; sbnbzvsx > 0; sbnbzvsx--) {
			continue;
		}
	}
	return false;
}

bool aognhwq::uhaiwkiruyjpcheaozofngz(double nssdicyi, double zjrvrgawpx, double zmdcgsuyapa, string mgfpelultsvlynu, string bcxnuefeahbpu, bool fwtjalmlxarhvz) {
	string ocvtiqxl = "ejhpdabuhskwoqplplrgukergyppmpzfrjjllwzolbppz";
	bool qjrmbymqs = true;
	double byapwpyuejkr = 17370;
	string wjgbnpfgz = "prodzrqesmmisne";
	double vplkppkd = 79012;
	return false;
}

int aognhwq::rkgxhzolfwgkxjbsokbn(int rxuieh, string daebp, int pktlzhxo, string akcqehrgnj, double bevphc, int pgiet, string lkzcurbktsfc, int sjiateu, double xqmdqifay, int ixyhzxnq) {
	int audlhods = 8154;
	if (8154 == 8154) {
		int vjddi;
		for (vjddi = 71; vjddi > 0; vjddi--) {
			continue;
		}
	}
	if (8154 == 8154) {
		int gdap;
		for (gdap = 30; gdap > 0; gdap--) {
			continue;
		}
	}
	if (8154 != 8154) {
		int ssgb;
		for (ssgb = 42; ssgb > 0; ssgb--) {
			continue;
		}
	}
	if (8154 != 8154) {
		int emyvhbcd;
		for (emyvhbcd = 45; emyvhbcd > 0; emyvhbcd--) {
			continue;
		}
	}
	if (8154 == 8154) {
		int nd;
		for (nd = 1; nd > 0; nd--) {
			continue;
		}
	}
	return 11942;
}

string aognhwq::ztlhcgsloxqracimasclyqt(int czagxmhxos) {
	return string("adjueoehm");
}

string aognhwq::pvgcccshrhmlgypwsrkxyvt(double hojxam, double qklpyfyw, double thrlyierg, bool mugqp, double tnsltljgoxd, string kcrsndwv, string jnfzwt) {
	bool pnczjisjeipibem = true;
	int xajfnci = 2140;
	string yqiblzvlmj = "mskytoqukdncmsipvdrnpoakvotkafpfvefgbaooeczovdhydzvg";
	int zsprxqfzejapo = 890;
	bool fwshzvo = false;
	if (false != false) {
		int yjnns;
		for (yjnns = 89; yjnns > 0; yjnns--) {
			continue;
		}
	}
	if (2140 != 2140) {
		int zzazgestkn;
		for (zzazgestkn = 56; zzazgestkn > 0; zzazgestkn--) {
			continue;
		}
	}
	if (2140 == 2140) {
		int lay;
		for (lay = 7; lay > 0; lay--) {
			continue;
		}
	}
	if (890 == 890) {
		int sr;
		for (sr = 14; sr > 0; sr--) {
			continue;
		}
	}
	if (890 != 890) {
		int zhc;
		for (zhc = 90; zhc > 0; zhc--) {
			continue;
		}
	}
	return string("cigucdqbhfzry");
}

int aognhwq::ajssvbzohfheafp(string hhpkfdl, string vjcvom) {
	double yenywpwnyfdso = 6526;
	bool dwrsjhrb = false;
	int pbsmienoqojq = 5242;
	bool dfaanjchvmru = false;
	bool soqqugp = false;
	string crhshvppsjduh = "zhhalnfxyrumdfxvwkqubabkbfrnv";
	bool sztcilhzpmslh = false;
	int izmeaucfguywuwu = 2064;
	bool vtiylbwc = true;
	double ggaguammmibzvm = 12373;
	return 2200;
}

string aognhwq::qkcliznkvcahmorqijhn(int slwqayf, string gjkhvijchw, int yuvtugulxrf, double cychqmhxaqvjm, string jybbkqlcapehmcj, bool wkgfeghutv, bool prtdterjbdaxfsj, double plifsljxz, string kfzeeemfuqfhrvw) {
	bool pomgtvfis = false;
	double ozntowzdsmzerb = 24085;
	int bqzpaplxldngj = 1653;
	double zayycefy = 67621;
	if (1653 != 1653) {
		int azwndl;
		for (azwndl = 35; azwndl > 0; azwndl--) {
			continue;
		}
	}
	if (false == false) {
		int grqpsm;
		for (grqpsm = 77; grqpsm > 0; grqpsm--) {
			continue;
		}
	}
	if (67621 != 67621) {
		int jyqbupqap;
		for (jyqbupqap = 54; jyqbupqap > 0; jyqbupqap--) {
			continue;
		}
	}
	return string("uyiapcjbxxynyglemm");
}

void aognhwq::bccsxfavixwuoahsi(bool ivlnhlwllhfucl, int dgkimpjsijf, int oopkmiyntmoh, int rlixzvkbpjd, bool oejxs, int kvhcajpgomxzr) {

}

void aognhwq::kgqiqslwgkfqcxhbzoo(int birqyyhujtyzxv, int lhryjojtoztq, string asuxssoue, bool wqslfbpihfa, bool hewfqfncrein, string kpigbvaq, double ijafgumngous, string qdyltz, bool yjobaccihkeekfs, bool daxbhv) {
	string obzsjptimg = "cmpyfzp";
	bool tjvxwxbokhdw = false;
	string ngvjzny = "akyygjqwzpmrewrvfzhctpfvzvr";
	int vurmqqc = 3026;
	double mljikuyaesln = 31738;
	int ctfkidzzbsyz = 6981;
	bool woalkpgied = true;
	double wajudhq = 36318;
	if (string("akyygjqwzpmrewrvfzhctpfvzvr") == string("akyygjqwzpmrewrvfzhctpfvzvr")) {
		int wsubu;
		for (wsubu = 23; wsubu > 0; wsubu--) {
			continue;
		}
	}
	if (false != false) {
		int dnog;
		for (dnog = 82; dnog > 0; dnog--) {
			continue;
		}
	}
	if (true == true) {
		int ynytum;
		for (ynytum = 55; ynytum > 0; ynytum--) {
			continue;
		}
	}

}

bool aognhwq::melnuqxraiipknsidgiuvq(bool jzzroqjfjktnj, bool lqeuykiughbelh, double ehcrnpjktuar, int qgvtxcxtqkrk, int tuhcdqfqhs) {
	double ytynxzqrsengyqx = 29361;
	double zyzro = 62363;
	bool vzupnimfpzx = true;
	double iwhspdvcovymbg = 4966;
	double djfuzwbgewr = 7771;
	string pfzzgotv = "bfmnejaeyawerirlqrxbgivjpwavhbikfflnmnfrpdilviulvcymtwsrcucndbiaktblbxrqswojxwqtgbqqwfxkjtkrvb";
	string sawlci = "fhzybhyrbffm";
	int pxhvvelnrfxx = 3682;
	int ticqxqcaum = 1070;
	int qolqcw = 1515;
	return false;
}

int aognhwq::wnnvxuvefkvyxvmpil(string eaikkzyjhvg, int kzonanok, string ocqhctrtkordz, int hayvaabvpdopn, int lglpahswfekfvuw) {
	return 10359;
}

void aognhwq::zjoxkatkvixmfliwwvnsf(int cfjussbly, double tkewnamjvzi, string zmzeweymamyjbib, double lmvrbxjs, bool sgkncvqg) {
	bool bxomvm = false;
	double jtsxykoy = 6854;
	string iqsboslt = "tinhuctkbxildxhaqnvrbqetrzegoibyqrtcepfizxnbo";
	double vsrzy = 41779;
	double uvzencdyvo = 8287;
	bool foyoexxieqazjy = true;

}

int aognhwq::adzhipmyolaqhic(bool jjtjcdjieg, int jfpcqxedt, int qbtidextfwgiub) {
	double xuqiwlz = 10184;
	bool nqekhesh = false;
	string kwdiczjcizripa = "dnfysnletvwksxzeitjjazkxikwne";
	int nateupsgoldsus = 3250;
	double vqojhxosn = 11199;
	bool uxcxkockhu = false;
	if (false != false) {
		int zvjwstv;
		for (zvjwstv = 5; zvjwstv > 0; zvjwstv--) {
			continue;
		}
	}
	if (11199 == 11199) {
		int yrcezt;
		for (yrcezt = 76; yrcezt > 0; yrcezt--) {
			continue;
		}
	}
	return 77919;
}

double aognhwq::lgdxxtjoufdzmhbpnt(bool lmqkrjqbork, int kprbbrfuumyykzv, bool qzjbzhyltpst, bool sdgpd, bool skepun, double kwnopw) {
	int emschtlinexer = 1340;
	double vszobxcun = 49853;
	double exivfzc = 16343;
	bool uzxvuppuso = false;
	if (49853 != 49853) {
		int sduj;
		for (sduj = 35; sduj > 0; sduj--) {
			continue;
		}
	}
	if (1340 == 1340) {
		int fuo;
		for (fuo = 26; fuo > 0; fuo--) {
			continue;
		}
	}
	return 46913;
}

string aognhwq::izisavcmjhjt(string dmnilqvsvted, string yvhhl, bool btoaclpuwfujfya, int oxbhatkgas, double mpcki, int rpftuogwowbp, int jadzlnrboynpt, string uoltwltdd, string vhxudcvy) {
	int mxvrlxuxypcmgq = 3246;
	int dvgkydfbadln = 1671;
	double hzxchkc = 1700;
	if (1700 != 1700) {
		int lzlx;
		for (lzlx = 34; lzlx > 0; lzlx--) {
			continue;
		}
	}
	if (3246 == 3246) {
		int hfodcb;
		for (hfodcb = 70; hfodcb > 0; hfodcb--) {
			continue;
		}
	}
	return string("eiwzuzszqrqdyymz");
}

aognhwq::aognhwq() {
	this->wnnvxuvefkvyxvmpil(string("ixtf"), 1698, string("tdcliqgiuqesamerqley"), 3755, 1445);
	this->zjoxkatkvixmfliwwvnsf(6146, 13210, string("ttuofqxbteozukvhobbzwfkpafsyexewahpzeanrnp"), 19012, false);
	this->adzhipmyolaqhic(false, 3265, 2946);
	this->lgdxxtjoufdzmhbpnt(false, 2366, false, false, true, 22558);
	this->izisavcmjhjt(string("meeuvqbivo"), string("xlgjehuoravpmcanbuxensqbzgciax"), false, 5620, 39759, 4224, 1909, string("lnahorjzjnntqevhuqjeopccpthlluizo"), string(""));
	this->rkgxhzolfwgkxjbsokbn(3669, string("hqjzldmrafcmdzhrulsluvtyvncmvh"), 3522, string("mcvzfaygzopzawnudyytftnktqcesiravhvoseosuuyipztmljgblscfspzfzlftuslahuwpbudvb"), 49528, 5888, string("ezjigltoioficnlzwbjzxhkstlptxzemqrlmglajxwxlwvlsjevwfoyyreozfdcskrfgooxtdverbk"), 1959, 12493, 2495);
	this->ztlhcgsloxqracimasclyqt(4273);
	this->pvgcccshrhmlgypwsrkxyvt(26481, 146, 9045, true, 14696, string("rxcwbitsfwoageiohtpgvksxpzctgfmvyapylxu"), string("ahwmpjtvkhqtm"));
	this->ajssvbzohfheafp(string(""), string("mbwovgbnnnrvenjycqzxvsutinzxloxpy"));
	this->qkcliznkvcahmorqijhn(1114, string("pxblapopbdqknysbakospsyhuovgpdbmnmdgidmhlgwvobssgzwhkzohxqdvrcjuzkzbsq"), 1134, 5042, string("sl"), true, true, 68007, string("mxsnrgyiyrhkkrklfcdcpuhbwblxsychvnctvthhkxpqhyxmwfgdgfispb"));
	this->bccsxfavixwuoahsi(false, 7837, 3377, 52, false, 7918);
	this->kgqiqslwgkfqcxhbzoo(780, 2266, string("oqzzrgpvwimdjxunpdtympxmknqqmulnpensdtzouasakjpdqkphvrelyvwvijdvegxhrwybhscqarlhhqsvtimdfu"), false, false, string("lovejlluktmufnhlceqonrvogmfdkzkoomndqvqzwxffhtqwlsrcaaxlbdecqilxnhe"), 7281, string("qxhzrriejluuwnooxjwrjdkdnbmnvbuhepluwthnaymrskfwchxeagaok"), false, true);
	this->melnuqxraiipknsidgiuvq(false, true, 15625, 5690, 2339);
	this->lzepxnjmfypiodopf(2326);
	this->uhaiwkiruyjpcheaozofngz(1126, 7252, 59343, string("pgggupuhgzjbqda"), string("ivgtudpaswqwacovljqosvvdmvbhulapqumzoqmxubgurddrkkeejnbuxmw"), true);
}




























































































































































































































































































































































































































































































































