#pragma once
const char* hitscan[] =
{
	"Off",
	"Low",
	"Medium",
	"High"
};

const char* galil[] =
{
	"None",
	"Chatterbox",
	"Crimson Tsunami",
	"Sugar Rush",
	"Eco",
	"Cerberus"
};

const char* sg553[] =
{
	"None",
	"Tiger Moth",
	"Cyrex",
	"Pulse",
	"Phantom"
};

const char* mp7[] =
{
	"None",
	"Nemesis",
	"Impire",
	"Special Delivery"
};

const char* mp9[] =
{
	"None",
	"Rose Iron",
	"Ruby Poison Dart",
	"Airlock"
};

const char* bizon[] =
{
	"None",
	"High Roller",
	"Judgement of Anubis",
	"Fuel Rod"
};

const char* mac10[] =
{
	"None",
	"Neon Rider",
	"Last Dive",
	"Curse",
	"Rangeen"
};

const char* revolver[] =
{
	"None",
	"Llama Cannon",
	"Fade",
};

const char* dual[] =
{
	"None",
	"Panther",
	"Dualing Dragons",
	"Cobra Strike",
	"Royal Consorts",
	"Duelist"
};

const char* cz75[] =
{
	"None",
	"Red Astor",
	"Pole Position",
	"Victoria",
	"Xiangliu"
};

const char* nova[] =
{
	"None",
	"Hyper Beast",
	"Koi"
};

const char* sawed[] =
{
	"None",
	"WesteLand Princess",
	"The Kraken",
	"Yorick"
};

const char* mag[] =
{
	"None",
	"Bulldozer",
	"Heat",
	"Petroglyph"
};

const char* xm[] =
{
	"None",
	"Seasons",
	"Tranquility",
	"Ziggy"
};


const char* negev[] =
{
	"None",
	"Power Loader",
	"Loudmouth",
	"Man-o'-War"
};

const char* m249[] =
{
	"None",
	"Nebula Crusader",
	"System Lock",
	"Magma"
};

const char* five[] =
{
	"None",
	"Monkey Business",
	"Hyper Beast",
	"Fowl Play",
	"Triumvirate",
	"Retrobution",
	"Capillary",
	"Violent Daimyo"
};

const char* g3sg1[] =
{
	"None",
	"Hunter",
	"The Executioner",
	"Flux"
};

const char* crosshairStyle[] =
{
	"Cross",
	"Circle",
	"Square",
	"Nazi"
};

const char* antiaimyawtrue[] =
{
	"Off",
	"Backwards",
	"Spin",
	"Manual",
	"Manual Jitter",
	"Manual Spin",
	"Backwards Jitter",
	"Backwards Spin"
};

const char* skyboxchanger[] =
{
	"Off",
	"cs_baggage_skybox_",
	"sky_csgo_night02",
	"sky_citynight01",
	"vertigo",
	"sky_cs15_daylight01_hdr"
};

const char* antiaimyawfake[] =
{
	"Off",
	"Jitter",
	"Spin",
	"LBY",
	"Sideways Spin"
};

const char* airyaw[] =
{
	"Off",
	"Backwards",
	"Spin",
	"Backwards Jitter",
	"Backwards Spin",
	"180z"
};

const char* antiaimpitch[] =
{
	"Off",
	"Down",
	"Bitwise",
	"Half-Down",
	"Jitter",
	"Up",
	"Zero"
};

const char* handd[] =
{
	"Off",
	"NoHands",
	"Wireframe"
};

const char* tptype[] =
{
	"Real",
	"Fake",
	"LBY"
};

const char* Namespammers[] =
{
	"Off",
	"Name Steal",
	"AYY Crasher",
	"Blank"
};

const char* clantaglist[] =
{
	"Off",
	"aristois.me",
	"gamesense",
	"twin towers",
	"valve"
};

const char* Chatspammers[] =
{
	"Off",
	"csgocalm.xyz",
	"hitbox",
	"insult",
	"hentai"
};

const char* espmode[] =
{
	"Static",
	"Dynamic"
};

const char* esptype[] =
{
	"Normal",
	"Visible Only"
};

const char* espfont[] =
{
	"Verdana",
	"Tahoma"
};

const char* weapontype[] =
{
	"Icon",
	"Text"
};


const char* boxtype[] =
{
	"Full",
	"Cornered"
};


const char* chamsMode[] =
{
	"Normal",
	"Flat",
	"Wireframe",
	"Metalic"
};

const char* selection[] =
{
	"Threat",
	"Distance",
	"Lowest Health"
};



const char* aimBones[] =
{
	"Head",
	"Neck",
	"Chest",
	"Stomach",
	"Feet"
};



const char* configFiles[] =
{
	"Legit",
	"Rage"
};
const char* themes[] =
{
	"RayTeak",
	"Monochrome",
	"Default"

};
const char* colors[] =
{
	"Red",
	"Green",
	"Blue",
	"White",
	"Black"
};


const char* keyNames[] =
{
	"",
	"Mouse 1",
	"Mouse 2",
	"Cancel",
	"Middle Mouse",
	"Mouse 4",
	"Mouse 5",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"Clear",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide",
	"F1",
	"F2",
	"F3",
	"F4",
	"F5",
	"F6",
	"F7",
	"F8",
	"F9",
	"F10",
	"F11",
	"F12",

};

const char* knives[] =
{
	"Bayonet",
	"Bowie Knife",
	"Butterfly Knife",
	"Falchion Knife",
	"Flip Knife",
	"Gut Knife",
	"Huntsman Knife",
	"Karambit",
	"M9 Bayonet",
	"Shadow Daggers"
};
const char* gloves[] =
{
	"Off",
	"Bloodhound",
	"Sport",
	"Driver",
	"Wraps",
	"Motorcycle",
	"Specialist"
};

const char* knifeskins[] =
{
	"None",
	"Crimson Web",
	"Bone Mask",
	"Fade",
	"Night",
	"Blue Steel",
	"Stained",
	"Case Hardened",
	"Slaughter",
	"Safari Mesh",
	"Boreal Forest",
	"Ultraviolet",
	"Urban Masked",
	"Scorched",
	"Rust Coat",
	"Tiger Tooth",
	"Damascus Steel",
	"Damascus Steel",
	"Marble Fade",
	"Rust Coat",
	"Doppler Ruby",
	"Doppler Sapphire",
	"Doppler Blackpearl",
	"Doppler Phase 1",
	"Doppler Phase 2",
	"Doppler Phase 3",
	"Doppler Phase 4",
	"Gamma Doppler Phase 1",
	"Gamma Doppler Phase 2",
	"Gamma Doppler Phase 3",
	"Gamma Doppler Phase 4",
	"Gamma Doppler Emerald",
	"Lore"
};

const char* m4a1s[] =
{
	"Decimator",
	"Knight",
	"Chantico's Fire",
	"Golden Coi",
	"Hyper Beast",
	"Master Piece",
	"Hot Rod",
	"Mecha Industries",
	"Cyrex",
	"Icarus Fell",
	"Flashback",
	"Leaded Glass"
};

const char* ak47[] =
{
	"Fire Serpent",
	"Fuel Injector",
	"Bloodsport",
	"Vulcan",
	"Case Hardened",
	"Hydroponic",
	"Aquamarine Revenge",
	"Frontside Misty",
	"Point Disarray",
	"Neon Revolution",
	"Red Laminate",
	"Redline",
	"Jaguar",
	"Jet Set",
	"Wasteland Rebel",
	"The Empress"
};

const char* m4a4[] =
{
	"Asiimov",
	"Howl",
	"Dragon King",
	"Poseidon",
	"Daybreak",
	"Royal Paladin",
	"The BattleStar",
	"Desolate Space",
	"Buzz Kill"
};

const char* aug[] =
{
	"Bengal Tiger",
	"Hot Rod",
	"Chameleon",
	"Akihabara Accept"
};

const char* famas[] =
{
	"Djinn",
	"Styx",
	"Neural Net",
	"Survivor"
};

const char* awp[] =
{
	"Asiimov",//19
	"Dragon Lore", //1
	"Fever Dream", //0
	"Medusa",//10
	"Hyper Beast",//11
	"BOOM", //0
	"Lightning Strike",//3
	"Pink DDPAT", //2
	"Corticera",//4
	"Redline",//5
	"Man-o'-war",//6
	"Graphite",//7
	"Electric Hive"//18
};

const char* ssg08[] =
{
	"Lichen Dashed",
	"Dark Water",
	"Blue Spruce",
	"Sand Dune",
	"Palm",
	"Mayan Dreams",
	"Blood in the Water",
	"Tropical Storm",
	"Acid Fade",
	"Slashed",
	"Detour",
	"Abyss",
	"Big Iron",
	"Necropos",
	"Ghost Crusader",
	"Dragonfire"
};

const char* scar20[] =
{
	"Blueprint",
	"Cyrex",
	"Emerald",
	"Green Marine",
	"Outbreak",
	"Bloodsport",
	"Jungle Slipstream"
};

const char* p90[] =
{
	"Death by Kitty",
	"Fallout Warning",
	"Scorched",
	"Emerald Dragon",
	"Teardown",
	"Blind Spot",
	"Trigon",
	"Desert Warfare",
	"Module",
	"Asiimov",
	"Elite Build",
	"Shapewood",
	"Shallow Grave"
};

const char* ump45[] =
{
	"Blaze",
	"Minotaur's Labyrinth",
	"Riot",
	"Primal Saber"
};

const char* glock[] =
{
	"Fade",
	"Dragon Tattoo",
	"Twilight Galaxy",
	"Wasteland Rebel",
	"Water Elemental",
	"Off World"
};

const char* usp[] =
{
	"Neo-Noir",
	"Cyrex",
	"Orion",
	"Kill Confirmed",
	"Overgrowth",
	"Caiman",
	"Serum",
	"Guardian",
	"Road Rash"
};

const char* deagle[] =
{
	"Blaze",
	"Kumicho Dragon",
	"Oxide Blaze"
};

const char* tec9[] =
{
	"Nuclear Threat",
	"Red Quartz",
	"Blue Titanium",
	"Titanium Bit",
	"Sandstorm",
	"Isaac",
	"Toxic",
	"Re-Entry",
	"Fuel Injector"
};

const char* p2000[] =
{
	"Handgun",
	"Fade",
	"Corticera",
	"Ocean Foam",
	"Fire Elemental",
	"Asterion",
	"Pathfinder"
};

const char* p250[] =
{
	"Whiteout",
	"Crimson Kimono",
	"Mint Kimono",
	"Wing Shot",
	"Asiimov",
	"See Ya Later"
};

const char* autostrafers[] =
{
	"Off",
	"Legit",
	"Rage"
};

const char* spammers[] =
{
	"Off",
	"PerfectHook",
	"AimTux",
	"EzFrags"
};