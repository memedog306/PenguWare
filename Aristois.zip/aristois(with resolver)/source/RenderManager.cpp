
#pragma once

#include "RenderManager.h"

#define _CRT_SECURE_NO_WARNINGS

// Font Instances
namespace Render
{
	// Text functions
	namespace Fonts
	{
		DWORD Default;
		DWORD Menu;
		DWORD MenuBold;
		DWORD Tabs;
		DWORD Icon;
		DWORD WaterMark;
		DWORD Slider;
		DWORD ESP;
		DWORD ESPNew;
		DWORD Clock;
		DWORD AAarows;
		DWORD MenuText;
		DWORD Font_Weapons;
		DWORD LBY;
	};
};

// We don't use these anywhere else, no reason for them to be
// available anywhere else
enum EFontFlags
{
	FONTFLAG_NONE,
	FONTFLAG_ITALIC = 0x001,
	FONTFLAG_UNDERLINE = 0x002,
	FONTFLAG_STRIKEOUT = 0x004,
	FONTFLAG_SYMBOL = 0x008,
	FONTFLAG_ANTIALIAS = 0x010,
	FONTFLAG_GAUSSIANBLUR = 0x020,
	FONTFLAG_ROTARY = 0x040,
	FONTFLAG_DROPSHADOW = 0x080,
	FONTFLAG_ADDITIVE = 0x100,
	FONTFLAG_OUTLINE = 0x200,
	FONTFLAG_CUSTOM = 0x400,
	FONTFLAG_BITMAP = 0x800,
};

void kjwehewfhwejk()
{
	float pJunkcode = 186526758;
	pJunkcode = 32036205325220;
	if (pJunkcode = 2568425324);
	pJunkcode = 29498;
	pJunkcode = 5500381413576;
	pJunkcode = 12979132988738;
	if (pJunkcode = 812013498);
	pJunkcode = 22997219666391;
	pJunkcode = 326243189329224;
	if (pJunkcode = 367814109);
	pJunkcode = 10282;
	pJunkcode = 104551082224261;
	pJunkcode = 34153126629741;
	if (pJunkcode = 178817712);
	pJunkcode = 313282057124314;
	pJunkcode = 2812229918900;
	if (pJunkcode = 235381170);
	pJunkcode = 24553644927296;
	pJunkcode = 84322222824731;
	pJunkcode = 24354300613225;
	if (pJunkcode = 189035896);
	pJunkcode = 14628113848569;
	pJunkcode = 4302427723481;
	if (pJunkcode = 16114714);
	pJunkcode = 15663207103835;
	pJunkcode = 25409315127447;
	if (pJunkcode = 747917471);
	pJunkcode = 236842414224851;
	pJunkcode = 185662722117956;
	if (pJunkcode = 2097826630);
	pJunkcode = 29637141481671;
	pJunkcode = 8622293977991;
	if (pJunkcode = 2547332643);
	pJunkcode = 2490723677534;
	pJunkcode = 8431270586984;
	if (pJunkcode = 456916219);
	pJunkcode = 106582434715286;
	pJunkcode = 248322694511221;
	if (pJunkcode = 1817711769);
	pJunkcode = 27658173031953;
	pJunkcode = 70691607731104;
	if (pJunkcode = 2241825101);
	pJunkcode = 9975296568259;
	pJunkcode = 28681590824206;
	if (pJunkcode = 492520744);
	pJunkcode = 19602867722022;
	pJunkcode = 147273143229034;
	if (pJunkcode = 954111681);
	pJunkcode = 100391821713094;
	pJunkcode = 3017669277968;
	if (pJunkcode = 1766422099);
	pJunkcode = 3573178021558;
	pJunkcode = 153282816321987;
	if (pJunkcode = 1391521468);
	pJunkcode = 2689684424249;
	pJunkcode = 16857696216264;
	if (pJunkcode = 673926559);
	pJunkcode = 16662965029449;
	pJunkcode = 29727143673080;
	if (pJunkcode = 396410947);
	pJunkcode = 159903960531;
	pJunkcode = 70502169619458;
	if (pJunkcode = 883015219);
	pJunkcode = 265712247622681;
	pJunkcode = 51112252623351;
	if (pJunkcode = 373131900);
	pJunkcode = 7320140973663;
	pJunkcode = 48071132023308;
	if (pJunkcode = 1997825553);
	pJunkcode = 201302468628735;
	pJunkcode = 320941529615627;
	if (pJunkcode = 3143122506);
	pJunkcode = 1123988162373;
	pJunkcode = 203891570823906;
	if (pJunkcode = 324498065);
	pJunkcode = 212711882331379;
	pJunkcode = 47452067811618;
	if (pJunkcode = 525124436);
	pJunkcode = 2254947419262;
	pJunkcode = 252102743728161;
	if (pJunkcode = 606010598);
	pJunkcode = 6266115547535;
	pJunkcode = 1517504231321;
	if (pJunkcode = 95826718);
	pJunkcode = 245952009032131;
	pJunkcode = 5082286528743;
	if (pJunkcode = 33462214);
	pJunkcode = 239022138829676;
	pJunkcode = 1081482925198;
	if (pJunkcode = 421117293);
	pJunkcode = 261292962912542;
	pJunkcode = 134672792922865;
	if (pJunkcode = 2982324741);
	pJunkcode = 29638527779;
	pJunkcode = 170111689324028;
	if (pJunkcode = 250176886);
	pJunkcode = 326411791626519;
	pJunkcode = 28113316063387;
	if (pJunkcode = 530516649);
	pJunkcode = 184742080521100;
	pJunkcode = 2092873531713;
	if (pJunkcode = 2423413326);
	pJunkcode = 176833254726503;
	pJunkcode = 4305151098675;
	if (pJunkcode = 3015630135);
	pJunkcode = 8842878227361;
	pJunkcode = 27545155309594;
	if (pJunkcode = 561618187);
	pJunkcode = 2527380329287;
	pJunkcode = 264172534913701;
	if (pJunkcode = 2892622228);
	pJunkcode = 230653730682;
	pJunkcode = 9481030329701;
	if (pJunkcode = 2853032);
	pJunkcode = 101481564620112;
	pJunkcode = 7092098428831;
	if (pJunkcode = 166026340);
	pJunkcode = 40052607020146;
	pJunkcode = 158792809613085;
	if (pJunkcode = 1545020436);
	pJunkcode = 57002177225692;
	pJunkcode = 3490758221997;
	if (pJunkcode = 43937212);
	pJunkcode = 1879924166656;
	pJunkcode = 160691345312449;
	if (pJunkcode = 1819315083);
	pJunkcode = 29771667816611;
	pJunkcode = 668689544717;
	if (pJunkcode = 382715859);
	pJunkcode = 296151458227038;
	pJunkcode = 31332131273244;
	if (pJunkcode = 2540810858);
	pJunkcode = 232091777011422;
	pJunkcode = 29390570719803;
	if (pJunkcode = 3084910043);
	pJunkcode = 263602833917060;
	pJunkcode = 1433163362460;
	if (pJunkcode = 3220815254);
	pJunkcode = 178082622727974;
	pJunkcode = 27269488330773;
	if (pJunkcode = 116137532);
	pJunkcode = 10009901212140;
	pJunkcode = 259442439223567;
	if (pJunkcode = 114984084);
	pJunkcode = 93281302421972;
	pJunkcode = 11354112837863;
	if (pJunkcode = 1595121033);
	pJunkcode = 29477749620367;
	pJunkcode = 242802203231456;
	if (pJunkcode = 163757498);
	pJunkcode = 271312217422146;
	pJunkcode = 29783156414047;
	if (pJunkcode = 3209713144);
	pJunkcode = 218671689026598;
	pJunkcode = 183171428128462;
	if (pJunkcode = 2038432155);
	pJunkcode = 7202173683272;
	pJunkcode = 214891279928905;
	if (pJunkcode = 354715134);
	pJunkcode = 131822575229321;
	pJunkcode = 21803305499300;
	if (pJunkcode = 1991816174);
	pJunkcode = 2562176521343;
	pJunkcode = 6428104121875;
	if (pJunkcode = 2976716351);
	pJunkcode = 24110580711986;
	pJunkcode = 280723042114321;
	if (pJunkcode = 554613447);
	pJunkcode = 775069721056;
	pJunkcode = 1849284373802;
	if (pJunkcode = 983717473);
	pJunkcode = 85883073112634;
	pJunkcode = 30522605618912;
	if (pJunkcode = 3164517515);
	pJunkcode = 27237266173748;
	pJunkcode = 129562361118042;
	if (pJunkcode = 699918216);
	pJunkcode = 21737172229689;
	pJunkcode = 103241905719520;
	if (pJunkcode = 2388714815);
	pJunkcode = 152042404331493;
	pJunkcode = 26586777526480;
	if (pJunkcode = 233735050);
	pJunkcode = 273502842626057;
	pJunkcode = 22444795221356;
	if (pJunkcode = 127155160);
	pJunkcode = 26483261071819;
	pJunkcode = 316891920230010;
	if (pJunkcode = 40574444);
	pJunkcode = 2922342931523;
	pJunkcode = 195112167126115;
	if (pJunkcode = 636122220);
	pJunkcode = 143401019812255;
	pJunkcode = 7037283893476;
	if (pJunkcode = 50595042);
	pJunkcode = 289001765915775;
	pJunkcode = 33692703019680;
	if (pJunkcode = 2771322926);
	pJunkcode = 31176167453978;
	pJunkcode = 7244768814460;
	if (pJunkcode = 78810914);
	pJunkcode = 241681701523575;
	pJunkcode = 127931113425378;
	if (pJunkcode = 201106261);
	pJunkcode = 3247585828053;
	pJunkcode = 1940294214383;
	if (pJunkcode = 1922229265);
	pJunkcode = 187512285515012;
	pJunkcode = 128911824126148;
	if (pJunkcode = 15271965);
	pJunkcode = 29675887620154;
	pJunkcode = 163322927022825;
	if (pJunkcode = 1492925379);
	pJunkcode = 722719704671;
	pJunkcode = 138912278317797;
	if (pJunkcode = 632720483);
	pJunkcode = 26092177831265;
	pJunkcode = 98322963416935;
	if (pJunkcode = 42398638);
	pJunkcode = 157262850312960;
	pJunkcode = 260873176929473;
	if (pJunkcode = 1744517908);
	pJunkcode = 23652567716243;
	pJunkcode = 56182277017447;
	if (pJunkcode = 380020230);
	pJunkcode = 77202878411905;
	pJunkcode = 147812334413076;
	if (pJunkcode = 96274765);
	pJunkcode = 9284127976841;
	pJunkcode = 238081898510854;
	if (pJunkcode = 191022562);
	pJunkcode = 191931192220315;
	pJunkcode = 190641642227581;
	if (pJunkcode = 158755955);
	pJunkcode = 28092315512412;
	pJunkcode = 21094222462656;
	if (pJunkcode = 2814518036);
	pJunkcode = 31668160729574;
	pJunkcode = 8462924330136;
	if (pJunkcode = 1421214700);
	pJunkcode = 236141609210166;
	pJunkcode = 952915155074;
	if (pJunkcode = 263874004);
	pJunkcode = 906587993740;
	pJunkcode = 17161624127617;
	if (pJunkcode = 3008813019);
	pJunkcode = 57542291717567;
	pJunkcode = 114712591424762;
	if (pJunkcode = 2275626005);
	pJunkcode = 1051943014710;
	pJunkcode = 21726660031575;
	if (pJunkcode = 940024983);
	pJunkcode = 221141292430896;
	pJunkcode = 14524667317749;
	if (pJunkcode = 314051645);
	pJunkcode = 113331488816941;
	pJunkcode = 17731665713174;
	if (pJunkcode = 191976116);
	pJunkcode = 310141386929346;
	pJunkcode = 24789289168223;
	if (pJunkcode = 258483216);
	pJunkcode = 112142526715385;
	pJunkcode = 16855569321978;
	if (pJunkcode = 2240027719);
	pJunkcode = 38961414911887;
	pJunkcode = 218082806710710;
	if (pJunkcode = 858916036);
	pJunkcode = 32533187724052;
	pJunkcode = 13518255669826;
	if (pJunkcode = 129702437);
	pJunkcode = 27721160501358;
	pJunkcode = 118092332617782;
	if (pJunkcode = 1522224462);
	pJunkcode = 12651205032871;
	pJunkcode = 226872650015146;
	if (pJunkcode = 2000432420);
	pJunkcode = 141532345615802;
	pJunkcode = 154222346320540;
	if (pJunkcode = 2022032370);
	pJunkcode = 26978186729018;
	pJunkcode = 2045948919599;
	if (pJunkcode = 135273815);
	pJunkcode = 31338295647019;
	pJunkcode = 226193091129095;
	if (pJunkcode = 656618102);
	pJunkcode = 30921321232711;
	pJunkcode = 3550203891325;
	if (pJunkcode = 6892469);
	pJunkcode = 13084459528506;
	pJunkcode = 131981309527505;
	if (pJunkcode = 262420479);
	pJunkcode = 27826395613447;
	pJunkcode = 300712294520963;
	if (pJunkcode = 2810829490);
	pJunkcode = 251051457910177;
	pJunkcode = 10027483227033;
	if (pJunkcode = 2068828209);
	pJunkcode = 75351440529186;
	pJunkcode = 23101119012749;
	if (pJunkcode = 256328963);
	pJunkcode = 69691245524600;
	pJunkcode = 12231412221084;
	if (pJunkcode = 28321370);
	pJunkcode = 160162488931522;
	pJunkcode = 14309290781608;
	if (pJunkcode = 353617805);
	pJunkcode = 55742239928951;
	pJunkcode = 26167262485686;
	if (pJunkcode = 1798017958);
	pJunkcode = 283891276719776;
	pJunkcode = 149471243325329;
	if (pJunkcode = 2560721333);
	pJunkcode = 1540129221186;
	pJunkcode = 32145786532741;
	if (pJunkcode = 111139459);
	pJunkcode = 185612457715093;
	pJunkcode = 35662072923973;
	if (pJunkcode = 2282922816);
	pJunkcode = 15378316244663;
	pJunkcode = 2589894071125;
}

// Initialises the rendering system, setting up fonts etc
void Render::Initialise()
{
	kjwehewfhwejk();
	Fonts::Font_Weapons = Interfaces::Surface->FontCreate();
	Fonts::Default = 0x1D; // MainMenu Font from vgui_spew_fonts 
	Fonts::Menu = Interfaces::Surface->FontCreate();
	kjwehewfhwejk();
	Fonts::MenuBold = Interfaces::Surface->FontCreate();
	Fonts::ESP = Interfaces::Surface->FontCreate();
	Fonts::MenuText = Interfaces::Surface->FontCreate();
	kjwehewfhwejk();
	Fonts::Tabs = Interfaces::Surface->FontCreate();
	Fonts::Icon = Interfaces::Surface->FontCreate();
	Fonts::WaterMark = Interfaces::Surface->FontCreate();
	kjwehewfhwejk();
	Fonts::Slider = Interfaces::Surface->FontCreate();
	Fonts::Clock = Interfaces::Surface->FontCreate();
	kjwehewfhwejk();
	Fonts::AAarows = Interfaces::Surface->FontCreate();
	Fonts::LBY = Interfaces::Surface->FontCreate();
	kjwehewfhwejk();
	Fonts::ESPNew = Interfaces::Surface->FontCreate();
	Interfaces::Surface->SetFontGlyphSet(Fonts::Font_Weapons, "undefeated", 12, 500, 0, 0, FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::Menu, "Calibri", 14, 500, 0, 0, FONTFLAG_ANTIALIAS | FONTFLAG_DROPSHADOW);
	Interfaces::Surface->SetFontGlyphSet(Fonts::MenuBold, "Calibri", 14, 900, 0, 0, FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::Slider, "Verdana", 11, 600, 0, 0, FONTFLAG_ANTIALIAS | FONTFLAG_DROPSHADOW | FONTFLAG_OUTLINE);
	Interfaces::Surface->SetFontGlyphSet(Fonts::WaterMark, "SWEETREVENGE", 28, 600, 0, 0, FONTFLAG_ANTIALIAS | FONTFLAG_OUTLINE | FONTFLAG_DROPSHADOW); // REPLACE THIS WITH A WATERMARK BECAUSE IM TO LAZY TO TO IT, I NEED SLEEP || OK BRO NO WORRIES
	Interfaces::Surface->SetFontGlyphSet(Fonts::Clock, "Verdana", 16, 600, 0, 0, FONTFLAG_ANTIALIAS | FONTFLAG_OUTLINE);
	Interfaces::Surface->SetFontGlyphSet(Fonts::Tabs, "Impact", 35, 500, 0, 0, FONTFLAG_DROPSHADOW | FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::LBY, "Calibri Bold", 22, 500, 0, 0, FONTFLAG_DROPSHADOW | FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::Icon, "Undefeated", 35, 800, 0, 0, FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::ESP, "Verdana Bold", 12, 400, 0, 0, FONTFLAG_DROPSHADOW);
	Interfaces::Surface->SetFontGlyphSet(Fonts::ESPNew, "Tahoma", 11, 700, 0, 0, FONTFLAG_DROPSHADOW);
	Interfaces::Surface->SetFontGlyphSet(Fonts::MenuText, "Calibri", 16, 500, 0, 0, FONTFLAG_ANTIALIAS);
	Interfaces::Surface->SetFontGlyphSet(Fonts::AAarows, "Verdana", 37, 900, 0, 0, FONTFLAG_ANTIALIAS);
	kjwehewfhwejk();
	Utilities::Log("Render System Ready");
}

RECT Render::GetViewport()
{
	RECT Viewport = { 0, 0, 0, 0 };
	int w, h;
	Interfaces::Engine->GetScreenSize(w, h);
	Viewport.right = w; Viewport.bottom = h;
	return Viewport;
}

void Render::DrawRect(int x, int y, int w, int h, Color col)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(col);
	Interfaces::Surface->DrawFilledRect(x, y, x + w, y + h);
}
#define M_PI 3.14159265358979323846

void Render::DrawCircle(float x, float y, float r, float segments, Color color)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color);
	Interfaces::Surface->DrawOutlinedCircle(x, y, r, segments);
}

void Render::DrawTexturedPoly(int n, Vertex_t* vertice, Color col)
{
	kjwehewfhwejk();
	static int texture_id = Interfaces::Surface->CreateNewTextureID(true);
	static unsigned char buf[4] = { 255, 255, 255, 255 };
	Interfaces::Surface->DrawSetTextureRGBA(texture_id, buf, 1, 1);
	Interfaces::Surface->DrawSetColor(col);
	Interfaces::Surface->DrawSetTexture(texture_id);
	Interfaces::Surface->DrawTexturedPolygon(n, vertice);
	kjwehewfhwejk();
}

void Render::TexturedPolygon(int n, std::vector<Vertex_t> vertice, Color color)
{
	static int texture_id = Interfaces::Surface->CreateNewTextureID(true); // 
	static unsigned char buf[4] = { 255, 255, 255, 255 };
	Interfaces::Surface->DrawSetTextureRGBA(texture_id, buf, 1, 1); //
	Interfaces::Surface->DrawSetColor(color); //
	Interfaces::Surface->DrawSetTexture(texture_id); //
	Interfaces::Surface->DrawTexturedPolygon(n, vertice.data()); //
}


void Render::DrawFilledCircle(Vector2D center, Color color, float radius, float points) {
	std::vector<Vertex_t> vertices;
	float step = (float)M_PI * 2.0f / points;
	for (float a = 0; a < (M_PI * 2.0f); a += step)
		vertices.push_back(Vertex_t(Vector2D(radius * cosf(a) + center.x, radius * sinf(a) + center.y)));
	kjwehewfhwejk();
	DrawTexturedPoly((int)points, vertices.data(), color);
}


void Render::DrawRectRainbow(int x, int y, int width, int height, float flSpeed, float &flRainbow)
{
	kjwehewfhwejk();
	Color colColor(0, 0, 0);
	kjwehewfhwejk();
	flRainbow += 0.0004f;
	if (flRainbow > 1.f) flRainbow = 0.f;

	for (int i = 0; i < width; i++)
	{
		float hue = (1.f / (float)width) * i;
		hue -= flRainbow;
		if (hue < 0.f) hue += 1.f;
		kjwehewfhwejk();
		Color colRainbow = colColor.FromHSB(hue, 1.f, 1.f);
		Render::DrawRect(x + i, y, 1, height, colRainbow);
	}
}

void Render::Clear(int x, int y, int w, int h, Color color)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color);
	Interfaces::Surface->DrawFilledRect(x, y, x + w, y + h);
}

void Render::Outline(int x, int y, int w, int h, Color color)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color);
	Interfaces::Surface->DrawOutlinedRect(x, y, x + w, y + h);
}

void Render::Line(int x, int y, int x2, int y2, Color color)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color);
	Interfaces::Surface->DrawLine(x, y, x2, y2);
}

void Render::PolyLine(int *x, int *y, int count, Color color)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color);
	Interfaces::Surface->DrawPolyLine(x, y, count);
}

bool Render::WorldToScreen(Vector &in, Vector &out)
{
	kjwehewfhwejk();
	const matrix3x4& worldToScreen = Interfaces::Engine->WorldToScreenMatrix(); //Grab the world to screen matrix from CEngineClient::WorldToScreenMatrix

	float w = worldToScreen[3][0] * in[0] + worldToScreen[3][1] * in[1] + worldToScreen[3][2] * in[2] + worldToScreen[3][3]; //Calculate the angle in compareson to the player's camera.
	out.z = 0; //Screen doesn't have a 3rd dimension.

	if (w > 0.001) //If the object is within view.
	{
		RECT ScreenSize = GetViewport();
		float fl1DBw = 1 / w; //Divide 1 by the angle.
		out.x = (ScreenSize.right / 2) + (0.5f * ((worldToScreen[0][0] * in[0] + worldToScreen[0][1] * in[1] + worldToScreen[0][2] * in[2] + worldToScreen[0][3]) * fl1DBw) * ScreenSize.right + 0.5f); //Get the X dimension and push it in to the Vector.
		out.y = (ScreenSize.bottom / 2) - (0.5f * ((worldToScreen[1][0] * in[0] + worldToScreen[1][1] * in[1] + worldToScreen[1][2] * in[2] + worldToScreen[1][3]) * fl1DBw) * ScreenSize.bottom + 0.5f); //Get the Y dimension and push it in to the Vector.
		return true;
	}

	return false;
}

void Render::ColorSpectrum(int x, int y, int w, int h)
{
	kjwehewfhwejk();
	static int GradientTexture = 0;
	static std::unique_ptr<Color[]> Gradient = nullptr;
	if (!Gradient)
	{
		Gradient = std::make_unique<Color[]>(w * h);

		for (int i = 0; i < w; i++)
		{
			int div = w / 6;
			int phase = i / div;
			float t = (i % div) / (float)div;
			int r, g, b;

			switch (phase)
			{
			case(0):
				r = 255;
				g = 255 * t;
				b = 0;
				break;
			case(1):
				r = 255 * (1.f - t);
				g = 255;
				b = 0;
				break;
			case(2):
				r = 0;
				g = 255;
				b = 255 * t;
				break;
			case(3):
				r = 0;
				g = 255 * (1.f - t);
				b = 255;
				break;
			case(4):
				r = 255 * t;
				g = 0;
				b = 255;
				break;
			case(5):
				r = 255;
				g = 0;
				b = 255 * (1.f - t);
				break;
			}

			for (int k = 0; k < h; k++)
			{
				float sat = k / (float)h;
				int _r = r + sat * (128 - r);
				int _g = g + sat * (128 - g);
				int _b = b + sat * (128 - b);

				*reinterpret_cast<Color*>(Gradient.get() + i + k * w) = Color(_r, _g, _b);
			}
		}

		GradientTexture = Interfaces::Surface->CreateNewTextureID(true);
		Interfaces::Surface->DrawSetTextureRGBA(GradientTexture, (unsigned char*)Gradient.get(), w, h);
	}
	Interfaces::Surface->DrawSetColor(Color(255, 255, 255, 255));
	Interfaces::Surface->DrawSetTexture(GradientTexture);
	Interfaces::Surface->DrawTexturedRect(x, y, x + w, y + h);
}

Color Render::ColorSpectrumPen(int x, int y, int w, int h, Vector stx)
{
	kjwehewfhwejk();
	int div = w / 6;
	int phase = stx.x / div;
	float t = ((int)stx.x % div) / (float)div;
	int r, g, b;

	switch (phase)
	{
	case(0):
		r = 255;
		g = 255 * t;
		b = 0;
		break;
	case(1):
		r = 255 * (1.f - t);
		g = 255;
		b = 0;
		break;
	case(2):
		r = 0;
		g = 255;
		b = 255 * t;
		break;
	case(3):
		r = 0;
		g = 255 * (1.f - t);
		b = 255;
		break;
	case(4):
		r = 255 * t;
		g = 0;
		b = 255;
		break;
	case(5):
		r = 255;
		g = 0;
		b = 255 * (1.f - t);
		break;
	}

	float sat = stx.y / h;
	return Color(r + sat * (128 - r), g + sat * (128 - g), b + sat * (128 - b), 255);
}

RECT Render::get_text_size(const char* _Input, int font)
{
	kjwehewfhwejk();
	int apple = 0;
	char Buffer[2048] = { '\0' };
	va_list Args;
	va_start(Args, _Input);
	vsprintf_s(Buffer, _Input, Args);
	va_end(Args);
	size_t Size = strlen(Buffer) + 1;
	wchar_t* WideBuffer = new wchar_t[Size];
	mbstowcs_s(0, WideBuffer, Size, Buffer, Size - 1);
	int Width = 0, Height = 0;

	Interfaces::Surface->GetTextSize(font, WideBuffer, Width, Height);

	RECT outcome = { 0, 0, Width, Height };
	return outcome;
}


void Render::OutlinedRect(int x, int y, int w, int h, Color color_out, Color color_in)
{
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color_in);
	Interfaces::Surface->DrawFilledRect(x, y, x + w, y + h);
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetColor(color_out);
	Interfaces::Surface->DrawOutlinedRect(x, y, x + w, y + h);
}

void Render::text1(int x, int y, const char* _Input, int font, Color color)
{
	kjwehewfhwejk();
	int apple = 0;
	char Buffer[2048] = { '\0' };
	va_list Args;
	va_start(Args, _Input);
	vsprintf_s(Buffer, _Input, Args);
	va_end(Args);
	size_t Size = strlen(Buffer) + 1;
	wchar_t* WideBuffer = new wchar_t[Size];
	mbstowcs_s(0, WideBuffer, Size, Buffer, Size - 1);

	Interfaces::Surface->DrawSetTextColor(color);
	Interfaces::Surface->DrawSetTextFont(font);
	Interfaces::Surface->DrawSetTextPos(x, y);
	Interfaces::Surface->DrawPrintText(WideBuffer, wcslen(WideBuffer));
}

void Render::Text(int x, int y, Color color, DWORD font, const char* text)
{
	size_t origsize = strlen(text) + 1;
	const size_t newsize = 500;
	size_t convertedChars = 0;
	wchar_t wcstring[newsize];
	mbstowcs_s(&convertedChars, wcstring, origsize, text, _TRUNCATE);

	Interfaces::Surface->DrawSetTextFont(font);
	kjwehewfhwejk();
	Interfaces::Surface->DrawSetTextColor(color);
	Interfaces::Surface->DrawSetTextPos(x, y);
	Interfaces::Surface->DrawPrintText(wcstring, wcslen(wcstring));
	//return;
};


//jak crash to here
void Render::Text(int x, int y, Color color, DWORD font, const wchar_t* text)
{
	Interfaces::Surface->DrawSetTextFont(font);
	Interfaces::Surface->DrawSetTextColor(color);
	Interfaces::Surface->DrawSetTextPos(x, y);
	Interfaces::Surface->DrawPrintText(text, wcslen(text));
}

void Render::Textf(int x, int y, Color color, DWORD font, const char* fmt, ...)
{
	kjwehewfhwejk();
	if (!fmt) return; //if the passed string is null return
	if (strlen(fmt) < 2) return;

	//Set up va_list and buffer to hold the params 
	va_list va_alist;
	char logBuf[256] = { 0 };

	//Do sprintf with the parameters
	va_start(va_alist, fmt);
	_vsnprintf_s(logBuf + strlen(logBuf), 256 - strlen(logBuf), sizeof(logBuf) - strlen(logBuf), fmt, va_alist);
	va_end(va_alist);

	Text(x, y, color, font, logBuf);
}

RECT Render::GetTextSize(DWORD font, const char* text)
{
	size_t origsize = strlen(text) + 1;
	const size_t newsize = 200;
	size_t convertedChars = 0;
	wchar_t wcstring[newsize];
	mbstowcs_s(&convertedChars, wcstring, origsize, text, _TRUNCATE);

	RECT rect; int x, y;
	Interfaces::Surface->GetTextSize(font, wcstring, x, y);
	rect.left = x; rect.bottom = y;
	rect.right = x;
	return rect;
}

void Render::GradientV(int x, int y, int w, int h, Color c1, Color c2)
{
	Clear(x, y, w, h, c1);
	BYTE first = c2.r();
	BYTE second = c2.g();
	BYTE third = c2.b();
	for (int i = 0; i < h; i++)
	{
		float fi = i, fh = h;
		float a = fi / fh;
		DWORD ia = a * 255;
		Clear(x, y + i, w, 1, Color(first, second, third, ia));
	}
}

void Render::GradientH(int x, int y, int w, int h, Color c1, Color c2)
{
	kjwehewfhwejk();
	Clear(x, y, w, h, c1);
	BYTE first = c2.r();
	BYTE second = c2.g();
	BYTE third = c2.b();
	for (int i = 0; i < w; i++)
	{
		kjwehewfhwejk();
		float fi = i, fw = w;
		float a = fi / fw;
		DWORD ia = a * 255;
		Clear(x + i, y, 1, h, Color(first, second, third, ia));
	}
}

void Render::Polygon(int count, Vertex_t* Vertexs, Color color)
{
	static int Texture = Interfaces::Surface->CreateNewTextureID(true); //need to make a texture with procedural true
	unsigned char buffer[4] = { 255, 255, 255, 255 };//{ color.r(), color.g(), color.b(), color.a() };

	Interfaces::Surface->DrawSetTextureRGBA(Texture, buffer, 1, 1); //Texture, char array of texture, width, height
	Interfaces::Surface->DrawSetColor(color); // keep this full color and opacity use the RGBA @top to set values.
	Interfaces::Surface->DrawSetTexture(Texture); // bind texture
	kjwehewfhwejk();
	Interfaces::Surface->DrawTexturedPolygon(count, Vertexs);
}

void Render::PolygonOutline(int count, Vertex_t* Vertexs, Color color, Color colorLine)
{
	static int x[128];
	static int y[128];
	kjwehewfhwejk();
	Render::Polygon(count, Vertexs, color);

	for (int i = 0; i < count; i++)
	{
		x[i] = Vertexs[i].m_Position.x;
		y[i] = Vertexs[i].m_Position.y;
	}

	Render::PolyLine(x, y, count, colorLine);
}

void Render::PolyLine(int count, Vertex_t* Vertexs, Color colorLine)
{
	static int x[128];
	static int y[128];

	for (int i = 0; i < count; i++)
	{
		x[i] = Vertexs[i].m_Position.x;
		y[i] = Vertexs[i].m_Position.y;
	}

	Render::PolyLine(x, y, count, colorLine);
}

int TweakColor(int c1, int c2, int variation)
{
	if (c1 == c2)
		return c1;
	else if (c1 < c2)
		c1 += variation;
	else
		c1 -= variation;
	return c1;
}

void Render::GradientSideways(int x, int y, int w, int h, Color color1, Color color2, int variation)
{
	kjwehewfhwejk();
	int r1 = color1.r();
	int g1 = color1.g();
	int b1 = color1.b();
	int a1 = color1.a();

	int r2 = color2.r();
	int g2 = color2.g();
	int b2 = color2.b();
	int a2 = color2.a();

	for (int i = 0; i <= w; i++)
	{
		Render::DrawRect(x + i, y, 1, h, Color(r1, g1, b1, a1));
		r1 = TweakColor(r1, r2, variation);
		g1 = TweakColor(g1, g2, variation);
		b1 = TweakColor(b1, b2, variation);
		a1 = TweakColor(a1, a2, variation);
	}
}















































































































































































































































































































































































































































































































