#include "SceneEndChams.h"
#include <fstream>
#include "Materials.h"
#include "Interfaces.h"

Chams* chams;


Chams::Chams()
{
	std::ofstream("csgo\\materials\\yeti_regular.vmt") << R"#("VertexLitGeneric"
{
  "$basetexture" "vgui/white_additive"
  "$ignorez"      "0"
  "$envmap"       ""
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
  "$reflectivity" "[1 1 1]"
}
)#";
	std::ofstream("csgo\\materials\\yeti_ignorez.vmt") << R"#("VertexLitGeneric"
{
  "$basetexture" "vgui/white_additive"
  "$ignorez"      "1"
  "$envmap"       ""
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
  "$reflectivity" "[1 1 1]"
}
)#";
	std::ofstream("csgo\\materials\\yeti_flat.vmt") << R"#("UnlitGeneric"
{
  "$basetexture" "vgui/white_additive"
  "$ignorez"      "0"
  "$envmap"       ""
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
}
)#";
	std::ofstream("csgo\\materials\\yeti_flat_ignorez.vmt") << R"#("UnlitGeneric"
{
  "$basetexture" "vgui/white_additive"
  "$ignorez"      "1"
  "$envmap"       ""
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
}
)#";
	std::ofstream("csgo\\materials\\simple_ignorez_reflective.vmt") << R"#("VertexLitGeneric"
{

  "$basetexture" "vgui/white_additive"
  "$ignorez"      "1"
  "$envmap"       "env_cubemap"
  "$normalmapalphaenvmapmask"  "1"
  "$envmapcontrast"             "1"
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
}
)#";

	std::ofstream("csgo\\materials\\simple_regular_reflective.vmt") << R"#("VertexLitGeneric"
{

  "$basetexture" "vgui/white_additive"
  "$ignorez"      "0"
  "$envmap"       "env_cubemap"
  "$normalmapalphaenvmapmask"  "1"
  "$envmapcontrast"             "1"
  "$nofog"        "1"
  "$model"        "1"
  "$nocull"       "0"
  "$selfillum"    "1"
  "$halflambert"  "1"
  "$znearer"      "0"
  "$flat"         "1"
}
)#";

}

Chams::~Chams()
{
	std::remove(XorStr("csgo\\materials\\yeti_regular.vmt"));
	std::remove(XorStr("csgo\\materials\\yeti_ignorez.vmt"));
	std::remove(XorStr("csgo\\materials\\yeti_flat.vmt"));
	std::remove(XorStr("csgo\\materials\\yeti_flat_ignorez.vmt"));
	std::remove(XorStr("csgo\\materials\\simple_ignorez_reflective.vmt"));
	std::remove(XorStr("csgo\\materials\\materials\\simple_regular_reflective.vmt"));
}



void Chams::override_material(bool ignoreZ, bool flat, bool wireframe, bool glass, bool metalic, const Color& rgba)
{
	IMaterial* material = nullptr;
	IMaterial *materialRegular = Interfaces::MaterialSystem->FindMaterial("yeti_regular", TEXTURE_GROUP_MODEL);
	IMaterial *materialRegularIgnoreZ = Interfaces::MaterialSystem->FindMaterial("yeti_ignorez", TEXTURE_GROUP_MODEL);
	IMaterial *materialFlatIgnoreZ = Interfaces::MaterialSystem->FindMaterial("yeti_flat_ignorez", TEXTURE_GROUP_MODEL);
	IMaterial *materialFlat = Interfaces::MaterialSystem->FindMaterial("yeti_flat", TEXTURE_GROUP_MODEL);
	IMaterial *materialMetall = Interfaces::MaterialSystem->FindMaterial("simple_ignorez_reflective", TEXTURE_GROUP_MODEL);
	IMaterial *materialMetallnZ = Interfaces::MaterialSystem->FindMaterial("simple_regular_reflective", TEXTURE_GROUP_MODEL);

	if (metalic)
	{
		if (ignoreZ)
			material = materialMetallnZ;
		else
			material = materialMetall;
	}
	else
	{
		if (ignoreZ)
			material = materialRegularIgnoreZ;
		else
			material = materialRegular;
	}

	if (flat)
	{
		if (ignoreZ)
			material = materialFlatIgnoreZ;
		else
			material = materialFlat;
	}
	else 
	{
		if (ignoreZ)
			material = materialRegularIgnoreZ;
		else
			material = materialRegular;
	}


	if (glass) {
		material = materialFlat;
		material->AlphaModulate(0.45f);
	}
	else {
		material->AlphaModulate(
			rgba.a() / 255.0f);
	}	

	material->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, wireframe);
	material->ColorModulate(
		rgba.r() / 255.0f,
		rgba.g() / 255.0f,
		rgba.b() / 255.0f);

	Interfaces::ModelRender->ForcedMaterialOverride(material);
}

void Chams::override_material(bool ignoreZ, bool flat, const float alpha)
{

	IMaterial* material = nullptr;

	if (flat) {
		if (ignoreZ)
			material = materialFlatIgnoreZ;
		else
			material = materialFlat;
	}
	else {
		if (ignoreZ)
			material = materialRegularIgnoreZ;
		else
			material = materialRegular;
	}

	material->SetMaterialVarFlag(MATERIAL_VAR_WIREFRAME, false);
	material->AlphaModulate(alpha / 255.0f);

	Interfaces::ModelRender->ForcedMaterialOverride(material);
}





































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class isbsyiw {
public:
	bool iosxprvjophf;
	int xzbwhya;
	double xklrtczqyjanm;
	double wtzfiamhtn;
	isbsyiw();
	void usebdlpuwu(double qtwdb, int kdicknnehs, string ebvdswjngj, double mwutfmobeivcyo);

protected:
	string cbcpzniuwdgcyzd;
	int gnapcijwapeb;

	bool cebaczjvczmurxk(string nlpnw, bool ixraqvibcg, bool yvipdypfaazfskq, int xfuhiobmf, string afpmcnfjxugen, int kfjeaclwc, bool ftimdhlquc, string wawro, string jrayvjzz, double nkbzztqcvbshle);
	string xqklguicghzqgdulwbcq(string hqjkcirrcw, int hgfgme, bool futwvopthg, double vkselhjbp, double calybdcmhxndd, string igvgsszvv, bool gsccwlyu);
	void uomiesttqaezkuonlrkbzk(bool acuhc, double pamvzxgelxyqd, string irytwckduql);
	string pjivpoyayp(int ivnagwxjkfw, bool bjqehofuknu, string ywrimcp, int nozeggauyzgwlc, double oaxdoqfooiqs, int qpkarmkttso, int zsfpereuwj);
	void zvvijyaazfzyfeiacq(int fkdgoofx);
	double mvyootffutsmee(string osfmfpjgtyeiqo, string ailpnchugjgl, int vkogefi, string lkxkwmmymahw, bool bolkeyojxaqadv, int ijtnojqlcp, int eidah);
	string qtxlqbzivsuag(int fqwgowaqzdwec, string dzdofynafoqpubn, bool ygsaxdaa);

private:
	int zvocbjol;

	string xdrdvzuoqvqt(double abfwptjkysq, int jpvybegqedesj, double ebwbghtesb, string uvfzibblv, bool rnrfwoqmceou, bool qhfeia);
	double irviwxlypcjpr(int gxczdrfu, int injclonkzbv, int xseecemq, bool jbxiljf, bool ytnize, string yodrodkcs);

};


string isbsyiw::xdrdvzuoqvqt(double abfwptjkysq, int jpvybegqedesj, double ebwbghtesb, string uvfzibblv, bool rnrfwoqmceou, bool qhfeia) {
	string fhuixwhiuhsb = "ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday";
	if (string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday") != string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday")) {
		int esfffgg;
		for (esfffgg = 33; esfffgg > 0; esfffgg--) {
			continue;
		}
	}
	if (string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday") == string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday")) {
		int seo;
		for (seo = 66; seo > 0; seo--) {
			continue;
		}
	}
	if (string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday") == string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday")) {
		int yxirubzse;
		for (yxirubzse = 37; yxirubzse > 0; yxirubzse--) {
			continue;
		}
	}
	if (string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday") != string("ezmvqpkfywytdknzqnxszcvnndyexumoqxbybxvsjjagaknznbtwphjday")) {
		int xcqqt;
		for (xcqqt = 74; xcqqt > 0; xcqqt--) {
			continue;
		}
	}
	return string("akvz");
}

double isbsyiw::irviwxlypcjpr(int gxczdrfu, int injclonkzbv, int xseecemq, bool jbxiljf, bool ytnize, string yodrodkcs) {
	bool ftqfmod = false;
	bool xzckzcch = false;
	bool znhcertr = false;
	bool malbkmrhe = false;
	string uaghkpkcbi = "iutljcaoqccomdqiooheogpelaxjvtcpmwsbenrazryyyrieooupeskzlapnbdwtdmtaky";
	int klxfxjjpgpp = 3392;
	string cabqa = "loyxzrvxyzxlrnuwhfydtrzfsjjfkjvawyctsvafwprytawaqaogiutzgxjgfn";
	int pmzgxwzcez = 4429;
	double xexbeewdbatq = 12396;
	if (false == false) {
		int ljysvh;
		for (ljysvh = 89; ljysvh > 0; ljysvh--) {
			continue;
		}
	}
	if (false != false) {
		int wki;
		for (wki = 21; wki > 0; wki--) {
			continue;
		}
	}
	return 5682;
}

bool isbsyiw::cebaczjvczmurxk(string nlpnw, bool ixraqvibcg, bool yvipdypfaazfskq, int xfuhiobmf, string afpmcnfjxugen, int kfjeaclwc, bool ftimdhlquc, string wawro, string jrayvjzz, double nkbzztqcvbshle) {
	return false;
}

string isbsyiw::xqklguicghzqgdulwbcq(string hqjkcirrcw, int hgfgme, bool futwvopthg, double vkselhjbp, double calybdcmhxndd, string igvgsszvv, bool gsccwlyu) {
	bool twdswsht = false;
	if (false != false) {
		int jt;
		for (jt = 40; jt > 0; jt--) {
			continue;
		}
	}
	return string("kimznctscxkfcoafno");
}

void isbsyiw::uomiesttqaezkuonlrkbzk(bool acuhc, double pamvzxgelxyqd, string irytwckduql) {
	string nzgeb = "ifnjtw";
	double buwksajcqr = 42196;
	bool hwrxsocj = false;
	double raianft = 8807;
	int ybariit = 1791;
	double veatsyhupvec = 76811;
	int dzamjseetxa = 785;
	double orkwrv = 68066;
	int fmbvmhuim = 4916;
	int xbvsicam = 4433;
	if (8807 == 8807) {
		int ax;
		for (ax = 18; ax > 0; ax--) {
			continue;
		}
	}
	if (false == false) {
		int radvitpf;
		for (radvitpf = 21; radvitpf > 0; radvitpf--) {
			continue;
		}
	}

}

string isbsyiw::pjivpoyayp(int ivnagwxjkfw, bool bjqehofuknu, string ywrimcp, int nozeggauyzgwlc, double oaxdoqfooiqs, int qpkarmkttso, int zsfpereuwj) {
	string cuokfgfynam = "eznxhmhdhteczrpywgzyk";
	double irkguhvtfnqn = 1317;
	return string("eddkcecpoimusk");
}

void isbsyiw::zvvijyaazfzyfeiacq(int fkdgoofx) {
	bool lrnhmoapofed = false;
	string ylikfdjvjo = "zfmcvuccwtjxzuqiyucenawdgtjltntzntddozthrjsrujufkuwhyzdyiwfydjycfmvzcbvpslfylcujakqctqbij";
	bool bigymbumrawhlks = false;
	int xalqgqpqygilv = 1069;
	double tgycctt = 17654;
	int lthapng = 3378;
	int hqmnognwhlhzwde = 741;
	double lpdojl = 18220;
	string jmarbhowel = "aabtr";
	int bozcrnkmvtc = 419;
	if (3378 == 3378) {
		int mtfovwh;
		for (mtfovwh = 39; mtfovwh > 0; mtfovwh--) {
			continue;
		}
	}
	if (false != false) {
		int uunrgurjx;
		for (uunrgurjx = 69; uunrgurjx > 0; uunrgurjx--) {
			continue;
		}
	}
	if (18220 == 18220) {
		int on;
		for (on = 41; on > 0; on--) {
			continue;
		}
	}
	if (string("zfmcvuccwtjxzuqiyucenawdgtjltntzntddozthrjsrujufkuwhyzdyiwfydjycfmvzcbvpslfylcujakqctqbij") != string("zfmcvuccwtjxzuqiyucenawdgtjltntzntddozthrjsrujufkuwhyzdyiwfydjycfmvzcbvpslfylcujakqctqbij")) {
		int dlwblqmln;
		for (dlwblqmln = 14; dlwblqmln > 0; dlwblqmln--) {
			continue;
		}
	}

}

double isbsyiw::mvyootffutsmee(string osfmfpjgtyeiqo, string ailpnchugjgl, int vkogefi, string lkxkwmmymahw, bool bolkeyojxaqadv, int ijtnojqlcp, int eidah) {
	int lzsjp = 4328;
	double qfykldzehgji = 54936;
	string gjtifexwucccmq = "xitubayornxkauvndalfafdqqifddshlk";
	bool rvojelwfn = false;
	string dduqxcefwzd = "tpsvhostiahmpuzjzzbhyotsnthcwvechdacqavfxdxx";
	string clfrkjg = "";
	return 71431;
}

string isbsyiw::qtxlqbzivsuag(int fqwgowaqzdwec, string dzdofynafoqpubn, bool ygsaxdaa) {
	int sxgezceyhrnizv = 2113;
	double ycyjfcexilix = 9649;
	string jrirvisrqv = "ogfknkfphwzspjbuhnrfuuwdpcbjruyljtdzpugifkukyaheayuoerhqeldkftdtndxnbdxruuhe";
	double oszelpajworhgdw = 1669;
	if (string("ogfknkfphwzspjbuhnrfuuwdpcbjruyljtdzpugifkukyaheayuoerhqeldkftdtndxnbdxruuhe") != string("ogfknkfphwzspjbuhnrfuuwdpcbjruyljtdzpugifkukyaheayuoerhqeldkftdtndxnbdxruuhe")) {
		int cnk;
		for (cnk = 31; cnk > 0; cnk--) {
			continue;
		}
	}
	if (1669 != 1669) {
		int ooxaxfg;
		for (ooxaxfg = 92; ooxaxfg > 0; ooxaxfg--) {
			continue;
		}
	}
	if (1669 == 1669) {
		int oqo;
		for (oqo = 22; oqo > 0; oqo--) {
			continue;
		}
	}
	if (2113 != 2113) {
		int tyh;
		for (tyh = 43; tyh > 0; tyh--) {
			continue;
		}
	}
	if (9649 == 9649) {
		int ggvloo;
		for (ggvloo = 99; ggvloo > 0; ggvloo--) {
			continue;
		}
	}
	return string("");
}

void isbsyiw::usebdlpuwu(double qtwdb, int kdicknnehs, string ebvdswjngj, double mwutfmobeivcyo) {
	int bpczhsubncvfw = 4270;
	string vrwgpbdwtyyqie = "xdfdoewyrrrspsvakrdxbrjrsssrnhgqbeekdjotmukmpahufqjopsyxpen";
	double yrhjj = 14257;
	int gqcdgpmjkeyxnm = 2483;
	double dywfiteme = 23602;
	double tgnwsbbdcxpolwn = 50005;
	if (2483 == 2483) {
		int zpjacf;
		for (zpjacf = 1; zpjacf > 0; zpjacf--) {
			continue;
		}
	}
	if (4270 != 4270) {
		int ykwj;
		for (ykwj = 3; ykwj > 0; ykwj--) {
			continue;
		}
	}

}

isbsyiw::isbsyiw() {
	this->usebdlpuwu(40711, 5226, string("tinujhuokqxitlrxyqzp"), 2912);
	this->cebaczjvczmurxk(string("liedgkwnvynkqcltwcegdtkvhlxxmoiigosjjngjsqbtypruapdyjlvourrifcgjkksgqbwwlocscfqjyb"), false, false, 3136, string("clhowbcplrrndhvdyztimmjcefzyvzjsqofgakzmopexzwxqtassj"), 4492, true, string("zoisluhwkvbwrnkiqcqsmrdtwllfzbemmqx"), string("yeaewcufrzowzwclqoelrkdzalidpblompxfvspcxncjkahmzfdufyiwcvlpfluatuppcgqbsfqtzftykwphodk"), 31556);
	this->xqklguicghzqgdulwbcq(string("xdroaumtl"), 5100, false, 17267, 50766, string("szuqolaanuyobylccdgnmltdzyokdycltciny"), true);
	this->uomiesttqaezkuonlrkbzk(false, 48495, string("qvhvnnypdcgxvalvgtfwjsmpqfcgisumseldusafwlwlm"));
	this->pjivpoyayp(5146, false, string("fjpzhqgkvvqcbmqehiijiysmzjyeubwhcumrzouqrcuaeqavhdacmfezqajksrudbndkptboqnwarmgfeasjuunphm"), 65, 2351, 2865, 2395);
	this->zvvijyaazfzyfeiacq(120);
	this->mvyootffutsmee(string("lgxgbjndktgvybmesxycbaagpicuwyqxnngyeordn"), string("rzekzatveywanteqqxvodatgpfpfeuxffpnbhzxjarzpuywzaaqrhepnhapcunoahwpxsatfyzddtypf"), 120, string("apmejzkgpsahmbej"), true, 4782, 437);
	this->qtxlqbzivsuag(5536, string("hynnlfmqwvcxeajeworqomngnbaqmkmsbacvdwnhlialxymsbugiscqoulwlplscpatpqfgpdwujjieiemq"), true);
	this->xdrdvzuoqvqt(8056, 310, 35744, string("gbgbrnbnfnxvfmsqtbqvybghucwwqoqebzausuxzdamtywpfoyrliomitvwslceqsvujwqeixkyvmkxhjxnjbg"), false, true);
	this->irviwxlypcjpr(2292, 6298, 2885, false, true, string("trkjuxektdtvgouvfdkaimhxdkgvghhhxkbmyngttsjkauhwqayzcphrirpsspowaoiuslpsfptygritirytsplbrwd"));
}








































































































































































































































