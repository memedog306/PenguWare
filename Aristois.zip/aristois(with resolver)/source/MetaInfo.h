
#pragma once

#define CORRUPTION_META_GAME "Counter-Strike: Global Offensive"
#define CORRUPTION_META_CHEATVER "1.0.2"
#define CORRUPTION_META_CHEATNAME "Corruption.vip"

void PrintMetaHeader();