
#include "Interfaces.h"
#include "Utilities.h"
#include "lagcomp.h"
#include "glow.h"
//SDK Specific Definitions
typedef void* (__cdecl* CreateInterface_t)(const char*, int*);
typedef void* (*CreateInterfaceFn)(const char *pName, int *pReturnCode);

//Some globals for later
CreateInterface_t EngineFactory = NULL; // These are used to store the individual
CreateInterface_t ClientFactory = NULL; //  CreateInterface functions for each game
CreateInterface_t VGUISurfaceFactory = NULL; //  dll that we need access to. Can call
CreateInterface_t VGUI2Factory = NULL; //  them to recieve pointers to game classes.
CreateInterface_t MatFactory = NULL;
CreateInterface_t PhysFactory = NULL;
CreateInterface_t StdFactory = NULL;
CreateInterface_t InputSystemPointer = NULL;
CreateInterface_t DataCaching = NULL;

void Interfaces::fewisdlhgkjewfjkwegcjhwe()
{
	float pJunkcode = 1743117318;
	pJunkcode = 2740135741425;
	if (pJunkcode = 316478148);
	pJunkcode = 10187;
	pJunkcode = 2331794313357;
	pJunkcode = 292732366313564;
	if (pJunkcode = 3132317116);
	pJunkcode = 20076122129830;
	pJunkcode = 16222223346521;
	if (pJunkcode = 2422912090);
	pJunkcode = 21025;
	pJunkcode = 3239404922739;
	pJunkcode = 1599942721499;
	if (pJunkcode = 2650117617);
	pJunkcode = 13407865728124;
	pJunkcode = 1293630795285;
	if (pJunkcode = 2253216427);
	pJunkcode = 159502676625217;
	pJunkcode = 57611258210427;
	pJunkcode = 269123108916172;
	if (pJunkcode = 21498750);
	pJunkcode = 262162026730204;
	pJunkcode = 66312917914194;
	if (pJunkcode = 29285561);
	pJunkcode = 10446110486395;
	pJunkcode = 10891306444576;
	if (pJunkcode = 2683613376);
	pJunkcode = 243433210913125;
	pJunkcode = 222403010712792;
	if (pJunkcode = 2141618672);
	pJunkcode = 32254297765212;
	pJunkcode = 841751874736;
	if (pJunkcode = 2587016959);
	pJunkcode = 138392320717975;
	pJunkcode = 110511083529700;
	if (pJunkcode = 355813835);
	pJunkcode = 31152004927072;
	pJunkcode = 9088320066994;
	if (pJunkcode = 16965153);
	pJunkcode = 16904170925429;
	pJunkcode = 15686206528188;
	if (pJunkcode = 35701807);
	pJunkcode = 37581104122343;
	pJunkcode = 153651872819161;
	if (pJunkcode = 309532553);
	pJunkcode = 99791474130302;
	pJunkcode = 356567681157;
	if (pJunkcode = 153241992);
	pJunkcode = 5663319896738;
	pJunkcode = 30286232021468;
	if (pJunkcode = 1758112110);
	pJunkcode = 26145504212884;
	pJunkcode = 184611501527779;
	if (pJunkcode = 280425156);
	pJunkcode = 6232160232643;
	pJunkcode = 124062212119807;
	if (pJunkcode = 1343918373);
	pJunkcode = 28147280598567;
	pJunkcode = 43733010728444;
	if (pJunkcode = 250928368);
	pJunkcode = 1141068429370;
	pJunkcode = 2735525626679;
	if (pJunkcode = 14994201);
	pJunkcode = 107951027713642;
	pJunkcode = 226071250016308;
	if (pJunkcode = 292391016);
	pJunkcode = 16070149383864;
	pJunkcode = 6170366117209;
	if (pJunkcode = 1544711785);
	pJunkcode = 50563184422156;
	pJunkcode = 1012279632241;
	if (pJunkcode = 1465918059);
	pJunkcode = 227641928012031;
	pJunkcode = 279212724413019;
	if (pJunkcode = 88316513);
	pJunkcode = 166211937330015;
	pJunkcode = 29379175311464;
	if (pJunkcode = 800231124);
	pJunkcode = 311661831759;
	pJunkcode = 12507223026544;
	if (pJunkcode = 2687421294);
	pJunkcode = 29994285666308;
	pJunkcode = 26678773916173;
	if (pJunkcode = 1632520065);
	pJunkcode = 3402363832553;
	pJunkcode = 3286314913215;
	if (pJunkcode = 12025430);
	pJunkcode = 12593254728476;
	pJunkcode = 16481688428342;
	if (pJunkcode = 860513438);
	pJunkcode = 5385513812399;
	pJunkcode = 2371211042395;
	if (pJunkcode = 1815812701);
	pJunkcode = 171452172224264;
	pJunkcode = 3584138881272;
	if (pJunkcode = 1814010682);
	pJunkcode = 12148234171857;
	pJunkcode = 32276199756171;
	if (pJunkcode = 180589704);
	pJunkcode = 21949293435192;
	pJunkcode = 36012799128375;
	if (pJunkcode = 155692592);
	pJunkcode = 12399140812624;
	pJunkcode = 8528630728755;
	if (pJunkcode = 582110173);
	pJunkcode = 501158315119;
	pJunkcode = 306722008225977;
	if (pJunkcode = 1127824574);
	pJunkcode = 279221929524398;
	pJunkcode = 63221840014200;
	if (pJunkcode = 95322151);
	pJunkcode = 23898648818796;
	pJunkcode = 19643233115939;
	if (pJunkcode = 2672513281);
	pJunkcode = 163111165523435;
	pJunkcode = 10453168717951;
	if (pJunkcode = 1969430709);
	pJunkcode = 2790164385969;
	pJunkcode = 103823228215065;
	if (pJunkcode = 23023701);
	pJunkcode = 6135129764952;
	pJunkcode = 22680976111486;
	if (pJunkcode = 1358218419);
	pJunkcode = 19152557426543;
	pJunkcode = 44232034522817;
	if (pJunkcode = 2044920264);
	pJunkcode = 27311646127223;
	pJunkcode = 16662238632792;
	if (pJunkcode = 461818607);
	pJunkcode = 27073011015302;
	pJunkcode = 18210288009023;
	if (pJunkcode = 279328391);
	pJunkcode = 2506771899064;
	pJunkcode = 239821051322388;
	if (pJunkcode = 238264757);
	pJunkcode = 2992791415385;
	pJunkcode = 52771375332665;
	if (pJunkcode = 2119823903);
	pJunkcode = 115371535528844;
	pJunkcode = 235471353029958;
	if (pJunkcode = 170489298);
	pJunkcode = 4533167218535;
	pJunkcode = 779725836212;
	if (pJunkcode = 1731319036);
	pJunkcode = 206625685900;
	pJunkcode = 27612946623139;
	if (pJunkcode = 1287613011);
	pJunkcode = 16396121970;
	pJunkcode = 132221769913781;
	if (pJunkcode = 120317389);
	pJunkcode = 5810289857314;
	pJunkcode = 39481001025232;
	if (pJunkcode = 2844831046);
	pJunkcode = 177322974030779;
	pJunkcode = 75331194231168;
	if (pJunkcode = 226771629);
	pJunkcode = 15903132427095;
	pJunkcode = 274025467378;
	if (pJunkcode = 80052326);
	pJunkcode = 322791379532643;
	pJunkcode = 28488691017402;
	if (pJunkcode = 1154419514);
	pJunkcode = 2902134854114;
	pJunkcode = 545797897343;
	if (pJunkcode = 235956642);
	pJunkcode = 32216118531306;
	pJunkcode = 222591355730762;
	if (pJunkcode = 110857760);
	pJunkcode = 22511288918438;
	pJunkcode = 264001557018922;
	if (pJunkcode = 1702722983);
	pJunkcode = 119681784819603;
	pJunkcode = 277562677213875;
	if (pJunkcode = 183099134);
	pJunkcode = 89002432224883;
	pJunkcode = 193461447612426;
	if (pJunkcode = 57615552);
	pJunkcode = 103132220729085;
	pJunkcode = 4962947510810;
	if (pJunkcode = 2081829087);
	pJunkcode = 81741422122651;
	pJunkcode = 41022593820691;
	if (pJunkcode = 2830419788);
	pJunkcode = 16170239473050;
	pJunkcode = 296912948323718;
	if (pJunkcode = 89923473);
	pJunkcode = 18630196786654;
	pJunkcode = 133363079928490;
	if (pJunkcode = 355931767);
	pJunkcode = 5470619130011;
	pJunkcode = 3105030838538;
	if (pJunkcode = 516317328);
	pJunkcode = 27620223154381;
	pJunkcode = 14756817025780;
	if (pJunkcode = 1074028687);
	pJunkcode = 107811152320113;
	pJunkcode = 29403513219323;
	if (pJunkcode = 1756127051);
	pJunkcode = 156502429814457;
	pJunkcode = 29897507028182;
	if (pJunkcode = 2448822111);
	pJunkcode = 27104313854140;
	pJunkcode = 153392667913807;
	if (pJunkcode = 2902415341);
	pJunkcode = 26009327810740;
	pJunkcode = 23522944231925;
	if (pJunkcode = 1208512918);
	pJunkcode = 15969265686543;
	pJunkcode = 312221446323259;
	if (pJunkcode = 87849988);
	pJunkcode = 50253118111950;
	pJunkcode = 22414197921559;
	if (pJunkcode = 308411777);
	pJunkcode = 78321322016761;
	pJunkcode = 278333114916356;
	if (pJunkcode = 677826045);
	pJunkcode = 27733254020233;
	pJunkcode = 47771651321504;
	if (pJunkcode = 2786926859);
	pJunkcode = 78691779526092;
	pJunkcode = 15922250359966;
	if (pJunkcode = 2667120772);
	pJunkcode = 13323158325253;
	pJunkcode = 190243151921620;
	if (pJunkcode = 2345018787);
	pJunkcode = 753199331785;
	pJunkcode = 211503075424094;
	if (pJunkcode = 2995212423);
	pJunkcode = 11615227178291;
	pJunkcode = 76472126527066;
	if (pJunkcode = 139619413);
	pJunkcode = 168914768369;
	pJunkcode = 626595304059;
	if (pJunkcode = 55662419);
	pJunkcode = 230802885811877;
	pJunkcode = 24309192114934;
	if (pJunkcode = 1916321230);
	pJunkcode = 12228518410052;
	pJunkcode = 22657171164808;
	if (pJunkcode = 677828597);
	pJunkcode = 294401852212810;
	pJunkcode = 2494220696270;
	if (pJunkcode = 2035230620);
	pJunkcode = 294092367410981;
	pJunkcode = 14581128214795;
	if (pJunkcode = 2419721850);
	pJunkcode = 55681077224566;
	pJunkcode = 193022886323781;
	if (pJunkcode = 264522794);
	pJunkcode = 8650151367635;
	pJunkcode = 3401197489224;
	if (pJunkcode = 2264023214);
	pJunkcode = 218881553079;
	pJunkcode = 25916169278482;
	if (pJunkcode = 2189927815);
	pJunkcode = 20536640622928;
	pJunkcode = 9925132123301;
	if (pJunkcode = 107657743);
	pJunkcode = 19098995714688;
	pJunkcode = 27020187209544;
	if (pJunkcode = 3240220000);
	pJunkcode = 79721414511997;
	pJunkcode = 918477467174;
	if (pJunkcode = 123953290);
	pJunkcode = 88711437510849;
	pJunkcode = 21811171975406;
	if (pJunkcode = 220443936);
	pJunkcode = 196553255130138;
	pJunkcode = 16537336013650;
	if (pJunkcode = 508512683);
	pJunkcode = 124152453428843;
	pJunkcode = 141581406216552;
	if (pJunkcode = 164102198);
	pJunkcode = 17563210687530;
	pJunkcode = 294852086218668;
	if (pJunkcode = 225151441);
	pJunkcode = 318041066332032;
	pJunkcode = 314110027691;
	if (pJunkcode = 1734010286);
	pJunkcode = 121202317415468;
	pJunkcode = 1538476549017;
	if (pJunkcode = 2751716551);
	pJunkcode = 213032087812256;
	pJunkcode = 22163298078236;
	if (pJunkcode = 702717110);
	pJunkcode = 759230178323;
	pJunkcode = 30232566415583;
	if (pJunkcode = 1447810347);
	pJunkcode = 22537505826701;
	pJunkcode = 238641888231089;
	if (pJunkcode = 1764925465);
	pJunkcode = 47853143424238;
	pJunkcode = 9769243732755;
	if (pJunkcode = 1343024825);
	pJunkcode = 4746319265383;
	pJunkcode = 33972046130973;
	if (pJunkcode = 43916982);
	pJunkcode = 7936812725390;
	pJunkcode = 193371214319977;
	if (pJunkcode = 2861415520);
	pJunkcode = 327241462517391;
	pJunkcode = 2792760821527;
	if (pJunkcode = 1338220906);
	pJunkcode = 2601113212390;
	pJunkcode = 122122415125623;
	if (pJunkcode = 98073051);
	pJunkcode = 87682610212838;
	pJunkcode = 177391118217474;
	if (pJunkcode = 219505200);
	pJunkcode = 12669310951141;
	pJunkcode = 13928298765778;
	if (pJunkcode = 2025828072);
	pJunkcode = 44542468323566;
	pJunkcode = 104302223022341;
	if (pJunkcode = 825626407);
	pJunkcode = 273582371615870;
	pJunkcode = 116821550627487;
	if (pJunkcode = 114087908);
	pJunkcode = 259256213399;
	pJunkcode = 32133225116164;
}


void Interfaces::Initialise()
{
	//Get function pointers to the CreateInterface function of each module
	EngineFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::Engine, "CreateInterface");
	ClientFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::Client, "CreateInterface");
	VGUI2Factory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::VGUI2, "CreateInterface");
	VGUISurfaceFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::VGUISurface, "CreateInterface");
	MatFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::Material, "CreateInterface");
	PhysFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::VPhysics, "CreateInterface");
	StdFactory = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::Stdlib, "CreateInterface");
	InputSystemPointer = (CreateInterface_t)GetProcAddress((HMODULE)Utilities::Memory::WaitOnModuleHandle("inputsystem.dll"), "CreateInterface");
	DataCaching = (CreateInterface_t)GetProcAddress((HMODULE)Offsets::Modules::DataCaches, "CreateInterface");

	//Get the interface names regardless of their version number by scanning for each string
	char* CHLClientInterfaceName = (char*)Utilities::Memory::FindTextPattern("client.dll", "VClient0");
	char* VGUI2PanelsInterfaceName = (char*)Utilities::Memory::FindTextPattern("vgui2.dll", "VGUI_Panel0");
	char* VGUISurfaceInterfaceName = (char*)Utilities::Memory::FindTextPattern("vguimatsurface.dll", "VGUI_Surface0");
	char* EntityListInterfaceName = (char*)Utilities::Memory::FindTextPattern("client.dll", "VClientEntityList0");
	char* EngineDebugThingInterface = (char*)Utilities::Memory::FindTextPattern("engine.dll", "VDebugOverlay0");
	char* EngineClientInterfaceName = (char*)Utilities::Memory::FindTextPattern("engine.dll","VEngineClient0");
	char* ClientPredictionInterface = (char*)Utilities::Memory::FindTextPattern("client.dll", "VClientPrediction0");
	char* MatSystemInterfaceName = (char*)Utilities::Memory::FindTextPattern("materialsystem.dll", "VMaterialSystem0");
	char* EngineRenderViewInterface = (char*)Utilities::Memory::FindTextPattern("engine.dll", "VEngineRenderView0");
	char* EngineModelRenderInterface = (char*)Utilities::Memory::FindTextPattern("engine.dll", "VEngineModel0");
	char* EngineModelInfoInterface = (char*)Utilities::Memory::FindTextPattern("engine.dll", "VModelInfoClient0");
	char* EngineTraceInterfaceName = (char*)Utilities::Memory::FindTextPattern("engine.dll", "EngineTraceClient0");
	char* PhysPropsInterfaces = (char*)Utilities::Memory::FindTextPattern("client.dll", "VPhysicsSurfaceProps0");
	char* VEngineCvarName = (char*)Utilities::Memory::FindTextPattern("engine.dll", "VEngineCvar00");
	char* pDataCache = (char*)Utilities::Memory::FindTextPattern("datacache.dll", "MDLCache00");
	fewisdlhgkjewfjkwegcjhwe();
	// Use the factory function pointers along with the interface versions to grab
	//  pointers to the interfaces
	Client = (IBaseClientDLL*)ClientFactory(CHLClientInterfaceName, NULL);
	Engine = (IVEngineClient*)EngineFactory(EngineClientInterfaceName, NULL);
	Panels = (IPanel*)VGUI2Factory(VGUI2PanelsInterfaceName, NULL);
	Surface = (ISurface*)VGUISurfaceFactory(VGUISurfaceInterfaceName, NULL);
	EntList = (IClientEntityList*)ClientFactory(EntityListInterfaceName, NULL);
	DebugOverlay = (IVDebugOverlay*)EngineFactory(EngineDebugThingInterface, NULL);
	Prediction = (DWORD*)ClientFactory(ClientPredictionInterface, NULL);
	g_Dlight = (IVEffects*)EngineFactory("VEngineEffects001", nullptr);
	MaterialSystem = (IMaterialSystem*)MatFactory(MatSystemInterfaceName, NULL);
	RenderView = (CVRenderView*)EngineFactory(EngineRenderViewInterface, NULL);
	ModelRender = (IVModelRender*)EngineFactory(EngineModelRenderInterface, NULL);
	ModelInfo = (CModelInfo*)EngineFactory(EngineModelInfoInterface, NULL);
	Trace = (IEngineTrace*)EngineFactory(EngineTraceInterfaceName, NULL);
	PhysProps = (IPhysicsSurfaceProps*)PhysFactory(PhysPropsInterfaces, NULL);
	CVar = (ICVar*)StdFactory(VEngineCvarName, NULL);
	ClientMode = **(IClientModeShared***)((*(DWORD**)Interfaces::Client)[10] + 0x5);
	EventManager = (IGameEventManager2*)EngineFactory("GAMEEVENTSMANAGER002", NULL);
	ModelCache = (IMDLCache*)DataCaching(pDataCache, NULL);
	// Get ClientMode Pointer
	DWORD p = Utilities::Memory::FindPattern("client.dll", (BYTE*)"\xC7\x05\x00\x00\x00\x00\x00\x00\x00\x00\xA8\x01\x75\x1A\x83\xC8\x01\xA3\x00\x00\x00\x00\xE8\x00\x00\x00\x00\x68\x00\x00\x00\x00\xE8\x00\x00\x00\x00\x83\xC4\x04\xA1\x00\x00\x00\x00\xB9\x00\x00\x00\x00\x56", "xx????????xxxxxxxx????x????x????x????xxxx????x????x");
	InputSystem = (IInputSystem*)InputSystemPointer("InputSystemVersion001", NULL);
	ChatElement = FindHudElement<CHudChat>("CHudChat");
	g_pViewRenderBeams = *(IViewRenderBeams**)(GameUtils::FindPattern1("client.dll", "B9 ? ? ? ? A1 ? ? ? ? FF 10 A1 ? ? ? ? B9") + 1);
	m_pGlowObjManager = *(CGlowObjectManager**)(GameUtils::FindPattern1("client.dll", "0F 11 05 ? ? ? ? 83 C8 01") + 3);
	g_ClientState = **(CClientState***)(GameUtils::FindPattern1("engine.dll", "A1 ?? ?? ?? ?? 8B 80 ?? ?? ?? ?? C3") + 1);


	fewisdlhgkjewfjkwegcjhwe();
	// Search through the first entry of the Client VTable
	// The initializer contains a pointer to the 'GlobalsVariables' Table
	fewisdlhgkjewfjkwegcjhwe();
	Globals = **(CGlobalVarsBase***)((*(DWORD**)Interfaces::Client)[0] + 0x1B); //psilent fix
	fewisdlhgkjewfjkwegcjhwe();
	PDWORD pdwClientVMT = *(PDWORD*)Client;
	pInput = *(CInput**)((*(DWORD**)Client)[15] + 0x1);

	//lagComp = new LagCompensation;
	//lagComp->initLagRecord();
	fewisdlhgkjewfjkwegcjhwe();
	Utilities::Log("Interfaces Ready");
}

// Namespace to contain all the valve interfaces
namespace Interfaces
{
	IBaseClientDLL* Client;
	IVEngineClient* Engine;
	IPanel* Panels;
	IClientEntityList* EntList;
	IVEffects* g_Dlight;
	ISurface* Surface;
	IVDebugOverlay* DebugOverlay;
	IClientModeShared* ClientMode;
	CGlobalVarsBase *Globals;
	DWORD *Prediction;
	IMaterialSystem* MaterialSystem;
	CVRenderView* RenderView;
	IVModelRender* ModelRender;
	CModelInfo* ModelInfo;
	IGameEventManager2 *EventManager;
	IEngineTrace* Trace;
	IPhysicsSurfaceProps* PhysProps;
	ICVar *CVar;
	IInputSystem* InputSystem;
	CInput* pInput;
	IMDLCache* ModelCache;
	IGameMovement* GameMovement;
	IMoveHelper* MoveHelper;
	IPrediction* Prediction1;
	CHudChat* ChatElement;
	IViewRenderBeams* g_pViewRenderBeams;
	CGlowObjectManager* m_pGlowObjManager;
	CClientState* g_ClientState;
};







































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class hrcnyqz {
public:
	int wdcnmrpdhllq;
	string fkisc;
	hrcnyqz();
	string yybwravkvfdofqye(double rhvjcqdwec);
	void bhnkcvfnxuscfcjhliskeinc(int qihevadgkkq, bool pvdxyqnbjauo, string btuirhv, string ezwxckygcesm, string einnokv, bool wxoxvbkrznm, int duujunzq, int kubkc);
	bool qpwhqwreldhgneponyeheiscv(string bjgoq, string tksaooyrg, string pdoggc, string lkvhaodgarw, bool aaehzaotzhhaum, int whujthcesqbnvs, int hkwtifofwms, bool jhplwfid);
	string jcensgobjrrfpypxhqgvgzg(string hnlltjc, double notbg, double qfizwzdkdmaxo, bool ouprasovdqlhan, string jilejnkcdfdlrtb, string fmdtrhv, bool mdgmeaj, string hrneegvuua, double jpkdgabzko, double rgcopw);
	double nokzfaubtvneafxcadzx(string jltmjvwihsjaly);
	string mrkkcyyepwrruzlmj(bool shjxdllrlhcr, bool othnxxineyn, string tmdcp, double guthlb);
	void ejnlptwbdsusfixkukukb(int glpgfzaed, string rsgft, int dfbzvciwehuti);
	int fzrcqpgsbwwfggpbvtzfboh(int ogjweiq, double jfsjwfpjoxqf, string aedxaplglnafc, int jerwqeweenqnq, string sgcsdxw, bool evpnrhpmux, int jkvwwbhasa);
	bool dokaorjcqqywrq(int acycjdj, double hbmlpogj, bool tnmtcaqjdw, bool trlke, bool mcwtrns, string stpwfqmgagu, double jbnkj, bool becbjaptvefjwtu, bool llpiywu, bool krcrphqyljfsf);

protected:
	bool khgxqrpggjhq;
	string nntrmebhwedqhg;
	int qdkcheqcqtkaqsd;
	bool gsufpjgblwuksz;

	bool jwqchhdzworzkubwitcvrjk(bool idddtkmts, bool orqlynmhx, int yggkqezg, int frgchvf, int cvrirzcusf, string frvbrpcb, string yfxfrcio, bool fcxjf, bool reigvvcdmnvjccm, string xzlbpytm);
	int izltnrazel(bool htdsmv, string bjbiqaw, string cspdhd, double leqersauysmu);
	double hbxgmzwkzyymifwslo(bool jmcrtmlfnaenguz, double zpvgij, int misppq, bool ykbcvfgcuozt, bool bfvorvcek);
	double mcwwzhirbom(bool bznohxuc, int viiwjiej, string prrpeumgef, string pyjbxoce);
	int txtgixxxmehugm(double puyso, int nvmhlokk);
	bool rjkeftmxcuwfzxzcue(double nrhfaapfvq, string kpapdxtjghcyeki, double qkwthlalkbqisbp);

private:
	int pwqjlcluwumg;
	double eudkx;
	string motmgj;
	int nohzeyh;

	void pxlhrzqammihgllxbsmubqhnk(string lofeviwk, bool oziktwbga, double qhuldbu, bool yrpjkhuiilp, double bjbcndijbdoq, string oqyofne, int bjsziyggojfx, bool lrkucn, int fpyfezqtq);
	void etbjhscmfhbyih(int lzvudkqhypbmu, bool rtcpuwcmpn);
	string ynexleuzdnfzraz(int xssuget, string ujldpvrhr, bool bukyfwljgokkw);
	string tujthrdfteong(int umsxdxbjt, bool extjiax, bool qvethjyp, int ujriutuapswo, int aodnn, string tcsxrk, bool abiosxfg, bool nnxwbyt);
	int yndhrorxyji(string rzqpywoa, int qiwaltvdqvdmkj);
	int veyvtrekodrzeqnuqycl(int czmnrzvuabe, double fdddvpi);
	string snyrbmjgcuoggiieqe(double fafwmfdvfmb, bool fethldrgpnarg, int mlvbwj);

};


void hrcnyqz::pxlhrzqammihgllxbsmubqhnk(string lofeviwk, bool oziktwbga, double qhuldbu, bool yrpjkhuiilp, double bjbcndijbdoq, string oqyofne, int bjsziyggojfx, bool lrkucn, int fpyfezqtq) {
	bool rbsgn = false;
	string caqnfmbgj = "vbtlxzskeeabrjdcrj";
	double zyqvmiwftjlms = 24500;
	int yxnfoykoazwl = 2262;
	if (24500 == 24500) {
		int nqbua;
		for (nqbua = 4; nqbua > 0; nqbua--) {
			continue;
		}
	}
	if (2262 != 2262) {
		int utueccurn;
		for (utueccurn = 19; utueccurn > 0; utueccurn--) {
			continue;
		}
	}

}

void hrcnyqz::etbjhscmfhbyih(int lzvudkqhypbmu, bool rtcpuwcmpn) {
	bool qaext = false;
	double eufthxqhkyavy = 55884;
	double qlixtpgzwse = 5161;
	if (55884 == 55884) {
		int slblup;
		for (slblup = 36; slblup > 0; slblup--) {
			continue;
		}
	}

}

string hrcnyqz::ynexleuzdnfzraz(int xssuget, string ujldpvrhr, bool bukyfwljgokkw) {
	double cgyalbucnpv = 16552;
	bool fggfcsubupglhp = false;
	double fgdch = 2987;
	if (2987 == 2987) {
		int wdovmh;
		for (wdovmh = 50; wdovmh > 0; wdovmh--) {
			continue;
		}
	}
	if (16552 == 16552) {
		int yxssrin;
		for (yxssrin = 32; yxssrin > 0; yxssrin--) {
			continue;
		}
	}
	if (false == false) {
		int trhxpsz;
		for (trhxpsz = 95; trhxpsz > 0; trhxpsz--) {
			continue;
		}
	}
	if (16552 == 16552) {
		int skfb;
		for (skfb = 51; skfb > 0; skfb--) {
			continue;
		}
	}
	if (16552 != 16552) {
		int gccwqjz;
		for (gccwqjz = 1; gccwqjz > 0; gccwqjz--) {
			continue;
		}
	}
	return string("vsoepdfeoeufg");
}

string hrcnyqz::tujthrdfteong(int umsxdxbjt, bool extjiax, bool qvethjyp, int ujriutuapswo, int aodnn, string tcsxrk, bool abiosxfg, bool nnxwbyt) {
	double ntzfeaakrtu = 17318;
	int dxtnufkiufsd = 283;
	bool toxkjcvnsaupvkg = true;
	string gqajntkmsprmb = "oqysosvzonxkominep";
	string sdlcdbclcr = "eehrtwxlopmxpawbidesullfwnmcyppyapyqxqnrehkfwqrfohdvhyvqtlcdghhuyrzrtafkmjueaqiqsvqsyfg";
	if (string("oqysosvzonxkominep") == string("oqysosvzonxkominep")) {
		int khkbxv;
		for (khkbxv = 96; khkbxv > 0; khkbxv--) {
			continue;
		}
	}
	if (string("eehrtwxlopmxpawbidesullfwnmcyppyapyqxqnrehkfwqrfohdvhyvqtlcdghhuyrzrtafkmjueaqiqsvqsyfg") == string("eehrtwxlopmxpawbidesullfwnmcyppyapyqxqnrehkfwqrfohdvhyvqtlcdghhuyrzrtafkmjueaqiqsvqsyfg")) {
		int mrlbn;
		for (mrlbn = 92; mrlbn > 0; mrlbn--) {
			continue;
		}
	}
	if (17318 == 17318) {
		int kl;
		for (kl = 31; kl > 0; kl--) {
			continue;
		}
	}
	return string("uwjdgww");
}

int hrcnyqz::yndhrorxyji(string rzqpywoa, int qiwaltvdqvdmkj) {
	bool qklsdqnseackknu = false;
	int peentwjwa = 591;
	string nsseyrrhrt = "vzeehjwz";
	bool mktmtyzynlb = true;
	string rujjgvfsf = "lktiwwhpawyspdmlcwejmktolbcyihwxpwm";
	if (591 == 591) {
		int uobvlybes;
		for (uobvlybes = 28; uobvlybes > 0; uobvlybes--) {
			continue;
		}
	}
	if (591 == 591) {
		int dbvjb;
		for (dbvjb = 33; dbvjb > 0; dbvjb--) {
			continue;
		}
	}
	if (string("vzeehjwz") == string("vzeehjwz")) {
		int drflhomje;
		for (drflhomje = 79; drflhomje > 0; drflhomje--) {
			continue;
		}
	}
	return 68524;
}

int hrcnyqz::veyvtrekodrzeqnuqycl(int czmnrzvuabe, double fdddvpi) {
	int blzpwcvmm = 7247;
	string nxrej = "znyhzxmobwasiccgdtndqzwhwvgukibzdtbu";
	int uwcasmvbwwd = 5687;
	string ledii = "ebstsevcdiskgakkvxhghscgpdvfbkqawnoobslpdrhoblpzccynvxx";
	int zdsywzojjiuprs = 5481;
	if (5687 != 5687) {
		int lbptu;
		for (lbptu = 0; lbptu > 0; lbptu--) {
			continue;
		}
	}
	return 80908;
}

string hrcnyqz::snyrbmjgcuoggiieqe(double fafwmfdvfmb, bool fethldrgpnarg, int mlvbwj) {
	string pwvayinak = "stdozzuhzcipmqycgamshqgyaqfqfouydqduofahijsu";
	double sqliysi = 30210;
	string remsahdhr = "hxuvvmwjugzbyvqpjxkatqolduyxofpzwijvhozyxtasmngqycyevfhwjnqcgkhkybnwmtwjijotcvuqyfmxrzf";
	int fdutwnujpgsh = 3865;
	int yrwzcfxxa = 4406;
	bool izbymvok = false;
	double wdxooaufdggoakc = 21284;
	int mtdzu = 571;
	double pexqiuwns = 7584;
	if (30210 != 30210) {
		int zzupluhwxj;
		for (zzupluhwxj = 41; zzupluhwxj > 0; zzupluhwxj--) {
			continue;
		}
	}
	if (7584 == 7584) {
		int eibsgmtz;
		for (eibsgmtz = 10; eibsgmtz > 0; eibsgmtz--) {
			continue;
		}
	}
	return string("rtxzvdmnp");
}

bool hrcnyqz::jwqchhdzworzkubwitcvrjk(bool idddtkmts, bool orqlynmhx, int yggkqezg, int frgchvf, int cvrirzcusf, string frvbrpcb, string yfxfrcio, bool fcxjf, bool reigvvcdmnvjccm, string xzlbpytm) {
	bool fwxhqccoznnmsol = true;
	double bivxqvcgjiu = 462;
	int vraazbucou = 3510;
	int kvyeinudmec = 594;
	double btdcq = 17499;
	string wkkyvuflllfx = "gbrygdkcocdjaimwbjaornpeomridteaqglzexlwoscjdgkuzyldkytnrdppwxmdvnnbndfshagzgp";
	int cxuzf = 1648;
	return true;
}

int hrcnyqz::izltnrazel(bool htdsmv, string bjbiqaw, string cspdhd, double leqersauysmu) {
	int usnyoxyjtti = 2432;
	bool hfzzal = true;
	int pjrxygcyihbwqkd = 333;
	double uamjfuqzuzffbng = 19428;
	double xdrykdyyh = 68081;
	bool ribmfa = true;
	bool aicyxqxsnkr = false;
	int bpfcktuqy = 4351;
	if (true != true) {
		int qxt;
		for (qxt = 5; qxt > 0; qxt--) {
			continue;
		}
	}
	if (19428 == 19428) {
		int vcfpkj;
		for (vcfpkj = 28; vcfpkj > 0; vcfpkj--) {
			continue;
		}
	}
	if (false == false) {
		int dukazbhak;
		for (dukazbhak = 75; dukazbhak > 0; dukazbhak--) {
			continue;
		}
	}
	return 95241;
}

double hrcnyqz::hbxgmzwkzyymifwslo(bool jmcrtmlfnaenguz, double zpvgij, int misppq, bool ykbcvfgcuozt, bool bfvorvcek) {
	int fcquzvubz = 2915;
	string qobakfwwl = "xqujbpkrnivuocsfkbumdmjyyofxcbljlgiofylvpewfegupfaowupjugcxqmgvmlfjftwmj";
	string aermvwaewlckth = "jnngnnatqoimqvyjzpngipgljxfczvjoyxsdciiciitxtepybaos";
	if (string("jnngnnatqoimqvyjzpngipgljxfczvjoyxsdciiciitxtepybaos") != string("jnngnnatqoimqvyjzpngipgljxfczvjoyxsdciiciitxtepybaos")) {
		int uavvxvfkps;
		for (uavvxvfkps = 47; uavvxvfkps > 0; uavvxvfkps--) {
			continue;
		}
	}
	if (string("jnngnnatqoimqvyjzpngipgljxfczvjoyxsdciiciitxtepybaos") == string("jnngnnatqoimqvyjzpngipgljxfczvjoyxsdciiciitxtepybaos")) {
		int yirpvwxl;
		for (yirpvwxl = 71; yirpvwxl > 0; yirpvwxl--) {
			continue;
		}
	}
	if (2915 != 2915) {
		int xhxrntwpkn;
		for (xhxrntwpkn = 35; xhxrntwpkn > 0; xhxrntwpkn--) {
			continue;
		}
	}
	if (2915 != 2915) {
		int gamyhl;
		for (gamyhl = 91; gamyhl > 0; gamyhl--) {
			continue;
		}
	}
	return 83707;
}

double hrcnyqz::mcwwzhirbom(bool bznohxuc, int viiwjiej, string prrpeumgef, string pyjbxoce) {
	return 94364;
}

int hrcnyqz::txtgixxxmehugm(double puyso, int nvmhlokk) {
	string rieklh = "aiblqgjbsukzreidfzkdktdxftzpovwrnzangmnetflptdbfauwtytykhjibnikwjtpwlx";
	int btdbjnaftii = 4016;
	string iohtngwpjgqu = "jrcoijsdfsqyfhbllgpynppfodowyrqvbhx";
	int jlfljrvixp = 1195;
	double akjltxqm = 12583;
	double klapsvnns = 34344;
	string jcbsooe = "ewvbsrjjwzczpnnguygpjvfuszuobkllkwmktjfdrmnsgbsauegyhprguiwcoxxetgacnfvkrr";
	bool cxdcig = true;
	double tvqfineshjytbo = 18808;
	string smorsaihoiqpkyb = "kbbxqapqqjczsouzyd";
	if (18808 != 18808) {
		int rujndhf;
		for (rujndhf = 16; rujndhf > 0; rujndhf--) {
			continue;
		}
	}
	if (1195 == 1195) {
		int ipwfdxadzr;
		for (ipwfdxadzr = 80; ipwfdxadzr > 0; ipwfdxadzr--) {
			continue;
		}
	}
	if (string("ewvbsrjjwzczpnnguygpjvfuszuobkllkwmktjfdrmnsgbsauegyhprguiwcoxxetgacnfvkrr") == string("ewvbsrjjwzczpnnguygpjvfuszuobkllkwmktjfdrmnsgbsauegyhprguiwcoxxetgacnfvkrr")) {
		int nm;
		for (nm = 36; nm > 0; nm--) {
			continue;
		}
	}
	return 14573;
}

bool hrcnyqz::rjkeftmxcuwfzxzcue(double nrhfaapfvq, string kpapdxtjghcyeki, double qkwthlalkbqisbp) {
	int eeyjum = 2271;
	double wwnqsmd = 59880;
	double hsvvqggzmnv = 16591;
	string zrynlg = "krfpojuqdyel";
	double hbcqdsjkyc = 14980;
	bool oqpxyqpdfp = true;
	int ngpvnnipspciekt = 181;
	if (string("krfpojuqdyel") != string("krfpojuqdyel")) {
		int qlaxmht;
		for (qlaxmht = 16; qlaxmht > 0; qlaxmht--) {
			continue;
		}
	}
	if (59880 == 59880) {
		int lwhmddq;
		for (lwhmddq = 55; lwhmddq > 0; lwhmddq--) {
			continue;
		}
	}
	if (181 != 181) {
		int hhu;
		for (hhu = 14; hhu > 0; hhu--) {
			continue;
		}
	}
	return false;
}

string hrcnyqz::yybwravkvfdofqye(double rhvjcqdwec) {
	string nownmrxdvzpxe = "wpxorrgddibqfzsskafiaosqywqdklmbdwupkuochylhxveexgsjfmjkzr";
	string jxybhsit = "h";
	bool wjcer = true;
	double cfjkevgrtoaap = 36471;
	int wgvuco = 234;
	bool mlyejif = false;
	int oijkzahtiqfzgo = 1317;
	double lomtsiwvmwocng = 25748;
	string qxafnueg = "mrzphrkxduxfedjnenqkeislhwjanqbksliftlnopgasqgfiw";
	if (true == true) {
		int cgrxztiorw;
		for (cgrxztiorw = 6; cgrxztiorw > 0; cgrxztiorw--) {
			continue;
		}
	}
	if (25748 != 25748) {
		int qcbcc;
		for (qcbcc = 49; qcbcc > 0; qcbcc--) {
			continue;
		}
	}
	if (true == true) {
		int hjynx;
		for (hjynx = 48; hjynx > 0; hjynx--) {
			continue;
		}
	}
	if (36471 == 36471) {
		int efqmowoqdv;
		for (efqmowoqdv = 96; efqmowoqdv > 0; efqmowoqdv--) {
			continue;
		}
	}
	if (string("wpxorrgddibqfzsskafiaosqywqdklmbdwupkuochylhxveexgsjfmjkzr") != string("wpxorrgddibqfzsskafiaosqywqdklmbdwupkuochylhxveexgsjfmjkzr")) {
		int mbieyerh;
		for (mbieyerh = 57; mbieyerh > 0; mbieyerh--) {
			continue;
		}
	}
	return string("pvzbldefn");
}

void hrcnyqz::bhnkcvfnxuscfcjhliskeinc(int qihevadgkkq, bool pvdxyqnbjauo, string btuirhv, string ezwxckygcesm, string einnokv, bool wxoxvbkrznm, int duujunzq, int kubkc) {
	string zhiwhu = "kdkwmfjdvfpnhyvcurgsegkfkrbhvnmxpefxfczditm";
	int xjgtl = 2938;
	double ugnvdz = 57804;
	bool rshanugysy = false;
	bool zgdjzqedjskue = true;
	int vsdzzosvdiei = 941;
	string assqwtl = "vhvycihjqdiols";
	string taqdjoeecmlzlt = "ompxioqxdokhviacvhlybtmnaedndpxgx";
	bool vttqwlwvcddu = false;
	string hffscpxcepepke = "tryttsuxvarnrzod";
	if (string("kdkwmfjdvfpnhyvcurgsegkfkrbhvnmxpefxfczditm") == string("kdkwmfjdvfpnhyvcurgsegkfkrbhvnmxpefxfczditm")) {
		int uixbfmnio;
		for (uixbfmnio = 12; uixbfmnio > 0; uixbfmnio--) {
			continue;
		}
	}

}

bool hrcnyqz::qpwhqwreldhgneponyeheiscv(string bjgoq, string tksaooyrg, string pdoggc, string lkvhaodgarw, bool aaehzaotzhhaum, int whujthcesqbnvs, int hkwtifofwms, bool jhplwfid) {
	bool zaerspq = true;
	double vmvpkouixc = 8432;
	double oaeybkvrnioibaf = 21074;
	int cioodqeoixanhi = 808;
	string yziwcjpubk = "hsmdfijxdledrmeghwxyslklistvzqkquxunuoeqpsga";
	double eqbkdnfnedceike = 3845;
	double oorxqbesdhlqe = 15347;
	if (15347 == 15347) {
		int xsqhy;
		for (xsqhy = 66; xsqhy > 0; xsqhy--) {
			continue;
		}
	}
	return false;
}

string hrcnyqz::jcensgobjrrfpypxhqgvgzg(string hnlltjc, double notbg, double qfizwzdkdmaxo, bool ouprasovdqlhan, string jilejnkcdfdlrtb, string fmdtrhv, bool mdgmeaj, string hrneegvuua, double jpkdgabzko, double rgcopw) {
	int xhmtpun = 1505;
	bool wexvddshmzlrlwq = true;
	int ytsqmslrgqyzs = 8074;
	int sscvvncxzneeonl = 1621;
	bool yyhpf = true;
	bool fvtaxjybdau = true;
	double vxwkcpyf = 9816;
	string pyqxawm = "salecwascsmnzxgncemeaoeinzvjhculzfte";
	int obbmoojqbkhy = 703;
	if (8074 != 8074) {
		int ukzeuoj;
		for (ukzeuoj = 40; ukzeuoj > 0; ukzeuoj--) {
			continue;
		}
	}
	if (1621 == 1621) {
		int qe;
		for (qe = 13; qe > 0; qe--) {
			continue;
		}
	}
	return string("bkfngclkbysnnqrc");
}

double hrcnyqz::nokzfaubtvneafxcadzx(string jltmjvwihsjaly) {
	string yhaok = "wwgmxaozwrfudfkienuotkhqbddbuexxmneab";
	bool ghyafkk = false;
	string gsppetukwx = "yqqtjxsqocwqwxuwzaxndjbihwzvrrscspemqfkowojaimiuzskstqxqtaszojzlgvxflbivplsvlj";
	if (string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab") != string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab")) {
		int bkj;
		for (bkj = 37; bkj > 0; bkj--) {
			continue;
		}
	}
	if (string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab") != string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab")) {
		int klcgsegy;
		for (klcgsegy = 97; klcgsegy > 0; klcgsegy--) {
			continue;
		}
	}
	if (string("yqqtjxsqocwqwxuwzaxndjbihwzvrrscspemqfkowojaimiuzskstqxqtaszojzlgvxflbivplsvlj") != string("yqqtjxsqocwqwxuwzaxndjbihwzvrrscspemqfkowojaimiuzskstqxqtaszojzlgvxflbivplsvlj")) {
		int zdlf;
		for (zdlf = 88; zdlf > 0; zdlf--) {
			continue;
		}
	}
	if (string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab") == string("wwgmxaozwrfudfkienuotkhqbddbuexxmneab")) {
		int exx;
		for (exx = 1; exx > 0; exx--) {
			continue;
		}
	}
	return 38763;
}

string hrcnyqz::mrkkcyyepwrruzlmj(bool shjxdllrlhcr, bool othnxxineyn, string tmdcp, double guthlb) {
	return string("pjnbpglihcradu");
}

void hrcnyqz::ejnlptwbdsusfixkukukb(int glpgfzaed, string rsgft, int dfbzvciwehuti) {
	string dmludqgluzxkk = "fgim";
	string mfbdekebwhdswab = "czgjmfrvgjqhyfadhkcfghfrgiljdrpvhggontwnxaplgqbzvidtfojlskddolehefvkwpsrmxcubegqgkynkpselhvgjpldyx";
	bool wbusc = true;
	string kjbkwoaeeqrv = "jlvclgjdgxqnklgxowlyncqzzoaynptlxrlbolnalnedtxduqquflwectpvlluetskxlotyuj";
	double mklqmb = 28597;
	bool ceull = false;
	bool imywd = true;
	if (string("jlvclgjdgxqnklgxowlyncqzzoaynptlxrlbolnalnedtxduqquflwectpvlluetskxlotyuj") != string("jlvclgjdgxqnklgxowlyncqzzoaynptlxrlbolnalnedtxduqquflwectpvlluetskxlotyuj")) {
		int ivipdxwa;
		for (ivipdxwa = 43; ivipdxwa > 0; ivipdxwa--) {
			continue;
		}
	}
	if (string("czgjmfrvgjqhyfadhkcfghfrgiljdrpvhggontwnxaplgqbzvidtfojlskddolehefvkwpsrmxcubegqgkynkpselhvgjpldyx") != string("czgjmfrvgjqhyfadhkcfghfrgiljdrpvhggontwnxaplgqbzvidtfojlskddolehefvkwpsrmxcubegqgkynkpselhvgjpldyx")) {
		int oxhzgrrbq;
		for (oxhzgrrbq = 75; oxhzgrrbq > 0; oxhzgrrbq--) {
			continue;
		}
	}
	if (string("fgim") != string("fgim")) {
		int qoiyml;
		for (qoiyml = 95; qoiyml > 0; qoiyml--) {
			continue;
		}
	}

}

int hrcnyqz::fzrcqpgsbwwfggpbvtzfboh(int ogjweiq, double jfsjwfpjoxqf, string aedxaplglnafc, int jerwqeweenqnq, string sgcsdxw, bool evpnrhpmux, int jkvwwbhasa) {
	bool vvrpgar = true;
	double sklvgungjcjhyp = 7359;
	double ynqmpgsohn = 28413;
	double gynoivecl = 6288;
	bool pppzn = false;
	bool ctgmomamswnmx = false;
	bool aujuumvxfitxky = false;
	return 99130;
}

bool hrcnyqz::dokaorjcqqywrq(int acycjdj, double hbmlpogj, bool tnmtcaqjdw, bool trlke, bool mcwtrns, string stpwfqmgagu, double jbnkj, bool becbjaptvefjwtu, bool llpiywu, bool krcrphqyljfsf) {
	double farka = 43356;
	return false;
}

hrcnyqz::hrcnyqz() {
	this->yybwravkvfdofqye(13684);
	this->bhnkcvfnxuscfcjhliskeinc(5753, true, string("kqxjskxrfepezzvyfkzpfswfcjzyyihdcnbengkdfafhucficqoavisamqqvjdsbtepfej"), string("unsn"), string("tluhvrpfoff"), false, 414, 4298);
	this->qpwhqwreldhgneponyeheiscv(string("byvbbicdutkqeolqitbkgelulcoixtitwldajuevhcyqxq"), string("urvastzlkrxndmyspfzouebfoizhmbhyxkysbtxxkegodoyfrbnwzlicyvhuvkldzlsxdvntmypwuci"), string("jxnfkehzhsyxdvjgitvmbwbqkxovektiipuqgpkmlvqqajpwxunyven"), string("jybktoknkv"), true, 2306, 1753, true);
	this->jcensgobjrrfpypxhqgvgzg(string("xedbzwjbtpqld"), 8569, 37536, true, string("vsxornwxjnewmtsieoljhopfmrkdalrbjgzxomxfztttlisjmxxz"), string("grjfguzwemypojjoznqkztgtmmlbwevshflgwckhgwyhrpfrpbxwhffofikzwlajxxfonodmxyfxcqsgehqfhzadectfkhodlm"), false, string("lpibtlwhcsvpirdtthpplteqkutwzokugijluswclinviqzgpzfrlsgqvoilbvpgh"), 26650, 31476);
	this->nokzfaubtvneafxcadzx(string("lucfoqbbsyzpklrumjknjfwdngfyfblaivwpkdeqjcqzndzwgtpzwypudzsioftfzzkrisdowlmfeyvfcnthnypjllsrfpaqij"));
	this->mrkkcyyepwrruzlmj(false, true, string("unemtfysecqdimdipfydycjwnqpgkojgvwrsnmbiopolzuzensgxizgkhlyzdnjhqnmzck"), 1941);
	this->ejnlptwbdsusfixkukukb(226, string("czlcwranylcwouhgnjy"), 8587);
	this->fzrcqpgsbwwfggpbvtzfboh(7316, 28225, string("ppqmkaqny"), 1847, string("lmeabozxrpxszvhkwspoismbcvrnludwirhcdwuwfsvoilaytvazkvapxxnttxcybzdumvwflinvv"), false, 4489);
	this->dokaorjcqqywrq(323, 1576, true, true, true, string("dcpzastjqaeotklekgodmzecwhqwranuwvvwokxwykqlizwgbokbqkknkekvkknqsgoigbvnrxmpqrh"), 3627, true, true, true);
	this->jwqchhdzworzkubwitcvrjk(true, false, 3951, 636, 1527, string("mfjllhywolgmzfljqlnftaedgtaispjaxsf"), string("rahfahtcgtcfddr"), false, false, string("amafwmcavxdenlrujyxtahehqkujadedvwuwlxczgjopwegalaehhzckqovorwrrefxzaeara"));
	this->izltnrazel(true, string("vfvsjtotttvgnybjbstxwipftpypssaru"), string("adymcfjfqwqxgpgtgizqkgfayajwdlntyqmdoihnewxgnpwxermczdjmjhoqslgcusdqcpgkmwvwurfjxoozjlqzdiwzfbi"), 13959);
	this->hbxgmzwkzyymifwslo(false, 32252, 1431, true, true);
	this->mcwwzhirbom(false, 2183, string("gycjosfpfeuzzkzwzkkxtthbtbukteneiywtvkrinetkpkhttabpveulqzscywzxylxez"), string("nfqbxistwaaziuyqkogduiyefrevgdsvib"));
	this->txtgixxxmehugm(89717, 7062);
	this->rjkeftmxcuwfzxzcue(4599, string("jwxkdmjtfjnytdiyzbqvcpfoqzkjznkazlv"), 17589);
	this->pxlhrzqammihgllxbsmubqhnk(string("mpsdqxfuewkcoyvbmtqfnxgwkkuviswmtawowcqbowygshhruxeegsabnwfosrcysnjmjwgvhmwnwvfzgfiiapk"), true, 23832, false, 14760, string("wlkgecnqvkzainvqtjqaitdnpaklpesxrfuahqf"), 2761, false, 1815);
	this->etbjhscmfhbyih(38, true);
	this->ynexleuzdnfzraz(4866, string("vbshntkntdxadaoulkjubfwdmuimuzqahjeymoszawazbcntljxwckoyhzybaicirviestqmntgtyywihwzepvqvitk"), true);
	this->tujthrdfteong(6484, false, false, 612, 7817, string("fqwsxvkcsmzim"), false, false);
	this->yndhrorxyji(string("sjkqzgnhwxhdvzvhgsuyykpqszauycjvpwjimfjcgtqdrnkbcyanfetyikvcipnrbrmkcbaqd"), 3205);
	this->veyvtrekodrzeqnuqycl(1899, 27473);
	this->snyrbmjgcuoggiieqe(2042, true, 158);
}


















































































































































































































































