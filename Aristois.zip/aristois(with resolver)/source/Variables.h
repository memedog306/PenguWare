#pragma once
#include <set>
#include <map>
#include <unordered_map>

extern void RenderInterface();

struct skinInfo
{
	int seed = -1;
	int paintkit;
	std::string tagName;
};


struct Variables
{
	Variables()
	{

	}

	struct Ragebot_s
	{
		bool MainSwitch;
		bool 	Enabled;
		bool 	AutoFire;
		float 	FOV;
		bool 	Silent;
		bool AutoPistol;
		int KeyPress;
		bool AimStep;


		bool	EnabledAntiAim;
		int		Pitch;
		int		YawTrue;
		int		YawFake;
		int AirTaw;
		bool Freestading;
		bool LBYbreaker;
		bool AntiLBYBacktrack;
		int LBYbreakerDelta;
		bool	AtTarget;
		bool pitchzero;
		float SpinSpeed;
		bool	Edge;
		bool KnifeAA;
		bool FreezeCheck;


		bool FriendlyFire;
		int Selection;
		int ResolverTest; // old empty shit
		int		Hitbox;
		int		Hitscan;
		float Pointscale;
		bool Multipoint;
		float Multipoints;


		bool AntiRecoil;
		bool AutoWall;
		bool AutoStop;
		bool PositionAdjustment;
		bool PreferBodyAim;
		bool awpbodyaim;
		int baimifhp;
		bool aacorection;
		bool BacktrackRage;
		bool AutoScope;
		float MinimumDamage;
		bool Hitchance;
		float HitchanceAmount;
		bool Resolver; // old empty shit
		bool TestBacktracking;
		bool FakePing;
		float fakepingvalue;
		bool AimbotResolver; // resolver
		bool NoSpreadResolver; // resolver
		bool FakeWalkResolver; // resolver
		int	OverrideNoobs; // resolver
		bool FakeLagFix;
		bool FakeLag;
		int Packets;
		bool playerlist;
		int BAIMkey;
		int OverrideKey;
		int miscsubtab = 0;
		int miscsubtab1 = 0;
		bool AimbotEnable;
	} Ragebot;

	struct
	{
		bool Enabled;
		int Knife;
		int gloves;
		int KnifeSkin;
		int AK47Skin;
		int GalilSkin;
		int M4A1SSkin;
		int M4A4Skin;
		int AUGSkin;
		int FAMASSkin;
		int AWPSkin;
		int SSG08Skin;
		int SCAR20Skin;
		int P90Skin;
		int Mp7Skin;
		int NovaSkin;
		int UMP45Skin;
		int GlockSkin;
		int SawedSkin;
		int USPSkin;
		int MagSkin;
		int XmSkin;
		int DeagleSkin;
		int DualSkin;
		int FiveSkin;
		int RevolverSkin;
		int Mac10Skin;
		int tec9Skin;
		int Cz75Skin;
		int NegevSkin;
		int M249Skin;
		int Mp9Skin;
		int P2000Skin;
		int BizonSkin;
		int Sg553Skin;
		int P250Skin;
		int G3sg1Skin;
		bool activeknife;
	} Skinchanger;

	struct
	{
		bool MainSwitch;
		bool backtrackkurwalegit;
		int enable;
		int ticks;
		struct
		{
			bool 	Enabled;
			bool AutoPistol;
		//	bool	Resolver;

		} Aimbot;


		int MainKey = 1;
		float MainSmooth;
		float Mainfov;
		float main_random_smooth;
		float main_recoil_min;
		float main_recoil_max;
		float main_randomized_angle;



		int PistolKey = 6;
		float Pistolfov;
		float PistolSmooth;
		float pistol_random_smooth;
		float pistol_recoil_min;
		float pistol_recoil_max;
		float pistol_randomized_angle;



		int SniperKey = 6;
		float Sniperfov;
		float SniperSmooth;
		float sniper_random_smooth;
		float sniper_recoil_min;
		float sniper_recoil_max;
		float sniper_randomized_angle;


		struct
		{
			bool	Enabled;
			float Delay;
			int Key = 6;
			float hitchance;
			struct
			{
				bool Head;
				bool Arms;
				bool Chest;
				bool Stomach;
				bool Legs;
			} Filter;

		} Triggerbot;

	} Legitbot;

	struct
	{
		bool 	Enabled;

		bool Box;
		bool BoxOutline;
		bool Self;
		bool Name;
		bool HP;
		bool HealthText;
		bool espoutline;
		bool Armor;
		bool Weapon;
		bool Ammo;
		bool Info;
		bool ResolverInfo;
		bool Chams;
		bool Skeleton;
		bool SnapLines;
		float snaplinescolor[3] = { 1.f, 0, 0 };
		float skeletoncolor[3] = { 1.f, 0, 0 };
		float armorcolor[3] = { 1.f, 0, 0 };
		float glowcolor[3] = { 1.f, 0, 0 };
		bool AimSpot;
		bool DLight;
		bool SpreadCrosshair;
		bool AARows;
		bool GrenadeESP;
		bool C4;
		int visualssubtab = 0;
		bool 	ESPEnable;
		bool ChamsEnemies;
		int ChamsType;
		int espmode;
		int esptype;
		int boxtypes;
		int weapontype;
		int espfont;
		bool ChamsTeam;
		bool LBYChams;
		bool SelfChams;
		bool FakeChams;
		bool ChamsTeamHidden;
		bool ChamsEnemiesHidden;
		int ThirdPersonKey;
		bool ThirdPersonTestwtf;
		bool ThirdPerson;
		int ThirdPersonType;
		float ChamsEnemiesHiddenColor[3] = { 1.f, 0, 0 };
		float ChamsEnemiesColor[3] = { 1.f, 0, 0 };
		float ChamsTeamColor[3] = { 1.f, 0, 0 };
		float ChamsTeamHiddenColor[3] = { 1.f, 0, 0 };
		float DMGIndicatorColor [3] = { 1.f, 0, 0 };
		float GlowColor[3] = { 1.f, 0, 0 };
		bool TeamMates;
		bool Hitmarker;
		bool DMGIndicator;
		bool LBYStatus;
		bool BacktrackDots;
		bool Glow;
		bool GlowFullBloom;
		int glowopa;
		float GlowValue;
		bool NoVisualRecoil;
		int Hands;
		int Weapons;
		float FOVChanger;
		float viewmodelChanger;
		bool NoFlash;
		bool NoSmoke;
		bool PostProc;
		bool NoSmokeWire;
		bool Time;

		bool money;
		float TracersCT[3] = { 1.f, 0, 0 };
		float TracersTT[3] = { 1.f, 0, 0 };
		bool C4World;
		bool WeaponsWorld;
		bool Radar;
		bool Spectators;
		bool Comprank;
		bool noscopeborder;
		bool GrenadePrediction;

		struct
		{
			bool Players;
			bool EnemyOnly;
		} Filter;

		struct
		{
			bool Players;
			bool EnemyOnly;
			bool Weapons;
		} GlowFilter;

	} Visuals;

	struct
	{
		bool silentstealer;
		int ragequit;

		bool 	Bhop;
		bool LastTickDef;
		int miscsubtab = 0;
		bool Logs;
		bool Nightmode;
		bool IgnoreScope;
		bool SafeMode;
		bool AsusProps;
		bool ChatSpam;
		float AsusPropsValue;
		bool BulletTracers;
		float FovOverride;
		float ChatSpamSpeed;
		bool	Airstuck;
		int 	AutoStrafe;
		float MinVel;
		int		AirStuckKey;
		int		FakeWalkKey;
		int lagexploit;
		int lagexploitmultiplier = 3;
		float lagexploitvalue;
		float FakeLag;
		bool AdaptiveFakeLag;
		bool nightMode;
		int NameSpammer;
		int Clantagspammer;
		bool NameChangerFix;
		bool NoName;
		int		ChatSpamMode;
		bool ClantagChanger;
		int ClanTagSpeed;
		bool syncclantag;
		bool SpecList;
		bool FPSBooster;
		int SkyBoxChanger;
		bool namespam;
		int spammer;
		int AutoDefuse;
		bool Spam;
		bool isRecording;
		bool isReplaying;
		bool RecordPath;
		bool AutoAccept;
		bool SpoofConfirmation = false;
		bool animatedclantag = false;
		int customtab;

		bool niggatest;


	} Misc;

	struct
	{
		bool	Opened = false;
		int 	Key;
		bool	Ragebot = false;
		bool	Legitbot = false;
		bool	Visual = false;
		bool	Misc = false;
		int		ConfigFile = 0;
		int		Theme = 0;
		bool	Colors = false;
		int currentWeapon;
	} Menu;
};

extern Variables g_Options;