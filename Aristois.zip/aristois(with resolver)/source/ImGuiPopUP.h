#pragma once

namespace Anime
{
	void Popup(const char* text, int onScreenMils, bool* done);
}
