/*
Syn's Payhake Framework for Insanity & Razor
*/

#define _CRT_SECURE_NO_WARNINGS

#include "Hacks.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "Variables.h"
#include "ESP.h"
#include "Visuals.h"
#include "RageBot.h"
#include "MiscHacks.h"
#include "Utilities.h"
#include "gamefunctions.h"
CVisuals Visuals;
CMiscHacks MiscHacks;
CRageBot RageBot;



// Initialise and register ALL hackmanager hacks in here nigga
void Hacks::SetupHacks()
{
	Visuals.Init();
	MiscHacks.Init();
	RageBot.Init();
	hackManager.RegisterHack(&Visuals);
	hackManager.RegisterHack(&MiscHacks);
	hackManager.RegisterHack(&RageBot);
	hackManager.Ready();
}

using PlaySoundFn = void(__stdcall*)(const char*);
extern PlaySoundFn oPlaySound;

namespace G // Global Stuff
{
	extern bool			Aimbotting;
	extern bool			InAntiAim;
	extern bool			Return;
	extern CUserCmd*	UserCmd;
	extern HMODULE		Dll;
	extern HWND			Window;
	extern bool			PressedKeys[256];
	extern bool			d3dinit;
	extern float		FOV;
	extern int			ChamMode;
	extern bool			SendPacket;
	extern int			BestTarget;
}

namespace game
{
	CGameFunctions functions;
}


IClientEntity* HackManager::localplayer()
{
	return Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
}

PlaySoundFn oPlaySound;
void __stdcall Hooked__PlaySoundCSGO(const char* fileName)
{

}


BYTE bMoveData[0x200];
void Prediction(CUserCmd* pCmd, IClientEntity* LocalPlayer)
{
	if (Interfaces::MoveHelper && g_Options.Ragebot.AimbotEnable && g_Options.Ragebot.PositionAdjustment && LocalPlayer->IsAlive())
	{
		float curtime = Interfaces::Globals->curtime;
		float frametime = Interfaces::Globals->frametime;
		int iFlags = LocalPlayer->GetFlags();

		Interfaces::Globals->curtime = (float)LocalPlayer->GetTickBase() * Interfaces::Globals->interval_per_tick;
		Interfaces::Globals->frametime = Interfaces::Globals->interval_per_tick;

		Interfaces::MoveHelper->SetHost(LocalPlayer);

		Interfaces::Prediction1->SetupMove(LocalPlayer, pCmd, nullptr, bMoveData);
		Interfaces::GameMovement->ProcessMovement(LocalPlayer, bMoveData);
		Interfaces::Prediction1->FinishMove(LocalPlayer, pCmd, bMoveData);

		Interfaces::MoveHelper->SetHost(0);

		Interfaces::Globals->curtime = curtime;
		Interfaces::Globals->frametime = frametime;
	}
}

// Only gets called in game, use a seperate draw UI call for menus in the hook
void Hacks::DrawHacks()
{
	IClientEntity *pLocal = hackManager.pLocal();

	void Hooked__PlaySoundCSGO(const char* fileName);


	// Check the master visuals switch, just to be sure
	if (!g_Options.Visuals.ESPEnable)
		return;

	if (g_Options.Visuals.Comprank && GetAsyncKeyState(VK_TAB))
	{

		GameUtils::ServerRankRevealAll();
	}

	hackManager.Draw();
	//--------------------------------
		
}

// Game Cmd Changes
void Hacks::MoveHacks(CUserCmd *pCmd, bool &bSendPacket)
{
	Vector origView = pCmd->viewangles;
	IClientEntity *pLocal = hackManager.pLocal();
	Prediction(pCmd, pLocal);
	hackManager.Move(pCmd, bSendPacket);
	// ------------------------------

	// Put it in here so it's applied AFTER the aimbot



	if (g_Options.Misc.AirStuckKey > 0 && GetAsyncKeyState(g_Options.Misc.AirStuckKey))
	{
		if (!(pCmd->buttons & IN_ATTACK))
		{
			pCmd->tick_count = INT_MAX;//0xFFFFF or 16777216
		}
	}	

}

//---------------------------------------------------------------------//
HackManager hackManager;

// Register a new hack
void HackManager::RegisterHack(CHack* hake)
{
	Hacks.push_back(hake);
	hake->Init();
}

// Draw all the hakes
void HackManager::Draw()
{
	if (!IsReady)
		return;

	// Grab the local player for drawing related hacks
	pLocalInstance = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalInstance) return;

	for (auto &hack : Hacks)
	{
		hack->Draw();
	}
}

// Handle all the move hakes
void HackManager::Move(CUserCmd *pCmd,bool &bSendPacket)
{
	if (!IsReady)
		return;

	// Grab the local player for move related hacks
	pLocalInstance = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalInstance) return;

	for (auto &hack : Hacks)
	{
		hack->Move(pCmd,bSendPacket); // 
	}
}

//---------------------------------------------------------------------//
// Other Utils and shit

// Saves hacks needing to call a bunch of virtuals to get the instance
// Saves on cycles and file size. Recycle your plastic kids
IClientEntity* HackManager::pLocal()
{
	return pLocalInstance;
}

// Makes sure none of the hacks are called in their 
// hooks until they are completely ready for use
void HackManager::Ready()
{
	IsReady = true;
}







































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class yveemco {
public:
	double xpxtlbgbgoprijm;
	int jjudq;
	string tjwccgssydzyzxh;
	yveemco();
	double rpgtqgauxeyhlm();
	int thsjmaqxigdswqsdhxma(string sjlbplbbfvinwpo, bool wxxztfjvjum, int xwhahco, bool zghuwkeclvp, bool bqigexgazrzu, double ywwdkhwh, double lktubrygrzyneaj, string gjpchy);
	bool sywcggcjcdf(int blteanc, bool hdywyusb, int scjmxowl, int xpkmvq, bool wzlur);
	string zboxhwtvdcjuqfi(bool uthsqwnlpkfgytj, bool cpnerwgzuhs);
	void nvrdwsapir(bool aizlbs, bool dwnbglzcd, string qqwbsauznfrxixg, int bhpidirfga);
	int tqrqkqlrzj(double fnkikxwr, string etfoikq, string pmiuazbt, bool wctgkrmbnlh, int pjiqkevlnshwpo, string boonmldt, double dnwdfagze, int paicpqhrcet);
	bool fkyojfgfstwnkqb(string osdmmtlf, double pwyihlwyf, double tlvzxvynyalyoy, string szxnhepbrpl, double lmvwfoj, bool wqicedujzptul);
	int amsaelflyxsnysgpcf(bool iehszbizbjne, int ixpcpnmkvnwl, double pfokxgrcqlmxiy, int jyyipxbmobtgwd, string qiovouhernpbd, double nmkitcswlvizmy, string kkqpxpnrbkmvxpb);
	string iitortfhfbkf(double lujakee, string mqcuccrbch);

protected:
	double viyuvpxdlh;

	int bejdorjepbgohbnxxkxdwf(bool qyczwp, string uelshhpffk, int mcpjflsnehtn, bool mvecsnmklepsmjq, bool qmhyxutlen, string jbjfjuhspuvb);
	int xywwudtzavtzzouaebwuttk(int nogscpwbdefnbm, double ybqkceeumezjsny, bool qmlcgskfyhz);
	void wldjfbwhudrfendmoam(bool gadjislahdgjdxh, int btpkqk, double tpqpfy, int yfckjwtqkagoa);
	bool unczabbilfh(double rsfjcjsbfyoho, bool qworopl, int vxxob, string tpwim, int zjkchomtcah, int vtllihxyzhjkzh, string knttwsz);
	int uqdazovxhmlewoyvw(bool jyukozhqha, bool lwkhub, int krumaaulqjbtiqo, bool wzlxx, double itlfjvo, double sttaflekfcl, double vvzzpv, string ibnqsadetk);
	double alkkqcvxyoayoo(string jsjjgklcbkbkwx, double piploihrwchn, string deijapjn, bool hoovpdbkotmyot, string kuakoagdhmv, bool ectiphjuigbqhnz, int kbwhqo, int wnzlkomaiqpvcro);

private:
	bool fkpefg;
	int vvlidicag;
	bool qnjas;
	double bxnxhfwkcjsygtt;

	bool asilmjmyndgkzzhej(double mdookdvjnzoac, int nkcoagcgcwkmo, string hlofqx, bool fyqmjayjbrsmdwp, string gppfd, string ldrwel, string reyjlvozmnaxyq, int nmpkuoaixgioar, double uawesmkjs);
	void arcrgjfekytsygfx(string tmaudwnavc);
	bool ijfwjaeobla(int pjvsdej, bool hbgvibzbqmmcvb, double mepinzoe, string ttbqoigdpcdwk);
	string jpeetiltubpgq(bool nxekyoqg, int clzbhchuwspuo, string ynrflapoh);
	bool qgakfptyxcjohvjlsxdmvsnaf(string gjuyigp, int bcfjpx, int htwalsdkbxlz, int vpyypcyoutnmtdd, int djfksyplackchfb, int mohzgsfgasihod, int mzlqghgdhmp);
	int uitklpzvqynqixera(double icmng, int ypluhtc, double soncfvdxkjaotx);
	void ptbticembcdxavmgekbldh(string lgkbigv);
	double wmxrbwnzalo(double ljgfrbfui, double xavarfb, bool rxnop, string kbikdxlwy);
	void xzufbvyrjtddcndztgoz();

};


bool yveemco::asilmjmyndgkzzhej(double mdookdvjnzoac, int nkcoagcgcwkmo, string hlofqx, bool fyqmjayjbrsmdwp, string gppfd, string ldrwel, string reyjlvozmnaxyq, int nmpkuoaixgioar, double uawesmkjs) {
	double buucsiu = 4406;
	bool jaoysjhq = false;
	return false;
}

void yveemco::arcrgjfekytsygfx(string tmaudwnavc) {
	int itcshnljqpq = 1656;

}

bool yveemco::ijfwjaeobla(int pjvsdej, bool hbgvibzbqmmcvb, double mepinzoe, string ttbqoigdpcdwk) {
	int aazbsdlzy = 3392;
	return true;
}

string yveemco::jpeetiltubpgq(bool nxekyoqg, int clzbhchuwspuo, string ynrflapoh) {
	int cevvpv = 216;
	bool zhhyhrt = true;
	bool vpfyt = true;
	bool jcmnjljqdyu = false;
	if (false != false) {
		int xi;
		for (xi = 100; xi > 0; xi--) {
			continue;
		}
	}
	if (true == true) {
		int rp;
		for (rp = 19; rp > 0; rp--) {
			continue;
		}
	}
	if (216 != 216) {
		int ht;
		for (ht = 91; ht > 0; ht--) {
			continue;
		}
	}
	return string("dyhkrwiqrpj");
}

bool yveemco::qgakfptyxcjohvjlsxdmvsnaf(string gjuyigp, int bcfjpx, int htwalsdkbxlz, int vpyypcyoutnmtdd, int djfksyplackchfb, int mohzgsfgasihod, int mzlqghgdhmp) {
	bool rnyhey = false;
	double ptgvgqkktbyvyq = 30967;
	int tpatogvpuk = 2177;
	double sqrkbyigayltcp = 51073;
	double lxixpmtka = 32068;
	int gxqwpcjejnget = 2004;
	double xcoki = 43214;
	bool ltbsrtcdndhuin = true;
	if (43214 == 43214) {
		int oukm;
		for (oukm = 66; oukm > 0; oukm--) {
			continue;
		}
	}
	if (30967 != 30967) {
		int pdobfjo;
		for (pdobfjo = 80; pdobfjo > 0; pdobfjo--) {
			continue;
		}
	}
	if (2004 != 2004) {
		int dctoqktzm;
		for (dctoqktzm = 30; dctoqktzm > 0; dctoqktzm--) {
			continue;
		}
	}
	return false;
}

int yveemco::uitklpzvqynqixera(double icmng, int ypluhtc, double soncfvdxkjaotx) {
	int zlloab = 3247;
	bool rohxfawtqbc = false;
	string biotqzubpvofv = "iosmpqjyxpewppb";
	int pasjgtttnbum = 1078;
	int zdgpuq = 50;
	int ewmpwxmo = 503;
	bool jqextat = true;
	string trkvdu = "mboezitfizrrmuqveimakpstnreylgnjioxccmguwqyajsoyzvrseaptzffxytjheslgcjxsvdjke";
	if (1078 == 1078) {
		int wvyqsecls;
		for (wvyqsecls = 99; wvyqsecls > 0; wvyqsecls--) {
			continue;
		}
	}
	if (false != false) {
		int pc;
		for (pc = 39; pc > 0; pc--) {
			continue;
		}
	}
	if (503 == 503) {
		int mqdrysuhn;
		for (mqdrysuhn = 46; mqdrysuhn > 0; mqdrysuhn--) {
			continue;
		}
	}
	if (3247 != 3247) {
		int nwvsxfiz;
		for (nwvsxfiz = 53; nwvsxfiz > 0; nwvsxfiz--) {
			continue;
		}
	}
	if (3247 != 3247) {
		int dpmtnd;
		for (dpmtnd = 56; dpmtnd > 0; dpmtnd--) {
			continue;
		}
	}
	return 39358;
}

void yveemco::ptbticembcdxavmgekbldh(string lgkbigv) {
	string xidkgyelberwi = "tnd";
	bool gqjmxyegn = true;
	double polmz = 15180;
	string quttn = "ddylsrlxpbypnhncnhbdzvkmhbzifzzrswsiriibwrqesazzdehmnprfjztfybitfwzxkkqocrbzsdsfcljdm";
	bool fbhgtlvizltswki = true;
	double hlgfk = 19139;
	bool atvowf = false;

}

double yveemco::wmxrbwnzalo(double ljgfrbfui, double xavarfb, bool rxnop, string kbikdxlwy) {
	string jladjjvyh = "xgzlwdykybyxnavhjgiofdgugmoipwtjostxekiduhfzp";
	string vlwqlw = "jufeasqhkpzgkpnfbbisljkai";
	double uwudjiu = 40923;
	string afkrgdejjnatqsb = "lpjjovegwakoypzzcxknfflqzcmwayrjsshlgfxpjfuocmyezylvqsglvnmhlrdjmguqahhxmybeuemtmgel";
	bool wouvruonekv = false;
	bool byyqlbtzfrkfc = false;
	bool iolgz = true;
	string dhzxulhon = "omqolphswrawnfij";
	string flijznrmiv = "qhsttbyhwzabqnxuvnknwsztlvttjsmkofuroyiscptsjjpyiradoillsdqkcrdczyjdmzfxdrmralblbberdyhkoxngshonro";
	if (true != true) {
		int hqzc;
		for (hqzc = 22; hqzc > 0; hqzc--) {
			continue;
		}
	}
	if (string("jufeasqhkpzgkpnfbbisljkai") != string("jufeasqhkpzgkpnfbbisljkai")) {
		int djxamzvz;
		for (djxamzvz = 29; djxamzvz > 0; djxamzvz--) {
			continue;
		}
	}
	if (40923 == 40923) {
		int jib;
		for (jib = 46; jib > 0; jib--) {
			continue;
		}
	}
	if (string("jufeasqhkpzgkpnfbbisljkai") != string("jufeasqhkpzgkpnfbbisljkai")) {
		int wieyq;
		for (wieyq = 29; wieyq > 0; wieyq--) {
			continue;
		}
	}
	return 35194;
}

void yveemco::xzufbvyrjtddcndztgoz() {
	double osctvyntzjzw = 22169;
	bool hdjkssn = false;
	bool fffrhqp = false;
	int eytqgywondcotkh = 1918;
	double jvdxacwzveht = 15539;
	if (15539 == 15539) {
		int jgumyos;
		for (jgumyos = 42; jgumyos > 0; jgumyos--) {
			continue;
		}
	}
	if (1918 == 1918) {
		int fogalbkye;
		for (fogalbkye = 35; fogalbkye > 0; fogalbkye--) {
			continue;
		}
	}
	if (22169 != 22169) {
		int kkiciyc;
		for (kkiciyc = 6; kkiciyc > 0; kkiciyc--) {
			continue;
		}
	}
	if (false != false) {
		int cvixkbx;
		for (cvixkbx = 49; cvixkbx > 0; cvixkbx--) {
			continue;
		}
	}
	if (1918 == 1918) {
		int whnhdharbx;
		for (whnhdharbx = 61; whnhdharbx > 0; whnhdharbx--) {
			continue;
		}
	}

}

int yveemco::bejdorjepbgohbnxxkxdwf(bool qyczwp, string uelshhpffk, int mcpjflsnehtn, bool mvecsnmklepsmjq, bool qmhyxutlen, string jbjfjuhspuvb) {
	string qtrorkskrnrwi = "qvjrffnxdxlnzcnzspryieaoleyqhivtyhghfvxujcpgcqswixnnhrmzhznguvbmkuetjsczmojxyaeetivymosuaavteityad";
	bool ndspfgv = true;
	string ajdiq = "ezhyfxkoffhibcpuysirqxgtcyalvxlugortbeadzyszyfakfidoqsbcbmohdajtg";
	string clfbzpqppdvb = "eq";
	return 390;
}

int yveemco::xywwudtzavtzzouaebwuttk(int nogscpwbdefnbm, double ybqkceeumezjsny, bool qmlcgskfyhz) {
	return 82453;
}

void yveemco::wldjfbwhudrfendmoam(bool gadjislahdgjdxh, int btpkqk, double tpqpfy, int yfckjwtqkagoa) {
	double pnkvgh = 21778;
	double mlexpz = 681;
	bool pnzupvs = false;
	bool dhginxpvbil = false;
	int hjjbssgcespugx = 137;
	int qezikvn = 3042;
	double hvypvpusxcfru = 38525;
	if (3042 == 3042) {
		int wyk;
		for (wyk = 8; wyk > 0; wyk--) {
			continue;
		}
	}
	if (false == false) {
		int desm;
		for (desm = 80; desm > 0; desm--) {
			continue;
		}
	}
	if (38525 != 38525) {
		int irurkpjni;
		for (irurkpjni = 43; irurkpjni > 0; irurkpjni--) {
			continue;
		}
	}

}

bool yveemco::unczabbilfh(double rsfjcjsbfyoho, bool qworopl, int vxxob, string tpwim, int zjkchomtcah, int vtllihxyzhjkzh, string knttwsz) {
	int nnarsjme = 1599;
	int nxdhv = 154;
	string yzhtbcp = "zhzodvkpagngauivsdfsbfpzfvjnhefovvgvwwb";
	double imczmoeuegdvlsl = 13499;
	int zarndb = 2108;
	if (2108 == 2108) {
		int huqzdxbhq;
		for (huqzdxbhq = 67; huqzdxbhq > 0; huqzdxbhq--) {
			continue;
		}
	}
	if (2108 == 2108) {
		int hcbfkpyi;
		for (hcbfkpyi = 77; hcbfkpyi > 0; hcbfkpyi--) {
			continue;
		}
	}
	if (1599 == 1599) {
		int iqyd;
		for (iqyd = 8; iqyd > 0; iqyd--) {
			continue;
		}
	}
	if (string("zhzodvkpagngauivsdfsbfpzfvjnhefovvgvwwb") == string("zhzodvkpagngauivsdfsbfpzfvjnhefovvgvwwb")) {
		int ttedbunxeg;
		for (ttedbunxeg = 38; ttedbunxeg > 0; ttedbunxeg--) {
			continue;
		}
	}
	if (13499 == 13499) {
		int xbmiafs;
		for (xbmiafs = 51; xbmiafs > 0; xbmiafs--) {
			continue;
		}
	}
	return false;
}

int yveemco::uqdazovxhmlewoyvw(bool jyukozhqha, bool lwkhub, int krumaaulqjbtiqo, bool wzlxx, double itlfjvo, double sttaflekfcl, double vvzzpv, string ibnqsadetk) {
	bool lylywmfxgguewj = false;
	int cltmdhq = 1078;
	double utkuofg = 53295;
	string xgvpip = "kpkidmakagkjmbwgpmlwduhvadddcexccieutjrpcwbojtzbocbqtzsrsrwrzviqtbbctwozcmqoawnugi";
	string iextpulgjtrcdw = "nuxolwhuowqjzssrwrqcqma";
	string ekiahgxwxfw = "szyzxnxamotpxxwedqurrpcvmlcdrncrfvclmcg";
	if (string("kpkidmakagkjmbwgpmlwduhvadddcexccieutjrpcwbojtzbocbqtzsrsrwrzviqtbbctwozcmqoawnugi") == string("kpkidmakagkjmbwgpmlwduhvadddcexccieutjrpcwbojtzbocbqtzsrsrwrzviqtbbctwozcmqoawnugi")) {
		int yaselcnivt;
		for (yaselcnivt = 82; yaselcnivt > 0; yaselcnivt--) {
			continue;
		}
	}
	if (false != false) {
		int evhwprkvca;
		for (evhwprkvca = 27; evhwprkvca > 0; evhwprkvca--) {
			continue;
		}
	}
	if (string("szyzxnxamotpxxwedqurrpcvmlcdrncrfvclmcg") == string("szyzxnxamotpxxwedqurrpcvmlcdrncrfvclmcg")) {
		int tkbenare;
		for (tkbenare = 9; tkbenare > 0; tkbenare--) {
			continue;
		}
	}
	if (string("nuxolwhuowqjzssrwrqcqma") == string("nuxolwhuowqjzssrwrqcqma")) {
		int oechea;
		for (oechea = 1; oechea > 0; oechea--) {
			continue;
		}
	}
	return 87585;
}

double yveemco::alkkqcvxyoayoo(string jsjjgklcbkbkwx, double piploihrwchn, string deijapjn, bool hoovpdbkotmyot, string kuakoagdhmv, bool ectiphjuigbqhnz, int kbwhqo, int wnzlkomaiqpvcro) {
	int cpjuiyity = 4985;
	bool zdstlsjjeritoem = true;
	bool gfsao = false;
	if (false != false) {
		int oe;
		for (oe = 78; oe > 0; oe--) {
			continue;
		}
	}
	if (4985 == 4985) {
		int pkhanojuj;
		for (pkhanojuj = 78; pkhanojuj > 0; pkhanojuj--) {
			continue;
		}
	}
	if (true != true) {
		int bvmaq;
		for (bvmaq = 94; bvmaq > 0; bvmaq--) {
			continue;
		}
	}
	if (4985 == 4985) {
		int vptjjc;
		for (vptjjc = 11; vptjjc > 0; vptjjc--) {
			continue;
		}
	}
	if (true != true) {
		int lf;
		for (lf = 75; lf > 0; lf--) {
			continue;
		}
	}
	return 9139;
}

double yveemco::rpgtqgauxeyhlm() {
	bool gzearakycoehq = true;
	if (true != true) {
		int aueolbytqp;
		for (aueolbytqp = 42; aueolbytqp > 0; aueolbytqp--) {
			continue;
		}
	}
	if (true == true) {
		int rgexnxs;
		for (rgexnxs = 34; rgexnxs > 0; rgexnxs--) {
			continue;
		}
	}
	return 87134;
}

int yveemco::thsjmaqxigdswqsdhxma(string sjlbplbbfvinwpo, bool wxxztfjvjum, int xwhahco, bool zghuwkeclvp, bool bqigexgazrzu, double ywwdkhwh, double lktubrygrzyneaj, string gjpchy) {
	bool njxud = false;
	int jwnhpp = 90;
	double qryrthkm = 5441;
	bool hzswrdh = false;
	string pjuiggda = "gbyypyvjxwzuekpjkbyppfdlpvqgnvparinvolqstg";
	if (false == false) {
		int iljeld;
		for (iljeld = 81; iljeld > 0; iljeld--) {
			continue;
		}
	}
	if (string("gbyypyvjxwzuekpjkbyppfdlpvqgnvparinvolqstg") != string("gbyypyvjxwzuekpjkbyppfdlpvqgnvparinvolqstg")) {
		int rlzve;
		for (rlzve = 7; rlzve > 0; rlzve--) {
			continue;
		}
	}
	if (5441 != 5441) {
		int fgjnytyyq;
		for (fgjnytyyq = 35; fgjnytyyq > 0; fgjnytyyq--) {
			continue;
		}
	}
	if (string("gbyypyvjxwzuekpjkbyppfdlpvqgnvparinvolqstg") != string("gbyypyvjxwzuekpjkbyppfdlpvqgnvparinvolqstg")) {
		int ugege;
		for (ugege = 38; ugege > 0; ugege--) {
			continue;
		}
	}
	if (5441 == 5441) {
		int esiqsy;
		for (esiqsy = 8; esiqsy > 0; esiqsy--) {
			continue;
		}
	}
	return 47;
}

bool yveemco::sywcggcjcdf(int blteanc, bool hdywyusb, int scjmxowl, int xpkmvq, bool wzlur) {
	bool hzpki = false;
	int xaopxzsk = 1082;
	return false;
}

string yveemco::zboxhwtvdcjuqfi(bool uthsqwnlpkfgytj, bool cpnerwgzuhs) {
	string qijyotvhqiwtkc = "zeshvbzlslvsjvikyewjupthoulcbczbajxhkaeahsspzyvzwbjrhrzoveduducapiqrkzoiohdxa";
	bool mzlnpvvpchm = true;
	bool djmkp = false;
	bool syeyybnqcahpth = true;
	bool oeydodpjxhmizq = true;
	string sgzedwuibauf = "hrzhfaglcrbssjswkqwjjchrfysyllo";
	double snnugxrqhfzbd = 34047;
	bool jlhgv = true;
	bool vuoygdswnixtiq = false;
	if (true == true) {
		int jxeesd;
		for (jxeesd = 66; jxeesd > 0; jxeesd--) {
			continue;
		}
	}
	if (string("zeshvbzlslvsjvikyewjupthoulcbczbajxhkaeahsspzyvzwbjrhrzoveduducapiqrkzoiohdxa") != string("zeshvbzlslvsjvikyewjupthoulcbczbajxhkaeahsspzyvzwbjrhrzoveduducapiqrkzoiohdxa")) {
		int nhkkcvdbin;
		for (nhkkcvdbin = 71; nhkkcvdbin > 0; nhkkcvdbin--) {
			continue;
		}
	}
	return string("ckztxbn");
}

void yveemco::nvrdwsapir(bool aizlbs, bool dwnbglzcd, string qqwbsauznfrxixg, int bhpidirfga) {

}

int yveemco::tqrqkqlrzj(double fnkikxwr, string etfoikq, string pmiuazbt, bool wctgkrmbnlh, int pjiqkevlnshwpo, string boonmldt, double dnwdfagze, int paicpqhrcet) {
	int ohxtsnrzie = 30;
	bool xriri = false;
	string bydyuqxt = "bdltghedpedumfqlbcnngfqjvqpdpgjtataznpslnxm";
	double jqcoqhzh = 76027;
	int heznjoz = 3450;
	double amkrcdhwyk = 69069;
	string bqhtnpsalzatp = "lof";
	bool llwujmq = false;
	if (76027 == 76027) {
		int ywdjkhqz;
		for (ywdjkhqz = 72; ywdjkhqz > 0; ywdjkhqz--) {
			continue;
		}
	}
	if (3450 != 3450) {
		int hnhfppf;
		for (hnhfppf = 11; hnhfppf > 0; hnhfppf--) {
			continue;
		}
	}
	if (string("lof") != string("lof")) {
		int pahd;
		for (pahd = 95; pahd > 0; pahd--) {
			continue;
		}
	}
	if (false != false) {
		int rk;
		for (rk = 94; rk > 0; rk--) {
			continue;
		}
	}
	return 937;
}

bool yveemco::fkyojfgfstwnkqb(string osdmmtlf, double pwyihlwyf, double tlvzxvynyalyoy, string szxnhepbrpl, double lmvwfoj, bool wqicedujzptul) {
	int nxlohpwqrjgd = 8324;
	int gbbftaisobnuv = 613;
	int kdfyeyegbtzxpxm = 8782;
	if (8782 != 8782) {
		int ikecfqpql;
		for (ikecfqpql = 22; ikecfqpql > 0; ikecfqpql--) {
			continue;
		}
	}
	if (8324 != 8324) {
		int gjwx;
		for (gjwx = 25; gjwx > 0; gjwx--) {
			continue;
		}
	}
	if (613 != 613) {
		int bckzywjeyd;
		for (bckzywjeyd = 62; bckzywjeyd > 0; bckzywjeyd--) {
			continue;
		}
	}
	if (8782 != 8782) {
		int hgzztjl;
		for (hgzztjl = 58; hgzztjl > 0; hgzztjl--) {
			continue;
		}
	}
	if (613 == 613) {
		int nixi;
		for (nixi = 14; nixi > 0; nixi--) {
			continue;
		}
	}
	return true;
}

int yveemco::amsaelflyxsnysgpcf(bool iehszbizbjne, int ixpcpnmkvnwl, double pfokxgrcqlmxiy, int jyyipxbmobtgwd, string qiovouhernpbd, double nmkitcswlvizmy, string kkqpxpnrbkmvxpb) {
	bool jumybbos = true;
	double skxeiqlmupmut = 7292;
	double smzxaeihntibjb = 28297;
	string wjzcdrng = "wrufldwmlcknskmhtrmxtbsapvrfoypelqesgikapuvrlaaeyzwcszvkxeeuqmikupkpbszfmpgz";
	bool wlrvokzryf = false;
	bool eiudw = true;
	string xdjlnwmiyqjidzi = "ctwrzdembdlomosulgglhglbzllygjlchswfg";
	if (true == true) {
		int egf;
		for (egf = 55; egf > 0; egf--) {
			continue;
		}
	}
	if (7292 == 7292) {
		int ois;
		for (ois = 98; ois > 0; ois--) {
			continue;
		}
	}
	if (string("wrufldwmlcknskmhtrmxtbsapvrfoypelqesgikapuvrlaaeyzwcszvkxeeuqmikupkpbszfmpgz") != string("wrufldwmlcknskmhtrmxtbsapvrfoypelqesgikapuvrlaaeyzwcszvkxeeuqmikupkpbszfmpgz")) {
		int cb;
		for (cb = 90; cb > 0; cb--) {
			continue;
		}
	}
	return 70296;
}

string yveemco::iitortfhfbkf(double lujakee, string mqcuccrbch) {
	string itbezufvzlochr = "kpalrlcxdhgixmxsdggqnykomfkeqfrmfvmrtlunhdp";
	int fiidkhi = 511;
	string tsrloaczzcdcy = "loejkrecklgllgdboqamrbifzlkpcsokvczpmlmvrowaodopvrllppgitbmhiplbpfxzyftwkygvydpoyahqjzjyjhbvmrkq";
	string occissrhupc = "vsldnmeeeccpqarvjfrotapoppbkaoktsqpxkezcwuzsqchczihutrsmdxqgjhtyubgqzifabtcvlqjefkjaihbx";
	double upsyy = 28180;
	if (511 == 511) {
		int xpbh;
		for (xpbh = 46; xpbh > 0; xpbh--) {
			continue;
		}
	}
	return string("");
}

yveemco::yveemco() {
	this->rpgtqgauxeyhlm();
	this->thsjmaqxigdswqsdhxma(string("irudwagvrlfxrdgcoqyieydjqzkwecebgghwtcgaafqhsgeuyvncjbexuotnzuargylgxzndszumr"), false, 1021, true, false, 20422, 50224, string("foqgyukkzeojsiuwrvuowzlcfftfkpnhtcqzowymcnawtfbhujdellvqaakjpcsxysvnzcxepfpsywwmszadlbgetavnfcn"));
	this->sywcggcjcdf(3749, false, 4409, 1820, true);
	this->zboxhwtvdcjuqfi(true, true);
	this->nvrdwsapir(false, false, string("opullgyskafjtggifbrpqylswgpxjyzufjndwuwcfjownjlggjxikaxgrnaqyrrypgqkpyinvdq"), 2847);
	this->tqrqkqlrzj(4972, string("lmedtircvclpamgpptliwxrxkmodkeihawaxglyxouosxhjgzwlyiephovjuixzuf"), string("qsdtdkeqdhokmgomvsieauxcqvrpdafdrcfq"), true, 5006, string("hnbyvphpfddyl"), 37543, 8151);
	this->fkyojfgfstwnkqb(string("wvfbgbkixgirwgednneuydlthhbebivojadixkkptuudxowihkrik"), 26247, 5498, string("hhecmmhbovulwwkkjoywwcpaeblhrcpivarsdcmxtpggfxjwkbceduirvhemtpkthfndbxeqdmbestokaqrxagtxhw"), 259, false);
	this->amsaelflyxsnysgpcf(false, 3454, 55264, 762, string("ncnqcfdcahcyzdffcptlfzweypewnibqyzbbopklrgdwkbgrcxpnnbvqdnwxtmlei"), 86007, string("xsqirzlfohqkowlbsvyfysjybbtejwgfbtqooqtpnlygmtmmmzzwgzfcqzgbxlvcbkqlutonnsrewngwk"));
	this->iitortfhfbkf(31291, string("bezqaiqcafvnafciovisngflydlauxhjgitzzanoswczudpylsjxftnipiillddjeeoamkuihoqlmlmvjkfzvxgcjxecpfsmkf"));
	this->bejdorjepbgohbnxxkxdwf(false, string("jkedcvuskildznhswsbnzdnrdlvzbqccbhehogvytgopfluygphomrkjdxvlnmdxjlaurd"), 1465, false, false, string("mxrvxhsqqqflolnekeliinpjgdsychsaczarfiyjogsylrctabwkqpbxdedwqclwbwxmofgyfsywdcriymhadbbksjvct"));
	this->xywwudtzavtzzouaebwuttk(1296, 17162, true);
	this->wldjfbwhudrfendmoam(true, 565, 7618, 1546);
	this->unczabbilfh(47195, false, 4095, string("fsvlqkvegfyeoqzgfvwowhydwjtbzqkywhsgwphrwsgtrrkqgfjgfnwmwthfxtekycqjovfymvrdal"), 5714, 6019, string("hefkgchrmakmgedvganvyiyeji"));
	this->uqdazovxhmlewoyvw(false, true, 1333, true, 43404, 13519, 16981, string("reqsnf"));
	this->alkkqcvxyoayoo(string("ircc"), 70385, string("qmjrcbohjfmqnojkcrdtqaowtqzmnpcenhguykzka"), false, string("jnicrlventkrzylnjitylqkuyezlmkvpimnpzweqgtupqmoayaeocwiwwadvmffjrektuubwsijewkppxdxnxu"), false, 6294, 6481);
	this->asilmjmyndgkzzhej(10069, 2483, string("dadblwmzhjdelfbopiszyvzmoibjbakwyolxgoexushezrzj"), true, string("krdawselxeeoqahvxfqquebcoeqymuziiziwxucwhlfrfruwcxl"), string("tbkngxutffptpfpipbyzxk"), string("mrulacfvgqpohgzgv"), 1588, 15285);
	this->arcrgjfekytsygfx(string("nnqmkymekdzomrxckwvbxohoqtxbubgswczrllusgzwbicix"));
	this->ijfwjaeobla(2063, true, 12260, string("mntc"));
	this->jpeetiltubpgq(false, 5881, string("tjgexnlffmldidabcqgwgnhauhpgxvtbnjnhhubsthzvzenjluqrduuovcyptkyprzcwvgbfopzwajcx"));
	this->qgakfptyxcjohvjlsxdmvsnaf(string("qbsekzbdeuiwkqttpsgrdjvpahohg"), 419, 4161, 4140, 730, 472, 1150);
	this->uitklpzvqynqixera(3871, 3580, 53833);
	this->ptbticembcdxavmgekbldh(string("gowzaigqrebfqyakqgqdmlxnpjeejbouehbbeemjj"));
	this->wmxrbwnzalo(22271, 49514, true, string("kepblknfhohfnzswxkzmeseqjfzcppzl"));
	this->xzufbvyrjtddcndztgoz();
}


















































































































































































































































