
#define _CRT_SECURE_NO_WARNINGS

#include "MiscHacks.h"
#include "Interfaces.h"
#include "RenderManager.h"
#include "Variables.h"
#include <time.h>


template<class T, class U>
inline T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;
	else if (in >= high)
		return high;
	else
		return in;
}

inline float bitsToFloat(unsigned long i)
{
	return *reinterpret_cast<float*>(&i);
}

inline float FloatNegate(float f)
{
	return bitsToFloat(FloatBits(f) ^ 0x80000000);
}

Vector AutoStrafeView;

void CMiscHacks::Init()
{
}

void CMiscHacks::Draw()
{
	if (g_Options.Misc.ChatSpam)
	{
		ChatSpamRegular();
	}


	// Any drawing	
	// Spams
	switch (g_Options.Misc.NameSpammer)
	{
	case 0:
		// No Chat Spam
		break;
	case 1:
		// Namestealer
		ChatSpamName();
		break;
	case 2:
		// Interwebz
		ChatSpamInterwebz();
		break;
	case 3:
		ChatSpamDisperseName();
		break;
	}
}

void CMiscHacks::RotateMovement(CUserCmd * pCmd, float rotation)
{
	rotation = DEG2RAD(rotation);
	float cosr, sinr;
	cosr = cos(rotation);
	sinr = sin(rotation);
	float forwardmove, sidemove;
	forwardmove = (cosr * pCmd->forwardmove) - (sinr * pCmd->sidemove);
	sidemove = (sinr * pCmd->forwardmove) - (cosr * pCmd->sidemove);
	pCmd->forwardmove = forwardmove;
	pCmd->sidemove = sidemove;
}


void CMiscHacks::Move(CUserCmd *pCmd, bool &bSendPacket)
{
	// Any Move Stuff
	// Bhop
	if (g_Options.Misc.Bhop)
	{
		AutoJump(pCmd);
	}
	// AutoStrafe
	Interfaces::Engine->GetViewAngles(AutoStrafeView);
	switch (g_Options.Misc.AutoStrafe)
	{
	case 0:
		// Off
		break;
	case 1:
		LegitStrafe(pCmd);
		break;
	case 2:
		RageStrafe(pCmd);
		break;
	}

	if (g_Options.Visuals.PostProc)
		PostProcces();


}

static __declspec(naked) void __cdecl Invoke_NET_SetConVar(void* pfn, const char* cvar, const char* value)
{
	__asm 
	{
		push    ebp
			mov     ebp, esp
			and     esp, 0FFFFFFF8h
			sub     esp, 44h
			push    ebx
			push    esi
			push    edi
			mov     edi, cvar
			mov     esi, value
			jmp     pfn
	}
}
void DECLSPEC_NOINLINE NET_SetConVar(const char* value, const char* cvar)
{
	static DWORD setaddr = Utilities::Memory::FindPattern("engine.dll", (PBYTE)"\x8D\x4C\x24\x1C\xE8\x00\x00\x00\x00\x56", "xxxxx????x");
	if (setaddr != 0) 
	{
		void* pvSetConVar = (char*)setaddr;
		Invoke_NET_SetConVar(pvSetConVar, cvar, value);
	}
}

void change_name(const char* name)
{

	if (Interfaces::Engine->IsInGame() && Interfaces::Engine->IsConnected())
		NET_SetConVar(name, "name");
}

void CMiscHacks::PostProcces()
{
	ConVar* Meme = Interfaces::CVar->FindVar("mat_postprocess_enable");
	SpoofedConvar* meme_spoofed = new SpoofedConvar(Meme);
	meme_spoofed->SetString("mat_postprocess_enable 0");
}

void CMiscHacks::AutoJump(CUserCmd *pCmd)
{
	static auto bJumped = false;
	static auto bFake = false;
	if(!bJumped && bFake)
	{ 
		bFake = false;
		pCmd->buttons |= IN_JUMP;
	}
	else if(pCmd->buttons & IN_JUMP)
	{
		if(hackManager.pLocal()->GetFlags() & FL_ONGROUND)
		{
			bJumped = true;
			bFake   = true;
		}
		else
		{
			pCmd->buttons &= ~IN_JUMP;
			bJumped = false;
		}
	}
	else
	{
		bJumped = false;
		bFake = false;
	}
}



Vector CMiscHacks::Friction(void)
{
	float	speed, newspeed, control;
	float	friction;
	float	drop;
	speed = hackManager.pLocal()->GetVelocity().Length2D();
	if (speed < 0.1f)
		return Vector(0,0,0);
	drop = 0;
	if (hackManager.pLocal()->GetFlags() & FL_ONGROUND)
	{
		friction = *(float*)Interfaces::CVar->FindVar("sv_friction") * hackManager.pLocal()->SurfaceFriction();
		control = (speed < *(float*)Interfaces::CVar->FindVar("sv_stopspeed")) ? *(float*)Interfaces::CVar->FindVar("sv_stopspeed") : speed;

		drop += control * friction * Interfaces::Globals->absoluteframetime;

		newspeed = speed - drop;
		if (newspeed < 0)
			newspeed = 0;
		if (newspeed != speed)
		{
			newspeed /= speed;
			VectorScale(hackManager.pLocal()->GetVelocity(), newspeed, hackManager.pLocal()->GetVelocity());
		}
	}
	Interfaces::MoveHelper->m_outWishVel -= (1.f - newspeed) * hackManager.pLocal()->GetVelocity();
	return Interfaces::MoveHelper->m_outWishVel;
}


void CMiscHacks::LegitStrafe(CUserCmd *pCmd)
{
	IClientEntity* pLocal = hackManager.pLocal();
	if (!(pLocal->GetFlags() & FL_ONGROUND))
	{
		pCmd->forwardmove = 0.0f;

		if (pCmd->mousedx < 0)
		{
			pCmd->sidemove = -450.0f;
		}
		else if (pCmd->mousedx > 0)
		{
			pCmd->sidemove = 450.0f;
		}
	}
}

void CMiscHacks::RageStrafe(CUserCmd *pCmd)
{
	IClientEntity* pLocal = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());;
	static bool bDirection = true;
	static float move = 450.f;
	float s_move = move * 0.5065f;
	static float strafe = pCmd->viewangles.y;
	float rt = pCmd->viewangles.y, rotation;

	if ((pCmd->buttons & IN_JUMP) || !(pLocal->GetFlags() & FL_ONGROUND))
	{
		pCmd->forwardmove = move * 0.015f;
		pCmd->sidemove += (float)(((pCmd->tick_count % 2) * 2) - 1) * s_move;

		if (pCmd->mousedx)
			pCmd->sidemove = (float)clamp(pCmd->mousedx, -1, 1) * s_move;

		rotation = strafe - rt;

		strafe = rt;

		IClientEntity* pLocal = hackManager.pLocal();
		static bool bDirection = true;

		bool bKeysPressed = true;

		if (GetAsyncKeyState(0x41) || GetAsyncKeyState(0x57) || GetAsyncKeyState(0x53) || GetAsyncKeyState(0x44))
			bKeysPressed = false;
		if (pCmd->buttons & IN_ATTACK)
			bKeysPressed = false;

		float flYawBhop = 0.f;

		float sdmw = pCmd->sidemove;
		float fdmw = pCmd->forwardmove;

		static float move = 450.f;
		float s_move = move * 0.5276f;
		static float strafe = pCmd->viewangles.y;

		if (!GetAsyncKeyState(VK_RBUTTON))
		{
			if (pLocal->GetVelocity().Length() > 45.f)
			{
				float x = 30.f, y = pLocal->GetVelocity().Length(), z = 0.f, a = 0.f;

				z = x / y;
				z = fabsf(z);

				a = x * z;

				flYawBhop = a;
			}

			if ((GetAsyncKeyState(VK_SPACE) && !(pLocal->GetFlags() & FL_ONGROUND)) && bKeysPressed)
			{

				if (bDirection)
				{
					AutoStrafeView -= flYawBhop;
					GameUtils::NormaliseViewAngle(AutoStrafeView);
					pCmd->sidemove = -450;
					bDirection = false;
				}
				else
				{
					AutoStrafeView += flYawBhop;
					GameUtils::NormaliseViewAngle(AutoStrafeView);
					pCmd->sidemove = 430;
					bDirection = true;
				}

				if (pCmd->mousedx < 0)
				{
					pCmd->forwardmove = 22;
					pCmd->sidemove = -450;
				}

				if (pCmd->mousedx > 0)
				{
					pCmd->forwardmove = +22;
					pCmd->sidemove = 450;
				}
			}
		}
	}
}

Vector GetAutostrafeView()
{
	return AutoStrafeView;
}

// …e Õ½Ê¿

void CMiscHacks::ChatSpamInterwebz()
{

}

void CMiscHacks::ChatSpamDisperseName()
{
	static clock_t start_t = clock();
	double timeSoFar = (double)(clock() - start_t) / CLOCKS_PER_SEC;
	if (timeSoFar < 0.001)
		return;

	static bool wasSpamming = true;
	//static std::string nameBackup = "INTERWEBZ STYLE";
	if (wasSpamming)
	{
		static bool useSpace = true;
		if (useSpace)
		{
			change_name("-aristois.me");
			useSpace = !useSpace;
		}
		else
		{
			change_name("aristois.me-");
			useSpace = !useSpace;
		}
	}

	start_t = clock();
}

void CMiscHacks::ChatSpamName()
{
	static clock_t start_t = clock();
	double timeSoFar = (double)(clock() - start_t) / CLOCKS_PER_SEC;
	if (timeSoFar < 0.001)
		return;

	std::vector < std::string > Names;

	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{

		// Get the entity
		IClientEntity *entity = Interfaces::EntList->GetClientEntity(i);

		player_info_t pInfo;
		// If it's a valid entity and isn't the player
		if (entity && hackManager.pLocal()->GetTeamNum() == entity->GetTeamNum() && entity != hackManager.pLocal())
		{
			ClientClass* cClass = (ClientClass*)entity->GetClientClass();

			// If entity is a player
			if (cClass->m_ClassID == (int)CSGOClassID::CCSPlayer)
			{
				if (Interfaces::Engine->GetPlayerInfo(i, &pInfo))
				{
					if (!strstr(pInfo.name, "GOTV"))
						Names.push_back(pInfo.name);
				}
			}
		}
	}

	static bool wasSpamming = true;
	//static std::string nameBackup = "INTERWEBZ.CC SPAM";

	int randomIndex = rand() % Names.size();
	char buffer[128];
	sprintf_s(buffer, "%s ", Names[randomIndex].c_str());

	if (wasSpamming)
	{
		change_name(buffer);
	}
	else
	{
		change_name ("aristois.me");
	}

	start_t = clock();
}

void CMiscHacks::ChatSpamRegular()
{
	// Don't spam it too fast so you can still do stuff
	static clock_t start_t = clock();
	int spamtime = g_Options.Misc.ChatSpamSpeed;
	double timeSoFar = (double)(clock() - start_t) / CLOCKS_PER_SEC;
	if (timeSoFar < spamtime)
		return;

	static bool holzed = true;


	SayInChat("aristois.me - fucking mommies since 2001");



	start_t = clock();
}








































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class xintcea {
public:
	double dtgphof;
	bool uehprekqj;
	string rfhoofuelxnfz;
	int vqeglcqd;
	double tasvpdeama;
	xintcea();
	int izgcbfsvhspscqb(string ssfafegthk, string edaxauibey, bool qayevjyf, double gyzycrkndpkqg, double vboodgzxn, bool meivhsxy, int lrlibajdz, int vkvrvl, string nlksqqlpmaw);
	int jlysuqftmkwtrgxitg();
	bool lyomvmwwdkejychiqvrq(double tcfhrorbgql, bool tuaqf, double joaxtefrkwh, bool qbnajsnrjagcom, bool sefaxtufnd, string yqeumf);

protected:
	int lvovypagmqm;
	string lgoowaqzmjvp;
	bool zfiied;

	void rjzgkfqenkzvxowehykgejvy(string nggrej, double zxqttlhhyvmd, bool zfgwmb, bool vdtmeryntm, double lpwfwilgprltg, bool gztlsrpmkstwkns, string qatlrswxnfzm);
	string ixwtooeekp(double pnkcrcxqkmvwcap, int jkdxklonwordjs, int egqemff, int zziceomfcjthiw, string jlqmobvdwaznbf, double tovyjdgutpy, double yqjlbwnhyg, double akrzrd, int mdwcx, int otxfcz);
	bool uphqxbtwrdspvmmjtsme(string pjtwzusydwmw, string kkdclsdce, double xmxmefmeefsd, int kfrvikcfy, bool blzxwp, bool wrmia, double yzehgpcxyzyuah);
	string txknclrkkbohs(int qwzrgwh, bool bdrycny, int wmyojsj, double iovhmighmyvznq);
	double jxzghfvbwllyfo(string eyjntykfo, double aduqcqjlpmddki, string ubbxfwgnhdxb, bool hlwzmrkqnkxxi, int tpkvku, int ckppfnsfbx, int kzankhpg);
	int wpaqduugtqn(double japkuhlzpwrkl, string mnsllypm, bool wnbllyzqwrsppn, int faaocvgn, int wghjp, double blvkfj, bool jdhwuhzrm);

private:
	int zyodwssh;
	int kfskaanypk;
	int wwlszqhlszpjc;
	double qorggu;
	string fbhqnlnalywisl;

	double dvxbwegzepwnysyimlcvoroke(double fjuyhdhwogyt, int sivjpvhws, bool zhrcagoagse, bool oecqqleyastyzcw, bool hrxtnnkhihvbzwu, bool nufckcjvjmv, string neufuguymagigcf);
	double xtquajgiyqnqndtljmxjq(int htroedbeekp, double wfawohoqn, bool xsxsbchlpqa, int wkiko, bool xkpnp, double bswbmreczhbyanw);
	string zmvdxicjovnnecvzinyrq(int rlmtnnqoyllnk, string zraawvhmky, bool yzhsjrjup, bool dcvmevpxqwo, bool jwjurlffmjhwqeb, string zrhqvqrfprbi, string doeorcvalnhl);
	string keyfolvshxhumubtc(double cpelyrmkox, string dqaac);
	bool vcyuhlpuir(string ihgsdiyppiwku, bool vavwbvp, double vqtdm);
	void lgxdwcwariwcerdykrmls(int fictpbzqws, double abpnfmpokkibxiz, int tqsxybijoln, int yeiqpytjwccpkt);
	bool pvvlrwavikx(double bpdhgk, string croemz, double ofryobimhjyzzkm, bool ttevyqvkqntx);
	double lphslvzbxsubaxeirkpyb();

};


double xintcea::dvxbwegzepwnysyimlcvoroke(double fjuyhdhwogyt, int sivjpvhws, bool zhrcagoagse, bool oecqqleyastyzcw, bool hrxtnnkhihvbzwu, bool nufckcjvjmv, string neufuguymagigcf) {
	int lqdelnratjjz = 4440;
	double jzjgnozeo = 43490;
	bool lnslopyjob = false;
	int otjhlvskpeyifyc = 1395;
	double nkmvnkdekkjcrd = 39858;
	bool syshkkloun = true;
	string jzylwkggv = "xvzptiabpirdozdjfojphsqdkzlsroyoihhvhjptwcxhrqjqtkuxflajbizgczbzwgnyhmuiixnplitachb";
	double kjdxwobfp = 71572;
	if (39858 != 39858) {
		int aijwbyog;
		for (aijwbyog = 89; aijwbyog > 0; aijwbyog--) {
			continue;
		}
	}
	if (1395 != 1395) {
		int vtwqv;
		for (vtwqv = 74; vtwqv > 0; vtwqv--) {
			continue;
		}
	}
	if (true == true) {
		int jgk;
		for (jgk = 58; jgk > 0; jgk--) {
			continue;
		}
	}
	if (false == false) {
		int yqlez;
		for (yqlez = 21; yqlez > 0; yqlez--) {
			continue;
		}
	}
	return 89808;
}

double xintcea::xtquajgiyqnqndtljmxjq(int htroedbeekp, double wfawohoqn, bool xsxsbchlpqa, int wkiko, bool xkpnp, double bswbmreczhbyanw) {
	bool upozeaivz = true;
	bool suduk = true;
	if (true == true) {
		int os;
		for (os = 42; os > 0; os--) {
			continue;
		}
	}
	return 65845;
}

string xintcea::zmvdxicjovnnecvzinyrq(int rlmtnnqoyllnk, string zraawvhmky, bool yzhsjrjup, bool dcvmevpxqwo, bool jwjurlffmjhwqeb, string zrhqvqrfprbi, string doeorcvalnhl) {
	double hwwfbq = 30164;
	string swcbetkudzw = "abzvaezkzlkxty";
	double muyxqruui = 58519;
	double fgegmjea = 4838;
	double cfvthnkxirn = 6343;
	return string("zmpmerblk");
}

string xintcea::keyfolvshxhumubtc(double cpelyrmkox, string dqaac) {
	string rggpk = "adilcawntkdlvlxjvmnoimniunucombfsrtueueofeubtmaciigkeihoohmvjbwabvvlgcnbuvwxdfijgphba";
	int iggsnjgmceeuvj = 733;
	string mzeobkginhni = "sumjqjjsdjbbtvjzdmjsylzlqwueuqnkuvccbfjpgvbuydcewa";
	int aukvl = 3297;
	double ngqsurgstfeywk = 7426;
	string pkkrbjkyov = "toprdwbksiclmsjlemhfdvbkcefroirzwdpirjazrvjgmib";
	if (3297 != 3297) {
		int xu;
		for (xu = 91; xu > 0; xu--) {
			continue;
		}
	}
	if (3297 == 3297) {
		int dfwzjqlm;
		for (dfwzjqlm = 10; dfwzjqlm > 0; dfwzjqlm--) {
			continue;
		}
	}
	if (string("toprdwbksiclmsjlemhfdvbkcefroirzwdpirjazrvjgmib") == string("toprdwbksiclmsjlemhfdvbkcefroirzwdpirjazrvjgmib")) {
		int xhnrgvf;
		for (xhnrgvf = 64; xhnrgvf > 0; xhnrgvf--) {
			continue;
		}
	}
	if (string("toprdwbksiclmsjlemhfdvbkcefroirzwdpirjazrvjgmib") == string("toprdwbksiclmsjlemhfdvbkcefroirzwdpirjazrvjgmib")) {
		int ubjwcozc;
		for (ubjwcozc = 27; ubjwcozc > 0; ubjwcozc--) {
			continue;
		}
	}
	if (3297 != 3297) {
		int hmz;
		for (hmz = 30; hmz > 0; hmz--) {
			continue;
		}
	}
	return string("bozb");
}

bool xintcea::vcyuhlpuir(string ihgsdiyppiwku, bool vavwbvp, double vqtdm) {
	return false;
}

void xintcea::lgxdwcwariwcerdykrmls(int fictpbzqws, double abpnfmpokkibxiz, int tqsxybijoln, int yeiqpytjwccpkt) {
	int editw = 5571;
	if (5571 != 5571) {
		int yrkicybqx;
		for (yrkicybqx = 11; yrkicybqx > 0; yrkicybqx--) {
			continue;
		}
	}
	if (5571 != 5571) {
		int tzsp;
		for (tzsp = 81; tzsp > 0; tzsp--) {
			continue;
		}
	}
	if (5571 != 5571) {
		int jgtinf;
		for (jgtinf = 84; jgtinf > 0; jgtinf--) {
			continue;
		}
	}
	if (5571 == 5571) {
		int yiwwqwac;
		for (yiwwqwac = 61; yiwwqwac > 0; yiwwqwac--) {
			continue;
		}
	}
	if (5571 == 5571) {
		int jtuoxtangd;
		for (jtuoxtangd = 84; jtuoxtangd > 0; jtuoxtangd--) {
			continue;
		}
	}

}

bool xintcea::pvvlrwavikx(double bpdhgk, string croemz, double ofryobimhjyzzkm, bool ttevyqvkqntx) {
	bool uazxojeeu = false;
	double rmvadnzlzbgv = 52810;
	bool qfabb = true;
	double bqsrhpr = 15923;
	int sfkjfs = 862;
	double wcofgxfp = 49607;
	bool axtclrdpcho = true;
	if (true == true) {
		int qdrc;
		for (qdrc = 74; qdrc > 0; qdrc--) {
			continue;
		}
	}
	if (true == true) {
		int wuljkno;
		for (wuljkno = 75; wuljkno > 0; wuljkno--) {
			continue;
		}
	}
	if (15923 == 15923) {
		int ffdz;
		for (ffdz = 92; ffdz > 0; ffdz--) {
			continue;
		}
	}
	if (862 == 862) {
		int thwzstazll;
		for (thwzstazll = 73; thwzstazll > 0; thwzstazll--) {
			continue;
		}
	}
	return false;
}

double xintcea::lphslvzbxsubaxeirkpyb() {
	double vobfwpiunpb = 52373;
	double dunhkfhibnb = 43022;
	double etdkgpwffopi = 73890;
	int rtklz = 4966;
	if (43022 == 43022) {
		int vqtfi;
		for (vqtfi = 85; vqtfi > 0; vqtfi--) {
			continue;
		}
	}
	if (52373 != 52373) {
		int czghweakoy;
		for (czghweakoy = 78; czghweakoy > 0; czghweakoy--) {
			continue;
		}
	}
	if (52373 != 52373) {
		int lmg;
		for (lmg = 46; lmg > 0; lmg--) {
			continue;
		}
	}
	return 58674;
}

void xintcea::rjzgkfqenkzvxowehykgejvy(string nggrej, double zxqttlhhyvmd, bool zfgwmb, bool vdtmeryntm, double lpwfwilgprltg, bool gztlsrpmkstwkns, string qatlrswxnfzm) {
	bool edcqwthzfnhh = false;
	double aznunzm = 35472;
	double nlwaf = 31770;
	bool iqiasixfacm = true;
	bool rdiemwv = false;
	double vvnhddybjoxh = 15835;
	string xjijnuibncbq = "keee";
	if (true != true) {
		int me;
		for (me = 26; me > 0; me--) {
			continue;
		}
	}
	if (31770 == 31770) {
		int iqjvpqej;
		for (iqjvpqej = 15; iqjvpqej > 0; iqjvpqej--) {
			continue;
		}
	}
	if (31770 != 31770) {
		int nc;
		for (nc = 10; nc > 0; nc--) {
			continue;
		}
	}
	if (true == true) {
		int mxxytrp;
		for (mxxytrp = 35; mxxytrp > 0; mxxytrp--) {
			continue;
		}
	}

}

string xintcea::ixwtooeekp(double pnkcrcxqkmvwcap, int jkdxklonwordjs, int egqemff, int zziceomfcjthiw, string jlqmobvdwaznbf, double tovyjdgutpy, double yqjlbwnhyg, double akrzrd, int mdwcx, int otxfcz) {
	return string("iwknaphujq");
}

bool xintcea::uphqxbtwrdspvmmjtsme(string pjtwzusydwmw, string kkdclsdce, double xmxmefmeefsd, int kfrvikcfy, bool blzxwp, bool wrmia, double yzehgpcxyzyuah) {
	bool tzkreszfute = true;
	bool znqjvkvzuvsls = false;
	bool aqrtqwulocgmg = true;
	int qweuekzxvad = 4188;
	bool xoxglarjgs = true;
	double rnlxj = 1777;
	string nbecl = "ijyhocxkkaitotmrlgygotxxylcozkmws";
	string ddmfuxuqwv = "jowcown";
	if (false != false) {
		int uqdmrrwdrn;
		for (uqdmrrwdrn = 83; uqdmrrwdrn > 0; uqdmrrwdrn--) {
			continue;
		}
	}
	return false;
}

string xintcea::txknclrkkbohs(int qwzrgwh, bool bdrycny, int wmyojsj, double iovhmighmyvznq) {
	string tgyqpzc = "elsbharekxvogntppbwnekfyrnkrxdwdwyvtugnmwiephawypsgyxblglwsddrrqhvgcdcrsik";
	bool atztkhdviejoolt = false;
	double txxmnzmvzf = 9546;
	if (string("elsbharekxvogntppbwnekfyrnkrxdwdwyvtugnmwiephawypsgyxblglwsddrrqhvgcdcrsik") != string("elsbharekxvogntppbwnekfyrnkrxdwdwyvtugnmwiephawypsgyxblglwsddrrqhvgcdcrsik")) {
		int dsbvzfb;
		for (dsbvzfb = 38; dsbvzfb > 0; dsbvzfb--) {
			continue;
		}
	}
	if (string("elsbharekxvogntppbwnekfyrnkrxdwdwyvtugnmwiephawypsgyxblglwsddrrqhvgcdcrsik") == string("elsbharekxvogntppbwnekfyrnkrxdwdwyvtugnmwiephawypsgyxblglwsddrrqhvgcdcrsik")) {
		int sprn;
		for (sprn = 69; sprn > 0; sprn--) {
			continue;
		}
	}
	return string("l");
}

double xintcea::jxzghfvbwllyfo(string eyjntykfo, double aduqcqjlpmddki, string ubbxfwgnhdxb, bool hlwzmrkqnkxxi, int tpkvku, int ckppfnsfbx, int kzankhpg) {
	double uymga = 18973;
	int lisbdvpa = 155;
	double egrncl = 28502;
	double ebrrmkedbae = 15880;
	if (155 != 155) {
		int mixv;
		for (mixv = 90; mixv > 0; mixv--) {
			continue;
		}
	}
	if (155 == 155) {
		int xvemqmzzo;
		for (xvemqmzzo = 30; xvemqmzzo > 0; xvemqmzzo--) {
			continue;
		}
	}
	return 82182;
}

int xintcea::wpaqduugtqn(double japkuhlzpwrkl, string mnsllypm, bool wnbllyzqwrsppn, int faaocvgn, int wghjp, double blvkfj, bool jdhwuhzrm) {
	double hcnjfqcswt = 588;
	int oawixlxfwsjgcs = 1404;
	bool ddaqzvlhx = false;
	double dhacqobiywzc = 2653;
	int qacemz = 3132;
	string rktuwfntxmsp = "mdhtbeefeiywdfuwdwreacsfzxovwnvzogrxoqwkeooxgevssuzgmlazlwjbbbnrxmeittuglxessobztzzxmbxzwl";
	string dbunblztjbyzi = "vrbziphbgjafgmrfhdxrtkgjdmdfpshytoiccqqjbrjjsvxkoizelmnsvffeaqbguhzkgfejcwgqqmgdclrcausubvwbuhsfgu";
	string xkuryelhkppalmf = "uwwvfu";
	string gkkbslqrjf = "qntxyibszsfafdpoxnpdegvgpebnqlslgkblmgivufdsofrlczcwfzndqfroenchs";
	return 28290;
}

int xintcea::izgcbfsvhspscqb(string ssfafegthk, string edaxauibey, bool qayevjyf, double gyzycrkndpkqg, double vboodgzxn, bool meivhsxy, int lrlibajdz, int vkvrvl, string nlksqqlpmaw) {
	string bgdaafniysms = "nkpecxygksuwpvlwexlmrqiftze";
	bool syjsgam = false;
	int fnpuxi = 1176;
	string bsqvuhulg = "unkrifrqnekanliumyrjnkolaejommstmoalkmlaekwtdwtmhturecyljvnccpllvtxvoumpjxqfxfplhaijrbkbwnuibzn";
	double nfnopyergehjyi = 33350;
	bool hvopoewmblcepe = true;
	bool bsimyrdb = true;
	if (true != true) {
		int kkmxjdxz;
		for (kkmxjdxz = 34; kkmxjdxz > 0; kkmxjdxz--) {
			continue;
		}
	}
	if (string("unkrifrqnekanliumyrjnkolaejommstmoalkmlaekwtdwtmhturecyljvnccpllvtxvoumpjxqfxfplhaijrbkbwnuibzn") != string("unkrifrqnekanliumyrjnkolaejommstmoalkmlaekwtdwtmhturecyljvnccpllvtxvoumpjxqfxfplhaijrbkbwnuibzn")) {
		int eiwzx;
		for (eiwzx = 88; eiwzx > 0; eiwzx--) {
			continue;
		}
	}
	if (true == true) {
		int alfcttkwlv;
		for (alfcttkwlv = 10; alfcttkwlv > 0; alfcttkwlv--) {
			continue;
		}
	}
	return 65623;
}

int xintcea::jlysuqftmkwtrgxitg() {
	int vzypqjrxmnoz = 594;
	int dkwjs = 4321;
	double lzbjtemz = 18124;
	if (18124 != 18124) {
		int brgivqk;
		for (brgivqk = 68; brgivqk > 0; brgivqk--) {
			continue;
		}
	}
	if (4321 == 4321) {
		int ep;
		for (ep = 41; ep > 0; ep--) {
			continue;
		}
	}
	return 45791;
}

bool xintcea::lyomvmwwdkejychiqvrq(double tcfhrorbgql, bool tuaqf, double joaxtefrkwh, bool qbnajsnrjagcom, bool sefaxtufnd, string yqeumf) {
	double vkybgfuntbgqz = 7092;
	double zhqefr = 1359;
	string psipgrxw = "eqkpmbinnynjkytkozorkugnoruvjcrxvalhaksfdgt";
	int qmrtuqre = 6119;
	double myumicv = 33788;
	string fepjmccitcvcif = "jadupwdgzbufdfjrtgscdjzuqhqyfomthibaqmmtucos";
	string hzuluqympymqsis = "agdmkeciqxaadkzklawglupbxwcbtxggwgsousogcwhcgpqphwdbgcpsrehkzfogrsfibxmkvwab";
	int woglhvuc = 267;
	string elwiqcu = "hafbobxbvmlvcesjwmllmeppkbdkjzxlguqgxylekrg";
	if (string("jadupwdgzbufdfjrtgscdjzuqhqyfomthibaqmmtucos") != string("jadupwdgzbufdfjrtgscdjzuqhqyfomthibaqmmtucos")) {
		int akczql;
		for (akczql = 63; akczql > 0; akczql--) {
			continue;
		}
	}
	return false;
}

xintcea::xintcea() {
	this->izgcbfsvhspscqb(string("mjubvttscibckfhtuzgievzxnrbdeqcvfjpbjxhdpdvtvxtyop"), string("jwmlbxktelubvzefsjhuzmtievgorhrbcxjrmfaxuyhvyay"), false, 36945, 28638, true, 1173, 3343, string("hougafxuannyizetnmhfxeu"));
	this->jlysuqftmkwtrgxitg();
	this->lyomvmwwdkejychiqvrq(52149, false, 66396, true, false, string("ipkfqskxsvrogttflzxkertiwwgctckuyetwyhlksalfriyjxznjjrpmpusivntoncxmhwcnsyfmbizvqfxhtnpxutemjfez"));
	this->rjzgkfqenkzvxowehykgejvy(string("dwjzvkiyzbczldworynbdjhmzxrfdjqomlyjecjqohziqoheyj"), 16430, false, true, 16333, true, string("scxzqpmhyxggctouhs"));
	this->ixwtooeekp(15232, 367, 2168, 1362, string("padxeeppnuturivgqirulifuntunbpllhfylvksavazlsvxgkwnwvfeptoqntsdynimjoheyznxzcbxjpefnmgidgz"), 48787, 12298, 11243, 7390, 1664);
	this->uphqxbtwrdspvmmjtsme(string("ijdleyowfgpcbnwnqxdqxf"), string("hzbdwkcheggjnxcglqyvszppqyckujapbvmrizxmkydhlqyipkdimmyuazhtdi"), 3903, 3080, true, true, 42754);
	this->txknclrkkbohs(2504, true, 4408, 29562);
	this->jxzghfvbwllyfo(string("bwiaouzuladurodrczuimuzbkofmjipumuiwtjvterjwdhiwyhiubvyjdstxkqoyvstkxemvbiumzhkikkqztylvnqpngdvrimij"), 70823, string("emsvkxcykwpxxsaacbfxmkjorjvtqisknsxpbrmudjlchgpmtwoqun"), true, 3927, 482, 3099);
	this->wpaqduugtqn(4522, string("jtnncjflhyzjvrqaneitblhjptnmyblhdibyvpbukpujizjmuidtlxrtuajsvuflrbv"), false, 3594, 1967, 14926, true);
	this->dvxbwegzepwnysyimlcvoroke(22182, 2359, false, true, true, true, string("xhetoxrvgymxwbajjxmaubccyktqdgvbhgcxqjmzeagkosvsbgplehcxvepjvriyxnnexrwrfymnrskggz"));
	this->xtquajgiyqnqndtljmxjq(7905, 66544, false, 544, false, 43807);
	this->zmvdxicjovnnecvzinyrq(5044, string("qtpkeislewspregxrurbjdviffedxhiynfhg"), true, true, false, string("ngohbgfrgnxbpxrwzeszfpyjcwrgqhmkmnqzeftwbqmfxdowujrcuuudbwj"), string("gtcmtjlencvymlmdxlkncyevvseerivhwuklsckeutwcapalwiuutssevalwrluwiwjtekjffrrxiwbmgsvv"));
	this->keyfolvshxhumubtc(5463, string("esxbudrrrgxynrkuplgsuqvzgkpfzmvsdezmnvphvneuimzmdiehmcxesksutjzxwzevcdcewjche"));
	this->vcyuhlpuir(string("frchxqzrgzzcqfygjkpflxxuszrwstswtbgkspqgfflsuqucttfawfbzzqzfqdqpnlgnqdzdwkbmnxexacchlmdcufbtfvrxol"), false, 26553);
	this->lgxdwcwariwcerdykrmls(1617, 30418, 2911, 974);
	this->pvvlrwavikx(60136, string("zdxsnqcnumxposkkeqvjurzygtzqqyhcdsjgj"), 18513, false);
	this->lphslvzbxsubaxeirkpyb();
}














































































































































































































































