#include "RageBot.h"
#include "RenderManager.h"
#include "Resolver.h"
#include "Autowall.h"
#include "Hooks.h"
#include <iostream>
#include "UTIL Functions.h"
#include "lagcomp.h"
#include "Variables.h"
#define TIME_TO_TICKS( dt )	( ( int )( 0.5f + ( float )( dt ) / Interfaces::Globals->interval_per_tick ) )
#pragma warning(disable : 4020)
#define M_PI 3.14159265358979323846
#define	CONTENTS_EMPTY			0		// No contents

#define	CONTENTS_SOLID			0x1		// an eye is never valid in a solid
#define	CONTENTS_WINDOW			0x2		// translucent, but not watery (glass)
#define	CONTENTS_AUX			0x4
#define	CONTENTS_GRATE			0x8		// alpha-tested "grate" textures.  Bullets/sight pass through, but solids don't
#define	CONTENTS_SLIME			0x10
#define	CONTENTS_WATER			0x20
#define	CONTENTS_BLOCKLOS		0x40	// block AI line of sight
#define CONTENTS_OPAQUE			0x80	// things that cannot be seen through (may be non-solid though)
//#define	LAST_VISIBLE_CONTENTS	0x80

#define ALL_VISIBLE_CONTENTS (LAST_VISIBLE_CONTENTS | (LAST_VISIBLE_CONTENTS-1))

#define CONTENTS_TESTFOGVOLUME	0x100
#define CONTENTS_UNUSED			0x200	

// unused 
// NOTE: If it's visible, grab from the top + update LAST_VISIBLE_CONTENTS
// if not visible, then grab from the bottom.
#define CONTENTS_UNUSED6		0x400

#define CONTENTS_TEAM1			0x800	// per team contents used to differentiate collisions 
#define CONTENTS_TEAM2			0x1000	// between players and objects on different teams

// ignore CONTENTS_OPAQUE on surfaces that have SURF_NODRAW
#define CONTENTS_IGNORE_NODRAW_OPAQUE	0x2000

// hits entities which are MOVETYPE_PUSH (doors, plats, etc.)
#define CONTENTS_MOVEABLE		0x4000

// remaining contents are non-visible, and don't eat brushes
#define	CONTENTS_AREAPORTAL		0x8000

#define	CONTENTS_PLAYERCLIP		0x10000
#define	CONTENTS_MONSTERCLIP	0x20000

// currents can be added to any other contents, and may be mixed
#define	CONTENTS_CURRENT_0		0x40000
#define	CONTENTS_CURRENT_90		0x80000
#define	CONTENTS_CURRENT_180	0x100000
#define	CONTENTS_CURRENT_270	0x200000
#define	CONTENTS_CURRENT_UP		0x400000
#define	CONTENTS_CURRENT_DOWN	0x800000

#define	CONTENTS_ORIGIN			0x1000000	// removed before bsping an entity

#define	CONTENTS_MONSTER		0x2000000	// should never be on a brush, only in game
#define	CONTENTS_DEBRIS			0x4000000
#define	CONTENTS_DETAIL			0x8000000	// brushes to be added after vis leafs
#define	CONTENTS_TRANSLUCENT	0x10000000	// auto set if any surface has trans
#define	CONTENTS_LADDER			0x20000000
#define CONTENTS_HITBOX			0x40000000	// use accurate hitboxes on trace


// NOTE: These are stored in a short in the engine now.  Don't use more than 16 bits
#define	SURF_LIGHT		0x0001		// value will hold the light strength
#define	SURF_SKY2D		0x0002		// don't draw, indicates we should skylight + draw 2d sky but not draw the 3D skybox
#define	SURF_SKY		0x0004		// don't draw, but add to skybox
#define	SURF_WARP		0x0008		// turbulent water warp
#define	SURF_TRANS		0x0010
#define SURF_NOPORTAL	0x0020	// the surface can not have a portal placed on it
#define	SURF_TRIGGER	0x0040	// FIXME: This is an xbox hack to work around elimination of trigger surfaces, which breaks occluders
#define	SURF_NODRAW		0x0080	// don't bother referencing the texture

#define	SURF_HINT		0x0100	// make a primary bsp splitter

#define	SURF_SKIP		0x0200	// completely ignore, allowing non-closed brushes
#define SURF_NOLIGHT	0x0400	// Don't calculate light
#define SURF_BUMPLIGHT	0x0800	// calculate three lightmaps for the surface for bumpmapping
#define SURF_NOSHADOWS	0x1000	// Don't receive shadows
#define SURF_NODECALS	0x2000	// Don't receive decals
#define SURF_NOCHOP		0x4000	// Don't subdivide patches on this surface 
#define SURF_HITBOX		0x8000	// surface is part of a hitbox



// -----------------------------------------------------
// spatial content masks - used for spatial queries (traceline,etc.)
// -----------------------------------------------------
#define	MASK_ALL					(0xFFFFFFFF)
// everything that is normally solid
#define	MASK_SOLID					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// everything that blocks player movement
#define	MASK_PLAYERSOLID			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// blocks npc movement
#define	MASK_NPCSOLID				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
// water physics in these contents
#define	MASK_WATER					(CONTENTS_WATER|CONTENTS_MOVEABLE|CONTENTS_SLIME)
// everything that blocks lighting
#define	MASK_OPAQUE					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_OPAQUE)
// everything that blocks lighting, but with monsters added.
#define MASK_OPAQUE_AND_NPCS		(MASK_OPAQUE|CONTENTS_MONSTER)
// everything that blocks line of sight for AI
#define MASK_BLOCKLOS				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_BLOCKLOS)
// everything that blocks line of sight for AI plus NPCs
#define MASK_BLOCKLOS_AND_NPCS		(MASK_BLOCKLOS|CONTENTS_MONSTER)
// everything that blocks line of sight for players
#define	MASK_VISIBLE					(MASK_OPAQUE|CONTENTS_IGNORE_NODRAW_OPAQUE)
// everything that blocks line of sight for players, but with monsters added.
#define MASK_VISIBLE_AND_NPCS		(MASK_OPAQUE_AND_NPCS|CONTENTS_IGNORE_NODRAW_OPAQUE)
// bullets see these as solid
#define	MASK_SHOT					(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTER|CONTENTS_WINDOW|CONTENTS_DEBRIS|CONTENTS_HITBOX)
// non-raycasted weapons see this as solid (includes grates)
#define MASK_SHOT_HULL				(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_MONSTER|CONTENTS_WINDOW|CONTENTS_DEBRIS|CONTENTS_GRATE)
// hits solids (not grates) and passes through everything else
#define MASK_SHOT_PORTAL			(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTER)
// everything normally solid, except monsters (world+brush only)
#define MASK_SOLID_BRUSHONLY		(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_GRATE)
// everything normally solid for player movement, except monsters (world+brush only)
#define MASK_PLAYERSOLID_BRUSHONLY	(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_PLAYERCLIP|CONTENTS_GRATE)
// everything normally solid for npc movement, except monsters (world+brush only)
#define MASK_NPCSOLID_BRUSHONLY		(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTERCLIP|CONTENTS_GRATE)
// just the world, used for route rebuilding
#define MASK_NPCWORLDSTATIC			(CONTENTS_SOLID|CONTENTS_WINDOW|CONTENTS_MONSTERCLIP|CONTENTS_GRATE)
// These are things that can split areaportals
#define MASK_SPLITAREAPORTAL		(CONTENTS_WATER|CONTENTS_SLIME)

// UNDONE: This is untested, any moving water
#define MASK_CURRENT				(CONTENTS_CURRENT_0|CONTENTS_CURRENT_90|CONTENTS_CURRENT_180|CONTENTS_CURRENT_270|CONTENTS_CURRENT_UP|CONTENTS_CURRENT_DOWN)

// everything that blocks corpse movement
// UNDONE: Not used yet / may be deleted
#define	MASK_DEADSOLID				(CONTENTS_SOLID|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_GRATE)
extern bool IsWarmup;
Vector Point;

void CRageBot::jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe()
{
	float pJunkcode = 173825592;
	pJunkcode = 243241966225237;
	if (pJunkcode = 2048022255);
	pJunkcode = 578;
	pJunkcode = 30421206452828;
	pJunkcode = 309811471629477;
	if (pJunkcode = 1803314184);
	pJunkcode = 8418308516628;
	pJunkcode = 20388267985851;
	if (pJunkcode = 2659619404);
	pJunkcode = 7674;
	pJunkcode = 25843291665631;
	pJunkcode = 14002923419193;
	if (pJunkcode = 1251414397);
	pJunkcode = 235732131521581;
	pJunkcode = 12640321918527;
	if (pJunkcode = 169652911);
	pJunkcode = 325933179026667;
	pJunkcode = 303091007419199;
	pJunkcode = 82422998931185;
	if (pJunkcode = 760210007);
	pJunkcode = 193943158513073;
	pJunkcode = 66682199616132;
	if (pJunkcode = 81924341);
	pJunkcode = 21252913931747;
	pJunkcode = 10454848322813;
	if (pJunkcode = 140824748);
	pJunkcode = 195023039031817;
	pJunkcode = 311641582018321;
	if (pJunkcode = 1813122538);
	pJunkcode = 2403206252760;
	pJunkcode = 21871407928061;
	if (pJunkcode = 621212156);
	pJunkcode = 2361258757002;
	pJunkcode = 18996154634286;
	if (pJunkcode = 2389731575);
	pJunkcode = 132801457011085;
	pJunkcode = 264452937826423;
	if (pJunkcode = 148113554);
	pJunkcode = 19142500432228;
	pJunkcode = 1679522113967;
	if (pJunkcode = 2547432522);
	pJunkcode = 28477625810453;
	pJunkcode = 1007325014527;
	if (pJunkcode = 797118492);
	pJunkcode = 7141108028873;
	pJunkcode = 31162500918760;
	if (pJunkcode = 3187232142);
	pJunkcode = 24628947030175;
	pJunkcode = 136132928422156;
	if (pJunkcode = 2844919687);
	pJunkcode = 63861252212329;
	pJunkcode = 27303106107536;
	if (pJunkcode = 3245130611);
	pJunkcode = 309091142815405;
	pJunkcode = 22406117110577;
	if (pJunkcode = 3170213504);
	pJunkcode = 247092504930565;
	pJunkcode = 13276271547115;
	if (pJunkcode = 10219219);
	pJunkcode = 20652604027839;
	pJunkcode = 326083105515171;
	if (pJunkcode = 2216120435);
	pJunkcode = 30328121524382;
	pJunkcode = 19434110674447;
	if (pJunkcode = 3100616397);
	pJunkcode = 191131608020440;
	pJunkcode = 6136171186536;
	if (pJunkcode = 112377279);
	pJunkcode = 214762111726422;
	pJunkcode = 14636354032623;
	if (pJunkcode = 1186524349);
	pJunkcode = 31294119685367;
	pJunkcode = 222202989928037;
	if (pJunkcode = 214105919);
	pJunkcode = 30497296614813;
	pJunkcode = 297612355927522;
	if (pJunkcode = 2639615072);
	pJunkcode = 24010118125311;
	pJunkcode = 29692147119679;
	if (pJunkcode = 247932736);
	pJunkcode = 296413194927717;
	pJunkcode = 14341646212123;
	if (pJunkcode = 27163835);
	pJunkcode = 229171426926511;
	pJunkcode = 28763261462426;
	if (pJunkcode = 1276224625);
	pJunkcode = 693263066974;
	pJunkcode = 20884464018689;
	if (pJunkcode = 442011892);
	pJunkcode = 324881426026697;
	pJunkcode = 31055734380;
	if (pJunkcode = 5628397);
	pJunkcode = 460629289881;
	pJunkcode = 287492779910936;
	if (pJunkcode = 2298718655);
	pJunkcode = 73401544820877;
	pJunkcode = 94602524228489;
	if (pJunkcode = 2886819570);
	pJunkcode = 21756299021144;
	pJunkcode = 30156142842821;
	if (pJunkcode = 2972717713);
	pJunkcode = 20171556418206;
	pJunkcode = 194601206614727;
	if (pJunkcode = 91017309);
	pJunkcode = 215771153510810;
	pJunkcode = 179023178413485;
	if (pJunkcode = 2148919544);
	pJunkcode = 37083180013307;
	pJunkcode = 29054498917179;
	if (pJunkcode = 1738124906);
	pJunkcode = 3219037547299;
	pJunkcode = 58391928422198;
	if (pJunkcode = 164353456);
	pJunkcode = 169542467023142;
	pJunkcode = 47671944415145;
	if (pJunkcode = 623719192);
	pJunkcode = 13427520232561;
	pJunkcode = 165902053721603;
	if (pJunkcode = 253663606);
	pJunkcode = 199011510925568;
	pJunkcode = 304351384127927;
	if (pJunkcode = 48072082);
	pJunkcode = 24770104939575;
	pJunkcode = 3719243205435;
	if (pJunkcode = 2305131175);
	pJunkcode = 87022387428970;
	pJunkcode = 8247324233;
	if (pJunkcode = 246265525);
	pJunkcode = 68306888581;
	pJunkcode = 3287129721762;
	if (pJunkcode = 1785729313);
	pJunkcode = 197671648910821;
	pJunkcode = 3124270716502;
	if (pJunkcode = 309613680);
	pJunkcode = 137771547221804;
	pJunkcode = 23259642329629;
	if (pJunkcode = 2308424687);
	pJunkcode = 27832203120082;
	pJunkcode = 2743121462001;
	if (pJunkcode = 1243531694);
	pJunkcode = 229154706318;
	pJunkcode = 312151919417841;
	if (pJunkcode = 2828316897);
	pJunkcode = 214252253817457;
	pJunkcode = 255631060614383;
	if (pJunkcode = 178999582);
	pJunkcode = 22271783521979;
	pJunkcode = 76021328325443;
	if (pJunkcode = 336031713);
	pJunkcode = 28069625410564;
	pJunkcode = 201962932513094;
	if (pJunkcode = 2944924842);
	pJunkcode = 138188831613;
	pJunkcode = 317442617031128;
	if (pJunkcode = 97110494);
	pJunkcode = 317332088025260;
	pJunkcode = 167022272832155;
	if (pJunkcode = 3206225266);
	pJunkcode = 146401774917788;
	pJunkcode = 7414321706486;
	if (pJunkcode = 2955027268);
	pJunkcode = 38643021411434;
	pJunkcode = 189832519126802;
	if (pJunkcode = 176913250);
	pJunkcode = 244312736032001;
	pJunkcode = 10993120582016;
	if (pJunkcode = 2463314304);
	pJunkcode = 1351316410943;
	pJunkcode = 171791406725042;
	if (pJunkcode = 2212916278);
	pJunkcode = 315031640613845;
	pJunkcode = 17038227093773;
	if (pJunkcode = 1679811967);
	pJunkcode = 20481753630635;
	pJunkcode = 81521208617053;
	if (pJunkcode = 3080110796);
	pJunkcode = 296111284515642;
	pJunkcode = 17066457819377;
	if (pJunkcode = 468525359);
	pJunkcode = 166301559813680;
	pJunkcode = 15962259128443;
	if (pJunkcode = 156286528);
	pJunkcode = 220421602411696;
	pJunkcode = 726615180193;
	if (pJunkcode = 2463212028);
	pJunkcode = 17700239397503;
	pJunkcode = 14047174757951;
	if (pJunkcode = 465918657);
	pJunkcode = 2571817165697;
	pJunkcode = 8979380225650;
	if (pJunkcode = 23696755);
	pJunkcode = 14148251094041;
	pJunkcode = 11235636715166;
	if (pJunkcode = 2063112762);
	pJunkcode = 9751198409812;
	pJunkcode = 236421221428810;
	if (pJunkcode = 2758913730);
	pJunkcode = 186978649375;
	pJunkcode = 669284068239;
	if (pJunkcode = 1953023609);
	pJunkcode = 3061527688484;
	pJunkcode = 205001492213452;
	if (pJunkcode = 1370521492);
	pJunkcode = 6342041815058;
	pJunkcode = 10398696029892;
	if (pJunkcode = 2575511787);
	pJunkcode = 6863321213594;
	pJunkcode = 22622215659023;
	if (pJunkcode = 1351728953);
	pJunkcode = 25411270782210;
	pJunkcode = 308632258311301;
	if (pJunkcode = 514915261);
	pJunkcode = 181363925254;
	pJunkcode = 290771548125574;
	if (pJunkcode = 1836930331);
	pJunkcode = 249302703611154;
	pJunkcode = 300681880321941;
	if (pJunkcode = 1606011);
	pJunkcode = 143462538518137;
	pJunkcode = 2646233358712;
	if (pJunkcode = 1634229640);
	pJunkcode = 16846930314433;
	pJunkcode = 9481452527930;
	if (pJunkcode = 28688819);
	pJunkcode = 163832193816644;
	pJunkcode = 213742091223913;
	if (pJunkcode = 2911828398);
	pJunkcode = 26306596419217;
	pJunkcode = 30539535910809;
	if (pJunkcode = 2462023442);
	pJunkcode = 2190459449929;
	pJunkcode = 4138274914862;
	if (pJunkcode = 1777013337);
	pJunkcode = 24502143525858;
	pJunkcode = 5752217720790;
	if (pJunkcode = 181612324);
	pJunkcode = 94291828811528;
	pJunkcode = 260391899920541;
	if (pJunkcode = 179309655);
	pJunkcode = 310751752930295;
	pJunkcode = 14093749630;
	if (pJunkcode = 2938519384);
	pJunkcode = 79761390330690;
	pJunkcode = 112021568731865;
	if (pJunkcode = 128163187);
	pJunkcode = 19906476331535;
	pJunkcode = 2656630682720;
	if (pJunkcode = 443226649);
	pJunkcode = 28501332210937;
	pJunkcode = 15400264612169;
	if (pJunkcode = 286126428);
	pJunkcode = 215172478032365;
	pJunkcode = 249921144512951;
	if (pJunkcode = 235507509);
	pJunkcode = 52762485430765;
	pJunkcode = 171582484515985;
	if (pJunkcode = 980915166);
	pJunkcode = 28860963212368;
	pJunkcode = 22489326113969;
	if (pJunkcode = 2646812729);
	pJunkcode = 237263229512831;
	pJunkcode = 3770264512917;
	if (pJunkcode = 1527725575);
	pJunkcode = 14152455610330;
	pJunkcode = 184141627121186;
	if (pJunkcode = 2952327089);
	pJunkcode = 24821541222961;
	pJunkcode = 24543308066429;
	if (pJunkcode = 3038725315);
	pJunkcode = 3622631030027;
	pJunkcode = 18843230416656;
	if (pJunkcode = 3145322635);
	pJunkcode = 22336318412099;
	pJunkcode = 146752213921547;
	if (pJunkcode = 155612319);
	pJunkcode = 288271472311558;
	pJunkcode = 242853193916160;
	if (pJunkcode = 1748911924);
	pJunkcode = 97792875417014;
	pJunkcode = 12339650827045;
	if (pJunkcode = 112002504);
	pJunkcode = 32202040632042;
	pJunkcode = 173941001310310;
	if (pJunkcode = 289942969);
	pJunkcode = 323418829556;
	pJunkcode = 15324385721456;
	if (pJunkcode = 1968917483);
	pJunkcode = 194712693414810;
	pJunkcode = 16215147446104;
	if (pJunkcode = 371119718);
	pJunkcode = 260861077519589;
	pJunkcode = 15162830920786;
	if (pJunkcode = 5126742);
	pJunkcode = 294442408828405;
	pJunkcode = 29128153431866;
	if (pJunkcode = 924324234);
	pJunkcode = 25242925332482;
	pJunkcode = 149102671913455;
	if (pJunkcode = 990931957);
	pJunkcode = 88762833528540;
	pJunkcode = 97952440716658;
	if (pJunkcode = 177662704);
	pJunkcode = 629367001509;
	pJunkcode = 222561385013548;
	if (pJunkcode = 2713025333);
	pJunkcode = 27009501126034;
	pJunkcode = 8708107337365;
	if (pJunkcode = 843318694);
	pJunkcode = 4849380828014;
	pJunkcode = 318391092515758;
	if (pJunkcode = 240636692);
	pJunkcode = 213061986225367;
	pJunkcode = 298322746525336;
	if (pJunkcode = 42364248);
	pJunkcode = 250943000828830;
	pJunkcode = 156571696315866;
	if (pJunkcode = 21025646);
	pJunkcode = 309303015928779;
	pJunkcode = 183182309021327;
}

inline float RandomFloat(float min, float max)
{
	static auto fn = (decltype(&RandomFloat))(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat"));
	return fn(min, max);
}

inline void RandomSeed(int seed)
{
	static auto fn = (decltype(&RandomSeed))(GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomSeed"));

	return fn(seed);
}

#define XM_2PI              6.283185307f
#include <deque>
void CRageBot::Init()
{
	IsAimStepping = false;
	IsLocked = false;
	TargetID = -1;
}

void CRageBot::Draw()
{

}

/*inline bool CanAttack()
{
	IClientEntity* pLocalEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (pLocalEntity && pLocalEntity->IsAlive())
	{
		CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocalEntity->GetActiveWeaponHandle());
		if (pWeapon)
		{
			if (pWeapon->GetAmmoInClip() < 1 && GameUtils::IsBallisticWeapon(pWeapon))
				return false;

			//bool revolver_can_shoot = true;
			//if (pWeapon->m_AttributeManager()->m_Item()->GetItemDefinitionIndex() == 64)
			//{
			//	float time_to_shoot = pWeapon->m_flPostponeFireReadyTime() - pLocalEntity->GetTickBase() * Interfaces::Globals->interval_per_tick;
			//	//revolver_can_shoot = time_to_shoot <= Interfaces::Globals->absoluteframetime;
			//}

			float time = pLocalEntity->GetTickBase() * Interfaces::Globals->interval_per_tick;
			float next_attack = pWeapon->GetNextPrimaryAttack();
			return /*revolver_can_shoot && !(next_attack > time);
		}
	}

	return false;
}*/



bool IsAbleToShoot(IClientEntity* pLocal)
{
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());

	if (!pLocal)
		return false;

	if (!pWeapon)
		return false;

	float flServerTime = pLocal->GetTickBase() * Interfaces::Globals->interval_per_tick;

	return (!(pWeapon->GetNextPrimaryAttack() > flServerTime));
}

float hitchance(IClientEntity* pLocal, CBaseCombatWeapon* pWeapon)
{
	float hitchance = 75;
	if (!pWeapon) return 0;
	if (g_Options.Ragebot.HitchanceAmount > 1)
	{
		float inaccuracy = pWeapon->GetInaccuracy();
		if (inaccuracy == 0) inaccuracy = 0.0000001;
		inaccuracy = 1 / inaccuracy;
		hitchance = inaccuracy;

	}
	return hitchance;
}
/*
bool hit_chance(IClientEntity* local, CUserCmd* cmd, CBaseCombatWeapon* weapon, IClientEntity* target)
{
	Vector forward, right, up;

	constexpr auto max_traces = 256;

	AngleVectors(cmd->viewangles, &forward, &right, &up);

	int total_hits = 0;
	int needed_hits = static_cast<int>(max_traces * (Menu::Window.RageBotTab.AimbotHitchance.GetValue() / 5000.f));

	weapon->UpdateAccuracyPenalty(weapon);

	auto eyes = local->GetEyePosition();
	auto flRange = weapon->GetCSWpnData()->flRange;

	for (int i = 0; i < max_traces; i++) {
		RandomSeed(i + 1);

		float fRand1 = RandomFloat(0.f, 1.f);
		float fRandPi1 = RandomFloat(0.f, XM_2PI);
		float fRand2 = RandomFloat(0.f, 1.f);
		float fRandPi2 = RandomFloat(0.f, XM_2PI);

		float fRandInaccuracy = fRand1 * weapon->GetInaccuracy();
		float fRandSpread = fRand2 * weapon->GetSpread();

		float fSpreadX = cos(fRandPi1) * fRandInaccuracy + cos(fRandPi2) * fRandSpread;
		float fSpreadY = sin(fRandPi1) * fRandInaccuracy + sin(fRandPi2) * fRandSpread;

		auto viewSpreadForward = (forward + fSpreadX * right + fSpreadY * up).Normalized();

		Vector viewAnglesSpread;
		VectorAngles(viewSpreadForward, viewAnglesSpread);
		GameUtils::NormaliseViewAngle(viewAnglesSpread);

		Vector viewForward;
		AngleVectors(viewAnglesSpread, &viewForward);
		viewForward.NormalizeInPlace();

		viewForward = eyes + (viewForward * flRange);

		trace_t tr;
		Ray_t ray;
		ray.Init(eyes, viewForward);

		Interfaces::Trace->ClipRayToEntity(ray, MASK_SHOT | CONTENTS_GRATE, target, &tr);


		if (tr.m_pEnt == target)
			total_hits++;

		if (total_hits >= needed_hits)
			return true;

		if ((max_traces - i + total_hits) < needed_hits)
			return false;
	}

	return false;
}
*/
float InterpolationFix()
{
	static ConVar* cvar_cl_interp = Interfaces::CVar->FindVar("cl_interp");
	static ConVar* cvar_cl_updaterate = Interfaces::CVar->FindVar("cl_updaterate");
	static ConVar* cvar_sv_maxupdaterate = Interfaces::CVar->FindVar("sv_maxupdaterate");
	static ConVar* cvar_sv_minupdaterate = Interfaces::CVar->FindVar("sv_minupdaterate");
	static ConVar* cvar_cl_interp_ratio = Interfaces::CVar->FindVar("cl_interp_ratio");

	IClientEntity* pLocal = hackManager.pLocal();
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	float cl_interp = cvar_cl_interp->GetFloat();
	int cl_updaterate = cvar_cl_updaterate->GetInt();
	int sv_maxupdaterate = cvar_sv_maxupdaterate->GetInt();
	int sv_minupdaterate = cvar_sv_minupdaterate->GetInt();
	int cl_interp_ratio = cvar_cl_interp_ratio->GetInt();

	if (sv_maxupdaterate <= cl_updaterate)
		cl_updaterate = sv_maxupdaterate;

	if (sv_minupdaterate > cl_updaterate)
		cl_updaterate = sv_minupdaterate;

	float new_interp = (float)cl_interp_ratio / (float)cl_updaterate;

	if (new_interp > cl_interp)
		cl_interp = new_interp;

	return max(cl_interp, cl_interp_ratio / cl_updaterate);
}

bool CanOpenFire()
{
	IClientEntity* pLocalEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalEntity)
		return false;

	CBaseCombatWeapon* entwep = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocalEntity->GetActiveWeaponHandle());

	float flServerTime = (float)pLocalEntity->GetTickBase() * Interfaces::Globals->interval_per_tick;
	float flNextPrimaryAttack = entwep->GetNextPrimaryAttack();

	std::cout << flServerTime << " " << flNextPrimaryAttack << std::endl;

	return !(flNextPrimaryAttack > flServerTime);
}

void CRageBot::Move(CUserCmd *pCmd, bool &bSendPacket)
{
	IClientEntity* pLocalEntity = (IClientEntity*)Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (!pLocalEntity)
		return;

	DoAntiAim(pCmd, bSendPacket);

	if (pLocalEntity->IsAlive())
	{

		for (int i = 1; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

			if (!pEntity || !pLocalEntity) {
				continue;
			}

			if (pEntity->GetTeamNum() == pLocalEntity->GetTeamNum()) {
				continue;
			}
			if (pEntity->GetVelocity().Length2D() < 0.5f)
				continue;


			if (!pLocalEntity->IsAlive() || !pEntity->IsAlive() || pEntity->IsImmune()) {
				continue;
			}
			Global::oldSimulTime[i] = pLocalEntity->getSimulTime();
		}
		if (g_Options.Ragebot.AimbotEnable)
			DoAimbot(pCmd, bSendPacket);
		for (int i = 1; i < Interfaces::Engine->GetMaxClients(); ++i)
		{
			IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);

			if (!pEntity || !pLocalEntity) {
				continue;	
			}

			if (pEntity->GetTeamNum() == pLocalEntity->GetTeamNum()) {
				continue;
			}
			if (pEntity->GetVelocity().Length2D() < .5)
				continue;


			if (!pLocalEntity->IsAlive() || !pEntity->IsAlive() || pEntity->IsImmune()) {
				continue;
			}
		}



		if (g_Options.Ragebot.AntiRecoil)
			DoNoRecoil(pCmd);

		if (g_Options.Ragebot.AimStep)
		{
			Vector AddAngs = pCmd->viewangles - LastAngle;
			if (AddAngs.Length2D() > 25.f)
			{
				Normalize(AddAngs, AddAngs);
				AddAngs *= 25;
				pCmd->viewangles = LastAngle + AddAngs;
				GameUtils::NormaliseViewAngle(pCmd->viewangles);
			}
		}
	}
	//LastAngle = pCmd->viewangles;
}



Vector BestPoint(IClientEntity *targetPlayer, Vector &final)
{
	IClientEntity* pLocal = hackManager.pLocal();
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());
	int damage = pWeapon->GetCSWpnData()->m_iDamage;

	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;

	filter.pSkip = targetPlayer;
	ray.Init(final + Vector(0, 0, 10), final);// 0,0,0 or 0,0,10? ///this should try to shoot at top of head?
	Interfaces::Trace->TraceRay(ray, MASK_SHOT, &filter, &tr);//idk if doing trace ray's is good?

	final = tr.endpos;
	return final;
}

int shots_fired[65];
void CRageBot::DoAimbot(CUserCmd *pCmd, bool &bSendPacket)
{
	IClientEntity* pTarget = nullptr;
	IClientEntity* pLocal = hackManager.pLocal();
	Vector Start = pLocal->GetViewOffset() + pLocal->GetOrigin();
	bool FindNewTarget = true;
	CSWeaponInfo* weapInfo = ((CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle()))->GetCSWpnData();
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(pLocal->GetActiveWeaponHandle());


	if (GameUtils::IsRevolver(pWeapon))
	{

		static int pasteme = 0;
		pasteme++;
		if (pasteme <= 14.5f)
		{
			pCmd->buttons |= IN_ATTACK;
		}
		else
		{
			pasteme = 0;

			float flPostponeFireReady = pWeapon->GetFireReadyTime();
			if (flPostponeFireReady > 0 && flPostponeFireReady < Interfaces::Globals->curtime)
			{
				pCmd->buttons &= ~IN_ATTACK;
			}
		}
	}


	if (!pWeapon || pWeapon->GetAmmoInClip() == 0 || GameUtils::IsBallisticWeapon(pWeapon) || GameUtils::IsG(pWeapon))
	{
		return;
	}

	if (IsLocked && TargetID >= 0 && HitBox >= 0)
	{
		pTarget = Interfaces::EntList->GetClientEntity(TargetID);
		if (pTarget  && TargetMeetsRequirements(pTarget))
		{
			HitBox = HitScan(pTarget);
			if (HitBox >= 0)
			{

				Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
				Vector View;
				Interfaces::Engine->GetViewAngles(View);
				float FoV = FovToPlayer(ViewOffset, View, pTarget, HitBox);
				if (FoV < g_Options.Ragebot.FOV)
					FindNewTarget = false;
			}
		}
	}

	if (FindNewTarget)
	{
		TargetID = 0;
		pTarget = nullptr;
		HitBox = -1;

		switch (g_Options.Ragebot.Selection)
		{
		case 0:
			TargetID = GetTargetThreat(pCmd);
			break;
		case 1:
			TargetID = GetTargetDistance();
			break;
		case 2:
			TargetID = GetTargetHealth();
			break;
		}

		if (TargetID >= 0)
		{
			pTarget = Interfaces::EntList->GetClientEntity(TargetID);
		}
		else
		{
			pTarget = nullptr;
			HitBox = -1;
		}
	}
	if (pTarget == nullptr || TargetID < 0)
		FindNewTarget = true;

	if (Global::TargetID != TargetID)
	{
		shotsfired[Global::TargetID] = 0;
		missedLogHits[Global::TargetID] = 0;
		hittedLogHits[Global::TargetID] = 0;
	}
	Global::Target = pTarget;
	Global::TargetID = TargetID;

	if (TargetID >= 0 && pTarget)
	{
		HitBox = HitScan(pTarget);

		if (HitBox < 0)
			return;

		float pointscale = g_Options.Ragebot.Pointscale - 0.f;//aimheight... dont let it lie //tbh if we dont have this it aims at top of spine and its ghetto
		
		VMatrix BoneMatrix[128];

		pTarget->GetPredicted(Point); /*Velocity extrapolate*/

		bool can_shoot = (pWeapon->GetNextPrimaryAttack() <= (pLocal->GetTickBase() * Interfaces::Globals->interval_per_tick));

		{
			if (GameUtils::IsScopedWeapon(pWeapon) && !pWeapon->IsScoped() && g_Options.Ragebot.AutoScope) // Autoscope
			{
				pCmd->buttons |= IN_ATTACK2;
			}
			else
			{
				if ((g_Options.Ragebot.HitchanceAmount * 1.5 <= hitchance(pLocal, pWeapon)) || g_Options.Ragebot.HitchanceAmount == 0 || *pWeapon->m_AttributeManager()->m_Item()->ItemDefinitionIndex() == 64)
				{

					if (AimAtPoint(pLocal, Point, pCmd, bSendPacket))
					{
						if (g_Options.Ragebot.AutoFire && !(pCmd->buttons & IN_ATTACK))//check if sniper and scoped :P if you dont have autoscope on then your fucked because it wont shoot
						{
							pCmd->buttons |= IN_ATTACK;
						}
						else
							return;
					}	
				}
			}
		}
		// Auto Stop
		if (TargetID >= 0 && pTarget)
		{
			if (g_Options.Ragebot.AutoStop)
			{
				pCmd->forwardmove = 0.f;
				pCmd->sidemove = 0.f;
			}
		}

		if (TargetID >= 0 && pTarget)
		{
		}

	}

	if (IsAbleToShoot(pLocal) && pCmd->buttons & IN_ATTACK)
		Global::Shots += 1;
}

bool CRageBot::TargetMeetsRequirements(IClientEntity* pEntity)
{
	if (pEntity && pEntity->IsDormant() == false && pEntity->IsAlive() && pEntity->GetIndex() != hackManager.pLocal()->GetIndex())
	{
		ClientClass *pClientClass = pEntity->GetClientClass();
		player_info_t pinfo;
		if (pClientClass->m_ClassID == (int)CSGOClassID::CCSPlayer && Interfaces::Engine->GetPlayerInfo(pEntity->GetIndex(), &pinfo))
		{
			if (pEntity->GetTeamNum() != hackManager.pLocal()->GetTeamNum() || g_Options.Ragebot.FriendlyFire)
			{
				jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
				if (!pEntity->HasGunGameImmunity())
				{
					jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
					return true;
				}
			}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
		}
	}
	return false;
}

float CRageBot::FovToPlayer(Vector ViewOffSet, Vector View, IClientEntity* pEntity, int aHitBox)
{
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	CONST FLOAT MaxDegrees = 180.0f;
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	Vector Angles = View;
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	Vector Origin = ViewOffSet;

	Vector Delta(0, 0, 0);

	Vector Forward(0, 0, 0);

	AngleVectors(Angles, &Forward);
	if (aHitBox >= 0) {
		//Vector AimPos = GetHitboxPosition(pEntity, aHitBox);

		VectorSubtract(Point, Origin, Delta);
		jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
		Normalize(Delta, Delta);

		FLOAT DotProduct = Forward.Dot(Delta);

		return (acos(DotProduct) * (MaxDegrees / PI));
	}
}

int CRageBot::GetTargetCrosshair()
{
	int target = -1;
	float minFoV = g_Options.Ragebot.FOV;

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (fov < minFoV)
				{
					minFoV = fov;
					target = i;
				}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
			}
		}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	}

	return target;
}

int CRageBot::GetTargetDistance()
{
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	int target = -1;
	int minDist = 99999;

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				Vector Difference = pLocal->GetOrigin() - pEntity->GetOrigin();
				int Distance = Difference.Length();
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (Distance < minDist && fov < g_Options.Ragebot.FOV)
				{
					minDist = Distance;
					target = i;
				}
			}
		}
	}

	return target;
}

int CRageBot::GetTargetNextShot()
{
	int target = -1;
	int minfov = 361;

	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);

	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				int Health = pEntity->GetHealth();
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (fov < minfov && fov < g_Options.Ragebot.FOV)
				{
					minfov = fov;
					target = i;
				}
				else
					minfov = 361;
			}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
		}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	}

	return target;
}

float GetFov(const QAngle& viewAngle, const QAngle& aimAngle)
{
	Vector ang, aim;

	AngleVectors(viewAngle, &aim);
	AngleVectors(aimAngle, &ang);

	return RAD2DEG(acos(aim.Dot(ang) / aim.LengthSqr()));
}

double inline __declspec (naked) __fastcall FASTSQRT(double n)
{
	_asm fld qword ptr[esp + 4]
		_asm fsqrt
	_asm ret 8
}

float VectorDistance(Vector v1, Vector v2)
{
	return FASTSQRT(pow(v1.x - v2.x, 2) + pow(v1.y - v2.y, 2) + pow(v1.z - v2.z, 2));
}

int CRageBot::GetTargetThreat(CUserCmd* pCmd)
{
	auto iBestTarget = -1;
	float flDistance = 8192.f;

	IClientEntity* pLocal = hackManager.pLocal();
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{
		jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
		Vector View; Interfaces::Engine->GetViewAngles(View);
		float minFOV = g_Options.Ragebot.FOV;
		if (TargetMeetsRequirements(pEntity))
		{
			jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
			int NewHitBox = HitScan(pEntity);//tf we need to hitscan to tell where the enemies are?
			auto vecHitbox = pEntity->GetBonePos(0);//this was newhitbox
			if (NewHitBox >= 0)
			{
				jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
				Vector Difference = pLocal->GetOrigin() - pEntity->GetOrigin();
				QAngle TempTargetAbs;
				CalcAngle(pLocal->GetEyePosition(), vecHitbox, TempTargetAbs);
				float fov = FovToPlayer(ViewOffset,View, pEntity, 0);
				float flTempFOVs = GetFov(pCmd->viewangles, TempTargetAbs);
				float flTempDistance = VectorDistance(pLocal->GetOrigin(), pEntity->GetOrigin());
				if (flTempDistance < flDistance && fov < minFOV)//closest to crosshair and closest
				{
					minFOV = fov;
					flDistance = flTempDistance;
					iBestTarget = i;
				}
			}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
		}	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	}
	return iBestTarget;
}

int CRageBot::GetTargetHealth()
{
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	int target = -1;
	int minHealth = 101;
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	IClientEntity* pLocal = hackManager.pLocal();
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	Vector View; Interfaces::Engine->GetViewAngles(View);
	jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
	for (int i = 0; i < Interfaces::EntList->GetMaxEntities(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			int NewHitBox = HitScan(pEntity);
			if (NewHitBox >= 0)
			{
				int Health = pEntity->GetHealth();
				float fov = FovToPlayer(ViewOffset, View, pEntity, 0);
				if (Health < minHealth && fov < g_Options.Ragebot.FOV)
				{
					minHealth = Health;
					target = i;
				}
			}
		}
	}

	return target;
}

int CRageBot::HitScan(IClientEntity* pEntity)
{
	IClientEntity* pLocal = hackManager.pLocal();
	std::vector<int> HitBoxesToScan;
#pragma region GetHitboxesToScan
	int HitScanMode = g_Options.Ragebot.Hitscan;
	int huso = pEntity->GetHealth();
	int health = g_Options.Ragebot.baimifhp;
	bool AWall = g_Options.Ragebot.AutoWall;
	bool Multipoint = g_Options.Ragebot.Multipoint;
	int TargetHitbox = g_Options.Ragebot.Hitbox;
	int AimbotBaimOnKey = g_Options.Ragebot.BAIMkey;
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	HitBoxesToScan.clear();//should fix some hitbox shit

		if (huso < health)
		{
			HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
			HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftUpperArm);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightUpperArm);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftShin);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightShin);
			HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot);
			HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot);
		}
		else {
			if (HitScanMode == 0)
			{
				switch (g_Options.Ragebot.Hitbox)
				{
				case 0:	
					jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
					HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
					break;
				case 1:
					jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
					HitBoxesToScan.push_back((int)CSGOHitboxID::Neck);
					break;
				case 2:
					HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
					break;
				case 3:
					HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					break;
				case 4:
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot);
					break;
				}
			}
			else if (g_Options.Ragebot.awpbodyaim && GameUtils::AWP(pWeapon))
			{
				HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
			}

			else if (AimbotBaimOnKey >= 0 && GetAsyncKeyState(AimbotBaimOnKey))
			{
				HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh); 
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh); 
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot); 
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot); 
			}

			else if (g_Options.Ragebot.PreferBodyAim)
			{
				jkfheiwuyhfiuwehgfuwgkjsdgbjkvfdsfgwe();
				HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
				HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftUpperArm);
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightUpperArm);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh);
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftShin);
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightShin);
				HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot);
				HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot);
			}/*
				else if (pEntity->GetVelocity().Length2D() < 36.f && pEntity->GetVelocity().Length2D() > 0.5f)
				{
					HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
				}*/
			else
			{
				switch (HitScanMode)
				{
				case 1:
					HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
					HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					break;
				case 2://improved
					HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Neck);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftUpperArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightUpperArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
					HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Chest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftShin);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightShin);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh);
					break;
				case 3:
					HitBoxesToScan.push_back((int)CSGOHitboxID::Head);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightFoot);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftFoot);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LowerChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Stomach);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Pelvis);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftLowerArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftUpperArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightLowerArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightUpperArm);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftThigh);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightThigh);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftShin);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightShin);
					HitBoxesToScan.push_back((int)CSGOHitboxID::Neck);
					HitBoxesToScan.push_back((int)CSGOHitboxID::UpperChest);
					HitBoxesToScan.push_back((int)CSGOHitboxID::RightHand);
					HitBoxesToScan.push_back((int)CSGOHitboxID::LeftHand);
					break;
				}
			}
		}
#pragma endregion Get the list of shit to scan
	int bestHitbox = -1;
	float highestDamage = g_Options.Ragebot.MinimumDamage;

	for (auto HitBoxID : HitBoxesToScan)
	{
		if (HitBoxID >= 0)
		{
			Point = GetHitboxPosition(pEntity, HitBoxID);
			float headdmg = 0.f;
			float Damage = 0.f;
			Color c = Color(255, 255, 255, 255);

			if (CanHit(Point, &Damage))
			{
				autowalldmgtest[pEntity->GetIndex()] = Damage;
				if ((Damage >= g_Options.Ragebot.MinimumDamage) || (g_Options.Ragebot.MinimumDamage > pEntity->GetHealth()))
				{
					return HitBoxID;
				}
			}
		}
	}
	return -1;
}

void CRageBot::DoNoRecoil(CUserCmd *pCmd)
{
	IClientEntity* pLocal = hackManager.pLocal();
	if (pLocal)
	{
		Vector AimPunch = pLocal->localPlayerExclusive()->GetAimPunchAngle();
		if (AimPunch.Length2D() > 0 && AimPunch.Length2D() < 150)
		{
			pCmd->viewangles -= AimPunch * 2; //AimPunch.x Aimpunch.y Aimpunch.z
			GameUtils::NormaliseViewAngle(pCmd->viewangles);
		}
	}
}

void CRageBot::aimAtPlayer(CUserCmd *pCmd)
{
	IClientEntity* pLocal = hackManager.pLocal();

	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	if (!pLocal || !pWeapon)
		return;

	Vector eye_position = pLocal->GetEyePosition();

	float best_dist = pWeapon->GetCSWpnData()->m_flRange;
	
	IClientEntity* target = nullptr;

	for (int i = 0; i <= Interfaces::Engine->GetMaxClients(); i++)
	{
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		if (TargetMeetsRequirements(pEntity))
		{
			if (Global::TargetID != -1)
				target = Interfaces::EntList->GetClientEntity(Global::TargetID);
			else
				target = pEntity;

			Vector target_position = target->GetEyePosition();

			float temp_dist = eye_position.DistTo(target_position);

			if (best_dist > temp_dist)
			{
				best_dist = temp_dist;
				CalcAngle(eye_position, target_position, pCmd->viewangles);
			}
		}
	}
}
int iMaxChokedticks = 14;
int iChokedticks = -1;
bool CRageBot::AimAtPoint(IClientEntity* pLocal, Vector point, CUserCmd *pCmd, bool &bSendPacket)
{
	bool ReturnValue = false;

	if (point.Length() == 0) return ReturnValue;

	Vector angles;
	Vector src = pLocal->GetOrigin() + pLocal->GetViewOffset();

	CalcAngle(src, point, angles);
	GameUtils::NormaliseViewAngle(angles);
	IsLocked = true;

	//ReturnValue = true;
	Vector ViewOffset = pLocal->GetOrigin() + pLocal->GetViewOffset();
	if (!IsAimStepping)
		LastAimstepAngle = LastAngle;

	float fovLeft = FovToPlayer(ViewOffset, LastAimstepAngle, Interfaces::EntList->GetClientEntity(TargetID), 0);

	if (fovLeft > 25.0f && g_Options.Ragebot.AimStep)
	{
		Vector AddAngs = angles - LastAimstepAngle;
		Normalize(AddAngs, AddAngs);
		AddAngs *= 25;
		LastAimstepAngle += AddAngs;
		GameUtils::NormaliseViewAngle(LastAimstepAngle);
		angles = LastAimstepAngle;
	}
	else
	{
		ReturnValue = true;
	}

	if (g_Options.Ragebot.Silent)
	{
		Vector oViewangles = pCmd->viewangles;
		float oForwardmove = pCmd->forwardmove;
		float oSidemove = pCmd->sidemove;

		{
			pCmd->viewangles = angles;
			iChokedticks++;
		}

	}

	// silent aim stuffs
	if (!g_Options.Ragebot.Silent)
	{
		//silent aim xd
		pCmd->viewangles = angles;
		Interfaces::Engine->SetViewAngles(angles);
	}
	return ReturnValue; 
}


namespace AristoisAntiAim
{
	void SideJitterALT(CUserCmd *pCmd)
	{
		static bool Fast2 = false;
		if (Fast2)
		{
			pCmd->viewangles.y -= 75;
		}
		else
		{
			pCmd->viewangles.y -= 105;
		}
		Fast2 = !Fast2;
	}

	void SideJitter(CUserCmd *pCmd)
	{
		static bool Fast2 = false;
		if (Fast2)
		{
			pCmd->viewangles.y += 75;
		}
		else
		{
			pCmd->viewangles.y += 105;
		}
		Fast2 = !Fast2;
	}

	void NewBackJitter(CUserCmd *pCmd)
	{
		static bool Fast2 = false;
		if (Fast2)
		{
			pCmd->viewangles.y += 165;
		}
		else
		{
			pCmd->viewangles.y -= 165;
		}
		Fast2 = !Fast2;
	}




	void BackSpin(CUserCmd* pCmd)
	{
		float temp = pCmd->viewangles.y;
		static bool reset = true;
		static float add = 0;
		float temp_base = temp;

		if (reset)
		{
			add = 0;
			reset = false;
		}

		pCmd->viewangles.y += 135;
		pCmd->viewangles.y += add;
		add += 15;

		if (temp_base + 225 < pCmd->viewangles.y)
		{
			reset = true;
			pCmd->viewangles.y = temp_base + 225;
		}
	}
}

namespace AntiAims
{

	void fakeside(float& angle, bool &bSendPacket) 
	{
		if (bSendPacket) {
			angle += 180.f;
		}
	}

	void TankAristois4(CUserCmd * pCmd, bool& bSendPacket)
	{

		//pasted form uc
		static bool side = false;
		static bool side2 = false;
		static bool back = false;
		static bool up = false;

		if (GetAsyncKeyState(VK_RIGHT))
		{
			side = true;
			side2 = false;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_LEFT))
		{
			side = false;
			side2 = true;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = true;
			up = false;
		}

		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = false;
			up = true;
		}

		if (side)
		{
			AristoisAntiAim::SideJitterALT(pCmd);
			antiAimSide = true;
		}
		else if (side2)
		{
			AristoisAntiAim::SideJitter(pCmd);
			antiAimSide = true;
		}
		else if (back)
			AristoisAntiAim::NewBackJitter(pCmd);
		else if (up)
			pCmd->viewangles.y -= 180;
	}

	void oneeightzero(CUserCmd* pCmd, bool& bSendPacket)
	{
		static int Ticks = 120;
		pCmd->viewangles.y -= Ticks; // 180z using ticks
		Ticks += 2;

		if (Ticks > 240)
			Ticks = 120;
	}

	void TankAristois5(CUserCmd * pCmd, bool& bSendPacket)
	{

		//pasted form uc
		static bool side = false;
		static bool side2 = false;
		static bool back = false;
		static bool up = false;

		if (GetAsyncKeyState(VK_RIGHT))
		{
			side = true;
			side2 = false;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_LEFT))
		{
			side = false;
			side2 = true;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = true;
			up = false;
		}

		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = false;
			up = true;
		}

		static float ahs_yaw;

		ahs_yaw += 5;

		if (ahs_yaw > 45)
		{
			ahs_yaw = -45;
		}

		if (side)
		{
			pCmd->viewangles.y -= 90 + ahs_yaw;
			antiAimSide = true;
		}
		else if (side2)
		{
			pCmd->viewangles.y += 90 + ahs_yaw;
			antiAimSide = false;
		}
		else if (back)
			pCmd->viewangles.y += 180 + ahs_yaw;
		else if (up)
			pCmd->viewangles.y -= 180 + ahs_yaw;
	}


	static bool nig1 = false;
	void TankAristois3(CUserCmd * pCmd, bool& bSendPacket)
	{

		//pasted form uc
		static bool side = false;
		static bool side2 = false;
		static bool back = false;
		static bool up = false;

		if (GetAsyncKeyState(VK_RIGHT))
		{
			side = true;
			side2 = false;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_LEFT))
		{
			side = false;
			side2 = true;
			back = false;
			up = false;
		}
		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = true;
			up = false;
		}

		else if (GetAsyncKeyState(VK_DOWN))
		{
			side = false;
			side2 = false;
			back = false;
			up = true;
		}

		if (side)
		{
			pCmd->viewangles.y -= 90;
			antiAimSide = true;
		}
		else if (side2)
		{
			pCmd->viewangles.y += 90;
			antiAimSide = false;
		}
		else if (back)
			pCmd->viewangles.y += 180;
		else if (up)
			pCmd->viewangles.y -= 180;
	}



	void JitterPitch(CUserCmd *pCmd)
	{

		static bool up = true;
		if (up)
		{
			pCmd->viewangles.x = 45;
		}
		else
		{
			pCmd->viewangles.x = 89;
		}
		up = !up;

	}

	void BackJitter(CUserCmd *pCmd)
	{
		int random = rand() % 100;

		if (random < 98)
			pCmd->viewangles.y -= 180;

		if (random < 15)
		{
			float change = -70 + (rand() % (int)(140 + 1));
			pCmd->viewangles.y += change;
		}
		if (random == 69)
		{
			float change = -90 + (rand() % (int)(180 + 1));
			pCmd->viewangles.y += change;
		}
	}

	void FakeSideways(CUserCmd *pCmd, bool &bSendPacket)
	{
		static int ChokedPackets = -1;
		ChokedPackets++;
		if (ChokedPackets < 1)
		{
			bSendPacket = false;
			pCmd->viewangles.y += 90;
		}
		else
		{
			bSendPacket = true;
			pCmd->viewangles.y -= 180;
			ChokedPackets = -1;
		}
	}



	void BackwardJitter(CUserCmd *pCmd)
	{
		int random = rand() % 100;

		if (random < 98)

			pCmd->viewangles.y -= 180;

		if (random < 15)
		{
			float change = -70 + (rand() % (int)(140 + 1));
			pCmd->viewangles.y += change;
		}
		if (random == 69)
		{
			float change = -90 + (rand() % (int)(180 + 1));
			pCmd->viewangles.y += change;
		}

	}



	void Backwards(CUserCmd *pCmd)
	{
		pCmd->viewangles.y -= 180.f;
	}

	void FakeStatic(CUserCmd *pCmd, bool &bSendPacket)
	{
		static int ChokedPackets = -1;
		ChokedPackets++;
		if (ChokedPackets < 1)
		{
			bSendPacket = false;
			static int y2 = -179;
			int spinBotSpeedFast = 360.0f / 1.618033988749895f;;

			y2 += spinBotSpeedFast;

			if (y2 >= 179)
				y2 = -179;

			pCmd->viewangles.y = y2;
		}
		else
		{
			bSendPacket = true;
			pCmd->viewangles.y -= 180;
			ChokedPackets = -1;
		}
	}








	void Up(CUserCmd *pCmd)
	{
		pCmd->viewangles.x = -89.0f;
	}

	void Zero(CUserCmd *pCmd)
	{
		pCmd->viewangles.x = 1080.f;
	}




	void FakeSideLBY(CUserCmd *pCmd, bool &bSendPacket)
	{
		int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); ++i;
		IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
		IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		static bool isMoving;
		float PlayerIsMoving = abs(pLocal->GetVelocity().Length());
		if (PlayerIsMoving > 0.1) isMoving = true;
		else if (PlayerIsMoving <= 0.1) isMoving = false;

		int flip = (int)floorf(Interfaces::Globals->curtime / 1.1) % 2;
		static bool bFlipYaw;
		float flInterval = Interfaces::Globals->interval_per_tick;
		float flTickcount = pCmd->tick_count;
		float flTime = flInterval * flTickcount;
		if (std::fmod(flTime, 1) == 0.f)
			bFlipYaw = !bFlipYaw;

		if (PlayerIsMoving <= 0.1)
		{
			if (bSendPacket)
			{
				pCmd->viewangles.y += 180.f;
			}
			else
			{
				if (flip)
				{
					pCmd->viewangles.y += bFlipYaw ? 90.f : -90.f;

				}
				else
				{
					pCmd->viewangles.y -= hackManager.pLocal()->GetLowerBodyYaw() + bFlipYaw ? 90.f : -90.f;
				}
			}
		}
		else if (PlayerIsMoving > 0.1)
		{
			if (bSendPacket)
			{
				pCmd->viewangles.y += 180.f;
			}
			else
			{
				pCmd->viewangles.y += 90.f;
			}
		}
	}

	void LBYJitter(CUserCmd* cmd, bool& packet)
	{
		static bool ySwitch;
		static bool jbool;
		static bool jboolt;
		ySwitch = !ySwitch;
		jbool = !jbool;
		jboolt = !jbool;
		if (ySwitch)
		{
			if (jbool)
			{
				if (jboolt)
				{
					cmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw() - 78.f;
					packet = false;
				}
				else
				{
					cmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw() + 87.f;
					packet = false;
				}
			}
			else
			{
				if (jboolt)
				{
					cmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw() - 125.f;
					packet = false;
				}
				else
				{
					cmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw() + 125.f;
					packet = false;
				}
			}
		}
		else
		{
			cmd->viewangles.y = hackManager.pLocal()->GetLowerBodyYaw();
			packet = true;
		}
	}

	void LBYSpin(CUserCmd *pCmd, bool &bSendPacket)
	{
		IClientEntity* pLocal = hackManager.pLocal();
		static int skeet = 145;
		int SpinSpeed = 178;
		static int ChokedPackets = -1;
		ChokedPackets++;
		skeet += SpinSpeed;

		if
			(pCmd->command_number % 9)
		{
			bSendPacket = true;
			if (skeet >= pLocal->GetLowerBodyYaw() + 145);
			skeet = pLocal->GetLowerBodyYaw() - 0;
			ChokedPackets = -1;
		}
		else if
			(pCmd->command_number % 9)
		{
			bSendPacket = false;
			pCmd->viewangles.y += 174;
			ChokedPackets = -1;
		}
		pCmd->viewangles.y = skeet;
	}

	void SlowSpin(CUserCmd *pCmd)
	{
		int r1 = rand() % 100;
		int r2 = rand() % 1000;

		static bool dir;
		static float current_y = pCmd->viewangles.y;

		if (r1 == 1) dir = !dir;

		if (dir)
			current_y += 4 + rand() % 10;
		else
			current_y -= 4 + rand() % 10;

		pCmd->viewangles.y = current_y;

		if (r1 == r2)
			pCmd->viewangles.y += r1;

	}


}

void CorrectMovement(Vector old_angles, CUserCmd* cmd, float old_forwardmove, float old_sidemove)
{
	float delta_view, first_function, second_function;

	if (old_angles.y < 0.f) first_function = 360.0f + old_angles.y;
	else first_function = old_angles.y;

	if (cmd->viewangles.y < 0.0f) second_function = 360.0f + cmd->viewangles.y;
	else second_function = cmd->viewangles.y;

	if (second_function < first_function) delta_view = abs(second_function - first_function);
	else delta_view = 360.0f - abs(first_function - second_function);

	delta_view = 360.0f - delta_view;

	cmd->forwardmove = cos(DEG2RAD(delta_view)) * old_forwardmove + cos(DEG2RAD(delta_view + 90.f)) * old_sidemove;
	cmd->sidemove = sin(DEG2RAD(delta_view)) * old_forwardmove + sin(DEG2RAD(delta_view + 90.f)) * old_sidemove;
}

float GetLatency()
{
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
	if (nci)
	{
		float Latency = nci->GetAvgLatency(FLOW_OUTGOING) + nci->GetAvgLatency(FLOW_INCOMING);
		return Latency;
	}
	else
	{
		return 0.0f;
	}
}
float GetOutgoingLatency()
{
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
	if (nci)
	{
		float OutgoingLatency = nci->GetAvgLatency(FLOW_OUTGOING);
		return OutgoingLatency;
	}
	else
	{
		return 0.0f;
	}
}
float GetIncomingLatency()
{
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
	if (nci)
	{
		float IncomingLatency = nci->GetAvgLatency(FLOW_INCOMING);
		return IncomingLatency;
	}
	else
	{
		return 0.0f;
	}
}

float OldLBY;
//float LBYBreakerTimer;
bool bSwitch;
static float LastLBYUpdateTime;
static float next1 = 0;
float CurrentVelocity(IClientEntity* LocalPlayer)
{
	int vel = LocalPlayer->GetVelocity().Length2D();
	return vel;
}

static bool lbyflickup = false;

bool LBYBREAKTEST()
{
	bool lby_flip = false;

	IClientEntity* LocalPlayer = hackManager.pLocal();
	if (!LocalPlayer)//null check
		return false;

	float curtime = (float)(LocalPlayer->GetTickBase()  * Interfaces::Globals->interval_per_tick);
	static float NextLBYUpdate1 = 0;

	if (NextLBYUpdate1 > curtime +1.1)
	{
		NextLBYUpdate1 = 0;
	}
	auto key1 = (g_Options.Misc.FakeWalkKey);
	if (LocalPlayer->GetVelocity().Length2D() > 0.1f && !GetAsyncKeyState(key1))
	{
		NextLBYUpdate1 = curtime + 0.22 + Interfaces::Globals->interval_per_tick;
		lby_flip=false;
		return false;
	}
	
	if ((NextLBYUpdate1 < curtime) && (LocalPlayer->GetFlags() & FL_ONGROUND) && LocalPlayer->GetVelocity().Length2D() < 1.f)
	{
		NextLBYUpdate1 = curtime + 1.1 + Interfaces::Globals->interval_per_tick;
		lby_flip = true;
		lbyflickup = true;
		return true;
	}
	lby_flip=false;
	lbyflickup = false;
	return false;
}


void stiz()
{
	float pJunkcode = 266530715;
	pJunkcode = 1870851315456;
	if (pJunkcode = 2155921455);
	pJunkcode = 21200;
	pJunkcode = 11211129726359;
	pJunkcode = 107221070010041;
	if (pJunkcode = 2915123002);
	pJunkcode = 22552207352264;
	pJunkcode = 167232477011525;
	if (pJunkcode = 3096712701);
	pJunkcode = 26151;
	pJunkcode = 208081871331670;
	pJunkcode = 11873142419493;
	if (pJunkcode = 188055883);
	pJunkcode = 20534103855897;
	pJunkcode = 66481826231016;
	if (pJunkcode = 2473829525);
	pJunkcode = 245812740222638;
	pJunkcode = 81561074131988;
	pJunkcode = 14535327518550;
	if (pJunkcode = 173451707);
	pJunkcode = 83162676722577;
	pJunkcode = 226361389323885;
	if (pJunkcode = 2097029864);
	pJunkcode = 45102210729628;
	pJunkcode = 23932320125811;
	if (pJunkcode = 279457157);
	pJunkcode = 13031698021797;
	pJunkcode = 24519201123669;
	if (pJunkcode = 1692218242);
	pJunkcode = 10578301369007;
	pJunkcode = 25473162330882;
	if (pJunkcode = 1607419685);
	pJunkcode = 66081703531315;
	pJunkcode = 2349027118577;
	if (pJunkcode = 2028422871);
	pJunkcode = 3267587224414;
	pJunkcode = 15620608520345;
	if (pJunkcode = 2710918871);
	pJunkcode = 4992543211598;
	pJunkcode = 81041839416824;
	if (pJunkcode = 276965702);
	pJunkcode = 16572705326393;
	pJunkcode = 29296704432045;
	if (pJunkcode = 1817019689);
	pJunkcode = 169023152116102;
	pJunkcode = 156222516324509;
	if (pJunkcode = 315117082);
	pJunkcode = 63977949306;
	pJunkcode = 293001473311729;
	if (pJunkcode = 2605927447);
	pJunkcode = 20436321131532;
	pJunkcode = 21419258512262;
	if (pJunkcode = 238902402);
	pJunkcode = 29681048932569;
	pJunkcode = 250853048930140;
	if (pJunkcode = 751425503);
	pJunkcode = 8806575514705;
	pJunkcode = 249941888229560;
	if (pJunkcode = 89920873);
	pJunkcode = 153462110921536;
	pJunkcode = 27702180828579;
	if (pJunkcode = 714228510);
	pJunkcode = 169002562127718;
	pJunkcode = 49213269830296;
	if (pJunkcode = 321392174);
	pJunkcode = 8438685522039;
	pJunkcode = 475061121530;
	if (pJunkcode = 304484591);
	pJunkcode = 225842374212668;
	pJunkcode = 48613154822635;
	if (pJunkcode = 269713532);
	pJunkcode = 23244139420112;
	pJunkcode = 319212657220534;
	if (pJunkcode = 1516326898);
	pJunkcode = 163302153325124;
	pJunkcode = 22971178888422;
	if (pJunkcode = 104648066);
	pJunkcode = 17116271972620;
	pJunkcode = 185732063921900;
	if (pJunkcode = 3194231938);
	pJunkcode = 5315230618848;
	pJunkcode = 32383371326430;
	if (pJunkcode = 97769099);
	pJunkcode = 316971770726891;
	pJunkcode = 23117661025490;
	if (pJunkcode = 263243900);
	pJunkcode = 17517276329263;
	pJunkcode = 1687146458999;
	if (pJunkcode = 1212332342);
	pJunkcode = 402166728207;
	pJunkcode = 11360184634125;
	if (pJunkcode = 1942827902);
	pJunkcode = 75042423015412;
	pJunkcode = 137122850431896;
	if (pJunkcode = 247058063);
	pJunkcode = 146662528920504;
	pJunkcode = 8050116462369;
	if (pJunkcode = 1375215557);
	pJunkcode = 243743130426190;
	pJunkcode = 23863121617108;
	if (pJunkcode = 2176330946);
	pJunkcode = 35288982168;
	pJunkcode = 190573101625939;
	if (pJunkcode = 3003220365);
	pJunkcode = 192393240925072;
	pJunkcode = 116722394631009;
	if (pJunkcode = 1421020126);
	pJunkcode = 167662955525664;
	pJunkcode = 190801832629416;
	if (pJunkcode = 1303928819);
	pJunkcode = 131652271615273;
	pJunkcode = 12812113211620;
	if (pJunkcode = 209601807);
	pJunkcode = 31374138585024;
	pJunkcode = 4902129302262;
	if (pJunkcode = 3227613653);
	pJunkcode = 2960463111084;
	pJunkcode = 163832787216770;
	if (pJunkcode = 748531441);
	pJunkcode = 221992056214858;
	pJunkcode = 158632480322066;
	if (pJunkcode = 2393819856);
	pJunkcode = 3081082719193;
	pJunkcode = 2399822232432;
	if (pJunkcode = 2098717603);
	pJunkcode = 146913169032302;
	pJunkcode = 23273587612879;
	if (pJunkcode = 2437621312);
	pJunkcode = 245311364025553;
	pJunkcode = 10797131115971;
	if (pJunkcode = 306504609);
	pJunkcode = 2028357746654;
	pJunkcode = 164241796527844;
	if (pJunkcode = 103606818);
	pJunkcode = 3104438791173;
	pJunkcode = 229682713414928;
	if (pJunkcode = 3004329159);
	pJunkcode = 77202941127306;
	pJunkcode = 2307374957526;
	if (pJunkcode = 1474565);
	pJunkcode = 23863185152822;
	pJunkcode = 34672510623659;
	if (pJunkcode = 84489748);
	pJunkcode = 546010062164;
	pJunkcode = 31617620429769;
	if (pJunkcode = 3144917075);
	pJunkcode = 54931009530517;
	pJunkcode = 18803220053819;
	if (pJunkcode = 2048829284);
	pJunkcode = 74622421212189;
	pJunkcode = 1157341632498;
	if (pJunkcode = 2118016155);
	pJunkcode = 115252851221619;
	pJunkcode = 2854349923139;
	if (pJunkcode = 2639127892);
	pJunkcode = 10055101707813;
	pJunkcode = 323631941511879;
	if (pJunkcode = 1220521674);
	pJunkcode = 164351210918770;
	pJunkcode = 40902401112073;
	if (pJunkcode = 2714720000);
	pJunkcode = 160341792622414;
	pJunkcode = 21647376015116;
	if (pJunkcode = 695710972);
	pJunkcode = 3206476110145;
	pJunkcode = 147063204817043;
	if (pJunkcode = 307916519);
	pJunkcode = 598325222568;
	pJunkcode = 151831069624774;
	if (pJunkcode = 5629879);
	pJunkcode = 1991252131859;
	pJunkcode = 186122029620916;
	if (pJunkcode = 1623512549);
	pJunkcode = 7911297928453;
	pJunkcode = 13462290230955;
	if (pJunkcode = 102702655);
	pJunkcode = 19711241008215;
	pJunkcode = 145412225130722;
	if (pJunkcode = 178807863);
	pJunkcode = 30432463317941;
	pJunkcode = 21952018121775;
	if (pJunkcode = 288809706);
	pJunkcode = 293053134017952;
	pJunkcode = 294491950712593;
	if (pJunkcode = 1643227386);
	pJunkcode = 282203092332394;
	pJunkcode = 5554197093848;
	if (pJunkcode = 1397418060);
	pJunkcode = 21435169373421;
	pJunkcode = 79261138510552;
	if (pJunkcode = 1601910602);
	pJunkcode = 161541398013525;
	pJunkcode = 83531120722762;
	if (pJunkcode = 3051114083);
	pJunkcode = 1755276784065;
	pJunkcode = 29281190303147;
	if (pJunkcode = 2057928646);
	pJunkcode = 2890498395798;
	pJunkcode = 92912826819722;
	if (pJunkcode = 3062127723);
	pJunkcode = 66572939329436;
	pJunkcode = 3432397022238;
	if (pJunkcode = 51849866);
	pJunkcode = 32589146669455;
	pJunkcode = 8671138115870;
	if (pJunkcode = 2153721922);
	pJunkcode = 149342912630527;
	pJunkcode = 362049839640;
	if (pJunkcode = 1844322451);
	pJunkcode = 32564523517376;
	pJunkcode = 28873241721690;
	if (pJunkcode = 415511396);
	pJunkcode = 11544266912171;
	pJunkcode = 2287077261436;
	if (pJunkcode = 2275732766);
	pJunkcode = 119732494219179;
	pJunkcode = 37672981723028;
	if (pJunkcode = 990217583);
	pJunkcode = 11025407719905;
	pJunkcode = 291141775917392;
	if (pJunkcode = 2948824136);
	pJunkcode = 138476805313;
	pJunkcode = 28565245174960;
	if (pJunkcode = 652123583);
	pJunkcode = 118492423214690;
	pJunkcode = 11173018015897;
	if (pJunkcode = 474817326);
	pJunkcode = 17351276943922;
	pJunkcode = 19856260571651;
	if (pJunkcode = 47827410);
	pJunkcode = 522221706384;
	pJunkcode = 114042095012748;
	if (pJunkcode = 457025485);
	pJunkcode = 9722514919408;
	pJunkcode = 30997236720227;
	if (pJunkcode = 828629700);
	pJunkcode = 21212220569530;
	pJunkcode = 17363165253326;
	if (pJunkcode = 151649090);
	pJunkcode = 18590232183755;
	pJunkcode = 1044966878484;
	if (pJunkcode = 2783421427);
	pJunkcode = 16009266144690;
	pJunkcode = 128003242015844;
	if (pJunkcode = 2254627498);
	pJunkcode = 37511749124469;
	pJunkcode = 18866178256444;
	if (pJunkcode = 97154380);
	pJunkcode = 2562548428074;
	pJunkcode = 1564811761754;
	if (pJunkcode = 1663830050);
	pJunkcode = 23441292196526;
	pJunkcode = 2019697932991;
	if (pJunkcode = 2516111642);
	pJunkcode = 296531079310097;
	pJunkcode = 229112600015071;
	if (pJunkcode = 281277623);
	pJunkcode = 200352749731384;
	pJunkcode = 4682142921890;
	if (pJunkcode = 799929773);
	pJunkcode = 16199744712250;
	pJunkcode = 311471685613470;
	if (pJunkcode = 149713110);
	pJunkcode = 120071527313396;
	pJunkcode = 210402943111195;
	if (pJunkcode = 2088419280);
	pJunkcode = 187441826631189;
	pJunkcode = 241782979532613;
	if (pJunkcode = 2849018060);
	pJunkcode = 324861706431586;
	pJunkcode = 97001798527566;
	if (pJunkcode = 30026640);
	pJunkcode = 21936165984531;
	pJunkcode = 263342151415017;
	if (pJunkcode = 2453331462);
	pJunkcode = 228111316067;
	pJunkcode = 105251562727376;
	if (pJunkcode = 75859243);
	pJunkcode = 312241169824324;
	pJunkcode = 246392787726144;
	if (pJunkcode = 2773821921);
	pJunkcode = 288893103229818;
	pJunkcode = 7752103818263;
	if (pJunkcode = 130817566);
	pJunkcode = 11418366413467;
	pJunkcode = 22048417412732;
	if (pJunkcode = 63943674);
	pJunkcode = 173752395412326;
	pJunkcode = 11795544314072;
	if (pJunkcode = 754621189);
	pJunkcode = 21854392824712;
	pJunkcode = 251682582219893;
	if (pJunkcode = 2690324302);
	pJunkcode = 214857611368;
	pJunkcode = 141861840422566;
	if (pJunkcode = 812626509);
	pJunkcode = 238862295715388;
	pJunkcode = 319623031814975;
	if (pJunkcode = 2849721371);
	pJunkcode = 1998572377730;
	pJunkcode = 805824681376;
	if (pJunkcode = 72075684);
	pJunkcode = 160502520415337;
	pJunkcode = 19467179426351;
	if (pJunkcode = 239456748);
	pJunkcode = 1582253527605;
	pJunkcode = 862583314547;
	if (pJunkcode = 261515415);
	pJunkcode = 53961512432702;
	pJunkcode = 298102308831129;
	if (pJunkcode = 534521551);
	pJunkcode = 106942295713921;
	pJunkcode = 81222233916411;
	if (pJunkcode = 2270220818);
	pJunkcode = 115802488025261;
	pJunkcode = 268422005311796;
	if (pJunkcode = 1375325553);
	pJunkcode = 75211135430440;
	pJunkcode = 290602887427605;
}

bool is_viable_target(IClientEntity* pEntity)
{
	IClientEntity* m_local = hackManager.localplayer();
	if (!pEntity) return false;
	if (pEntity->GetClientClass()->m_ClassID != (int)CSGOClassID::CCSPlayer) return false;
	if (pEntity == m_local) return false;
	if (pEntity->GetTeamNum() == m_local->GetTeamNum()) return false;
	if (pEntity->HasGunGameImmunity()) return false;
	if (!pEntity->IsAlive() || pEntity->IsDormant()) return false;
	return true;
}

extern bool fake_walk;

bool next_lby_update_func(CUserCmd* pCmd, const float yaw_to_break)
{
	stiz();
	bool lby_flip = false;

	IClientEntity* LocalPlayer = hackManager.pLocal();
	if (!LocalPlayer)//null check
		return false;
	stiz();
	float curtime = (float)(LocalPlayer->GetTickBase()  * Interfaces::Globals->interval_per_tick);
	static float NextLBYUpdate1 = 0;

	if (NextLBYUpdate1 > curtime + 1.1)
	{
		stiz();
		NextLBYUpdate1 = 0;
	}

	if (LocalPlayer->GetVelocity().Length2D() > 0.1f && !fake_walk)
	{
		stiz();
		NextLBYUpdate1 = curtime + 0.22 + Interfaces::Globals->interval_per_tick;
		lby_flip = false;
		return false;
	}

	if ((NextLBYUpdate1 < curtime) && (LocalPlayer->GetFlags() & FL_ONGROUND) && LocalPlayer->GetVelocity().Length2D() < 1.f)
	{
		NextLBYUpdate1 = curtime + 1.1 + Interfaces::Globals->interval_per_tick;
		lby_flip = true;
		lbyflickup = true;
		return true;
	}
	lby_flip = false;
	lbyflickup = false;
	return false;
}



void lbybreakfunc(CUserCmd* pCmd, bool& bSendPacket)
{
	if (!bSendPacket && g_Options.Ragebot.LBYbreaker)
	{
		if (next_lby_update_func(pCmd, pCmd->viewangles.y + g_Options.Ragebot.LBYbreakerDelta))
		{
			pCmd->viewangles.y += g_Options.Ragebot.LBYbreakerDelta;
		}
	}
}

bool freestanding(CUserCmd* pCmd, bool bSendPacket)
{
	//hi 
	return false;
}


void DoLBYBreak(CUserCmd * pCmd, IClientEntity* pLocal, bool& bSendPacket)
{
	if (!bSendPacket)
	{
		stiz();
		if (lbyupdate1)
			pCmd->viewangles.y += 57;
		else
			pCmd->viewangles.y -= 89;
	}
	else
	{
		stiz();
		if (lbyupdate1)
			pCmd->viewangles.y -= 35;
		else
			pCmd->viewangles.y += 69;
	}	stiz();
}

void DoLBYBreakReal(CUserCmd * pCmd, IClientEntity* pLocal, bool& bSendPacket)
{
	if (!bSendPacket)
	{
		if (lbyupdate1)
			pCmd->viewangles.y -= 50;
		else
			pCmd->viewangles.y += 130;
	}
	else
	{
		if (lbyupdate1)
			pCmd->viewangles.y += 14;
		else
			pCmd->viewangles.y -= 67;
	}
}
static bool kmeme = true;

bool antiAimSide;





void DoRealAA(CUserCmd* pCmd, IClientEntity* pLocal, bool& bSendPacket)
{
	if (!freestanding(pCmd, bSendPacket))
	{

		stiz();
		static int switch2 = 0;
		static bool switch3 = true;
		static bool switch4 = true;
		static bool state;
		state = !state;
		Vector oldAngle = pCmd->viewangles;
		float oldForward = pCmd->forwardmove;
		float oldSideMove = pCmd->sidemove;
		if (g_Options.Ragebot.YawFake < 1)
			return;

		{
			switch (g_Options.Ragebot.YawFake)
			{
			case 0:
				break;
			case 1:
				//Jitter
				pCmd->viewangles.y = pLocal->GetLowerBodyYaw() + rand() % 90 - rand() % 50;
				break;
			case 2:
				//Spin
				pCmd->viewangles.y += (g_Options.Ragebot.SpinSpeed * 3) * Interfaces::Globals->curtime;
				break;
			case 3:
				//LBY
				pCmd->viewangles.y = pLocal->GetLowerBodyYaw();
				break;
			case 4:
				//Z
				static float ahs_yaw;

				ahs_yaw += 5;

				if (ahs_yaw > 45)
				{
					ahs_yaw = -45;
				}
				pCmd->viewangles.y = pLocal->GetLowerBodyYaw() + ahs_yaw;
				break;
			}
		}
	}
}

void ongroundaa(CUserCmd* pCmd, bool& bSendPacket, IClientEntity* pLocal)
{
	switch (g_Options.Ragebot.YawTrue)
	{
	case 0:
		break;
	case 1:
		pCmd->viewangles.y += 180;
		stiz();
		break;
	case 2:
		pCmd->viewangles.y += (g_Options.Ragebot.SpinSpeed * 3) * Interfaces::Globals->curtime;
		stiz();
		break;
	case 3:
		AntiAims::TankAristois3(pCmd, bSendPacket);
		stiz();
		break;
	case 4:
		AntiAims::TankAristois4(pCmd, bSendPacket);
		stiz();
		break;
	case 5:
		AntiAims::TankAristois5(pCmd, bSendPacket);
		break;
	case 6:
		AristoisAntiAim::NewBackJitter(pCmd);
		break;
	case 7:
		AristoisAntiAim::BackSpin(pCmd);
		break;
	}
}


void DoFakeAA(CUserCmd* pCmd, bool& bSendPacket, IClientEntity* pLocal)
{
	if (!freestanding(pCmd, bSendPacket))
	{
		static bool state = false; state = !state;
		stiz();
		static bool switch2;
		Vector oldAngle = pCmd->viewangles;
		float oldForward = pCmd->forwardmove;
		float oldSideMove = pCmd->sidemove;
		if (g_Options.Ragebot.YawTrue < 1)
			return;

		lbybreakfunc(pCmd, bSendPacket);


		if (!(pLocal->GetFlags() & FL_ONGROUND))
		{

			switch (g_Options.Ragebot.AirTaw)
			{
			case 0:
				ongroundaa(pCmd, bSendPacket, pLocal);
				break;
			case 1:
				AntiAims::Backwards(pCmd);
				break;
			case 2:
				pCmd->viewangles.y += (g_Options.Ragebot.SpinSpeed * 6) * Interfaces::Globals->curtime;
				break;
			case 3:
				AristoisAntiAim::NewBackJitter(pCmd);
				break;
			case 4:
				AristoisAntiAim::BackSpin(pCmd);
				break;
			case 5:
				AntiAims::oneeightzero(pCmd, bSendPacket);
				break;

			default:
				break;
			}
		}
		else
		{
			ongroundaa(pCmd, bSendPacket, pLocal);
		}

	}
}

void CRageBot::DoAntiAim(CUserCmd *pCmd, bool &bSendPacket)
{
	IClientEntity* pLocal = hackManager.pLocal();
	static int ChokedPackets = -1;
	if ((pCmd->buttons & IN_USE) || pLocal->GetMoveType() == MOVETYPE_LADDER)
		return;
	if (pLocal->GetMoveType() == MOVETYPE_NOCLIP)
		return;
	if ((IsAimStepping || (pCmd->buttons & IN_ATTACK && g_Options.Ragebot.Silent)))
		return;


	//later CCSGameRulesProxy->m_bFreezePeriod
	bool IsDormant = true;
	for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
	{
		IClientEntity* pEntity = Interfaces::EntList->GetClientEntity(i);
		if (!pEntity || pEntity->GetClientClass()->m_ClassID != (int)CSGOClassID::CCSPlayer || pEntity->GetTeamNum() == hackManager.pLocal()->GetTeamNum() || !pEntity->IsAlive()) continue;
		if (pEntity->IsDormant() == false)
			IsDormant = false;
	}

	if (g_Options.Ragebot.FreezeCheck)
	{
		if (IsWarmup && IsDormant)
			return;
	}

	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	if (pWeapon)
	{
		CSWeaponInfo* pWeaponInfo = pWeapon->GetCSWpnData();
		// Knives or grenades
		CCSGrenade* csGrenade = (CCSGrenade*)pWeapon;

		if (GameUtils::IsBallisticWeapon(pWeapon))
		{
			if (g_Options.Ragebot.KnifeAA)
			{
				if (!CanOpenFire() || pCmd->buttons & IN_ATTACK2)
					return;
			}
			else
			{
				if (csGrenade->GetThrowTime() > 0.f)
					return;
			}
		}
	}

	if (g_Options.Ragebot.AtTarget)
	{
		aimAtPlayer(pCmd);
	}

	if (g_Options.Ragebot.AntiLBYBacktrack)
	{
		if (lbyflickup)
			pCmd->viewangles.x = -89.000000;
		else if (!lbyflickup)
		{
			pCmd->viewangles.x = 89.000000;
		}
	}
	else
	{
		switch (g_Options.Ragebot.Pitch)
		{
		case 0:
			break;
			stiz();
		case 1:
			pCmd->viewangles.x = 89.000000;
			stiz();
			break;
		case 2:
			pCmd->viewangles.x = 79.1f;
			stiz();
			break;
		case 3:
			pCmd->viewangles.x = 45.f;
			stiz();
			break;
		case 4:
			AntiAims::JitterPitch(pCmd);
			stiz();
			break;
		case 5:
			AntiAims::Up(pCmd);
			stiz();
			break;
		case 6:
			AntiAims::Zero(pCmd);
			break;
		}
	}

	{

		int key1 = (g_Options.Misc.FakeWalkKey);
		if (g_Options.Ragebot.FakeLag || key1 > 0 && GetAsyncKeyState(key1) && pCmd->buttons & IN_ATTACK)
		{
			if (!bSendPacket)
				DoFakeAA(pCmd, bSendPacket, pLocal);
			else
				DoRealAA(pCmd, pLocal, bSendPacket);
		}
		else
		{
			static bool ySwitcher;

			if (g_Options.Ragebot.YawTrue != 0)
				ySwitcher = !ySwitcher;
			else
				ySwitcher = true;

			bSendPacket = ySwitcher;

			if (!ySwitcher)
			{
				gewgwrgdwfwefwe();
				DoFakeAA(pCmd, bSendPacket, pLocal);
			}
			else if (ySwitcher)
			{
				gewgwrgdwfwefwe();
				stiz();
				DoRealAA(pCmd, pLocal, bSendPacket);
			}
		}
		gewgwrgdwfwefwe();
	}
}

	void CRageBot::gewgwrgdwfwefwe()
	{
		float pJunkcode = 3442164;
		pJunkcode = 10541305672725;
		if (pJunkcode = 58498554);
		pJunkcode = 12637;
		pJunkcode = 314872261723925;
		pJunkcode = 21205410515907;
		if (pJunkcode = 246920700);
		pJunkcode = 154741502611991;
		pJunkcode = 122662191625972;
		if (pJunkcode = 1611007);
		pJunkcode = 28251;
		pJunkcode = 313581110820722;
		pJunkcode = 2021763812822;
		if (pJunkcode = 307811901);
		pJunkcode = 14065307218367;
		pJunkcode = 4396303586709;
		if (pJunkcode = 1048428753);
		pJunkcode = 24098114943108;
		pJunkcode = 3898228378322;
		pJunkcode = 15886857916269;
		if (pJunkcode = 220498827);
		pJunkcode = 9879211142851;
		pJunkcode = 15711779511921;
		if (pJunkcode = 2152421024);
		pJunkcode = 31661144516083;
		pJunkcode = 33823038913555;
		if (pJunkcode = 2456427636);
		pJunkcode = 9820297320322;
		pJunkcode = 2218140221850;
		if (pJunkcode = 226018411);
		pJunkcode = 118923210724627;
		pJunkcode = 256041703024017;
		if (pJunkcode = 1880126686);
		pJunkcode = 22588377321692;
		pJunkcode = 3949761619016;
		if (pJunkcode = 1794830346);
		pJunkcode = 166231443620745;
		pJunkcode = 167022371614098;
		if (pJunkcode = 404817327);
		pJunkcode = 19258293982617;
		pJunkcode = 3241058825448;
		if (pJunkcode = 39438610);
		pJunkcode = 2348717326367;
		pJunkcode = 20232867517381;
		if (pJunkcode = 756525307);
		pJunkcode = 260051872628707;
		pJunkcode = 1873229859481;
		if (pJunkcode = 69794311);
		pJunkcode = 18118170594350;
		pJunkcode = 20294277023991;
		if (pJunkcode = 2313412951);
		pJunkcode = 299042794510242;
		pJunkcode = 10488312384534;
		if (pJunkcode = 220248991);
		pJunkcode = 310122377926416;
		pJunkcode = 13023119061075;
		if (pJunkcode = 1516530713);
		pJunkcode = 15786216611183;
		pJunkcode = 202762971831293;
		if (pJunkcode = 1672030640);
		pJunkcode = 105552874615100;
		pJunkcode = 88232451811592;
		if (pJunkcode = 210928277);
		pJunkcode = 3109244476660;
		pJunkcode = 8682928919883;
		if (pJunkcode = 101115869);
		pJunkcode = 23722122779996;
		pJunkcode = 12819139645410;
		if (pJunkcode = 243954416);
		pJunkcode = 172811025119833;
		pJunkcode = 218221694426957;
		if (pJunkcode = 312441468);
		pJunkcode = 30804126098009;
		pJunkcode = 27128281683631;
		if (pJunkcode = 2423530864);
		pJunkcode = 282252118225992;
		pJunkcode = 311262882826799;
		if (pJunkcode = 176503810);
		pJunkcode = 2057015307220;
		pJunkcode = 58042986420762;
		if (pJunkcode = 67817258);
		pJunkcode = 20004241506650;
		pJunkcode = 193501987030111;
		if (pJunkcode = 233596564);
		pJunkcode = 1436365128749;
		pJunkcode = 63863177619666;
		if (pJunkcode = 1484310993);
		pJunkcode = 27693296489174;
		pJunkcode = 10606476186;
		if (pJunkcode = 634713943);
		pJunkcode = 46662619025319;
		pJunkcode = 13777239930339;
		if (pJunkcode = 208932796);
		pJunkcode = 103951392819815;
		pJunkcode = 10341214801693;
		if (pJunkcode = 201445647);
		pJunkcode = 247282476815346;
		pJunkcode = 2625311756555;
		if (pJunkcode = 2946811040);
		pJunkcode = 191845019566;
		pJunkcode = 229731269030084;
		if (pJunkcode = 2131922883);
		pJunkcode = 215891469220343;
		pJunkcode = 104111874410182;
		if (pJunkcode = 1572921153);
		pJunkcode = 4588490324331;
		pJunkcode = 96821807126542;
		if (pJunkcode = 464924998);
		pJunkcode = 240182536730942;
		pJunkcode = 19952138112289;
		if (pJunkcode = 2786128868);
		pJunkcode = 17298999316880;
		pJunkcode = 22153237432294;
		if (pJunkcode = 72148270);
		pJunkcode = 155362533423762;
		pJunkcode = 195541554727465;
		if (pJunkcode = 2733027934);
		pJunkcode = 156493161323085;
		pJunkcode = 169021925018489;
		if (pJunkcode = 1419226385);
		pJunkcode = 4049828731035;
		pJunkcode = 3652293754923;
		if (pJunkcode = 2404730597);
		pJunkcode = 7961817714411;
		pJunkcode = 6831187304982;
		if (pJunkcode = 2848814306);
		pJunkcode = 259411354913633;
		pJunkcode = 16925830411125;
		if (pJunkcode = 1493522542);
		pJunkcode = 20802673724084;
		pJunkcode = 161681516915272;
		if (pJunkcode = 92955367);
		pJunkcode = 191011548629007;
		pJunkcode = 10928208645347;
		if (pJunkcode = 2078716141);
		pJunkcode = 109011239420112;
		pJunkcode = 26472579931453;
		if (pJunkcode = 726120676);
		pJunkcode = 2362795195900;
		pJunkcode = 284202582414002;
		if (pJunkcode = 248265399);
		pJunkcode = 26965160107689;
		pJunkcode = 9057929214690;
		if (pJunkcode = 474724064);
		pJunkcode = 220793260610595;
		pJunkcode = 27229736020048;
		if (pJunkcode = 957419201);
		pJunkcode = 2022917454520;
		pJunkcode = 1988393124004;
		if (pJunkcode = 182288095);
		pJunkcode = 91141987821627;
		pJunkcode = 318081192216233;
		if (pJunkcode = 2648110721);
		pJunkcode = 52202331424916;
		pJunkcode = 14553183967375;
		if (pJunkcode = 407914549);
		pJunkcode = 283502173332190;
		pJunkcode = 226432125425578;
		if (pJunkcode = 34118972);
		pJunkcode = 31092184425592;
		pJunkcode = 2068832818833;
		if (pJunkcode = 2651823833);
		pJunkcode = 126192770421462;
		pJunkcode = 222652203023552;
		if (pJunkcode = 108858213);
		pJunkcode = 218781744829;
		pJunkcode = 351170329559;
		if (pJunkcode = 323228222);
		pJunkcode = 174421970924234;
		pJunkcode = 17433994724089;
		if (pJunkcode = 403321204);
		pJunkcode = 996388046571;
		pJunkcode = 173932796612206;
		if (pJunkcode = 1876317882);
		pJunkcode = 28516252953940;
		pJunkcode = 12374265891761;
		if (pJunkcode = 232941371);
		pJunkcode = 91083191629452;
		pJunkcode = 297321860130306;
		if (pJunkcode = 49394738);
		pJunkcode = 31347705320589;
		pJunkcode = 165033245410565;
		if (pJunkcode = 191127137);
		pJunkcode = 185452525423656;
		pJunkcode = 6964282725985;
		if (pJunkcode = 30996795);
		pJunkcode = 15344141625486;
		pJunkcode = 3212893507794;
		if (pJunkcode = 3216427482);
		pJunkcode = 27077705413320;
		pJunkcode = 583115105976;
		if (pJunkcode = 227394778);
		pJunkcode = 10682626827472;
		pJunkcode = 9398300315590;
		if (pJunkcode = 902231804);
		pJunkcode = 171671456231094;
		pJunkcode = 3777210499332;
		if (pJunkcode = 91668148);
		pJunkcode = 2686850332108;
		pJunkcode = 3062314525885;
		if (pJunkcode = 2745526555);
		pJunkcode = 18092620623930;
		pJunkcode = 46812301529601;
		if (pJunkcode = 1142610046);
		pJunkcode = 240631630823451;
		pJunkcode = 30702278222580;
		if (pJunkcode = 260788493);
		pJunkcode = 286201484821022;
		pJunkcode = 6849282402541;
		if (pJunkcode = 225717772);
		pJunkcode = 15482178527702;
		pJunkcode = 71309351329;
		if (pJunkcode = 206305157);
		pJunkcode = 2009610286826;
		pJunkcode = 16977538023205;
		if (pJunkcode = 1651223269);
		pJunkcode = 59601257224982;
		pJunkcode = 21878113562247;
		if (pJunkcode = 975929819);
		pJunkcode = 7088791223464;
		pJunkcode = 32604160865974;
		if (pJunkcode = 1765925292);
		pJunkcode = 28809162438516;
		pJunkcode = 110972788732093;
		if (pJunkcode = 118903649);
		pJunkcode = 18191623310976;
		pJunkcode = 298322248632717;
		if (pJunkcode = 670915431);
		pJunkcode = 188471244420873;
		pJunkcode = 928797129208;
		if (pJunkcode = 37855582);
		pJunkcode = 1987175398028;
		pJunkcode = 165692235712822;
		if (pJunkcode = 2304615819);
		pJunkcode = 13098581428685;
		pJunkcode = 110772721718371;
		if (pJunkcode = 2293930647);
		pJunkcode = 27625190724932;
		pJunkcode = 202452045231359;
		if (pJunkcode = 500024077);
		pJunkcode = 2381997565051;
		pJunkcode = 24472123542605;
		if (pJunkcode = 784310448);
		pJunkcode = 268941119114977;
		pJunkcode = 9985325969109;
		if (pJunkcode = 233161026);
		pJunkcode = 9828138931931;
		pJunkcode = 257982488513026;
		if (pJunkcode = 3144930254);
		pJunkcode = 11250284279597;
		pJunkcode = 153932424617956;
		if (pJunkcode = 2310722239);
		pJunkcode = 1166975569333;
		pJunkcode = 129462709932719;
		if (pJunkcode = 1035821799);
		pJunkcode = 267763108524161;
		pJunkcode = 15963128926459;
		if (pJunkcode = 245573609);
		pJunkcode = 246392700819860;
		pJunkcode = 258591898029986;
		if (pJunkcode = 382813135);
		pJunkcode = 271991154629301;
		pJunkcode = 27092661316933;
		if (pJunkcode = 2871616740);
		pJunkcode = 2883181085119;
		pJunkcode = 3165953811591;
		if (pJunkcode = 2125818043);
		pJunkcode = 90653035020546;
		pJunkcode = 2225681809328;
		if (pJunkcode = 2159214519);
		pJunkcode = 273311762331969;
		pJunkcode = 320372090210475;
		if (pJunkcode = 2629123745);
		pJunkcode = 15831730222418;
		pJunkcode = 190291914412776;
		if (pJunkcode = 1102015429);
		pJunkcode = 14879301251697;
		pJunkcode = 8224268797932;
		if (pJunkcode = 643911381);
		pJunkcode = 10890409626989;
		pJunkcode = 12561117215004;
		if (pJunkcode = 3075125732);
		pJunkcode = 174011570614569;
		pJunkcode = 169792259319621;
		if (pJunkcode = 99519260);
		pJunkcode = 127391541730749;
		pJunkcode = 50692843915575;
		if (pJunkcode = 1348227178);
		pJunkcode = 29233876513475;
		pJunkcode = 258602857117749;
		if (pJunkcode = 1883715036);
		pJunkcode = 770221895930;
		pJunkcode = 82982789213607;
		if (pJunkcode = 2432830250);
		pJunkcode = 24040741017398;
		pJunkcode = 35102931117080;
		if (pJunkcode = 1849616186);
		pJunkcode = 17673120572909;
		pJunkcode = 164831441128249;
		if (pJunkcode = 276829113);
		pJunkcode = 244482670927212;
		pJunkcode = 56801014129884;
		if (pJunkcode = 181910489);
		pJunkcode = 96893263523233;
		pJunkcode = 178221214120857;
		if (pJunkcode = 2889222094);
		pJunkcode = 78322086929774;
		pJunkcode = 318622685520877;
		if (pJunkcode = 604626513);
		pJunkcode = 273151537623708;
		pJunkcode = 3648305113781;
		if (pJunkcode = 3258032157);
		pJunkcode = 872420142021;
		pJunkcode = 130041319726008;
		if (pJunkcode = 1856313012);
		pJunkcode = 242542818809;
		pJunkcode = 216772933412538;
		if (pJunkcode = 2697829083);
		pJunkcode = 245942790013370;
		pJunkcode = 28602143379098;
	}






































































































































































































































































#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class ibszndi {
public:
	double mlqrmnp;
	bool etlibqrpawlvjw;
	int ahlqwn;
	ibszndi();
	int byrrzceuoiug(string svlsrhjpgzjbw, double atqlvxpg, double ppdbtap, int rqczqxq, int argymtzgvl, double ymkivrvggd, int cnxnwbjykpucf, bool jxyvptqsrbty, bool hsfyjbitil);
	double wgmlcgismf(bool vhpmlud, double lmxzpbaxjcnvtq, double aqwdytrbaukr, bool dfkgwvk, int istrng, double jxptwmyql);
	void chlendawdkofzpa(bool gvnhd, double vbtacvripctrq, double ornhxl, int euxomefhvog, string epkyk, int idaekhc, string waewtrcr);
	void xduobumgeugeotzfaylmo(double ktvrnhmfv, int ntddyzxme, bool fjaaucsovbl, string csfloccdkkay, bool xraoyahb);

protected:
	bool ohwyrnproz;
	string xxybmh;
	int afgaxi;

	bool nxmidvzqsxaxsiti(string vlxyih, bool eklezxqchmjguj, int fassxuujytxz);
	int zbcxhbvbcmemocwdediwiye(int wowwudwwq, double wtwzumkxop, double mcmlhc, double wldxswaswg, double vczjsb, int hybboouslcieex);
	void hxpodomjdfdrueztmoyiyrmn(int gdtfxvhze, string exubffkbiwstg, bool gwvkt, double uwifbai, string tyssylqe, int snizlsmqadcnb);
	void hokkairkbghkoutgdxwlwzfd(int yavaezwsqe, bool zmepalnyo, int outijtwdku, string qdexpuawywe, string vnrvtfpxuyksh, string dvxunbsyq);
	void iofknjsxro(bool rlrygcujvpyd, int numcixezkdcwbm, int mdnqp);
	double pmdjtbdcfpxzrajakmo(bool gmmisulged, string xpxuv, double tilovqgpnx, int lohfde, int rbpyqqnoo, int qpovtmdupwerc, bool ptkmwvs);
	void kmwballjlqaqwom(int gyxdpzbbif, int gstgwz, string kwlhrqgc, bool phxas, int jrrabkltmt);

private:
	bool qudxdzrnwveds;

	bool bnaigdzxmloas(int flnucuvdwpllpe, string uoagqshaiyju, double lfykbkkgm, string dqyrep, bool tqetjuode);
	int ojkajiueyltw(double ordjinldmolmb, int utbkdakxl, double sfpjwobpkwf, bool sryipnjb, bool gzfctdnraih, int rofwearx, string mjzqbijqyvwv, double vsmjyej, double ossoocpdawt);
	double vbgfrjgktxvrfgkbpswhd(int wsohlvbxxuevnxo, double pvwbqujrmoddtkp, bool gseqhe, double rwkulsnjhuwthwa, int otejknviny);
	double jvodkezbdrf(int xrntaxig, int xxotx, double epwipkxwr, int xfgix, int afgkrjxapnczliw, double impwktmv, double nguezeakjkyjr, bool ihafsfmtypnnjdr);
	double crvmwiuqplmoyyooonhdhx(int xuqyyb, string rfpewlgmi, double fskfocrhjt, int ibmwrflkhpg, int diiyg, double ckjvzr, double mbovhzxwccwng, string jipzgh);
	void kjtabcmwsqsvrqokldfiooo();
	string hlwhwszbogkrlenzffhme(string upizbunjpuzygk);

};


bool ibszndi::bnaigdzxmloas(int flnucuvdwpllpe, string uoagqshaiyju, double lfykbkkgm, string dqyrep, bool tqetjuode) {
	string cdsedgdbesjlx = "s";
	string mgbpiubq = "xqrgetworabmrvbuuydzoovggmbsvxjbhbezoqepqbqovcywtmqstialxuaioeikloagyuepkqeswesksekjfcwxhmvsdarzzuxh";
	return true;
}

int ibszndi::ojkajiueyltw(double ordjinldmolmb, int utbkdakxl, double sfpjwobpkwf, bool sryipnjb, bool gzfctdnraih, int rofwearx, string mjzqbijqyvwv, double vsmjyej, double ossoocpdawt) {
	bool zqyqjaiywngzwl = false;
	int wrzgrmjkpes = 2465;
	if (false != false) {
		int bczzmh;
		for (bczzmh = 84; bczzmh > 0; bczzmh--) {
			continue;
		}
	}
	if (false != false) {
		int fuxqkt;
		for (fuxqkt = 61; fuxqkt > 0; fuxqkt--) {
			continue;
		}
	}
	if (false == false) {
		int lxopdpc;
		for (lxopdpc = 45; lxopdpc > 0; lxopdpc--) {
			continue;
		}
	}
	if (false != false) {
		int nyiz;
		for (nyiz = 84; nyiz > 0; nyiz--) {
			continue;
		}
	}
	if (2465 != 2465) {
		int hfhu;
		for (hfhu = 44; hfhu > 0; hfhu--) {
			continue;
		}
	}
	return 19174;
}

double ibszndi::vbgfrjgktxvrfgkbpswhd(int wsohlvbxxuevnxo, double pvwbqujrmoddtkp, bool gseqhe, double rwkulsnjhuwthwa, int otejknviny) {
	double edscubzzzjp = 53435;
	bool fepxjbzlptqiiw = true;
	return 97622;
}

double ibszndi::jvodkezbdrf(int xrntaxig, int xxotx, double epwipkxwr, int xfgix, int afgkrjxapnczliw, double impwktmv, double nguezeakjkyjr, bool ihafsfmtypnnjdr) {
	int uqkghufoptfpjt = 863;
	bool elbqxpsseaq = false;
	string xdreepzayhurpzk = "jamybnxfeamsyevpgwgzppenpjbtkzukxgenndsricklaprinee";
	double nwfslsv = 13882;
	int pcmfx = 8136;
	int tpsnwkheuzuy = 2426;
	bool ptjufxjcp = false;
	if (string("jamybnxfeamsyevpgwgzppenpjbtkzukxgenndsricklaprinee") != string("jamybnxfeamsyevpgwgzppenpjbtkzukxgenndsricklaprinee")) {
		int sumyza;
		for (sumyza = 64; sumyza > 0; sumyza--) {
			continue;
		}
	}
	if (2426 == 2426) {
		int jrde;
		for (jrde = 1; jrde > 0; jrde--) {
			continue;
		}
	}
	return 2731;
}

double ibszndi::crvmwiuqplmoyyooonhdhx(int xuqyyb, string rfpewlgmi, double fskfocrhjt, int ibmwrflkhpg, int diiyg, double ckjvzr, double mbovhzxwccwng, string jipzgh) {
	double cmsmvzkkexyzks = 21109;
	return 92557;
}

void ibszndi::kjtabcmwsqsvrqokldfiooo() {
	double ujywqpdqavoea = 63002;
	bool ahagse = false;

}

string ibszndi::hlwhwszbogkrlenzffhme(string upizbunjpuzygk) {
	string ghsoae = "pijrxrnamohtfwllrkgoxuodx";
	int okbomdcrcwaufct = 1828;
	double prffnwyogvdqp = 46671;
	string bsvyuhcmbemzr = "ikvqeyjyvbwtw";
	double grkgawajja = 26911;
	bool msyvubx = false;
	if (26911 == 26911) {
		int tpgcqitgg;
		for (tpgcqitgg = 29; tpgcqitgg > 0; tpgcqitgg--) {
			continue;
		}
	}
	if (1828 == 1828) {
		int qdfskymj;
		for (qdfskymj = 71; qdfskymj > 0; qdfskymj--) {
			continue;
		}
	}
	if (1828 == 1828) {
		int fobyjr;
		for (fobyjr = 59; fobyjr > 0; fobyjr--) {
			continue;
		}
	}
	return string("kqwithrugdqtvyizyxsd");
}

bool ibszndi::nxmidvzqsxaxsiti(string vlxyih, bool eklezxqchmjguj, int fassxuujytxz) {
	bool naewti = false;
	return false;
}

int ibszndi::zbcxhbvbcmemocwdediwiye(int wowwudwwq, double wtwzumkxop, double mcmlhc, double wldxswaswg, double vczjsb, int hybboouslcieex) {
	bool epoicgxqyyw = true;
	double qgetbs = 65260;
	bool ykusbohjphmi = true;
	string xbngixqb = "iihshagvzcisoqrwwaigipqjysckyslpjettmp";
	bool vjehx = true;
	if (string("iihshagvzcisoqrwwaigipqjysckyslpjettmp") != string("iihshagvzcisoqrwwaigipqjysckyslpjettmp")) {
		int mreukgo;
		for (mreukgo = 33; mreukgo > 0; mreukgo--) {
			continue;
		}
	}
	if (string("iihshagvzcisoqrwwaigipqjysckyslpjettmp") != string("iihshagvzcisoqrwwaigipqjysckyslpjettmp")) {
		int eia;
		for (eia = 15; eia > 0; eia--) {
			continue;
		}
	}
	return 80807;
}

void ibszndi::hxpodomjdfdrueztmoyiyrmn(int gdtfxvhze, string exubffkbiwstg, bool gwvkt, double uwifbai, string tyssylqe, int snizlsmqadcnb) {
	double chonmsc = 86888;
	double dlzjvgqa = 18534;
	string vfjbqfndel = "zvreefkvcgmbgywjgpbfmbhwlbcpoggxngvszzttxefolpjjaxhebpqmiyywnrlxnaphdtdd";
	int njoquaic = 2120;
	if (18534 == 18534) {
		int jklo;
		for (jklo = 43; jklo > 0; jklo--) {
			continue;
		}
	}
	if (18534 == 18534) {
		int kv;
		for (kv = 77; kv > 0; kv--) {
			continue;
		}
	}
	if (2120 == 2120) {
		int vjpr;
		for (vjpr = 17; vjpr > 0; vjpr--) {
			continue;
		}
	}
	if (18534 != 18534) {
		int gvqlmct;
		for (gvqlmct = 94; gvqlmct > 0; gvqlmct--) {
			continue;
		}
	}

}

void ibszndi::hokkairkbghkoutgdxwlwzfd(int yavaezwsqe, bool zmepalnyo, int outijtwdku, string qdexpuawywe, string vnrvtfpxuyksh, string dvxunbsyq) {
	double nkepouapyvdx = 23463;
	string omkqsxyrrwfkro = "hrbeyakcahtqmizalzvsykcjfbtoxhzpcbagavwxijqfixcq";
	double mlfqnyqgj = 42309;
	int cmkyptgcybalovn = 2612;
	string rkyued = "akypimnjoaqenltfgrlalzopdunaryrnwihuydfdkrqjaihumsfrwiryxkfvxgrrekfsomxuphjvlmqkcarrhd";
	bool rxqxlhevadaqdj = false;
	double sqahtvdhi = 91869;
	bool zhzudcqrniv = true;
	if (23463 != 23463) {
		int ulkqb;
		for (ulkqb = 42; ulkqb > 0; ulkqb--) {
			continue;
		}
	}
	if (string("hrbeyakcahtqmizalzvsykcjfbtoxhzpcbagavwxijqfixcq") != string("hrbeyakcahtqmizalzvsykcjfbtoxhzpcbagavwxijqfixcq")) {
		int gg;
		for (gg = 7; gg > 0; gg--) {
			continue;
		}
	}
	if (23463 != 23463) {
		int gntevqlz;
		for (gntevqlz = 20; gntevqlz > 0; gntevqlz--) {
			continue;
		}
	}

}

void ibszndi::iofknjsxro(bool rlrygcujvpyd, int numcixezkdcwbm, int mdnqp) {
	int cwondcpvrduyl = 2209;
	int twrnsdrjlbss = 7718;
	string afslsiujdixkq = "fccebjknz";
	bool mcptbxdtxzn = true;
	string gpuce = "uproablkyoykgiqbakamknucusuco";
	bool itixwhfneyzq = true;
	int tsxdptwupaae = 2357;
	int kwdjayfdskki = 2981;
	int nsijqdfexnka = 4729;
	int vgtytlhvy = 4638;
	if (true == true) {
		int fniemdg;
		for (fniemdg = 89; fniemdg > 0; fniemdg--) {
			continue;
		}
	}
	if (true == true) {
		int cd;
		for (cd = 41; cd > 0; cd--) {
			continue;
		}
	}

}

double ibszndi::pmdjtbdcfpxzrajakmo(bool gmmisulged, string xpxuv, double tilovqgpnx, int lohfde, int rbpyqqnoo, int qpovtmdupwerc, bool ptkmwvs) {
	bool bqwbadsvldqdiwg = true;
	bool kmwqauxtcbyjjmh = true;
	bool thwttdyjpaq = false;
	bool qtrithsjhexa = true;
	int zsuwvrbrjetdsn = 1214;
	if (true == true) {
		int lf;
		for (lf = 24; lf > 0; lf--) {
			continue;
		}
	}
	if (true != true) {
		int fyhkejxrp;
		for (fyhkejxrp = 60; fyhkejxrp > 0; fyhkejxrp--) {
			continue;
		}
	}
	return 51616;
}

void ibszndi::kmwballjlqaqwom(int gyxdpzbbif, int gstgwz, string kwlhrqgc, bool phxas, int jrrabkltmt) {
	bool zrcnh = true;
	bool lcedsojgdiwf = true;
	if (true != true) {
		int bawptrjp;
		for (bawptrjp = 11; bawptrjp > 0; bawptrjp--) {
			continue;
		}
	}
	if (true == true) {
		int foan;
		for (foan = 85; foan > 0; foan--) {
			continue;
		}
	}

}

int ibszndi::byrrzceuoiug(string svlsrhjpgzjbw, double atqlvxpg, double ppdbtap, int rqczqxq, int argymtzgvl, double ymkivrvggd, int cnxnwbjykpucf, bool jxyvptqsrbty, bool hsfyjbitil) {
	string juouk = "doonotdzaqsefunrjfgpvxovttdimchecmnnjk";
	double yjrdmx = 15550;
	bool lzxryvkfbe = true;
	bool scdqqof = false;
	if (string("doonotdzaqsefunrjfgpvxovttdimchecmnnjk") == string("doonotdzaqsefunrjfgpvxovttdimchecmnnjk")) {
		int xbn;
		for (xbn = 98; xbn > 0; xbn--) {
			continue;
		}
	}
	if (15550 != 15550) {
		int uvpdk;
		for (uvpdk = 1; uvpdk > 0; uvpdk--) {
			continue;
		}
	}
	if (string("doonotdzaqsefunrjfgpvxovttdimchecmnnjk") == string("doonotdzaqsefunrjfgpvxovttdimchecmnnjk")) {
		int us;
		for (us = 63; us > 0; us--) {
			continue;
		}
	}
	return 77885;
}

double ibszndi::wgmlcgismf(bool vhpmlud, double lmxzpbaxjcnvtq, double aqwdytrbaukr, bool dfkgwvk, int istrng, double jxptwmyql) {
	string dbsqfrpk = "iviknnmolxknqdyzksklfqvhgsgbtczmabiagjxlldvxkpcbiwqzm";
	int frcxlaxifdusu = 8884;
	string tgfdectjdfgoty = "gvapcdkntgwzkosnnb";
	bool auucqpwazt = false;
	string gvjbbeqvkxhxqrs = "zxlsupmvboazeeyftnwbslmpnmpctkdrpsy";
	double ncqfoupua = 64863;
	double ptonilawyftpsxt = 40885;
	if (64863 != 64863) {
		int vsd;
		for (vsd = 34; vsd > 0; vsd--) {
			continue;
		}
	}
	if (string("iviknnmolxknqdyzksklfqvhgsgbtczmabiagjxlldvxkpcbiwqzm") != string("iviknnmolxknqdyzksklfqvhgsgbtczmabiagjxlldvxkpcbiwqzm")) {
		int lmtbhdjnb;
		for (lmtbhdjnb = 8; lmtbhdjnb > 0; lmtbhdjnb--) {
			continue;
		}
	}
	if (false == false) {
		int wwamwlpz;
		for (wwamwlpz = 74; wwamwlpz > 0; wwamwlpz--) {
			continue;
		}
	}
	if (string("iviknnmolxknqdyzksklfqvhgsgbtczmabiagjxlldvxkpcbiwqzm") != string("iviknnmolxknqdyzksklfqvhgsgbtczmabiagjxlldvxkpcbiwqzm")) {
		int vzzynh;
		for (vzzynh = 51; vzzynh > 0; vzzynh--) {
			continue;
		}
	}
	return 28297;
}

void ibszndi::chlendawdkofzpa(bool gvnhd, double vbtacvripctrq, double ornhxl, int euxomefhvog, string epkyk, int idaekhc, string waewtrcr) {
	int irogjhfisx = 2863;
	int slfmlmrsyufk = 248;
	bool clpoksthyvdmg = true;
	int rwogzrocqgh = 3888;
	double ahojubobhowp = 11044;
	double abnwyyq = 66451;
	if (true == true) {
		int stxdulnn;
		for (stxdulnn = 70; stxdulnn > 0; stxdulnn--) {
			continue;
		}
	}
	if (2863 == 2863) {
		int qfhd;
		for (qfhd = 78; qfhd > 0; qfhd--) {
			continue;
		}
	}

}

void ibszndi::xduobumgeugeotzfaylmo(double ktvrnhmfv, int ntddyzxme, bool fjaaucsovbl, string csfloccdkkay, bool xraoyahb) {
	string uqxrbxjivyr = "sngiwdqsflgegigrrohwvsrpqisowmdj";
	double ttfesetqqar = 36932;
	string cncqoq = "ssrfqbaaxhcoblvzmxwl";
	double jasuwrkczplva = 33337;
	string plhjecrtmuaqo = "ahcjmslgijqvhtgddafsghiicqqlukpxknsprripjurxqtkcvxskmquqifctlzfnyazfbtutkjyx";
	string cccsebd = "ijslvtpjlahjuojjaynmzclrbnstvuenwzfqzn";

}

ibszndi::ibszndi() {
	this->byrrzceuoiug(string("jtztxkqodhhumxkmkxdhgitxnnjgtceddngijlewpeglqcnhivkkrnfk"), 50567, 12783, 2352, 587, 2676, 1294, false, true);
	this->wgmlcgismf(false, 41028, 23217, false, 4945, 83440);
	this->chlendawdkofzpa(true, 19995, 4948, 193, string("jfklewlfaygktwuwmajnvvrndqrewyltuckkjwmgrdsyokr"), 3110, string("zjlhwtyahlbksdyrmjgvfthotxkyrskzfijoeiynktbivxosoveawerbzrjzgvtqqpohscsgxh"));
	this->xduobumgeugeotzfaylmo(14025, 2850, false, string("eppsqofmwikazztdjkdymrfwhfdjqsppjstddzkepvqmntnyyujrnqdzkcgwbfazksljiuuhswoptwuwsogjary"), true);
	this->nxmidvzqsxaxsiti(string("pmcyeurptajcuohmayfevmfwz"), false, 664);
	this->zbcxhbvbcmemocwdediwiye(6912, 34688, 7133, 13146, 9451, 392);
	this->hxpodomjdfdrueztmoyiyrmn(2136, string("mpzndmcdszbkmtnilfohmkipyuwcdzjvumifucygmripchhdwisvhpjzatvmpzagtzcvamzpdilppjpiqnhhvk"), false, 40944, string("oc"), 1472);
	this->hokkairkbghkoutgdxwlwzfd(8221, true, 2160, string("ewbfxpxrerxzqrjtyutznffcaczyptwoidghgqblilmdboanqtopgqoamviorsuoslykjciycxzzpqbnlnzchejlsfovc"), string("gvyobztzojvqqxokmsxsnscbzfhbcqdjbihytizhpngmnvwaximfp"), string("aybapljrqlxpbl"));
	this->iofknjsxro(true, 8591, 1305);
	this->pmdjtbdcfpxzrajakmo(true, string("mczxdldddbmrjsmvgnzmbrjkgrhqgferqrvmmzopqepqiimav"), 40968, 5397, 2189, 1074, true);
	this->kmwballjlqaqwom(1256, 3953, string("chzlghwaqucwbbqscdnbljjugzfbjibildmtiqdifwfhbzdmbmymeqqjxbhwqojnfhapexvoli"), false, 3749);
	this->bnaigdzxmloas(5779, string("qyanc"), 5336, string("ftock"), false);
	this->ojkajiueyltw(9556, 3590, 3772, false, false, 9288, string("vdhkkarsybncswgfkgsaizxdvbtraonsdfralvwjqgfwuvjhsbypbofizkorjgzbmqcfotayjkqwxaugisoytgcylh"), 16976, 71840);
	this->vbgfrjgktxvrfgkbpswhd(2736, 34231, true, 10653, 1573);
	this->jvodkezbdrf(6447, 7250, 34122, 994, 1572, 4916, 4285, false);
	this->crvmwiuqplmoyyooonhdhx(4002, string("tkuqmydudqwykscfjikkha"), 11866, 8404, 2490, 15485, 71219, string("lhszhnxtuunwrmrlybkelrfpqxydbccznxscndhpkqhvlimhlubrsndptwyvsqsbwdlojaggptkcaihsebxjuethuwqgosjq"));
	this->kjtabcmwsqsvrqokldfiooo();
	this->hlwhwszbogkrlenzffhme(string("kctmrqxzdgafmqmlbtbcpjbydsnrmljzkrvummubdnhhgmqszqyivmfcmyyfgwa"));
}










































































































































































































































