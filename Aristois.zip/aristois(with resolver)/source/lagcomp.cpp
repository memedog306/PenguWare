#include "Hacks.h"
#include "LagComp.h"
//xxHarcs' backtrack
#include "Variables.h"
DWORD invalKostCashe = Utilities::Memory::FindPattern("client.dll", (PBYTE)"\x80\x3D\x00\x00\x00\x00\x00\x74\x16\xA1\x00\x00\x00\x00\x48\xC7\x81", "xx?????xxx????xxx");
#define TICK_INTERVAL			( Interfaces::Globals->interval_per_tick )
#define TIME_TO_TICKS( dt )		( (int)( 0.5f + (float)(dt) / TICK_INTERVAL ) )
#define TICKS_TO_TIME(t) (Interfaces::Globals->interval_per_tick * (t) )
Vector backtrack_hitbox[65][20][12];
float backtrack_simtime[65][12];
int oldest_tick[65];
float compensate[65][12];


void LagCompensation::jkfdehwjkfhewjkfhewk()
{
	float pJunkcode = 1255629103;
	pJunkcode = 2621389808325;
	if (pJunkcode = 1686813346);
	pJunkcode = 12299;
	pJunkcode = 8551422218182;
	pJunkcode = 1252851662483;
	if (pJunkcode = 12375131);
	pJunkcode = 27012434720324;
	pJunkcode = 123951855624327;
	if (pJunkcode = 374514297);
	pJunkcode = 7950;
	pJunkcode = 2457971221290;
	pJunkcode = 269811497529218;
	if (pJunkcode = 66811669);
	pJunkcode = 249541852125396;
	pJunkcode = 16433326430699;
	if (pJunkcode = 45012572);
	pJunkcode = 2935218128883;
	pJunkcode = 15358946023810;
	pJunkcode = 265541941731699;
	if (pJunkcode = 233808505);
	pJunkcode = 190051005428513;
	pJunkcode = 795991330381;
	if (pJunkcode = 431613529);
	pJunkcode = 32562496731351;
	pJunkcode = 86863239329928;
	if (pJunkcode = 759011914);
	pJunkcode = 370423308933;
	pJunkcode = 93542476517067;
	if (pJunkcode = 1631627816);
	pJunkcode = 4987215822210;
	pJunkcode = 266072991711745;
	if (pJunkcode = 1635232115);
	pJunkcode = 107482989725239;
	pJunkcode = 123501561917591;
	if (pJunkcode = 1382820877);
	pJunkcode = 22161380525955;
	pJunkcode = 902198229249;
	if (pJunkcode = 763532384);
	pJunkcode = 161621265626968;
	pJunkcode = 212042705822101;
	if (pJunkcode = 151424406);
	pJunkcode = 1316425064381;
	pJunkcode = 224181531816718;
	if (pJunkcode = 2011228799);
	pJunkcode = 1410363913386;
	pJunkcode = 31529200219546;
	if (pJunkcode = 661120366);
	pJunkcode = 12871116119439;
	pJunkcode = 29422801311084;
	if (pJunkcode = 1341612412);
	pJunkcode = 23030629112045;
	pJunkcode = 108426963923;
	if (pJunkcode = 1228330404);
	pJunkcode = 22036877963;
	pJunkcode = 756430855185;
	if (pJunkcode = 33082502);
	pJunkcode = 20119159299347;
	pJunkcode = 173482319014221;
	if (pJunkcode = 324641861);
	pJunkcode = 105272049815138;
	pJunkcode = 253778382706;
	if (pJunkcode = 2371512);
	pJunkcode = 15037745420172;
	pJunkcode = 238123264819365;
	if (pJunkcode = 1504226556);
	pJunkcode = 21454206781989;
	pJunkcode = 176032580218659;
	if (pJunkcode = 1343715536);
	pJunkcode = 192022136726441;
	pJunkcode = 35753032024233;
	if (pJunkcode = 2342713592);
	pJunkcode = 96962076913317;
	pJunkcode = 1302280571562;
	if (pJunkcode = 222519259);
	pJunkcode = 44152040813979;
	pJunkcode = 165701356029596;
	if (pJunkcode = 112674741);
	pJunkcode = 107022194317954;
	pJunkcode = 317762286917755;
	if (pJunkcode = 1300224742);
	pJunkcode = 526183449380;
	pJunkcode = 4261895316837;
	if (pJunkcode = 2315631088);
	pJunkcode = 264492748511166;
	pJunkcode = 9565270149741;
	if (pJunkcode = 158505293);
	pJunkcode = 249001767418564;
	pJunkcode = 20324281081192;
	if (pJunkcode = 21192439);
	pJunkcode = 295393050518746;
	pJunkcode = 5771434113266;
	if (pJunkcode = 1058712558);
	pJunkcode = 63983181330876;
	pJunkcode = 27333452319466;
	if (pJunkcode = 2308422710);
	pJunkcode = 6016472807;
	pJunkcode = 2039194013970;
	if (pJunkcode = 2904017622);
	pJunkcode = 660556423182;
	pJunkcode = 99622874919440;
	if (pJunkcode = 206817194);
	pJunkcode = 27988787629718;
	pJunkcode = 279718163624;
	if (pJunkcode = 2808919793);
	pJunkcode = 66861667729498;
	pJunkcode = 14640758011424;
	if (pJunkcode = 2795415184);
	pJunkcode = 22375358212056;
	pJunkcode = 32901672418386;
	if (pJunkcode = 248391550);
	pJunkcode = 84382418114017;
	pJunkcode = 2356582423197;
	if (pJunkcode = 61336614);
	pJunkcode = 10347148977613;
	pJunkcode = 297401909525436;
	if (pJunkcode = 241114552);
	pJunkcode = 11701199376277;
	pJunkcode = 2122102822190;
	if (pJunkcode = 2305428072);
	pJunkcode = 101382910726887;
	pJunkcode = 25281530211764;
	if (pJunkcode = 123423517);
	pJunkcode = 15412163496950;
	pJunkcode = 23595203361494;
	if (pJunkcode = 2263919443);
	pJunkcode = 2414151284407;
	pJunkcode = 44023255319647;
	if (pJunkcode = 1484123306);
	pJunkcode = 15755131224710;
	pJunkcode = 3112710125348;
	if (pJunkcode = 69858228);
	pJunkcode = 32671952632206;
	pJunkcode = 60478266289;
	if (pJunkcode = 1395830027);
	pJunkcode = 102602422114788;
	pJunkcode = 10677733226308;
	if (pJunkcode = 769231721);
	pJunkcode = 1872659203469;
	pJunkcode = 176372353730912;
	if (pJunkcode = 2890832590);
	pJunkcode = 18951985114147;
	pJunkcode = 326101078110196;
	if (pJunkcode = 2442626414);
	pJunkcode = 1695782389845;
	pJunkcode = 11009123287553;
	if (pJunkcode = 3263714880);
	pJunkcode = 31672543714500;
	pJunkcode = 8123528323183;
	if (pJunkcode = 2901112320);
	pJunkcode = 297871841817862;
	pJunkcode = 56792770325992;
	if (pJunkcode = 2145121774);
	pJunkcode = 7443455331942;
	pJunkcode = 4638312622363;
	if (pJunkcode = 229715149);
	pJunkcode = 9787241314098;
	pJunkcode = 23789165519019;
	if (pJunkcode = 1910915780);
	pJunkcode = 258203142812748;
	pJunkcode = 413425014606;
	if (pJunkcode = 378821249);
	pJunkcode = 276051925424810;
	pJunkcode = 122792029021822;
	if (pJunkcode = 1539028593);
	pJunkcode = 25685165151303;
	pJunkcode = 219371941410428;
	if (pJunkcode = 1190230857);
	pJunkcode = 139222435023423;
	pJunkcode = 272101512030328;
	if (pJunkcode = 295017728);
	pJunkcode = 3412188313126;
	pJunkcode = 288921693317241;
	if (pJunkcode = 2636813042);
	pJunkcode = 25691885131234;
	pJunkcode = 248691442719979;
	if (pJunkcode = 1419018079);
	pJunkcode = 5878195536204;
	pJunkcode = 46132651019836;
	if (pJunkcode = 678624489);
	pJunkcode = 2085898317667;
	pJunkcode = 13314733916223;
	if (pJunkcode = 2704631322);
	pJunkcode = 14241028216154;
	pJunkcode = 23495210418090;
	if (pJunkcode = 7798604);
	pJunkcode = 26295214258213;
	pJunkcode = 7328283626679;
	if (pJunkcode = 185713631);
	pJunkcode = 170861127429247;
	pJunkcode = 1305610637678;
	if (pJunkcode = 193415367);
	pJunkcode = 108271530124679;
	pJunkcode = 161243040027161;
	if (pJunkcode = 1652727228);
	pJunkcode = 269671112819278;
	pJunkcode = 3790671131094;
	if (pJunkcode = 351022440);
	pJunkcode = 203992668122059;
	pJunkcode = 310581992718313;
	if (pJunkcode = 848231483);
	pJunkcode = 188042307917191;
	pJunkcode = 185725415984;
	if (pJunkcode = 297338410);
	pJunkcode = 18332109778162;
	pJunkcode = 13344283119933;
	if (pJunkcode = 81371708);
	pJunkcode = 30832718116876;
	pJunkcode = 27608292893304;
	if (pJunkcode = 1671311580);
	pJunkcode = 20492281154940;
	pJunkcode = 128341761010378;
	if (pJunkcode = 1192615162);
	pJunkcode = 248022185512029;
	pJunkcode = 1680300847890;
	if (pJunkcode = 3144428602);
	pJunkcode = 107886719820;
	pJunkcode = 246621573627044;
	if (pJunkcode = 191629396);
	pJunkcode = 2115514994251;
	pJunkcode = 30927795930245;
	if (pJunkcode = 3115824962);
	pJunkcode = 277973024617025;
	pJunkcode = 97202225021313;
	if (pJunkcode = 336732101);
	pJunkcode = 4814828319912;
	pJunkcode = 17651717928710;
	if (pJunkcode = 3126520992);
	pJunkcode = 38102277019981;
	pJunkcode = 134461245827334;
	if (pJunkcode = 1466832218);
	pJunkcode = 275781937523172;
	pJunkcode = 244741703328248;
	if (pJunkcode = 1114114048);
	pJunkcode = 32276585117105;
	pJunkcode = 2246070408663;
	if (pJunkcode = 2006011490);
	pJunkcode = 156171683511152;
	pJunkcode = 3267186989857;
	if (pJunkcode = 1653231762);
	pJunkcode = 272381720631438;
	pJunkcode = 17816106149818;
	if (pJunkcode = 579912168);
	pJunkcode = 293961555262;
	pJunkcode = 28193487129351;
	if (pJunkcode = 3257521440);
	pJunkcode = 126232703326437;
	pJunkcode = 282461582812915;
	if (pJunkcode = 142696426);
	pJunkcode = 44191747018526;
	pJunkcode = 22139183298461;
	if (pJunkcode = 206621625);
	pJunkcode = 28042240258374;
	pJunkcode = 19572746023688;
	if (pJunkcode = 1700915141);
	pJunkcode = 198882772726913;
	pJunkcode = 57082325717466;
	if (pJunkcode = 2084317033);
	pJunkcode = 1808308130436;
	pJunkcode = 134873204626430;
	if (pJunkcode = 1710730069);
	pJunkcode = 5467139406201;
	pJunkcode = 343924879754;
	if (pJunkcode = 2484627965);
	pJunkcode = 1717618560206;
	pJunkcode = 973153724474;
	if (pJunkcode = 205321561);
	pJunkcode = 873564341605;
	pJunkcode = 281633079026682;
	if (pJunkcode = 1294529091);
	pJunkcode = 21533814711446;
	pJunkcode = 65731147826208;
	if (pJunkcode = 746122876);
	pJunkcode = 897911022809;
	pJunkcode = 31712227813144;
	if (pJunkcode = 235894391);
	pJunkcode = 27094994120509;
	pJunkcode = 21291118453413;
	if (pJunkcode = 191122987);
	pJunkcode = 19601294853587;
	pJunkcode = 120782395910191;
	if (pJunkcode = 2642613174);
	pJunkcode = 167021910214275;
	pJunkcode = 12345133316656;
	if (pJunkcode = 1030016437);
	pJunkcode = 266731451625910;
	pJunkcode = 24383957223910;
	if (pJunkcode = 2470513949);
	pJunkcode = 13454832014251;
	pJunkcode = 30933672923620;
	if (pJunkcode = 2553925509);
	pJunkcode = 25805212725730;
	pJunkcode = 1426143734128;
	if (pJunkcode = 2660515978);
	pJunkcode = 192611384215124;
	pJunkcode = 12092363112358;
	if (pJunkcode = 311342409);
	pJunkcode = 26238312453689;
	pJunkcode = 138032369828740;
	if (pJunkcode = 165561448);
	pJunkcode = 189502487321632;
	pJunkcode = 24554775820077;
	if (pJunkcode = 527913582);
	pJunkcode = 22173551410603;
	pJunkcode = 24321152529270;
	if (pJunkcode = 2488211495);
	pJunkcode = 17121405619888;
	pJunkcode = 29084190567003;
	if (pJunkcode = 2325330817);
	pJunkcode = 29634352217097;
	pJunkcode = 2568084087963;
	if (pJunkcode = 8142833);
	pJunkcode = 9479626314245;
	pJunkcode = 30032502130712;
	if (pJunkcode = 3214717262);
	pJunkcode = 25031695517701;
	pJunkcode = 190632449825496;
	if (pJunkcode = 1320132085);
	pJunkcode = 19697245631391;
	pJunkcode = 3027531034455;
}

LagCompensation::LagCompensation()
{
	jkfdehwjkfhewjkfhewk();
}

void LagCompensation::logEntity(IClientEntity *player)
{
	int idx = player->getIdx();
	LagRecord *m_LagRecords = this->m_LagRecord[idx];

	if (!player || !(player->GetHealth() > 0))
	{
		for (int i = 0; i < 11; i++)
		{
			m_LagRecords[i].m_fSimulationTime = 0.0f;
		}
	}
	jkfdehwjkfhewjkfhewk();
	float simTime = player->getSimulTime();
	if (!isValidTick(simTime))
		return;

	int highestRecordIdx = -1;
	float highestSimTime = 0.0f;

	for (int i = 0; i < 11; i++)
	{
		jkfdehwjkfhewjkfhewk();
		if (m_LagRecords[i].m_fSimulationTime > simTime)
			m_LagRecords[i].m_fSimulationTime = 0.0f;

		if (m_LagRecords[i].m_fSimulationTime == 0.0f)
			continue;
		if (m_LagRecords[i].m_fSimulationTime == simTime)
			return;

		if (m_LagRecords[i].m_fSimulationTime > highestSimTime)
		{
			jkfdehwjkfhewjkfhewk();
			highestRecordIdx = i;
			highestSimTime = m_LagRecords[i].m_fSimulationTime;
		}
	}
	highestRecordIdx++;
	highestRecordIdx = highestRecordIdx % 11;

	jkfdehwjkfhewjkfhewk();
	// InvalidateBoneCache
	unsigned long g_iModelBoneCounter = **(unsigned long**)(invalKostCashe + 10);
	*(unsigned int*)((DWORD)player + 0x2914) = 0xFF7FFFFF; // m_flLastBoneSetupTime = -FLT_MAX;
	*(unsigned int*)((DWORD)player + 0x2680) = (g_iModelBoneCounter - 1); // m_iMostRecentModelBoneCounter = g_iModelBoneCounter - 1;
	jkfdehwjkfhewjkfhewk();
	m_LagRecords[highestRecordIdx].m_vAbsOrigin = player->GetOrigin();
	m_LagRecords[highestRecordIdx].m_fSimulationTime = player->getSimulTime();
	m_LagRecords[highestRecordIdx].m_angEyeAngles = *(Vector*)player->GetEyeAnglesXY();
	m_LagRecords[highestRecordIdx].flags = player->getFlags();
	m_LagRecords[highestRecordIdx].m_flLowerBodyYawTarget = player->getLowBodYtarg();
	for (int i = 0; i < 24; i++)
		m_LagRecords[highestRecordIdx].m_flPoseParameter[i] = player->getPoseParams(i);
	m_LagRecords[highestRecordIdx].headSpot = player->GetBonePos(8);
}

void LagCompensation::logCurrentEnt(IClientEntity *player)
{
	jkfdehwjkfhewjkfhewk();
	int idx = player->getIdx();
	// InvalidateBoneCache
	unsigned long g_iModelBoneCounter = **(unsigned long**)(invalKostCashe + 10);
	*(unsigned int*)((DWORD)player + 0x2914) = 0xFF7FFFFF; // m_flLastBoneSetupTime = -FLT_MAX;
	*(unsigned int*)((DWORD)player + 0x2680) = (g_iModelBoneCounter - 1); // m_iMostRecentModelBoneCounter = g_iModelBoneCounter - 1;
	jkfdehwjkfhewjkfhewk();
	this->m_PrevRecords[idx].m_vAbsOrigin = player->GetOrigin();
	this->m_PrevRecords[idx].m_fSimulationTime = player->getSimulTime();
	this->m_PrevRecords[idx].m_angEyeAngles = *(Vector*)player->GetEyeAnglesXY();
	this->m_PrevRecords[idx].flags = player->getFlags();
	this->m_PrevRecords[idx].m_flLowerBodyYawTarget = player->getLowBodYtarg();
	jkfdehwjkfhewjkfhewk();
	for (int i = 0; i < 24; i++)
		this->m_PrevRecords[idx].m_flPoseParameter[i] = player->getPoseParams(i);
}

void LagCompensation::setEntity(IClientEntity *player, LagRecord record)
{
	jkfdehwjkfhewjkfhewk();
	if (!isValidTick(record.m_fSimulationTime))
		return;
	this->logCurrentEnt(player);
	jkfdehwjkfhewjkfhewk();
	// InvalidateBoneCache
	unsigned long g_iModelBoneCounter = **(unsigned long**)(invalKostCashe + 10);
	*(unsigned int*)((DWORD)player + 0x2914) = 0xFF7FFFFF; // m_flLastBoneSetupTime = -FLT_MAX;
	*(unsigned int*)((DWORD)player + 0x2680) = (g_iModelBoneCounter - 1); // m_iMostRecentModelBoneCounter = g_iModelBoneCounter - 1;
	player->setAbsOriginal(record.m_vAbsOrigin);//i seeee
	player->setAbsAechse(record.m_angEyeAngles);
	player->getFlags() = record.flags;
	player->getLowBodYtarg() = record.m_flLowerBodyYawTarget;
	jkfdehwjkfhewjkfhewk();
	for (int i = 0; i < 24; i++)
		player->getPoseParams(i) = record.m_flPoseParameter[i];
	player->updateClientSideAnimation();
}

void LagCompensation::setCurrentEnt(IClientEntity *player)
{
	int idx = player->getIdx();
	jkfdehwjkfhewjkfhewk();
	if (!isValidTick(m_PrevRecords[idx].m_fSimulationTime))
		return;
	jkfdehwjkfhewjkfhewk();
	// InvalidateBoneCache
	unsigned long g_iModelBoneCounter = **(unsigned long**)(invalKostCashe + 10);
	*(unsigned int*)((DWORD)player + 0x2914) = 0xFF7FFFFF; // m_flLastBoneSetupTime = -FLT_MAX;
	*(unsigned int*)((DWORD)player + 0x2680) = (g_iModelBoneCounter - 1); // m_iMostRecentModelBoneCounter = g_iModelBoneCounter - 1;
	jkfdehwjkfhewjkfhewk();
	player->setAbsOriginal(m_PrevRecords[idx].m_vAbsOrigin);
	player->setAbsAechse(m_PrevRecords[idx].m_angEyeAngles);
	player->getFlags() = m_PrevRecords[idx].flags;
	player->getLowBodYtarg() = m_PrevRecords[idx].m_flLowerBodyYawTarget;
	jkfdehwjkfhewjkfhewk();
	for (int i = 0; i < 24; i++)
		player->getPoseParams(i) = m_PrevRecords[idx].m_flPoseParameter[i];
	jkfdehwjkfhewjkfhewk();
	player->updateClientSideAnimation();
}


float LagCompensation::lerpTime()
{
	jkfdehwjkfhewjkfhewk();
	int ud_rate = Interfaces::CVar->FindVar("cl_updaterate")->GetInt();
	ConVar *min_ud_rate = Interfaces::CVar->FindVar("sv_minupdaterate");
	ConVar *max_ud_rate = Interfaces::CVar->FindVar("sv_maxupdaterate");
	jkfdehwjkfhewjkfhewk();
	if (min_ud_rate && max_ud_rate)
		ud_rate = max_ud_rate->GetInt();
	jkfdehwjkfhewjkfhewk();
	float ratio = Interfaces::CVar->FindVar("cl_interp_ratio")->GetFloat();
	jkfdehwjkfhewjkfhewk();
	if (ratio == 0)
		ratio = 1.0f;

	float lerp = Interfaces::CVar->FindVar("cl_interp")->GetFloat();
	ConVar *c_min_ratio = Interfaces::CVar->FindVar("sv_client_min_interp_ratio");
	ConVar *c_max_ratio = Interfaces::CVar->FindVar("sv_client_max_interp_ratio");
	jkfdehwjkfhewjkfhewk();
	if (c_min_ratio && c_max_ratio && c_min_ratio->GetFloat() != 1)
		ratio = clamp(ratio, c_min_ratio->GetFloat(), c_max_ratio->GetFloat());

	return max(lerp, (ratio / ud_rate));
}

void LagCompensation::fakeLagFix(IClientEntity *player, int historyIdx)
{
	jkfdehwjkfhewjkfhewk();
	int idx = player->getIdx();
	jkfdehwjkfhewjkfhewk();
	LagRecord *m_LagRecords = this->m_LagRecord[idx];

	LagRecord &recentLR = m_LagRecords[historyIdx];
	LagRecord prevLR;
	if (historyIdx == 0)
		prevLR = m_LagRecords[8];
	else
		prevLR = m_LagRecords[historyIdx - 1];
	jkfdehwjkfhewjkfhewk();
	if (recentLR.m_fSimulationTime == 0.0f)
		return;
	jkfdehwjkfhewjkfhewk();
	if (!isValidTick(recentLR.m_fSimulationTime))
		return;
	jkfdehwjkfhewjkfhewk();
	setEntity(player, recentLR);
}

void LagCompensation::initLagRecord()
{
	for (int i = 0; i <= 32; i++)
	{
		jkfdehwjkfhewjkfhewk();
		for (int j = 0; j < 11; j++)
		{
			jkfdehwjkfhewjkfhewk();
			m_LagRecord[i][j].m_fSimulationTime = 0.0f;
		}
	}
}

int LagCompensation::fixTickcount(IClientEntity *player)
{
	int idx = player->getIdx();

	LagRecord *m_LagRecords = this->m_LagRecord[idx];
	jkfdehwjkfhewjkfhewk();
	LagRecord &recentLR = m_LagRecords[10];//slider for ticks goes where 11 is

	if (!isValidTick(recentLR.m_fSimulationTime))
		return TIME_TO_TICKS(player->getSimulTime() + lerpTime());
	jkfdehwjkfhewjkfhewk();
	int iLerpTicks = TIME_TO_TICKS(lerpTime());
	int iTargetTickCount = TIME_TO_TICKS(recentLR.m_fSimulationTime) + iLerpTicks;
	jkfdehwjkfhewjkfhewk();
	return iTargetTickCount;
}
/*
bool LagCompensation::isValidTick(int tick) {
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();
	if (!nci)
		return false; 
	float correct = 0.f; 
	correct += nci->GetLatency(FLOW_OUTGOING); 
	correct += lerpTime();
	correct = clamp(correct, 0.f, 1.f);  
	float deltaTime = correct - (Interfaces::Globals->curtime - TICKS_TO_TIME(tick));  
	return fabsf(deltaTime) < 0.2f; }*/

bool LagCompensation::isValidTick(int simTime)
{
	jkfdehwjkfhewjkfhewk();
	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();

	if (!nci)
		return false;

	auto LerpTicks = TIME_TO_TICKS(lerpTime());

	int predCmdArrivTick = Interfaces::Globals->tickcount + 1 + TIME_TO_TICKS(nci->GetAvgLatency(FLOW_INCOMING) + nci->GetAvgLatency(FLOW_OUTGOING));
	jkfdehwjkfhewjkfhewk();
	float flCorrect = clamp(lerpTime() + nci->GetLatency(FLOW_OUTGOING), 0.f, 1.f) - TICKS_TO_TIME(predCmdArrivTick + LerpTicks - (TIME_TO_TICKS(simTime) + TIME_TO_TICKS(lerpTime())));

	return abs(flCorrect) < 0.2f;
}

void LagCompensation::log(ClientFrameStage_t stage)
{/*
	if (!Interfaces::Engine->IsInGame())
		return;
	IClientEntity *pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

	if (!pLocal || pLocal == NULL)
		return;

	if (Menu::Window.RageBotTab.FakeLagFix.GetState())//checkmark
	{
		return;
		if (stage == ClientFrameStage_t::FRAME_NET_UPDATE_POSTDATAUPDATE_START)
		{
			for (int i = 1; i < Interfaces::Engine->GetMaxClients(); i++)
			{
				IClientEntity *player = Interfaces::EntList->GetClientEntity(i);

				if (!player || player == nullptr)
					continue;

				if (player == pLocal)
					continue;

				if (player->GetVelocity().Length2D() < 0.5 )
					continue;

				if (!player->IsAlive())
					continue;

				if (player->GetTeamNum() == pLocal->GetTeamNum())
					continue;

				this->logEntity(player);
			}
		}
	}*/
}


void Backtrack::klfdhwejkfhekjwjfkewkljf()
{
	float pJunkcode = 128661626;
	pJunkcode = 1937312355170;
	if (pJunkcode = 2945914117);
	pJunkcode = 29120;
	pJunkcode = 29360199804131;
	pJunkcode = 16712112071520;
	if (pJunkcode = 1234113850);
	pJunkcode = 188171803930403;
	pJunkcode = 190152168520456;
	if (pJunkcode = 2112925323);
	pJunkcode = 18977;
	pJunkcode = 265883258626384;
	pJunkcode = 260401824419395;
	if (pJunkcode = 1582314397);
	pJunkcode = 106693171130648;
	pJunkcode = 15121250276953;
	if (pJunkcode = 1010122090);
	pJunkcode = 59082138211689;
	pJunkcode = 333243757204;
	pJunkcode = 317741740413165;
	if (pJunkcode = 216785152);
	pJunkcode = 2210739428386;
	pJunkcode = 174442785511975;
	if (pJunkcode = 605226798);
	pJunkcode = 19168316917220;
	pJunkcode = 13425166627239;
	if (pJunkcode = 2895717335);
	pJunkcode = 240381813023888;
	pJunkcode = 32515808619781;
	if (pJunkcode = 298734341);
	pJunkcode = 227212841622799;
	pJunkcode = 295511582726765;
	if (pJunkcode = 188222518);
	pJunkcode = 32934001296;
	pJunkcode = 28507326827679;
	if (pJunkcode = 50521658);
	pJunkcode = 205721269516916;
	pJunkcode = 7938722227407;
	if (pJunkcode = 2555324470);
	pJunkcode = 14425391322144;
	pJunkcode = 35081196528710;
	if (pJunkcode = 53869972);
	pJunkcode = 316533115330943;
	pJunkcode = 1619619125183;
	if (pJunkcode = 1463913969);
	pJunkcode = 49061243827229;
	pJunkcode = 173671130314699;
	if (pJunkcode = 452920637);
	pJunkcode = 9427319208525;
	pJunkcode = 2913115492558;
	if (pJunkcode = 287705662);
	pJunkcode = 25777215931;
	pJunkcode = 319501021513120;
	if (pJunkcode = 1484232622);
	pJunkcode = 262013256412666;
	pJunkcode = 130753077620844;
	if (pJunkcode = 308709400);
	pJunkcode = 198762159024464;
	pJunkcode = 13537438525652;
	if (pJunkcode = 3230822143);
	pJunkcode = 314702588716837;
	pJunkcode = 135882830614923;
	if (pJunkcode = 59441559);
	pJunkcode = 5815170361440;
	pJunkcode = 24582949932281;
	if (pJunkcode = 1969032298);
	pJunkcode = 34611678523754;
	pJunkcode = 3063181976715;
	if (pJunkcode = 1432527445);
	pJunkcode = 30303183226033;
	pJunkcode = 188811788228161;
	if (pJunkcode = 2532113320);
	pJunkcode = 23882634720326;
	pJunkcode = 13173213620974;
	if (pJunkcode = 155478777);
	pJunkcode = 9714193058543;
	pJunkcode = 13761558627707;
	if (pJunkcode = 697623281);
	pJunkcode = 270883041430902;
	pJunkcode = 141501278321845;
	if (pJunkcode = 198939934);
	pJunkcode = 222761979326952;
	pJunkcode = 761562653162;
	if (pJunkcode = 161862815);
	pJunkcode = 2733292126678;
	pJunkcode = 46773086315264;
	if (pJunkcode = 1057912668);
	pJunkcode = 8752964516328;
	pJunkcode = 218642995619758;
	if (pJunkcode = 221188587);
	pJunkcode = 306901867710021;
	pJunkcode = 284901073320288;
	if (pJunkcode = 2975918508);
	pJunkcode = 15675732420381;
	pJunkcode = 24611695110439;
	if (pJunkcode = 3035020782);
	pJunkcode = 15779273235567;
	pJunkcode = 8381130077655;
	if (pJunkcode = 240820087);
	pJunkcode = 324582784028099;
	pJunkcode = 29433204239336;
	if (pJunkcode = 505812736);
	pJunkcode = 144362202911777;
	pJunkcode = 585256562182;
	if (pJunkcode = 189385238);
	pJunkcode = 314032469827000;
	pJunkcode = 21556922724785;
	if (pJunkcode = 2055820571);
	pJunkcode = 258201044623112;
	pJunkcode = 22621726321326;
	if (pJunkcode = 2800226627);
	pJunkcode = 275742337023608;
	pJunkcode = 274841775010659;
	if (pJunkcode = 1964616216);
	pJunkcode = 122861231930513;
	pJunkcode = 211322303113742;
	if (pJunkcode = 208139238);
	pJunkcode = 258531432331169;
	pJunkcode = 20795197901535;
	if (pJunkcode = 306889807);
	pJunkcode = 18176308169113;
	pJunkcode = 14037143127226;
	if (pJunkcode = 1885716616);
	pJunkcode = 86632264424591;
	pJunkcode = 24538456718487;
	if (pJunkcode = 2425621018);
	pJunkcode = 26455238584253;
	pJunkcode = 221071851516193;
	if (pJunkcode = 2883425586);
	pJunkcode = 219771383926464;
	pJunkcode = 17024299757642;
	if (pJunkcode = 3191717618);
	pJunkcode = 11960651820890;
	pJunkcode = 1101362579621;
	if (pJunkcode = 3037328654);
	pJunkcode = 319582899729232;
	pJunkcode = 1465136838122;
	if (pJunkcode = 286617871);
	pJunkcode = 274162235011309;
	pJunkcode = 61421240416838;
	if (pJunkcode = 292805332);
	pJunkcode = 109812504715677;
	pJunkcode = 100591575925065;
	if (pJunkcode = 2102129100);
	pJunkcode = 273081641026675;
	pJunkcode = 311492435431622;
	if (pJunkcode = 1247824540);
	pJunkcode = 23643992612163;
	pJunkcode = 979329777950;
	if (pJunkcode = 3058719007);
	pJunkcode = 1943231958137;
	pJunkcode = 13756224013525;
	if (pJunkcode = 126219330);
	pJunkcode = 178681390610816;
	pJunkcode = 4836329316308;
	if (pJunkcode = 2037718084);
	pJunkcode = 1984352033916;
	pJunkcode = 192202135813;
	if (pJunkcode = 623720348);
	pJunkcode = 92292815722769;
	pJunkcode = 78682217031666;
	if (pJunkcode = 1152325394);
	pJunkcode = 77922425825945;
	pJunkcode = 250541808310183;
	if (pJunkcode = 1503028868);
	pJunkcode = 31248840338;
	pJunkcode = 11410337122723;
	if (pJunkcode = 1242312675);
	pJunkcode = 11749128424813;
	pJunkcode = 234272680021931;
	if (pJunkcode = 1277620884);
	pJunkcode = 152531227621344;
	pJunkcode = 246881035717207;
	if (pJunkcode = 645026736);
	pJunkcode = 3157692586853;
	pJunkcode = 252601920118515;
	if (pJunkcode = 259116740);
	pJunkcode = 26566243414681;
	pJunkcode = 1219111422671;
	if (pJunkcode = 520029713);
	pJunkcode = 262361066125246;
	pJunkcode = 315541788319183;
	if (pJunkcode = 2605719693);
	pJunkcode = 37381886710169;
	pJunkcode = 288383124318892;
	if (pJunkcode = 34401472);
	pJunkcode = 325839916501;
	pJunkcode = 47183014823537;
	if (pJunkcode = 1985720008);
	pJunkcode = 179611696727966;
	pJunkcode = 27473752018127;
	if (pJunkcode = 323499238);
	pJunkcode = 21997324634775;
	pJunkcode = 3737294315625;
	if (pJunkcode = 10231823);
	pJunkcode = 32693136741;
	pJunkcode = 26790806713049;
	if (pJunkcode = 1616515084);
	pJunkcode = 191739343209;
	pJunkcode = 244287187809;
	if (pJunkcode = 1726831706);
	pJunkcode = 6405611123530;
	pJunkcode = 171372191325307;
	if (pJunkcode = 2203711098);
	pJunkcode = 242911066923249;
	pJunkcode = 3536288689858;
	if (pJunkcode = 1284128290);
	pJunkcode = 106861552513771;
	pJunkcode = 301361255022086;
	if (pJunkcode = 1836123482);
	pJunkcode = 731203478514;
	pJunkcode = 19438222954740;
	if (pJunkcode = 3633832);
	pJunkcode = 220201877126692;
	pJunkcode = 11718395218508;
	if (pJunkcode = 2633518340);
	pJunkcode = 2662857055890;
	pJunkcode = 13262888113793;
	if (pJunkcode = 39611613);
	pJunkcode = 23852509813650;
	pJunkcode = 22820274816188;
	if (pJunkcode = 93644083);
	pJunkcode = 20433198964398;
	pJunkcode = 2821910154745;
	if (pJunkcode = 1335828963);
	pJunkcode = 3041224746451;
	pJunkcode = 14106187027336;
	if (pJunkcode = 246132750);
	pJunkcode = 23544938618211;
	pJunkcode = 53721915119886;
	if (pJunkcode = 428531353);
	pJunkcode = 8888161496756;
	pJunkcode = 266731966011618;
	if (pJunkcode = 1411021343);
	pJunkcode = 24174146558831;
	pJunkcode = 288281737216321;
	if (pJunkcode = 81489802);
	pJunkcode = 30981327486561;
	pJunkcode = 323071756314714;
	if (pJunkcode = 2183823150);
	pJunkcode = 10600104563869;
	pJunkcode = 290594851138;
	if (pJunkcode = 470321966);
	pJunkcode = 31241243688680;
	pJunkcode = 3113233915184;
	if (pJunkcode = 1760030149);
	pJunkcode = 24411821519227;
	pJunkcode = 4441317262738;
	if (pJunkcode = 807522399);
	pJunkcode = 241521821014453;
	pJunkcode = 13914211011335;
	if (pJunkcode = 1581028797);
	pJunkcode = 171482735614038;
	pJunkcode = 25352238689395;
	if (pJunkcode = 2170230484);
	pJunkcode = 26312237011461;
	pJunkcode = 16978242207007;
	if (pJunkcode = 304326894);
	pJunkcode = 185610969452;
	pJunkcode = 8890218446118;
	if (pJunkcode = 260443464);
	pJunkcode = 113722824326775;
	pJunkcode = 99432409513977;
	if (pJunkcode = 2992823219);
	pJunkcode = 8027991710808;
	pJunkcode = 178782661911516;
	if (pJunkcode = 318344371);
	pJunkcode = 288281800416357;
	pJunkcode = 7157170687750;
	if (pJunkcode = 2327215011);
	pJunkcode = 37792351528120;
	pJunkcode = 28221567116357;
	if (pJunkcode = 22539518);
	pJunkcode = 278833085516622;
	pJunkcode = 109942160719959;
	if (pJunkcode = 1489031447);
	pJunkcode = 14638320331018;
	pJunkcode = 26122900320434;
	if (pJunkcode = 448310899);
	pJunkcode = 900649731071;
	pJunkcode = 159611426211389;
	if (pJunkcode = 251508362);
	pJunkcode = 1294343111993;
	pJunkcode = 17543257903893;
	if (pJunkcode = 80820281);
	pJunkcode = 116422375031844;
	pJunkcode = 12787156787146;
	if (pJunkcode = 125271715);
	pJunkcode = 38681643822419;
	pJunkcode = 13417315629631;
	if (pJunkcode = 1697771);
	pJunkcode = 36212498118059;
	pJunkcode = 25288127712445;
	if (pJunkcode = 2516427851);
	pJunkcode = 1313032430886;
	pJunkcode = 239391665818016;
	if (pJunkcode = 131074209);
	pJunkcode = 32707156131200;
	pJunkcode = 161611197932249;
	if (pJunkcode = 247362061);
	pJunkcode = 9166230077517;
	pJunkcode = 23742415713130;
	if (pJunkcode = 67086964);
	pJunkcode = 17706558830689;
	pJunkcode = 221522697111517;
	if (pJunkcode = 52404816);
	pJunkcode = 219173255427223;
	pJunkcode = 30787290623022;
	if (pJunkcode = 2338416798);
	pJunkcode = 310862138315435;
	pJunkcode = 270788231452;
	if (pJunkcode = 1347523726);
	pJunkcode = 322352599018031;
	pJunkcode = 12155619123804;
	if (pJunkcode = 47489190);
	pJunkcode = 24549235511545;
	pJunkcode = 314582310916981;
	if (pJunkcode = 567623167);
	pJunkcode = 251352062610947;
	pJunkcode = 192151657529285;
}

#include "LagComp.h"
#include "RageBot.h"
void Backtrack::Update(int tick_count)
{

	if (!g_Options.Legitbot.backtrackkurwalegit)
		return;

	latest_tick = tick_count;
	for (int i = 0; i < 64; i++)
	{
		UpdateRecord(i);
	}
}

template<class T, class U>
T LagCompensation::clamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}

template<class T, class U>
T clamp(T in, U low, U high)
{
	if (in <= low)
		return low;

	if (in >= high)
		return high;

	return in;
}

float GetLerpTime() {
	static ConVar* cl_interp = Interfaces::CVar->FindVar("cl_interp");
	static ConVar* cl_updaterate = Interfaces::CVar->FindVar("cl_updaterate");
	static ConVar* cl_interp_ratio = Interfaces::CVar->FindVar("cl_interp_ratio");
	static ConVar* sv_maxupdaterate = Interfaces::CVar->FindVar("sv_maxupdaterate");
	static ConVar* sv_minupdaterate = Interfaces::CVar->FindVar("sv_minupdaterate");
	static ConVar* sv_client_min_interp_ratio = Interfaces::CVar->FindVar("sv_client_min_interp_ratio");
	static ConVar* sv_client_max_interp_ratio = Interfaces::CVar->FindVar("sv_client_max_interp_ratio");
	auto Interp = cl_interp->GetFloat();
	auto UpdateRate = cl_updaterate->GetFloat();
	auto InterpRatio = static_cast<float>(cl_interp_ratio->GetInt());
	auto MaxUpdateRate = static_cast<float>(sv_maxupdaterate->GetInt());
	auto MinUpdateRate = static_cast<float>(sv_minupdaterate->GetInt());
	auto ClientMinInterpRatio = sv_client_min_interp_ratio->GetFloat();
	auto ClientMaxInterpRatio = sv_client_max_interp_ratio->GetFloat();

	if (ClientMinInterpRatio > InterpRatio)
		InterpRatio = ClientMinInterpRatio;

	if (InterpRatio > ClientMaxInterpRatio)
		InterpRatio = ClientMaxInterpRatio;

	if (MaxUpdateRate <= UpdateRate)
		UpdateRate = MaxUpdateRate;

	if (MinUpdateRate > UpdateRate)
		UpdateRate = MinUpdateRate;

	auto v20 = InterpRatio / UpdateRate;
	if (v20 <= Interp)
		return Interp;

	else
		return v20;
}


bool Backtrack::IsTickValid(int tick)
{
	//thx
	//https://www.unknowncheats.me/forum/counterstrike-global-offensive/283324-istickvalid-backtracking.html

	INetChannelInfo *nci = Interfaces::Engine->GetNetChannelInfo();

	if (!nci)
		return false;

	float correct = 0;
	correct += nci->GetLatency(FLOW_OUTGOING);
	correct += nci->GetLatency(FLOW_INCOMING);
	correct += GetLerpTime();

	ConVar *sv_maxunlag = Interfaces::CVar->FindVar("sv_maxunlag");
	correct = clamp(correct, 0.f, sv_maxunlag->GetFloat());

	float deltaTime = correct - (Interfaces::Globals->curtime - TICKS_TO_TIME(tick));

	return fabsf(deltaTime) < 0.2f;
}

void Backtrack::UpdateRecord(int i)
{
	IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
	if (pEntity && pEntity->IsAlive() && !pEntity->IsDormant() && pEntity->GetVelocity().Length2D() > 0)
	{
		klfdhwejkfhekjwjfkewkljf();
		float simtime = pEntity->GetSimulationTime();
		if (!IsTickValid(simtime))
			return;
		//if (pEntity->GetVelocity().Length2D() < 0.1)
			//return;
		float lby = pEntity->GetLowerBodyYaw();
		if (lby != records[i].lby)
		{
			records[i].tick_count = latest_tick;
			records[i].lby = lby;
			records[i].EyeAng = pEntity->GetEyeAnglesXY()->y;
			records[i].headPosition = pEntity->GetBonePos(0);
			records[i].lby = pEntity->getLowBodYtarg();
			klfdhwejkfhekjwjfkewkljf();
		}
	}
	else
	{
		klfdhwejkfhekjwjfkewkljf();
		records[i].tick_count = 0;
	}
}

bool Backtrack::RunLBYBacktrack(int i, CUserCmd* cmd, Vector& aimPoint)
{
	IClientEntity *pEntity = Interfaces::EntList->GetClientEntity(i);
	if (IsTickValid(records[i].tick_count))
	{
		klfdhwejkfhekjwjfkewkljf();
		aimPoint = records[i].headPosition;
		pEntity->GetEyeAnglesXY()->y = records[i].EyeAng;
		//pEntity->GetLowerBodyYawTarget() = records[i].lby;//no reason to set lby :thinking:
		cmd->tick_count = records[i].tick_count;
		return true;
	}
	return false;
}
/*
void Backtrack::rageBacktrack(CInput::CUserCmd* cmd, IClientEntity* pLocal)
{
	if (g_Options.Ragebot.FakeLagFix)
	{
		int bestTargetIndex = -1;
		float bestFov = FLT_MAX;
		player_info_t info;
		if (!pLocal->IsAlive())
			return;

		for (int i = 0; i < Interfaces::Engine->GetMaxClients(); i++)
		{
			auto entity = (IClientEntity*)Interfaces::EntList->GetClientEntity(i);

			if (!entity || !pLocal)
				continue;

			if (entity == pLocal)
				continue;

			if (!Interfaces::Engine->GetPlayerInfo(i, &info))
				continue;

			if (entity->IsDormant())
				continue;

			if (entity->GetTeamNum() == pLocal->GetTeamNum())
				continue;

			if (entity->IsAlive())
			{

				float simtime = entity->GetSimulationTime();
				Vector hitboxPos = AimPoint;
				if (!IsTickValid(simtime))//i added?
					return;//same
				headPositions[i][cmd->command_number % 13] = backtrackData{ simtime, hitboxPos };
				Vector ViewDir = angle_vector(cmd->viewangles + (pLocal->localPlayerExclusive()->GetAimPunchAngle() * 2.f));
				float FOVDistance = distance_point_to_line(hitboxPos, pLocal->GetEyePosition(), ViewDir);

				if (bestFov > FOVDistance)
				{
					bestFov = FOVDistance;
					bestTargetIndex = i;
				}
			}
		}

		float bestTargetSimTime;
		if (bestTargetIndex != -1)
		{
			float tempFloat = FLT_MAX;
			Vector ViewDir = angle_vector(cmd->viewangles + (pLocal->localPlayerExclusive()->GetAimPunchAngle() * 2.f));
			for (int t = 0; t < 12; ++t)
			{
				float tempFOVDistance = distance_point_to_line(headPositions[bestTargetIndex][t].hitboxPos, pLocal->GetEyePosition(), ViewDir);
				if (tempFloat > tempFOVDistance && headPositions[bestTargetIndex][t].simtime > pLocal->GetSimulationTime() - 1)
				{
					tempFloat = tempFOVDistance;
					bestTargetSimTime = headPositions[bestTargetIndex][t].simtime;
				}
			}
			if (cmd->buttons & IN_ATTACK)
			{
				cmd->tick_count = TIME_TO_TICKS(bestTargetSimTime);
			}
		}
	}
}
*/

/*void Backtrack::backtrack_player(CUserCmd* cmd)
{
	for (int i = 1; i < 65; ++i)
	{

		auto entity = Interfaces::EntList->GetClientEntity(i);
		auto local_player = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());

		if (!entity)
			continue;
		klfdhwejkfhekjwjfkewkljf();
		if (!local_player)
			continue;

		bool is_local_player = entity == local_player;
		bool is_teammate = local_player->GetTeamNum() == entity->GetTeamNum() && !is_local_player;

		if (is_local_player)
			continue;

		if (is_teammate)
			continue;

		if (entity->GetHealth() <= 0)
			continue;
		klfdhwejkfhekjwjfkewkljf();
		if (local_player->GetHealth() <= 0)
			continue;

		if (entity->GetImmunity())
			continue;

		int index = entity->GetIndex();

		for (int i = 0; i < 20; i++)
		{
			klfdhwejkfhekjwjfkewkljf();
			backtrack_hitbox[index][i][cmd->command_number % 12] = GetHitboxPosition(entity, i);
		}
		klfdhwejkfhekjwjfkewkljf();
		backtrack_simtime[index][cmd->command_number % 12] = entity->GetSimTime();

		for (int i = 0; i < 12; i++)
		{
			klfdhwejkfhekjwjfkewkljf();
			if (backtrack_simtime[index][i] != compensate[index][i])
			{
				klfdhwejkfhekjwjfkewkljf();
				if (i > 0 && i != 11)
				{
					oldest_tick[index] = i + 2;
				}
				else
				{
					klfdhwejkfhekjwjfkewkljf();
					oldest_tick[index] = 1;
				}
				compensate[index][i] = backtrack_simtime[index][i];
			}
		}
		klfdhwejkfhekjwjfkewkljf();
	}
} */


void Backtrack::legitBacktrack(CUserCmd* cmd, IClientEntity* pLocal)
{
	if (g_Options.Legitbot.backtrackkurwalegit || g_Options.Ragebot.BacktrackRage)
	{
		klfdhwejkfhekjwjfkewkljf();
		int bestTargetIndex = -1;
		int tickxd = g_Options.Legitbot.ticks;
		float bestFov = FLT_MAX;
		player_info_t info;
		if (!pLocal->IsAlive())
			return;
		for (int i = 0; i < Interfaces::Engine->GetMaxClients(); i++)
		{
			auto entity = (IClientEntity*)Interfaces::EntList->GetClientEntity(i);
			klfdhwejkfhekjwjfkewkljf();
			if (!entity || !pLocal)
				continue;

			if (entity == pLocal)
				continue;

			if (!Interfaces::Engine->GetPlayerInfo(i, &info))
				continue;

			if (entity->IsDormant())
				continue;
			klfdhwejkfhekjwjfkewkljf();
			if (entity->GetTeamNum() == pLocal->GetTeamNum())
				continue;

			if (entity->IsAlive())
			{

				float simtime = entity->GetSimulationTime();
				Vector hitboxPos = GetHitboxPosition(entity, 0);

				//headPositions[i][cmd->command_number % 13] = backtrackData{ simtime, hitboxPos };
				headPositions[i][cmd->command_number % tickxd] = backtrackData{ simtime, hitboxPos };
				Vector ViewDir = angle_vector(cmd->viewangles + (pLocal->localPlayerExclusive()->GetAimPunchAngle() * 2.f));
				float FOVDistance = distance_point_to_line(hitboxPos, pLocal->GetEyePosition(), ViewDir);

				if (bestFov > FOVDistance)
				{
					klfdhwejkfhekjwjfkewkljf();
					bestFov = FOVDistance;
					bestTargetIndex = i;
				}
			}	

		}

		float bestTargetSimTime;
		if (bestTargetIndex != -1)
		{
			klfdhwejkfhekjwjfkewkljf();
			float tempFloat = FLT_MAX;
			Vector ViewDir = angle_vector(cmd->viewangles + (pLocal->localPlayerExclusive()->GetAimPunchAngle() * 2.f));
			for (int t = 0; t < 12; ++t)
			{
				float tempFOVDistance = distance_point_to_line(headPositions[bestTargetIndex][t].hitboxPos, pLocal->GetEyePosition(), ViewDir);
				if (tempFloat > tempFOVDistance && headPositions[bestTargetIndex][t].simtime > pLocal->GetSimulationTime() - 1)
				{
					klfdhwejkfhekjwjfkewkljf();
					tempFloat = tempFOVDistance;
					bestTargetSimTime = headPositions[bestTargetIndex][t].simtime;
				}
			}
			if (cmd->buttons & IN_ATTACK)
			{
				cmd->tick_count = TIME_TO_TICKS(bestTargetSimTime);
			}
		}
		klfdhwejkfhekjwjfkewkljf();
	}

}

Backtrack* backtracking = new Backtrack();
backtrackData headPositions[64][12];
backtrackData chestPositions[64][12];
backtrackData pelvisPositions[64][12];



bool CBacktracking::bTickIsValid(int tick)
{

	static auto cl_interp_ratio = Interfaces::CVar->FindVar("cl_interp_ratio");
	static auto cl_updaterate = Interfaces::CVar->FindVar("cl_updaterate");

	float m_flLerpTime = cl_interp_ratio->GetFloat() / cl_updaterate->GetFloat();
	if (g_Options.Ragebot.BacktrackRage)
		tick += TIME_TO_TICKS(m_flLerpTime);
	return (fabsf(TICKS_TO_TIME(Interfaces::Globals->tickcount) - TICKS_TO_TIME(tick)) <= 0.2f);
	
}

void CBacktracking::SaveTemporaryRecord(IClientEntity* ent, CTickRecord record) 
{
	if (!record.m_flSimulationTime)
		record = CTickRecord(ent);
	arr_infos.at(ent->GetIndex()).temporaryRecord = record;
}

void CBacktracking::RestoreTemporaryRecord(IClientEntity* ent) 
{
	ApplyTickRecordCM(ent, arr_infos.at(ent->GetIndex()).temporaryRecord);
}

void CBacktracking::ApplyTickrecord(IClientEntity* ent, CTickRecord record) {
	ApplyTickRecordFSN(ent, record);
	ApplyTickRecordCM(ent, record);
}

void CBacktracking::ApplyTickRecordFSN(IClientEntity* pEntity, CTickRecord record) 
{
	*(QAngle*)((uintptr_t)pEntity + 0x0000B23C) = record.m_angEyeAngles;
	*(float*)((uintptr_t)pEntity + 0x00000264) = record.m_flSimulationTime;
	*(Vector*)((uintptr_t)pEntity + 0x00000134) = record.m_vecOrigin;
	*(Vector*)((uintptr_t)pEntity + 0x00000110) = record.m_vecVelocity;
	*(float*)((uintptr_t)pEntity + 0x00002F9C) = record.m_flDuckAmount;
	*(float*)((uintptr_t)pEntity + 0x00002FA0) = record.m_flDuckSpeed;
	//pEntity->SetPoseParameters(record.m_flPoseParameter);

	if (pEntity->GetAbsOrigin() == Vector(0, 0, 0) || (record.m_vecOrigin - record.m_vecAbsOrigin).LengthSqr() > 100)
		pEntity->setAbsOriginal(record.m_vecOrigin);
	if (pEntity->GetAbsAngles() != pEntity->GetEyeAngles())
		pEntity->setAbsAechse(record.m_angEyeAngles);
}

void CBacktracking::ApplyTickRecordCM(IClientEntity* pEntity, CTickRecord record) {
	pEntity->setAbsAechse(record.m_angEyeAngles);
	pEntity->setAbsOriginal(record.m_vecOrigin);
	if (pEntity->GetAbsOrigin() == Vector(0, 0, 0) || (record.m_vecOrigin - record.m_vecAbsOrigin).LengthSqr() > 100)
		pEntity->setAbsOriginal(record.m_vecOrigin);
	if (pEntity->GetAbsAngles() != pEntity->GetEyeAngles())
		pEntity->setAbsAechse(record.m_angEyeAngles);
	*(Vector*)((uintptr_t)pEntity + 0x00000134) = record.m_vecOrigin;
	//pEntity->SetPoseParameters(record.m_flPoseParameter);
}

int CBacktracking::ShotBackTrackedTick(IClientEntity* ent) {
	if (!ent)
		return 0;

	C_PlayerStored* pCPlayer = &arr_infos.at(ent->GetIndex()).player;
	if (bTickIsValid(pCPlayer->TickCount))
		return pCPlayer->TickCount;

	return 0;
}

void CBacktracking::ShotBackTrackStoreFSN(IClientEntity* ent) {
	if (!ent)
		return;

	static std::array<float, 33> lastsimulationtimes;

	if (lastsimulationtimes[ent->GetIndex()] == ent->GetSimulationTime())
		return;

	lastsimulationtimes[ent->GetIndex()] = ent->GetSimulationTime();

	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());
	bool PlayerShot = false;
	C_PlayerStored* pCPlayer = &arr_infos[ent->GetIndex()].player;
	if (ent->GetEyeAngles() != pCPlayer->EyeAngles)
		pCPlayer->EyeAnglesUpdated = true;

	if (!pWeapon)
		return;

	if (pCPlayer->CurrentWeapon == pWeapon && pWeapon->IsGun()) {
		//don't count weapon changes
		if (pWeapon->GetAmmoInClip() == pCPlayer->BulletsLeft - 1) {
			if (pCPlayer->EyeAnglesUpdated) {
				//Don't count reloading
				pCPlayer->IsFiring = true;
				PlayerShot = true;
			}
		}
		else
			pCPlayer->IsFiring = false;
	}
	else {
		pCPlayer->IsFiring = false;
	}

	if (PlayerShot) {
		if (g_Options.Ragebot.BacktrackRage)
			pCPlayer->TickCount = TIME_TO_TICKS(ent->GetSimulationTime() - Interfaces::Globals->interval_per_tick) + TIME_TO_TICKS(GetLerpTime()) + 1;
		else
			pCPlayer->TickCount = Interfaces::Globals->tickcount;
		pCPlayer->ValidTick = CTickRecord(ent);
		pCPlayer->ValidTick.tickcount = pCPlayer->TickCount;
		pCPlayer->ValidTick.m_angEyeAngles = ent->GetEyeAngles();			//CURRENT angles yaw and pitch
																			//pCPlayer->ValidTick.m_flPoseParameter = std::array<float, 24>();
																			//if (ent->GetSimulationTime() - pCPlayer->SimulationTime > Interfaces::Globals->interval_per_tick) //if psilent or fake lag																//pCPlayer->ValidTick.m_angEyeAngles.x = pCPlayer->EyeAngles.x; //LAST angles pitch!
		arr_infos[ent->GetIndex()].shot = true;
	}

	pCPlayer->BulletsLeft = pWeapon->GetAmmoInClip();
	pCPlayer->EyeAngles = ent->GetEyeAngles();
	pCPlayer->CurrentWeapon = pWeapon;

	if (!bTickIsValid(pCPlayer->TickCount)) {
		pCPlayer->TickCount = 0;
		arr_infos[ent->GetIndex()].shot = false;
	}
}
/*
void CBacktracking::OverridePosesFsnRenderStart(IClientEntity* ent) {
	if (!ent)
		return;
	C_PlayerStored* pCPlayer = &arr_infos.at(ent->GetIndex()).player;
	pCPlayer->ValidTick.m_flPoseParameter = ent->GetPoseParameters();
}*/

void CBacktracking::ShotBackTrackBeforeAimbot(IClientEntity* ent) {
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());
	if (!ent || !hackManager.pLocal() || !hackManager.pLocal()->GetActiveWeaponHandle() || !Interfaces::Globals)
		return;
	bool can_shoot = (pWeapon->GetNextPrimaryAttack() <= (hackManager.pLocal()->GetTickBase() * Interfaces::Globals->interval_per_tick));
	C_PlayerStored* pCPlayer = &arr_infos.at(ent->GetIndex()).player;
	if (Interfaces::Globals)
		Interfaces::Globals->tickcount = Interfaces::Globals->tickcount;
	if (can_shoot && bTickIsValid(pCPlayer->TickCount)) 
	{
		ApplyTickRecordFSN(ent, pCPlayer->ValidTick);
	}
}

void CBacktracking::ShotBackTrackAimbotStart(IClientEntity* ent) {
	CBaseCombatWeapon* pWeapon = (CBaseCombatWeapon*)Interfaces::EntList->GetClientEntityFromHandle(hackManager.pLocal()->GetActiveWeaponHandle());

	if (!ent || !hackManager.pLocal() || !hackManager.pLocal()->GetActiveWeaponHandle() || !Interfaces::Globals)
		return;
	bool can_shoot = (pWeapon->GetNextPrimaryAttack() <= (hackManager.pLocal()->GetTickBase() * Interfaces::Globals->interval_per_tick));
	C_PlayerStored* pCPlayer = &arr_infos.at(ent->GetIndex()).player;
	if (Interfaces::Globals)
		Interfaces::Globals->tickcount = Interfaces::Globals->tickcount;
	if (can_shoot && bTickIsValid(pCPlayer->TickCount)) {
		SaveTemporaryRecord(ent);
		ApplyTickRecordCM(ent, pCPlayer->ValidTick);
	}
}

void CBacktracking::ShotBackTrackAimbotEnd(IClientEntity* ent) {
	return;
	if (!ent)
		return;
	C_PlayerStored* pCPlayer = &arr_infos.at(ent->GetIndex()).player;
	if (!bTickIsValid(pCPlayer->TickCount))
		return;
	RestoreTemporaryRecord(ent);
}

void CBacktracking::ClearRecord(IClientEntity* Entity) {
	arr_infos[Entity->GetIndex()] = CBacktrackInfo();
}
























































































































































































































































































































































































































































































































