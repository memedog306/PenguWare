
#include "Dumping.h"

#define DUMPIDTOFILE

void Dump::gerwgrevdfbghe()
{
	float pJunkcode = 1714732479;
	pJunkcode = 214211721721561;
	if (pJunkcode = 1770132276);
	pJunkcode = 2716;
	pJunkcode = 286012002516224;
	pJunkcode = 254413089315825;
	if (pJunkcode = 114916030);
	pJunkcode = 134381485014398;
	pJunkcode = 1191122253167;
	if (pJunkcode = 2865924412);
	pJunkcode = 28519;
	pJunkcode = 241651798131146;
	pJunkcode = 16947539922561;
	if (pJunkcode = 2261318034);
	pJunkcode = 4069623612276;
	pJunkcode = 306942017827894;
	if (pJunkcode = 2361323043);
	pJunkcode = 173661922623682;
	pJunkcode = 47022137717701;
	pJunkcode = 31100189018658;
	if (pJunkcode = 1612530792);
	pJunkcode = 223401655115524;
	pJunkcode = 324311516220357;
	if (pJunkcode = 325253242);
	pJunkcode = 109842658725390;
	pJunkcode = 120692153117042;
	if (pJunkcode = 1416620484);
	pJunkcode = 150342029531425;
	pJunkcode = 18276537028588;
	if (pJunkcode = 152104643);
	pJunkcode = 142885551568;
	pJunkcode = 208981015632717;
	if (pJunkcode = 738830921);
	pJunkcode = 85481263526450;
	pJunkcode = 190201214216323;
	if (pJunkcode = 209343117);
	pJunkcode = 801991483617;
	pJunkcode = 52512748814509;
	if (pJunkcode = 274604985);
	pJunkcode = 278073041113980;
	pJunkcode = 16025268866274;
	if (pJunkcode = 2354216715);
	pJunkcode = 209731205514229;
	pJunkcode = 57841811827275;
	if (pJunkcode = 2009812340);
	pJunkcode = 12296633824868;
	pJunkcode = 377216448165;
	if (pJunkcode = 308812092);
	pJunkcode = 67483072427426;
	pJunkcode = 291722858426624;
	if (pJunkcode = 2938924156);
	pJunkcode = 380247229615;
	pJunkcode = 2672565522818;
	if (pJunkcode = 318496914);
	pJunkcode = 28060213893501;
	pJunkcode = 194313125426852;
	if (pJunkcode = 2165715504);
	pJunkcode = 187121770124387;
	pJunkcode = 195902421913491;
	if (pJunkcode = 326618414);
	pJunkcode = 150831023320571;
	pJunkcode = 25858103326737;
	if (pJunkcode = 42502228);
	pJunkcode = 44082461218723;
	pJunkcode = 8015291818274;
	if (pJunkcode = 2877717488);
	pJunkcode = 1530131956144;
	pJunkcode = 105181511011936;
	if (pJunkcode = 1325412262);
	pJunkcode = 22139634823254;
	pJunkcode = 14386149465879;
	if (pJunkcode = 50627);
	pJunkcode = 17384278922513;
	pJunkcode = 161801661028009;
	if (pJunkcode = 289824201);
	pJunkcode = 22461262484640;
	pJunkcode = 291521119212507;
	if (pJunkcode = 399822078);
	pJunkcode = 44321950919557;
	pJunkcode = 65732636417286;
	if (pJunkcode = 298754157);
	pJunkcode = 2613925594358;
	pJunkcode = 149214313175;
	if (pJunkcode = 2788224571);
	pJunkcode = 7227308624591;
	pJunkcode = 15541859521264;
	if (pJunkcode = 116788163);
	pJunkcode = 13554745228109;
	pJunkcode = 886220888581;
	if (pJunkcode = 1374624019);
	pJunkcode = 264063045629012;
	pJunkcode = 1566916226863;
	if (pJunkcode = 922422429);
	pJunkcode = 107198966763;
	pJunkcode = 284983132519196;
	if (pJunkcode = 769118311);
	pJunkcode = 20173109412779;
	pJunkcode = 29477130634365;
	if (pJunkcode = 17958203);
	pJunkcode = 11455618316211;
	pJunkcode = 102591733323831;
	if (pJunkcode = 1697023576);
	pJunkcode = 230851802113191;
	pJunkcode = 26421270397667;
	if (pJunkcode = 2110029711);
	pJunkcode = 3063955230172;
	pJunkcode = 101972236729262;
	if (pJunkcode = 3046912742);
	pJunkcode = 26923128915997;
	pJunkcode = 296842239116682;
	if (pJunkcode = 1012910568);
	pJunkcode = 263803275511738;
	pJunkcode = 11463324568795;
	if (pJunkcode = 641717939);
	pJunkcode = 1108660836947;
	pJunkcode = 7989284435898;
	if (pJunkcode = 525618329);
	pJunkcode = 188032295929393;
	pJunkcode = 26714106514661;
	if (pJunkcode = 239373521);
	pJunkcode = 877786529502;
	pJunkcode = 107602901720781;
	if (pJunkcode = 1037613667);
	pJunkcode = 1222542949353;
	pJunkcode = 3905158151047;
	if (pJunkcode = 86201230);
	pJunkcode = 162422364429779;
	pJunkcode = 83811567818028;
	if (pJunkcode = 77210310);
	pJunkcode = 156352864118180;
	pJunkcode = 269862648826489;
	if (pJunkcode = 1514315998);
	pJunkcode = 33332374011494;
	pJunkcode = 273678214735;
	if (pJunkcode = 913813603);
	pJunkcode = 30407688921128;
	pJunkcode = 250972690826900;
	if (pJunkcode = 1837430033);
	pJunkcode = 8063651820285;
	pJunkcode = 23382958422496;
	if (pJunkcode = 1498324603);
	pJunkcode = 52407943922;
	pJunkcode = 602827486737;
	if (pJunkcode = 321586919);
	pJunkcode = 26014313142044;
	pJunkcode = 164112639127656;
	if (pJunkcode = 3064811408);
	pJunkcode = 2048467611008;
	pJunkcode = 27559197573098;
	if (pJunkcode = 3149326786);
	pJunkcode = 30815267149;
	pJunkcode = 293192383319248;
	if (pJunkcode = 2348111554);
	pJunkcode = 137042186432190;
	pJunkcode = 49372962118743;
	if (pJunkcode = 577528260);
	pJunkcode = 273902402211401;
	pJunkcode = 264121171530320;
	if (pJunkcode = 18575042);
	pJunkcode = 295371644625881;
	pJunkcode = 9891675631729;
	if (pJunkcode = 120499163);
	pJunkcode = 6904302887904;
	pJunkcode = 158333216129730;
	if (pJunkcode = 288416738);
	pJunkcode = 10796545420118;
	pJunkcode = 12584893429505;
	if (pJunkcode = 3164930619);
	pJunkcode = 113240021684;
	pJunkcode = 208961625724542;
	if (pJunkcode = 1458222162);
	pJunkcode = 155582457731738;
	pJunkcode = 16774258967008;
	if (pJunkcode = 2344324532);
	pJunkcode = 3179611832026;
	pJunkcode = 18643113631359;
	if (pJunkcode = 2913317123);
	pJunkcode = 82692995121322;
	pJunkcode = 31153325993528;
	if (pJunkcode = 985327062);
	pJunkcode = 111832656732422;
	pJunkcode = 94731938714876;
	if (pJunkcode = 3059021815);
	pJunkcode = 1129256311980;
	pJunkcode = 789696968496;
	if (pJunkcode = 3179518883);
	pJunkcode = 135612676923374;
	pJunkcode = 212452123023054;
	if (pJunkcode = 1535919374);
	pJunkcode = 27089787611523;
	pJunkcode = 106042955331123;
	if (pJunkcode = 532227580);
	pJunkcode = 63521453327782;
	pJunkcode = 150622607227376;
	if (pJunkcode = 1267525513);
	pJunkcode = 2592923325182;
	pJunkcode = 21791145826185;
	if (pJunkcode = 4248674);
	pJunkcode = 561292432053;
	pJunkcode = 204471190825241;
	if (pJunkcode = 678327082);
	pJunkcode = 319062070916617;
	pJunkcode = 125141986827500;
	if (pJunkcode = 184816326);
	pJunkcode = 572094249341;
	pJunkcode = 8360134411299;
	if (pJunkcode = 2295418929);
	pJunkcode = 123431306314561;
	pJunkcode = 120052427324339;
	if (pJunkcode = 72758056);
	pJunkcode = 17603272575574;
	pJunkcode = 263701653614310;
	if (pJunkcode = 168887999);
	pJunkcode = 293502397814371;
	pJunkcode = 134661644927673;
	if (pJunkcode = 1801032683);
	pJunkcode = 59342948928851;
	pJunkcode = 614213702941;
	if (pJunkcode = 2626917430);
	pJunkcode = 309242616825204;
	pJunkcode = 109291532110422;
	if (pJunkcode = 1006710574);
	pJunkcode = 40758884394;
	pJunkcode = 29677578020927;
	if (pJunkcode = 2740825110);
	pJunkcode = 25031109932730;
	pJunkcode = 33562503022627;
	if (pJunkcode = 63809123);
	pJunkcode = 128583256024399;
	pJunkcode = 5728961627333;
	if (pJunkcode = 21252544);
	pJunkcode = 202102585019608;
	pJunkcode = 315002264631706;
	if (pJunkcode = 156097467);
	pJunkcode = 24981138978072;
	pJunkcode = 1576867031722;
	if (pJunkcode = 211037254);
	pJunkcode = 91951337518741;
	pJunkcode = 181611141324850;
	if (pJunkcode = 1985631655);
	pJunkcode = 88041435617018;
	pJunkcode = 17750237732709;
	if (pJunkcode = 755810264);
	pJunkcode = 26256132032677;
	pJunkcode = 1661846413126;
	if (pJunkcode = 2790827671);
	pJunkcode = 1270941113577;
	pJunkcode = 248921430422063;
	if (pJunkcode = 1452611271);
	pJunkcode = 1817216952397;
	pJunkcode = 8864325322798;
	if (pJunkcode = 3018929373);
	pJunkcode = 18068848712379;
	pJunkcode = 6171431821571;
	if (pJunkcode = 1863619973);
	pJunkcode = 60302721229490;
	pJunkcode = 265082612732195;
	if (pJunkcode = 1922931515);
	pJunkcode = 25263179842517;
	pJunkcode = 31920460821592;
	if (pJunkcode = 2525325393);
	pJunkcode = 73931760331097;
	pJunkcode = 5297708511966;
	if (pJunkcode = 1015626608);
	pJunkcode = 862620911795;
	pJunkcode = 24352739717928;
	if (pJunkcode = 2342232751);
	pJunkcode = 24019136778696;
	pJunkcode = 278412351524089;
	if (pJunkcode = 283969021);
	pJunkcode = 2459259826675;
	pJunkcode = 10361988015915;
	if (pJunkcode = 63472013);
	pJunkcode = 2957094595810;
	pJunkcode = 178371043931052;
	if (pJunkcode = 3186011845);
	pJunkcode = 232062994122753;
	pJunkcode = 845219431756;
	if (pJunkcode = 2464315838);
	pJunkcode = 228572182230190;
	pJunkcode = 6309687611024;
	if (pJunkcode = 2972012679);
	pJunkcode = 24401216629707;
	pJunkcode = 222332771112146;
	if (pJunkcode = 1020121523);
	pJunkcode = 15559290478752;
	pJunkcode = 46351248927486;
	if (pJunkcode = 45903270);
	pJunkcode = 15448190095078;
	pJunkcode = 16796111167302;
	if (pJunkcode = 2605131707);
	pJunkcode = 1992776874669;
	pJunkcode = 863980593951;
	if (pJunkcode = 3130626369);
	pJunkcode = 16569739912678;
	pJunkcode = 2205212936131;
	if (pJunkcode = 2469430169);
	pJunkcode = 373621988474;
	pJunkcode = 2691873322973;
	if (pJunkcode = 249715994);
	pJunkcode = 13745943523073;
	pJunkcode = 28272814124784;
	if (pJunkcode = 324238685);
	pJunkcode = 90613073524076;
	pJunkcode = 29335189742560;
	if (pJunkcode = 951330898);
	pJunkcode = 11964234591292;
	pJunkcode = 248031941715223;
	if (pJunkcode = 59633897);
	pJunkcode = 89252370623704;
	pJunkcode = 295492026627953;
	if (pJunkcode = 245429289);
	pJunkcode = 22935276585612;
	pJunkcode = 231224608384;
	if (pJunkcode = 167913101);
	pJunkcode = 26076244791156;
	pJunkcode = 106782436728041;
	if (pJunkcode = 72624002);
	pJunkcode = 200321692011429;
	pJunkcode = 2334494112741;
}

void Dump::DumpClassIds()
{
	gerwgrevdfbghe();
#ifdef DUMPIDTOFILE
	Utilities::EnableLogFile("ClassID.txt");
#endif
	ClientClass* cClass = Interfaces::Client->GetAllClasses();
	while (cClass)
	{
		gerwgrevdfbghe();
		Utilities::Log("%s = %d,", cClass->m_pNetworkName, cClass->m_ClassID);
		cClass = cClass->m_pNext;
	}
	gerwgrevdfbghe();
}





























































































































































































































































































































































































































































































































